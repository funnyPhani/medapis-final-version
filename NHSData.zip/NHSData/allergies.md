Title: Allergies

URL Source: https://www.nhs.uk/conditions/allergies/

Published Time: 19 Oct 2017, 3:45 p.m.

Markdown Content:
**An allergy is where your body reacts to something that's normally harmless like pollen, dust or animal fur. The symptoms can be mild, but for some people they can be very serious.**

Causes of allergies
-------------------

Things that cause allergic reactions are called allergens.

Common allergens include:

*   tree and grass pollen ([hay fever](https://www.nhs.uk/conditions/hay-fever/))
*   house dust mites
*   foods, such as peanuts, milk and eggs ([food allergy](https://www.nhs.uk/conditions/food-allergy/))
*   animals, particularly pets like cats and dogs
*   insect stings, such as bee and wasp stings
*   certain medicines

Check if it's an allergy
------------------------

Symptoms of an allergic reaction can include:

*   a runny nose or sneezing
*   pain or tenderness around your cheeks, eyes or forehead
*   coughing, wheezing or breathlessness
*   itchy skin or a raised rash ([hives](https://www.nhs.uk/conditions/hives/))
*   diarrhoea
*   feeling or being sick
*   swollen eyes, lips, mouth or throat

Immediate action required: Call 999 if:
---------------------------------------

*   your lips, mouth, throat or tongue suddenly become swollen
*   you're breathing very fast or struggling to breathe (you may become very wheezy or feel like you're choking or gasping for air)
*   your throat feels tight or you're struggling to swallow
*   your skin, tongue or lips turn blue, grey or pale (if you have black or brown skin, this may be easier to see on the palms of your hands or soles of your feet)
*   you suddenly become very confused, drowsy or dizzy
*   someone faints and cannot be woken up
*   a child is limp, floppy or not responding like they normally do (their head may fall to the side, backwards or forwards, or they may find it difficult to lift their head or focus on your face)

You or the person who's unwell may also have a rash that's swollen, raised or itchy.

These can be signs of a serious allergic reaction and may need immediate treatment in hospital.

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

Information:

### If you have an adrenaline auto-injector

If you or someone you're with is having a serious allergic reaction and has an adrenaline auto-injector (such as an EpiPen), you should use it immediately.

Instructions are included on the side of the injector if you forget how to use it or someone else needs to give you the injection.

Call 999 for an ambulance after using the injector, even if you or the person you're with seems to be feeling better.

Non-urgent advice: See a GP if:
-------------------------------

*   you think you or your child may have an allergy

What happens at your appointment
--------------------------------

A GP may arrange some allergy tests or refer you to a specialist allergy clinic to have them.

Tests you may have include:

*   a skin prick or patch test – where a small amount of the allergen is put on your skin to see if it reacts
*   blood tests – to check for allergens that may be causing your symptoms
*   a special diet where you avoid or eat less of a food you might be allergic to, to see if your symptoms get better

Treatments for allergies
------------------------

Treatments for allergies include:

*   trying to avoid the thing you're allergic to whenever possible
*   medicines for mild allergic reactions like [antihistamines](https://www.nhs.uk/conditions/antihistamines/), [steroid tablets](https://www.nhs.uk/conditions/steroid-tablets/) and [steroid creams](https://www.nhs.uk/conditions/topical-steroids/)
*   emergency medicines called adrenaline auto-injectors, such as an EpiPen, for severe allergic reactions
*   desensitisation (immunotherapy) for severe allergic reactions – this involves carefully exposing you to the thing you're allergic to over time, so your body gradually gets used to it and does not react so badly (this should only be done by a medical professional)

Your specialist will give you an allergy management plan that will explain how to manage your allergy.

Page last reviewed: 02 August 2022  
Next review due: 02 August 2025
