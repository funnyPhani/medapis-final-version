Title: Glue ear

URL Source: https://www.nhs.uk/conditions/glue-ear/

Published Time: 23 Oct 2017, 3:39 p.m.

Markdown Content:
**Glue ear is where the middle part of the ear canal fills up with fluid. This can cause temporary hearing loss. It usually clears up within 3 months, but see a GP about any hearing problems.**

Check if it's glue ear
----------------------

The most common symptom of glue ear is temporary hearing loss. It can affect both ears at the same time.

Other symptoms may include:

*   [earache or ear pain](https://www.nhs.uk/conditions/earache/)
*   hearing sounds like ringing or buzzing ([tinnitus](https://www.nhs.uk/conditions/tinnitus/))
*   problems with balance

If glue ear lasts a long time, it can affect a child's speech development and progress at school.

Glue ear is much more common in children, but adults with glue ear have the same symptoms.

Other conditions that cause ear pain

Non-urgent advice: See a GP if:
-------------------------------

Your child has signs of a hearing problem, such as:

*   speaking loudly
*   being difficult to understand
*   asking people to repeat what they say
*   asking for the TV or music to be turned up loud
*   strugglng to hear people far away
*   becoming easily distracted when people are talking
*   finding it hard to concentrate or seeming tired and irritable because it's harder for them to listen

What happens at your appointment
--------------------------------

A GP should be able to tell if it's glue ear by looking for fluid inside the ear.

They'll use a small scope with a light and magnifying glass. This should not be painful.

If your child has had glue ear for more than 3 months, they may be referred to a specialist for [hearing tests](https://www.nhs.uk/conditions/hearing-tests-children/).

Hearing tests can help find out how severe any hearing loss is and what's causing it.

Treatment for glue ear from a GP
--------------------------------

Glue ear is not always treated. The GP will usually wait to see if the symptoms get better on their own.

This is because there's no effective medicine for glue ear, and it often clears up on its own within 3 months.

Your child may be monitored for up to a year in case their symptoms change or get worse.

The GP may suggest trying a treatment called autoinflation while waiting for symptoms to improve. Autoinflation can help fluid in the ear to drain.

It's done by either:

*   blowing up a special balloon using 1 nostril at a time
*   swallowing while holding the nostrils closed

As autoinflation has to be done several times a day, it's not usually recommended for children under 3 years old.

Antibiotics may be prescribed if glue ear causes an [ear infection](https://www.nhs.uk/conditions/ear-infections/).

### Hospital treatment

Your child may be referred to a specialist in hospital if:

*   glue ear symptoms are affecting their learning and development
*   they already had severe hearing loss before glue ear
*   they have [Down's syndrome](https://www.nhs.uk/conditions/downs-syndrome/) or a [cleft lip and palate](https://www.nhs.uk/conditions/cleft-lip-and-palate/), as glue ear is less likely to get better by itself

The 2 main treatments are temporary [hearing aids](https://www.nhs.uk/conditions/hearing-aids-and-implants/) or grommets (small tubes implanted in the ear).

Occasionally, surgery may be recommended to remove some glands at the back of the nose (adenoids). This is known as an [adenoidectomy](https://www.nhs.uk/conditions/adenoidectomy/).

The specialist in hospital will help you decide on the best treatment option.

#### Grommets for glue ear

A grommet is a small tube that's placed in your child's ear during surgery. It drains fluid away and keeps the eardrum open.

The grommet should fall out naturally within 6 to 12 months as your child's ear gets better.

If your child needs grommets, you might find these links useful:

*   [Great Ormond Street Hospital (GOSH): treatment of glue ear with grommets](https://www.gosh.nhs.uk/conditions-and-treatments/procedures-and-treatments/treatment-glue-ear-grommets/)
*   [National Deaf Children's Society (NDCS): Harvey gets grommets](https://www.ndcs.org.uk/documents-and-resources/harvey-gets-grommets/)

Video: What is glue ear?
------------------------

This animation explains in detail what glue ear is, what causes it and how it's treated.

Media last reviewed: 1 April 2024  
Media review due: 1 April 2027

Page last reviewed: 05 June 2023  
Next review due: 05 June 2026
