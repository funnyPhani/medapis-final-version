Title: Dyspraxia in adults

URL Source: https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia-in-adults/

Published Time: 18 Oct 2017, 11:05 a.m.

Markdown Content:
**Dyspraxia, also known as developmental co-ordination disorder (DCD), is a common disorder that affects movement and co-ordination.**

Dyspraxia does not affect your intelligence. It can affect your co-ordination skills – such as tasks requiring balance, playing sports or learning to drive a car. Dyspraxia can also affect your fine motor skills, such as writing or using small objects.

This page focuses on dyspraxia in adults. You can also read about [childhood dyspraxia](https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia/).

Symptoms of dyspraxia
---------------------

Symptoms of dyspraxia can vary between individuals and may change over time. You may find routine tasks difficult.

If you have dyspraxia it may affect:

*   your co-ordination, balance and movement
*   how you learn new skills, think, and remember information at work and home
*   your daily living skills, such as dressing or preparing meals
*   your ability to write, type, draw and grasp small objects
*   how you function in social situations
*   how you deal with your emotions
*   time management, planning and personal organisation skills

Dyspraxia should not be confused with other disorders affecting movement, such as [cerebral palsy](https://www.nhs.uk/conditions/cerebral-palsy/) and [stroke](https://www.nhs.uk/conditions/stroke/). It can affect people of all intellectual abilities.

When to see a GP
----------------

See a GP if you think you may have undiagnosed dyspraxia or problems with your co-ordination. It's a good idea to keep a diary of your symptoms.

The GP may refer you to a [physiotherapist](https://www.nhs.uk/conditions/physiotherapy/) or an [occupational therapist](https://www.nhs.uk/conditions/occupational-therapy/) for tests. They'll assess your movements and how your symptoms are affecting you before making a diagnosis.

If you have dyspraxia, you may also have other conditions, such as:

*   [attention deficit hyperactivity disorder (ADHD)](https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd/)
*   [dyslexia](https://www.nhs.uk/conditions/dyslexia/)
*   [autism spectrum disorder](https://www.nhs.uk/conditions/autism/)
*   difficulty learning or understanding maths (dyscalculia)
*   [depression](https://www.nhs.uk/conditions/clinical-depression/) or [anxiety](https://www.nhs.uk/conditions/generalised-anxiety-disorder/)

Causes of dyspraxia
-------------------

It's not known what causes dyspraxia. You may be at a higher risk of developing it if you were born prematurely.

Dyspraxia is more common in men and often runs in families.

Treatment for dyspraxia
-----------------------

There is no cure for dyspraxia but there are therapies that can help with daily living, such as:

*   [occupational therapy](https://www.nhs.uk/conditions/occupational-therapy/) – to help you find practical ways to remain independent and manage everyday tasks such as writing or preparing food
*   [cognitive behavioural therapy (CBT)](https://www.nhs.uk/conditions/cognitive-behavioural-therapy-cbt/) – a talking therapy that can help you manage your problems by changing the way you think and behave

It may also help if you:

*   [keep fit](https://www.nhs.uk/live-well/exercise/) – you may find regular exercise helps with co-ordination, reduces feelings of fatigue and prevents you gaining weight
*   learn how to use a computer or laptop if writing by hand is difficult
*   use a calendar, diary or app to improve your organisation
*   learn how to talk positively about your challenges and how you've overcome them
*   get support from programmes such as [Access to Work](https://www.gov.uk/access-to-work/overview) from Jobcentre Plus

Support for people living with dyspraxia
----------------------------------------

Dyspraxia can have a big effect on your life. It might help to talk to others with dyspraxia.

[Dyspraxic Adults](http://www.dyspraxicadults.org.uk/forums/) is an online forum for adults with dyspraxia to chat, discuss challenges and share experiences.

Page last reviewed: 01 October 2020  
Next review due: 01 October 2023
