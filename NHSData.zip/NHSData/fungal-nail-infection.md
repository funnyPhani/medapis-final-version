Title: Fungal nail infection

URL Source: https://www.nhs.uk/conditions/fungal-nail-infection/

Published Time: 19 Oct 2017, 5:04 p.m.

Markdown Content:
Check if you have a fungal nail infection
-----------------------------------------

Fungal nail infections usually affect your toenails, but you can sometimes get them on your fingernails, too.

![Image 1: The nail on a person's big toe. The sides of the nail are yellow and the edge that's trimmed is flaky. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/DA5M57.width-320_uwfKeTQ.jpg)

Fungal nail infections usually start at the edge of the nail.

![Image 2: A person's toenails that are thickened and discoloured. The person has medium brown skin and their toenails are covered in white patches.](https://assets.nhs.uk/nhsuk-cms/images/C0509911-Fungal_nail_infection_1.width-320.png)

The infection often spreads to all of the nail, making it thicker and turning it white or yellow.

![Image 3: The toes on the left foot of a person with white skin. The right side of their big toenail is yellow and there's a piece missing from the tip of the nail.](https://assets.nhs.uk/nhsuk-cms/images/C28R5H.width-320_zA0ImfH.jpg)

The nail may become brittle and crumbly. The whole nail can sometimes lift off, causing the skin around it to become swollen and painful.

A pharmacist can help with fungal nail infections
-------------------------------------------------

Speak to a pharmacist if the look of your nail bothers you or it's painful.

They may suggest trying an antifungal nail medicine that you brush onto the affected nail.

These medicines:

*   should be used daily or weekly, depending on the type
*   need to be used for 6 to 12 months – it may take several months before you start to see an improvement
*   may not be suitable for you if you're under 18, pregnant or breastfeeding

The infection is cured when you see healthy nail growing back at the base.

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Important: Diabetes or a weakened immune system
-----------------------------------------------

See a foot specialist (podiatrist) if you have diabetes or a weakened immune system and get a fungal nail infection. Left untreated, an infection can cause serious health problems.

Non-urgent advice: See a GP if:
-------------------------------

You have a fungal nail infection that:

*   is severe and treatment has not worked
*   has spread to other nails

Treatment for a fungal nail infection
-------------------------------------

A GP can prescribe antifungal tablets if you have a fungal nail infection and treatments from a pharmacy have not worked.

But before they give you tablets, they should take a sample of your nail and have it tested, to find out what type of infection you have.

You may also need to have a blood test before starting treatment and during treatment to check your liver is working properly.

You may need to take antifungal tablets for up to 6 months.

The tablets can have side effects, including:

*   headaches
*   an itchy rash
*   stomach ache
*   feeling sick and diarrhoea

You cannot take antifungal tablets if you have certain conditions, such as liver or kidney disease. They may also not be suitable if you're pregnant or breastfeeding.

Badly infected nails sometimes need to be removed. It's a small procedure done while the area is numbed (under [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/)).

Preventing fungal nail infections
---------------------------------

You can get a fungal nail infection if your feet are constantly warm and damp.

You're more likely to get an infection if you wear trainers for a long time and have hot, sweaty feet.

There are some things you can do to help prevent fungal nail infections.

### Do

*   treat [athlete's foot](https://www.nhs.uk/conditions/athletes-foot/) as soon as possible to avoid it spreading to nails
    
*   keep your nails short
    
*   keep your feet clean and dry
    
*   wear clean socks every day
    
*   wear flip-flops in showers at the gym or pool
    
*   wear shoes that fit well and do not have high heels or narrow toes
    
*   throw out old shoes
    

### Don’t

*   do not wear shoes that make your feet hot and sweaty
    
*   do not share towels
    
*   do not wear other people's shoes
    
*   do not share nail clippers or scissors
    

Page last reviewed: 27 March 2024  
Next review due: 27 March 2027
