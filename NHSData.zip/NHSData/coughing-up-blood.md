Title: Coughing up blood

URL Source: https://www.nhs.uk/conditions/coughing-up-blood/

Published Time: 18 Oct 2017, 2:18 p.m.

Markdown Content:
Coughing up blood (blood in phlegm)
-----------------------------------

**Coughing up blood can have lots of possible causes. It could be something serious so it's important to get it checked.**

Causes of coughing up blood
---------------------------

Common causes of coughing up blood include:

*   a long-lasting or severe cough
*   a lung or airway infection like a [chest infection](https://www.nhs.uk/conditions/chest-infection/), [pneumonia](https://www.nhs.uk/conditions/pneumonia/) or [bronchitis](https://www.nhs.uk/conditions/bronchitis/)
*   a problem with your airways that causes them to widen and produce more mucus ([bronchiectasis](https://www.nhs.uk/conditions/bronchiectasis/))

Sometimes coughing up blood can be a sign of something more serious like a [blood clot](https://www.nhs.uk/conditions/blood-clots/) or [lung cancer](https://www.nhs.uk/conditions/lung-cancer/).

It's important to get it checked out as soon as possible.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you've coughed up a few small spots, flecks or streaks of blood, or noticed blood in your phlegm or handkerchief

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Immediate action required: Call 999 or go to A&E immediately if:
----------------------------------------------------------------

*   you're coughing up more than just a few spots or streaks of blood
*   you're coughing up blood and finding it hard to breathe, have a very fast heartbeat or have pain in your chest or upper back

These symptoms could be a sign of a more serious problem like a blood clot in the lungs ([pulmonary embolism](https://www.nhs.uk/conditions/pulmonary-embolism/)).

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Page last reviewed: 29 October 2021  
Next review due: 29 October 2024
