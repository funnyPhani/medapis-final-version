Title: Gum disease

URL Source: https://www.nhs.uk/conditions/gum-disease/

Published Time: 3 Oct 2018, 9:03 p.m.

Markdown Content:
**Gum disease is where the gums become red, swollen and sore, and bleed. It's very common, but it's important to get it checked by a dentist.**

Check if you have gum disease
-----------------------------

Symptoms of gum disease include:

*   your gums bleeding when you brush your teeth, floss or eat hard foods such as apples
*   your gums becoming swollen, red and sore

Gum disease can lead to:

*   bad breath and a bad taste in the mouth
*   your gums shrinking
*   your teeth becoming loose or falling out

Non-urgent advice: See a dentist if:
------------------------------------

*   your gums bleed when you brush your teeth or eat hard foods
*   your gums are painful and swollen
*   you have bad breath
*   your child has sore, bleeding gums

Urgent advice: Ask for an urgent dentist appointment if:
--------------------------------------------------------

You or your child have gum disease and other symptoms such as:

*   very sore and swollen gums
*   teeth becoming loose or falling out
*   ulcers or red patches in your mouth
*   a lump in your mouth or on your lip

Information:

### To see a dentist in an emergency or out of hours:

*   call your dentist – if they're closed, their answerphone may tell you what to do

### If you do not have a dentist or cannot get an emergency appointment:

*   call 111 – they can advise you what to do
*   [find a dentist near you](https://www.nhs.uk/service-search/Dentists/LocationSearch/3) – ask if you can have an emergency appointment

You may have to pay for your appointment.

Read more about [NHS dental charges](https://www.nhs.uk/nhs-services/dentists/understanding-nhs-dental-charges/).

### Important: Get regular dental check-ups

You should have regular dental check-ups even if you do not have any problems. See a dentist if you have not had a check-up for 2 years (or 1 year if you're under 18).

Treatments for gum disease
--------------------------

Your dentist will check your teeth and gums, and may take some [X-rays](https://www.nhs.uk/conditions/x-ray/) to check your teeth and jaw bone.

They may also refer you to a specialist for further tests and treatment.

How gum disease is treated depends on how severe it is.

In the early stages, your dentist will:

*   give you advice about keeping your teeth clean, such as using interdental brushes
*   advise you to stop smoking, if you smoke
*   advise you to get your teeth cleaned by a hygienist

If your gum disease is serious, you may need:

*   to have deep cleaning under the gums
*   antibiotics
*   to have some teeth removed
*   gum surgery

Cost of dental treatment

NHS dental treatment is free for some people, including:

*   children aged under 18, or under 19 and in full-time education
*   if you're pregnant or have had a baby in the past 12 months
*   if you're on some benefits, including Income Support or Universal Credit

If you do not qualify for free dental care, you will usually have to pay for treatment.

[Find out more about dental costs](https://www.nhs.uk/nhs-services/dentists/)

Preventing gum disease
----------------------

Gum disease is caused by a build-up of plaque on the teeth.

If you do not remove plaque from your teeth by brushing and cleaning in between them regularly, it builds up and irritates your gums.

There are things you can do yourself to prevent gum disease.

### Do

*   brush your teeth with fluoride toothpaste at least twice a day – spit after brushing, do not rinse
    
*   clean in between your teeth every day using floss or interdental brushes
    
*   replace your toothbrush every 1 to 3 months
    
*   see a dentist and dental hygienist for regular check-ups, especially if you're pregnant or have type 2 diabetes
    

### Don’t

*   do not use mouthwash straight after brushing your teeth
    
*   do not smoke
    

Page last reviewed: 18 February 2022  
Next review due: 18 February 2025
