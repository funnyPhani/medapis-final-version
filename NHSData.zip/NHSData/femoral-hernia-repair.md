Title: Femoral hernia repair

URL Source: https://www.nhs.uk/conditions/femoral-hernia-repair/

Published Time: 6 Aug 2018, 3:33 p.m.

Markdown Content:
**A hernia occurs when an internal part of the body pushes through a weakness in the muscle or surrounding tissue wall.**

Your muscles are usually strong and tight enough to keep your intestines and organs in place, but a hernia can develop if there are any weak spots.

A femoral hernia is a rare type of hernia.

Femoral hernias sometimes appear as a painful lump in the inner upper part of the thigh or groin. The lump can often be pushed back in or disappears when you lie down. Coughing or straining may make the lump appear.

For information on other types of [hernia](https://www.nhs.uk/conditions/hernia/), see:

*   [inguinal hernia](https://www.nhs.uk/conditions/inguinal-hernia-repair/)
*   [hiatus hernia](https://www.nhs.uk/conditions/hiatus-hernia/)
*   [umbilical hernia](https://www.nhs.uk/conditions/umbilical-hernia-repair/)

Causes of a femoral hernia
--------------------------

A femoral hernia usually occurs when fatty tissue or a part of your bowel pokes through into your groin at the top of your inner thigh.

It pushes through a weak spot in the surrounding muscle wall (abdominal wall) into an area called the femoral canal.

Unlike inguinal hernias, femoral hernias are far more common in women, particularly older women. This is because of the wider shape of the female pelvis. Femoral hernias are rare in children.

Femoral hernias can sometimes appear suddenly because of strain on the tummy, such as:

*   straining on the toilet if you have [constipation](https://www.nhs.uk/conditions/constipation/)
*   carrying and pushing heavy loads

They've also been linked to [obesity](https://www.nhs.uk/conditions/obesity/) and having a persistent, heavy cough.

When surgery is needed
----------------------

Femoral hernias can be repaired using surgery to push the bulge back into place and strengthen the weakness in the wall of the tummy.

Unlike some other types of hernia, treatment of femoral hernias is almost always recommended straight away because there's a higher risk of complications developing in these cases.

Complications that can develop as a result of a femoral hernia include:

*   **obstruction** – where a section of the bowel becomes stuck in the femoral canal, causing nausea, vomiting and stomach pain, as well as a painful lump in the groin
*   **strangulation** – where a section of bowel becomes trapped and its blood supply is cut off; this requires emergency surgery within hours to release the trapped tissue and restore its blood supply, so it does not die

Surgery gets rid of the hernia and prevents any serious complications, although there's a chance of it returning after the operation.

What happens during surgery
---------------------------

There are 2 ways a femoral hernia repair can be performed:

*   **open surgery** – where a cut is made to allow the surgeon to push the lump back into your tummy
*   **laparoscopy (keyhole) surgery** – a less invasive, but more difficult, technique where several smaller cuts are made, allowing the surgeon to use various instruments to repair the hernia

There are advantages and disadvantages to both methods. The type of surgery you have depends on which method suits you and your surgeon's experience.

You should be able to go home the same day or the day after surgery. It's important to follow the hospital's instructions on how to look after yourself. This includes eating a good diet to avoid constipation, caring for the wound and not straining yourself too soon.

Most people make a full recovery from femoral hernia repair within 6 weeks, although many people can return to driving, work and light activities within 2 weeks.

Read more about:

*   [how femoral hernia repair is performed](https://www.nhs.uk/conditions/femoral-hernia-repair/what-happens/)
*   [recovering from femoral hernia repair](https://www.nhs.uk/conditions/femoral-hernia-repair/recovery/)

Risks of femoral hernia repair
------------------------------

Femoral hernia repair is a routine operation with very few risks, although in a small number of cases, the hernia returns after the operation.

Other uncommon complications of femoral hernia repair include:

*   developing a lump under the wound
*   difficulty passing urine
*   injury or narrowing of the femoral vein (which passes through the femoral canal)
*   injury to the bowel
*   temporary weakness of the leg
*   injury to the nerves, causing pain or numbness in the groin area

Complications are more likely in older people or those with existing conditions.

Page last reviewed: 11 January 2022  
Next review due: 11 January 2025
