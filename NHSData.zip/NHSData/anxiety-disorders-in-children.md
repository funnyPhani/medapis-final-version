Title: Anxiety disorders in children

URL Source: https://www.nhs.uk/mental-health/children-and-young-adults/advice-for-parents/anxiety-disorders-in-children/

Published Time: 4 Feb 2021, 12:39 p.m.

Markdown Content:
**It's normal for children and young people to feel worried or anxious from time to time – such as when they're starting school or nursery, or moving to a new area.**

But for some children and young people, anxiety affects their behaviour and thoughts every day, interfering with their school, home and social life.

This is when you may need professional help to tackle it.

Symptoms of anxiety in children and young people
------------------------------------------------

Signs to look out for in your child are:

*   finding it hard to concentrate
*   not sleeping, or waking in the night with bad dreams
*   eating more or less than usual
*   quickly getting angry or irritable, and being out of control during outbursts
*   constantly worrying or having negative thoughts
*   feeling tense and fidgety, or using the toilet often
*   always crying
*   being clingy, especially in young children
*   complaining of tummy aches and feeling unwell

[Separation anxiety](https://www.nhs.uk/conditions/baby/babys-development/behaviour/separation-anxiety/) is common in younger children, whereas older children and teenagers tend to worry more about school or have [social anxiety](https://www.nhs.uk/mental-health/conditions/social-anxiety/).

How to help your anxious child
------------------------------

If your child is having problems with anxiety, there's plenty you can do to help.

Above all, it's important to talk to your child about their anxiety or worries.

Read more about [anxiety in children](https://www.nhs.uk/mental-health/children-and-young-adults/advice-for-parents/anxiety-in-children/), including self-help tips for parents of anxious children.

Many children at different ages may have anxieties that will go away after a while, with your reassurance.

However, it's a good idea to seek professional help or reassurance yourself if your child is constantly anxious and:

*   it's not getting better, or is getting worse
*   self-help is not working
*   it's affecting their school or family life, or their friendships

Where to get help for anxiety
-----------------------------

An appointment with a GP is a good place to start.

You can talk to the GP on your own or with your child, or your child might be able to have an appointment without you.

If the GP thinks your child could have an anxiety disorder, they may refer them for an assessment with your local [children and young people's mental health services (CYPMHS)](https://www.nhs.uk/mental-health/children-and-young-adults/mental-health-support/mental-health-services/).

Specialist CYPMHS are NHS mental health services that focus on the needs of children and young people. CYPMHS workers are trained to help young people with a wide range of problems, including anxiety.

If your child does not want to see a doctor, they may be able to get help directly from a local youth counselling service. For more information, visit [Youth Access](http://www.youthaccess.org.uk/). You may also want to talk to your child's school about their anxiety and any support they need.

Treatments for anxiety disorders in children and young people
-------------------------------------------------------------

The type of treatment offered will depend on your child's age and the cause of their anxiety.

*   Counselling can help your child understand what's making them anxious and allow them to work through the situation.
*   [Cognitive behavioural therapy (CBT)](https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/talking-therapies-and-counselling/cognitive-behavioural-therapy-cbt/overview/) is a talking therapy that can help your child manage their anxiety by changing the way they think and behave. This could be in person or as self-help online.
*   Anxiety medicines may be offered to your child if their anxiety is severe or does not get better with talking therapies. They're usually only prescribed by doctors who specialise in children and young people's mental health.

What causes anxiety disorders in children and young people
----------------------------------------------------------

Having a close family member with anxiety may increase your child's chance of having it too.

Children can also pick up anxious behaviour from being around anxious people.

Some children develop anxiety after stressful events, such as:

*   frequently moving house or school
*   parents fighting or arguing
*   the death of a close relative or friend
*   becoming seriously ill or getting injured in an accident
*   school-related issues like exams or bullying
*   being abused or neglected

Children with [attention deficit hyperactivity disorder (ADHD)](https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd/) and [autistic spectrum disorders](https://www.nhs.uk/conditions/autism/) are more likely to have problems with anxiety.

More information and support
----------------------------

### For you

*   [Mental Health Foundation: The Anxious Child – a booklet for parents and carers](https://www.mentalhealth.org.uk/explore-mental-health/publications/anxious-child)
*   [Royal College of Psychiatrists: worries and anxieties – for parents and carers](https://www.rcpsych.ac.uk/mental-health/parents-and-young-people/information-for-parents-and-carers/worries-and-anxieties-for-parents)
*   [YoungMinds Parents Helpline](https://www.youngminds.org.uk/parent/parents-helpline-and-webchat/) – call 0808 802 5544 (Monday to Friday 9.30am to 4pm, free for mobiles and landlines)

### For your child

*   [YoungMinds: anxiety](https://www.youngminds.org.uk/young-person/mental-health-conditions/anxiety)
*   [Childline: coping with anxiety](https://www.childline.org.uk/info-advice/your-feelings/anxiety-stress-panic/anxiety/)
