Title: Aspergillosis

URL Source: https://www.nhs.uk/conditions/aspergillosis/

Published Time: 20 Oct 2017, 1:45 p.m.

Markdown Content:
How you get aspergillosis
-------------------------

Aspergillosis is usually caused by breathing in tiny bits of mould.

The mould is found in lots of places, including:

*   soil, compost and rotting leaves
*   plants, trees and crops
*   dust
*   bedding
*   damp buildings
*   air conditioning systems

You cannot catch aspergillosis from someone else or from animals.

Information:

Aspergillosis is rare in healthy people. Most people who breathe in the mould do not get ill.

You're usually only at risk of aspergillosis if you have:

*   a lung condition, such as asthma, cystic fibrosis or chronic obstructive pulmonary disease (COPD)
*   a weakened immune system (for example, if you've had an organ transplant or are having chemotherapy)
*   had tuberculosis (TB) in the past
*   had severe flu or COVID-19 and needed help breathing with artificial ventilation

Symptoms of aspergillosis
-------------------------

Symptoms of aspergillosis include:

*   shortness of breath
*   a cough – you may cough up blood or lumps of mucus
*   wheezing
*   a high temperature
*   losing weight without trying
*   feeling tired

If you already have a lung condition, your symptoms may get worse.

Non-urgent advice: See a GP if:
-------------------------------

*   you have a cough for more than 3 weeks
*   you have a lung condition that's getting worse or harder to control with your usual treatment
*   you have a weakened immune system and symptoms of aspergillosis

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you cough up blood

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

What happens at your appointment
--------------------------------

It can be difficult to diagnose aspergillosis and may take time. A GP will check your symptoms are not being caused by something else, like a chest infection.

If they're not sure what's causing your symptoms, they may refer you to a specialist for tests such as:

*   X-rays and scans
*   blood tests or tests on a sample of mucus
*   [allergy](https://www.nhs.uk/conditions/allergies/) tests
*   a bronchoscopy (where a thin, flexible tube with a camera at the end is used to look inside your lungs)

Treatment for aspergillosis
---------------------------

Treatment for aspergillosis depends on the type you have and usually aims to help control the symptoms.

If it's not treated or well controlled, there's a risk it could damage your lungs.

Treatments for common types of aspergillosis
| Common types | Treatment |
| --- | --- |
| Allergic bronchopulmonary aspergillosis or ABPA (an allergy to aspergillus mould)
 | [Steroid tablets](https://www.nhs.uk/conditions/steroid-tablets/) and [antifungal tablets](https://www.nhs.uk/conditions/antifungal-medicines/)

 |
| Chronic pulmonary aspergillosis or CPA (a long-term lung infection)

 | Long-term (possibly lifelong) treatment with antifungal tablets

 |
| Aspergilloma (a ball of mould in the lungs, often linked to CPA)

 | Surgery to remove the ball if it's causing symptoms, often after antifungal treatment

 |
| Invasive pulmonary aspergillus or IPA (a life-threatening infection in people with a weakened immune system)

 | Antifungal medicine given directly into a vein in hospital

 |

Preventing aspergillosis
------------------------

It's almost impossible to completely avoid aspergillus mould.

But there are things you can do to lower your chances of getting aspergillosis if you have a lung condition or weakened immune system.

### Do

*   try to avoid places where aspergillus mould is often found, such as compost heaps and piles of dead leaves
    
*   open your windows several times a day to air your rooms, especially if you're cooking or using a shower
    
*   wear a face mask in dusty places or when you're gardening
    
*   consider using a dehumidifier and an air purifier with a HEPA filter at home
    
*   keep your house heated at between 18 and 21C in cold weather
    

### Don’t

*   do not dry your laundry in your bedroom or living areas, if possible – ideally dry it outside or in a tumble dryer
    
*   do not open your windows if there's construction work or digging outside
    

Page last reviewed: 19 April 2024  
Next review due: 19 April 2027
