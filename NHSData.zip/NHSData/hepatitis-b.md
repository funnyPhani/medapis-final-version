Title: Hepatitis B

URL Source: https://www.nhs.uk/conditions/hepatitis-b/

Published Time: 23 Oct 2017, 1:49 p.m.

Markdown Content:
**Hepatitis B is a liver infection that is spread through blood, semen and vaginal fluids. The chance of getting it in the UK is low. There's a vaccine if you're at high risk or travelling to a country where it's more common.**

The infection usually only lasts for a few months, but some people can have hepatitis B long-term.

How you can get hepatitis B
---------------------------

Hepatitis B is caused by a virus that is spread through blood, semen and vaginal fluids.

You can get hepatitis B from:

*   having vaginal, anal or oral sex without using a condom or dam
*   injecting drugs using shared needles
*   being injured by a used needle
*   having a tattoo or piercing with unsterilised equipment
*   having a blood transfusion in a country that does not check blood for hepatitis B. Blood transfusions in the UK are checked for hepatitis B.

If you're pregnant and have hepatitis B, you can also pass it onto your baby during pregnancy or birth.

### Hepatitis B from infected blood before 1996

If you received a blood transfusion or blood products before 1996, there's a chance you may have been infected with hepatitis B.

Information:

If you have contracted hepatitis B from infected blood help and support is available.

Find out more about [support for people who may have been affected by infected blood](https://www.nhs.uk/conditions/support-for-people-who-may-have-been-affected-by-infected-blood/).

### Higher risk areas

The risk of getting hepatitis B is higher in some parts of the world, including:

*   Africa
*   Asia
*   the Middle East
*   parts of South America and eastern Europe

How to prevent hepatitis B
--------------------------

### Hepatitis B vaccination

Vaccination is the best way to prevent hepatitis B. In the UK, the hepatitis B vaccine is given to babies as part of the [6-in-1 vaccine](https://www.nhs.uk/vaccinations/6-in-1-vaccine/).

Babies born to mothers with hepatitis B are given additional vaccinations at birth, 4, weeks and 1 year, to reduce the risk of them getting the infection.

Adults only need to get the [hepatitis B vaccine](https://www.nhs.uk/vaccinations/hepatitis-b-vaccine/) if they're at high risk, for example:

*   you are travelling to a high-risk country – you may have to pay for a hepatitis B vaccine for travel
*   you have liver or kidney disease
*   you have HIV
*   your job puts you at risk of infection – for example, you're a healthcare worker or work in a prison

Your employer should organise your vaccination if your job puts you at risk.

If you're travelling abroad, get advice from a travel clinic, GP, nurse or pharmacist before you go.

### Other ways to reduce your risk

To help protect yourself from hepatitis B you should also:

*   use a condom or dam when having vaginal, anal, or oral sex
*   avoid sharing razors, toothbrushes, and needles with others

Check if you have hepatitis B
-----------------------------

Symptoms of hepatitis B infection include:

*   a high temperature
*   tiredness
*   pain in your upper tummy
*   feeling sick or being sick
*   patches of raised skin that may be itchy ([hives](https://www.nhs.uk/conditions/hives/))
*   yellowing of the skin and whites of the eyes ([jaundice](https://www.nhs.uk/conditions/jaundice/))

The infection usually lasts for 1 to 3 months and most people either have no symptoms or mild symptoms. If the infection lasts longer than 6 months it is called chronic hepatitis B.

Non-urgent advice: See a GP if:
-------------------------------

*   you think you might have hepatitis B

Treatments for hepatitis B
--------------------------

Hepatitis B usually clears up on its own without treatment. You may be offered medicine to help with the symptoms, such as painkillers or medicines to stop you feeling sick.

Your GP will refer you to see a liver specialist who will check how well your liver is working.

If hepatitis B lasts for over 6 months it is called long-term (chronic) hepatitis B.

It is usually treated with antivirals and medicine to help relieve symptoms such as itchiness, pain, and sickness. You will also need to see a liver specialist for regular check-ups.

Living with hepatitis B
-----------------------

As well as medical treatments, there are some things you can when you have hepatitis B to help ease the symptoms and stop the infection spreading to others.

### Do

*   rest and stay hydrated
    
*   take painkillers like paracetamol and [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) – ask your doctor for advice about how much paracetamol you should take as you may not be able to take a normal dose
    
*   keep your room well ventilated, wear loose clothing and avoid hot showers and baths if you feel itchy
    

### Don’t

*   do not drink alcohol
    
*   do not have sex without a condom or dam
    
*   do not share razors, toothbrushes or needles with others
    

Complications of hepatitis B
----------------------------

Most people do not have any lasting problems after having a hepatitis B infection.

If left untreated, chronic hepatitis B can cause liver damage ([cirrhosis](https://www.nhs.uk/conditions/cirrhosis/)) and increase your risk of getting [liver cancer](https://www.nhs.uk/conditions/liver-cancer/).

It is important to take any medicine you have been prescribed and go for regular check-ups to make sure your liver is working properly.

Page last reviewed: 01 July 2022  
Next review due: 01 July 2025
