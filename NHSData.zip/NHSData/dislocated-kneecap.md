Title: Dislocated kneecap

URL Source: https://www.nhs.uk/conditions/dislocated-kneecap/

Published Time: 18 Oct 2017, 10:34 a.m.

Markdown Content:
**A dislocated kneecap is where your kneecap (patella) moves out of place. It is usually caused by an injury to the knee. Get medical advice as soon as possible if you think you have a dislocated kneecap.**

Urgent advice: Get help from NHS 111 if:
----------------------------------------

You've injured your knee and:

*   it's very painful
*   it's swollen or bruised
*   you cannot stand up or move your knee
*   you think your kneecap dislocated and then moved back into place

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Go to A&E if:
----------------------------------------

You've injured your knee and:

*   your knee has changed shape
*   it becomes very swollen very quickly
*   you felt a pop or snap in your knee
*   you can see bone sticking out of your skin
*   it's bleeding heavily

Call 999 if you're unable to get to A&E.

[Find your local A&E](https://www.nhs.uk/Service-Search/other-services/Accident%20and%20emergency%20services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

While you are waiting for medical help
--------------------------------------

If you think you have dislocated your kneecap, there are some things you can do while waiting for treatment:

### Do

*   keep the knee still
    
*   keep the knee supported with padding while sitting or lying down – you can use rolled up clothing, towels or cushions
    

### Don’t

*   do not raise the affected knee
    
*   do not try to stand or walk on the affected leg
    
*   do not try to put the kneecap back into place yourself
    

Treatment for a dislocated kneecap
----------------------------------

A dislocated kneecap often moves back into place by itself.

Even if it does, you will still need to get it checked by a doctor. You will usually need [X-rays](https://www.nhs.uk/conditions/x-ray/) or an [MRI scan](https://www.nhs.uk/conditions/mri-scan/).

If your kneecap does not go back into place by itself, a doctor may have to move it back. You will be given a [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) and may be offered a sedative so you do not feel any pain.

Surgery may be needed if you have badly damaged your knee. Some people may also need surgery to stop the knee from dislocating again.

After treatment, you'll need to go to follow-up appointments to check your knee is healing properly.

Recovering from a dislocated kneecap
------------------------------------

It can take 6 to 8 weeks to fully recover from a dislocated kneecap, but you will usually be able to walk using the affected knee within a few days.

You may be given a knee support to wear for 2 weeks to help it heal. If walking is painful, using a crutch may help.

Your doctor or a physiotherapist will show you knee exercises that you should do regularly to help speed up your recovery.

### Things you can do to help your recovery

There are some things you can do to help with the recovery of a dislocated kneecap.

#### Do

*   take painkillers like [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to help with pain
    
*   keep your knee and lower leg slightly raised and supported when resting to reduce swelling
    
*   do knee exercises throughout the day to stop your knee getting stiff
    
*   stay as active as you can
    

#### Don’t

*   do not twist your knee
    
*   do not play sport until your knee has fully recovered its usual strength – your doctor or physiotherapist should be able to give you advice about this
    

Page last reviewed: 25 January 2023  
Next review due: 25 January 2026
