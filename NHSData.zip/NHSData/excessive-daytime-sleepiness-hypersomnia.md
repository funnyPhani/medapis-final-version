Title: Excessive daytime sleepiness (hypersomnia)

URL Source: https://www.nhs.uk/conditions/excessive-daytime-sleepiness-hypersomnia/

Published Time: 18 Oct 2017, 11:43 a.m.

Markdown Content:
**Excessive daytime sleepiness (hypersomnia) is a condition where people fall asleep repeatedly during the day.**

Check if it's hypersomnia
-------------------------

Excessive daytime sleepiness (hypersomnia) is different from feeling tired all the time.

If you have hypersomnia, you may:

*   regularly nap during the day
*   fall asleep during the day
*   still sleep for long hours at night

Non-urgent advice: See a GP if:
-------------------------------

*   you often fall asleep during the day
*   sleepiness is affecting your life

What happens at your appointment
--------------------------------

To find out why you're sleeping excessively, a GP might:

*   ask you about possible causes of your sleepiness, such as mental or physical health problems, or any medicines you may be taking
*   suggest you keep a diary of when you sleep
*   refer you to a doctor who specialises in sleep disorders

Treatment for excessive sleepiness will depend on what's causing it. It may include medicine to help keep you awake.

Causes of hypersomnia
---------------------

Sometimes other conditions may be related to excessive sleepiness (hypersomnia). These conditions can have additional symptoms.

Some medicines, drinking too much alcohol and taking drugs can also cause excessive daytime sleepiness.

### Idiopathic hypersomnia

Idiopathic hypersomnia is when someone sleeps for long periods and wakes up feeling confused or irritable (known as sleep inertia) and not refreshed.

There's no known cause for idiopathic hypersomnia.

Things you can try to help your sleeping habits
-----------------------------------------------

Changing your sleep habits may not cure excessive daytime sleepiness (hypersomnia), but it might help you feel better.

Try to:

*   go to bed at the same time every night
*   avoid drinking alcohol and caffeine
*   create a peaceful sleeping environment
*   if possible, avoid medicines that can cause drowsiness
*   avoid working late into the night

It might also help to talk to your family and friends about your excessive daytime sleepiness so they're aware of it.

Information:

If you're diagnosed with hypersomnia you'll need to tell the Driver and Vehicle Licensing Agency (DVLA) and you may not be able to drive.

[Find out about the rules on excessive sleepiness and driving from GOV.UK](https://www.gov.uk/excessive-sleepiness-and-driving)

Page last reviewed: 23 June 2023  
Next review due: 23 June 2026
