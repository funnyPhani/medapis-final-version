Title: Cholera

URL Source: https://www.nhs.uk/conditions/cholera/

Published Time: 19 Apr 2018, 10:41 a.m.

Markdown Content:
Check if you could be at risk of cholera
----------------------------------------

Cholera is not found in the UK. It's mostly found in parts of Africa and Asia, in places without a clean water supply.

You can get cholera from:

*   drinking unclean water
*   eating food (particularly shellfish) that's been in unclean water
*   eating food that's been handled by an infected person

The risk of getting it while travelling is very small.

How to avoid cholera while travelling
-------------------------------------

There are things you can do to help avoid getting ill while travelling in areas where cholera is found.

### Do

*   wash your hands with soap and water regularly, especially after using the toilet and before preparing food or eating
    
*   only drink bottled water or tap water that's been boiled
    
*   brush your teeth using bottled or boiled water
    

### Don’t

*   do not eat uncooked fruit and vegetables (including salads) that you have not washed with bottled or boiled water and prepared yourself
    
*   do not eat shellfish and seafood
    
*   do not have ice in your drinks
    

### Vaccination for cholera

There's a vaccine for cholera, but most people do not need it.

It's usually only recommended if either:

*   you're travelling to an area where cholera is common and you'll be visiting remote places without access to medical care
*   you're an aid or disaster relief worker going to an area where a cholera outbreak is likely

The vaccine is given as a drink. For adults, 2 doses (given 1 to 6 weeks apart) can provide protection for up to 2 years.

You need to have had both doses at least a week before travelling.

Information:

If you need the cholera vaccine, you may be able to get it for free on the NHS. Ask at your GP surgery.

Symptoms of cholera
-------------------

Symptoms of cholera include:

*   having lots of watery diarrhoea
*   feeling sick or being sick
*   tummy pain
*   [dehydration](https://www.nhs.uk/conditions/dehydration/)

Urgent advice: See a doctor if:
-------------------------------

You have been in an area where there is cholera and you have:

*   severe watery diarrhoea and vomiting
*   symptoms of [dehydration](https://www.nhs.uk/conditions/dehydration/), such as feeling thirsty or dark yellow and strong-smelling pee

Tell the doctor if you have been in an area where cholera is found in the last few weeks.

You may need treatment to stop you becoming dangerously dehydrated.

Treatment for cholera
---------------------

The main treatment for cholera is drinking plenty of fluids, including rehydration solution.

Rehydration solution is a powder you mix with water to replace salts, sugars and minerals your body has lost through diarrhoea. It's usually available from pharmacies.

If you're very unwell, you may need treatment in hospital where you may be treated with:

*   fluids given through a vein
*   antibiotics

Page last reviewed: 12 June 2024  
Next review due: 12 June 2027
