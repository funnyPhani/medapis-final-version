Title: Hiatus hernia

URL Source: https://www.nhs.uk/conditions/hiatus-hernia/

Published Time: 23 Oct 2017, 1:25 p.m.

Markdown Content:
**A hiatus hernia is when part of your stomach moves up into your chest. It's very common if you're over 50. It does not normally need treatment if it's not causing you problems.**

Check if you have a hiatus hernia
---------------------------------

You can have a hiatus hernia without knowing and without it being a problem.

Symptoms include:

*   a painful burning feeling in your chest, often after eating (heartburn)
*   bringing up small amounts of food or bitter-tasting fluids (acid reflux)
*   bad breath
*   feeling bloated
*   feeling or being sick
*   difficulty or pain when swallowing (dysphagia)

These are the symptoms of [gastro-oesophageal reflux disease (GORD)](https://www.nhs.uk/conditions/heartburn-and-acid-reflux/).

Things you can do to ease a hiatus hernia
-----------------------------------------

There are things you can do yourself to manage hiatus hernia symptoms.

### Do

*   eat smaller, more frequent meals
    
*   raise the head end of your bed by 10 to 20cm so your chest and head are above the level of your waist, which can stop stomach acid travelling up towards your throat
    
*   try to lose weight if you're overweight
    
*   try to find ways to relax
    

### Don’t

*   do not have food or drink that triggers your symptoms
    
*   do not eat within 3 or 4 hours of going to bed
    
*   do not wear clothes that are tight around your waist
    
*   do not smoke
    
*   do not drink too much alcohol
    
*   do not stop taking any prescribed medicine without speaking to a doctor first
    

### A pharmacist can help with hiatus hernia symptoms

Speak to a pharmacist for advice if you keep getting hiatus hernia symptoms.

They may recommend medicines called antacids or alginates, which can help ease your symptoms.

It's best to take these with food or soon after eating, as this is when you're most likely to get symptoms. They may also work for longer if taken with food.

Although antacids and alginates help symptoms in the short term, they will not cure the problem and should not be taken regularly for long periods.

If you're pregnant, a pharmacist can advise you about medicines you can take.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   your symptoms do not go away after 3 weeks
*   your symptoms are very bad or getting worse
*   medicines from a pharmacy do not help

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

You have indigestion or acid reflux and:

*   you have lost weight without trying
*   swallowing becomes difficult
*   you're being sick (vomiting) frequently
*   there's blood in your sick
*   you have pain in your upper tummy

You can call 111 or get help from [111 online](https://111.nhs.uk/).

Treatment for a hiatus hernia
-----------------------------

If medicines from a pharmacy and changing your eating habits do not help, a GP can prescribe stronger medicines.

If stronger medicines do not work, a GP can send you for tests to find out if your symptoms are caused by a hiatus hernia. They might also prescribe medicines for long-term gastro-oesophageal reflux disease (GORD).

A GP might refer you to a specialist to check if you need surgery. This usually only happens if other treatments have not worked and you keep having very bad symptoms.

### Surgery for a hiatus hernia

Keyhole surgery (also called a [laparoscopy](https://www.nhs.uk/conditions/laparoscopy/)) is usually used for a hiatus hernia. This involves making small cuts in your tummy.

It's done under general anaesthetic, so you'll be asleep during the operation.

After surgery, it can take up to 6 weeks before you can eat what you want and a few months to recover from things like bloating, farting and difficulty swallowing.

There's a chance that you may need more surgery.

Causes of a hiatus hernia
-------------------------

It's not clear what causes a hiatus hernia. Anyone can have one, but it's more common if you're over 50, pregnant or overweight.

Page last reviewed: 08 May 2024  
Next review due: 08 May 2027
