Title: High temperature (fever) in adults

URL Source: https://www.nhs.uk/conditions/fever-in-adults/

Published Time: 7 Apr 2020, 3 p.m.

Markdown Content:
What is a high temperature?
---------------------------

Normal body temperature is different for everyone and changes during the day.

A high temperature is usually considered to be 38C or above. This is sometimes called a fever.

Check if you have a high temperature
------------------------------------

You may have a high temperature if:

*   your chest or back feel hotter than usual
*   you have other symptoms, such as shivering (chills), sweating or warm, red skin (this may be harder to see on black or brown skin)
*   a thermometer says your temperature is 38C or above

### Important

If you feel hot or shivery, you may have a high temperature even if a thermometer says your temperature is below 38C.

### Taking your temperature

You do not need to take your temperature using a thermometer, but you can if you have one.

Make sure you use it correctly to help get an accurate result.

How to take your temperature with a digital thermometer

To use a digital thermometer:

1.  Clean the tip with cold water and soap, then rinse it.
2.  Turn the thermometer on.
3.  Put the tip under your tongue, towards the back of your mouth.
4.  Close your lips around the thermometer.
5.  Wait until it beeps or flashes.
6.  Remove the thermometer and check the temperature on the display.

You can also use a digital thermometer in your armpit. Make sure you keep your arm tight against your body until the thermometer beeps or flashes.

### Other types of thermometer

If you use a digital ear thermometer, follow the instructions that come with it. You usually need to gently pull your ear up and back before putting the thermometer in your ear.

Do not use:

*   a glass thermometer because they can be dangerous
*   an infrared thermometer because some do not meet UK regulations
*   forehead strips because they're not accurate

Information:

### Advice for children and babies

This page is for adults. For advice about children and babies, including how to take a temperature, see:

*   [high temperature (fever) in children](https://www.nhs.uk/conditions/fever-in-children/)
*   [how to take your baby's temperature](https://www.nhs.uk/conditions/baby/health/how-to-take-your-babys-temperature/)

Treating a high temperature
---------------------------

There are some things you can do to help treat a high temperature.

### Do

*   get lots of rest
    
*   drink plenty of fluids (water is best) to avoid dehydration – drink enough so your pee is light yellow and clear
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) if you feel uncomfortable
    

Information:

Try to stay at home and avoid contact with other people until you do not have a high temperature.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if you have:
-------------------------------------------------------------------------------------

*   a high temperature and you've been treating it at home but it's not getting better or is getting worse

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Causes of a high temperature
----------------------------

Many things can cause a high temperature. It's not usually a sign of anything serious.

It's often just caused by your body fighting an infection, such as a [cold](https://www.nhs.uk/conditions/common-cold/) or [flu](https://www.nhs.uk/conditions/flu/).

Sometimes it could be a sign of something more serious if your temperature is very high or will not come down.

Page last reviewed: 24 May 2023  
Next review due: 24 May 2026
