Title: Falls

URL Source: https://www.nhs.uk/conditions/falls/

Published Time: 1 May 2018, 12:14 p.m.

Markdown Content:
**Anyone can have a fall, but older people are more vulnerable and likely to fall, especially if they have a long-term health condition.**

Falls are a common, but often overlooked, cause of injury. Around 1 in 3 adults over 65 and half of people over 80 will have at least one fall a year.

Most falls do not result in serious injury. But there's always a risk that a fall could lead to broken bones, and it can cause the person to lose confidence, become withdrawn, and feel as if they have lost their independence.

What should I do if I fall?
---------------------------

If you have a fall, it's important to keep calm. If you're not hurt and you feel strong enough to get up, do not get up quickly.

Roll onto your hands and knees and look for a stable piece of furniture, such as a chair or bed.

Hold on to the furniture with both hands to support yourself and, when you feel ready, slowly get up. Sit down and rest for a while before carrying on with your daily activities.

If you're hurt or unable to get up, try to get someone's attention by calling out for help, banging on the wall or floor, or using your [personal alarm or security system](https://www.nhs.uk/conditions/social-care-and-support-guide/care-services-equipment-and-care-homes/personal-alarms-security-systems-and-keysafes/) (if you have one). If possible, crawl to a telephone and dial 999 to ask for an ambulance.

Try to reach something warm, such as a blanket or dressing gown, to put over you, particularly your legs and feet.

Stay as comfortable as possible and try to change your position at least once every half an hour or so.

You may want to get a personal alarm system so that you can signal for help in the event of a fall.

An alternative would be to always keep a mobile phone in your pocket so you can phone for help after having a fall.

If you're living with or caring for an elderly person, read what to do [after an incident](https://www.nhs.uk/conditions/first-aid/after-an-accident/).

What causes a fall?
-------------------

The natural ageing process means that older people have an increased risk of having a fall.

Older people are more likely to have a fall because they may have:

*   balance problems and muscle weakness
*   [vision loss](https://www.nhs.uk/conditions/vision-loss/)
*   a long-term health condition, such as [heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/), [dementia](https://www.nhs.uk/conditions/dementia/about-dementia/what-is-dementia/) or [low blood pressure (hypotension)](https://www.nhs.uk/conditions/low-blood-pressure-hypotension/), which can lead to [dizziness](https://www.nhs.uk/conditions/dizziness/) and a brief loss of consciousness

A fall is also more likely to happen if:

*   floors are wet, such as in the bathroom, or recently polished
*   the lighting in the room is dim
*   rugs or carpets are not properly secured
*   the person reaches for storage areas, such as a cupboard, or is going down stairs
*   the person is rushing to get to the toilet during the day or at night

Another common cause of falls, particularly among older men, is falling from a ladder while carrying out home maintenance work.

In older people, falls can be particularly problematic because [osteoporosis](https://www.nhs.uk/conditions/osteoporosis/) is a fairly common problem.

It can develop in both men and women, particularly in people who smoke, drink excessive amounts of alcohol, take steroid medicine, or have a family history of [hip fractures](https://www.nhs.uk/conditions/broken-hip/).

But older women are most at risk because osteoporosis is often associated with the hormonal changes that occur during the [menopause](https://www.nhs.uk/conditions/menopause/).

Preventing a fall
-----------------

There are several simple measures that can help prevent falls in the home.

For example:

*   using non-slip mats in the bathroom
*   mopping up spills to prevent wet, slippery floors
*   ensuring all rooms, passages and staircases are well lit
*   removing clutter
*   getting help lifting or moving items that are heavy or difficult to lift

The charity Age UK has more advice about [home adaptations to make tasks easier](https://www.ageuk.org.uk/information-advice/care/housing-options/adapting-home/).

Healthcare professionals take falls in older people very seriously because of the huge consequences they can have for the health and wellbeing of this group.

As a result, there's a great deal of help and support available for older people, and it's worth asking a GP about the various options.

The GP may carry out some simple tests to check your balance. They can also review any medicines you're taking in case their side effects may increase your risk of falling.

The GP may also recommend:

*   looking after your eyes with a sight test if you're having problems with your vision, even if you already wear glasses
*   having an [electrocardiogram (ECG)](https://www.nhs.uk/conditions/electrocardiogram/) and checking your blood pressure while lying and standing
*   requesting a home hazard assessment, where a healthcare professional visits your home to identify potential hazards and give advice
*   doing exercises to improve your strength and balance ([read about physical activity guidelines for older adults](https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-older-adults/))

[Read more about preventing falls](https://www.nhs.uk/conditions/falls/prevention/)

Information:

Self-refer for help if you've had a fall
----------------------------------------

If you've had a fall, you might be able to refer yourself directly to services that can help you without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS services that can help after a fall near you

Page last reviewed: 25 June 2021  
Next review due: 25 June 2024
