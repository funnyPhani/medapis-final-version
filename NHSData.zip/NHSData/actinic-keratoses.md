Title: Actinic keratoses (solar keratoses)

URL Source: https://www.nhs.uk/conditions/actinic-keratoses/

Published Time: 17 Oct 2017, 4:23 p.m.

Markdown Content:
**Actinic keratoses (also called solar keratoses) are dry, scaly patches of skin that have been damaged by the sun. It's** **not usually serious, but there's a small chance the patches could become skin cancer. Protecting your skin in the sun and watching out for changes can help.**

Check if you have actinic keratoses
-----------------------------------

Actinic keratoses patches:

*   can feel dry, rough and scaly, or like sandpaper
*   are usually between 1cm and 2cm in size
*   can be the same colour as your skin, or range from pink to red to brown
*   may be itchy

![Image 1: An actinic keratosis patch on white skin. The patch has an irregular shape and looks dry and rough.](https://assets.nhs.uk/nhsuk-cms/images/AXBN7E.width-320.jpg)

The patches usually appear on areas of your body that are often exposed to the sun, such as your face, hands and arms, ears, scalp and legs.

Non-urgent advice: See a GP if:
-------------------------------

*   you notice new patches on your skin
*   the patches begin to bleed, get bigger, change colour, feel tender or develop into a lump
*   a patch appears on your lips

It's important to get these skin changes checked in case they're being caused by something more serious, such as skin cancer.

Treatment for actinic keratoses
-------------------------------

If you only have 1 actinic keratoses patch, a GP might suggest waiting to see if it goes away by itself.

If you have more than 1 patch, or a patch is causing you problems such as pain and itchiness, treatment is usually recommended.

A GP may refer you to a skin specialist (dermatologist).

Treatments for actinic keratoses include:

*   prescription creams and gels
*   freezing the patches (cryotherapy) – this makes the patches turn into blisters and fall off after a few weeks
*   surgery to cut out or scrape away the patches – you'll be given a local anaesthetic first, so it does not hurt
*   photodynamic therapy (PDT), where special cream is applied to the patches and a light is shone on them

Things you can do if you have actinic keratoses
-----------------------------------------------

There are things you can do to stop your actinic keratoses patches getting worse and lower your chances of developing skin cancer.

### Do

*   check your skin regularly for any changes
    
*   use sunscreen with a sun protection factor (SPF) of at least 30 before going out in the sun and reapply regularly
    
*   wear a hat and clothing that fully covers your arms and legs when you're out in the sun
    

### Don’t

*   do not sunbathe
    
*   do not use sunlamps or sunbeds as these can also damage your skin
    
*   do not go into the sun between 11am and 3pm – this is when the sun is at its strongest
    

Information:

Consider taking 10 micrograms of [vitamin D](https://www.nhs.uk/conditions/vitamins-and-minerals/vitamin-d/) a day if you always cover up outdoors. This is because you may not get enough vitamin D from sunlight.

Page last reviewed: 14 June 2023  
Next review due: 14 June 2026
