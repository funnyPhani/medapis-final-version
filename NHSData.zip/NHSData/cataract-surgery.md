Title: Cataract surgery

URL Source: https://www.nhs.uk/conditions/cataract-surgery/

Published Time: 24 Oct 2017, 4:31 p.m.

Markdown Content:
**Cataract surgery involves replacing the cloudy lens inside your eye with an artificial one.**

It has a high success rate in improving your eyesight.

It can take 2 to 6 weeks to fully recover from cataract surgery.

What are cataracts?
-------------------

Cataracts are when the lens of your eye, a small transparent disc, develops cloudy patches.

When we're young, our lenses are usually like clear glass, allowing us to see through them.

As we get older they start to become frosted, like bathroom glass, and begin to limit our vision.

Cataracts most commonly affect adults as a result of ageing.

[Find out more about age-related cataracts](https://www.nhs.uk/conditions/cataracts/)

Do you need surgery?
--------------------

If you have cataracts, it's your decision whether or not to go ahead with cataract surgery.

Cataracts usually get slowly worse over time. Surgery to replace the cloudy lens is the only way to improve your eyesight.

Surgery is usually offered on the NHS if your cataracts are affecting your eyesight and quality of life.

The decision to have surgery should not be based solely on your eye test (visual acuity) results.

You may have other personal reasons for deciding to have surgery, such as your daily activities, hobbies and interests.

You can choose to put off having surgery for a while and have regular check-ups to monitor the situation.

There are no medicines or eye drops that have been proven to improve cataracts or stop them getting worse.

Before the operation
--------------------

Before surgery, you'll be referred to a specialist eye doctor for an assessment.

During the assessment different measurements will be taken of your eyes and your eyesight.

The assessment is an opportunity to discuss anything to do with your operation, including:

*   your lens preference, such as near sight or long sight
*   the risks and benefits of surgery
*   if you'll need glasses after surgery
*   how long you'll take to fully recover

If you're used to using 1 eye for distance and 1 for reading, which is called monovision, you can ask to stay that way.

This usually means you'll get a near-sight lens fitted in 1 eye and a long-sighted lens fitted in the other eye.

The operation
-------------

Cataract surgery is a straightforward procedure that usually takes 30 to 45 minutes.

It's often carried out as day surgery under [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) and you should be able to go home on the same day.

During the operation, the surgeon will make a tiny cut in your eye to remove the cloudy lens and replace it with a clear plastic one.

With the NHS, you'll usually be offered monofocal lenses, which have a single point of focus. This means the lens will be fixed for either near or distance vision, but not both.

If you go private, you may be able to choose either a multifocal or an accommodating lens, which allow the eye to focus on both near and distant objects.

Most people will need to wear glasses for some tasks, like reading, after surgery regardless of the type of lens they have fitted.

If you have cataracts in both eyes it may be recommended that both eyes are treated on the same day. This procedure is known as immediate sequential bilateral cataract surgery (ISBCS). ISBCS is usually only recommended for people thought to have a low risk of complications. The surgeon will discuss this with you if this is an option.

Otherwise, surgery is done 6 to 12 weeks apart to allow the recovery one eye at a time.

[Find out more about recovering from cataract surgery](https://www.nhs.uk/conditions/cataract-surgery/recovery/)

Benefits of surgery
-------------------

After cataract surgery you should be able to:

*   see things in focus
*   look into bright lights and not see as much glare
*   tell the difference between colours

If you have another condition affecting your eyes, such as diabetes or glaucoma, you may still have limited vision, even after successful surgery.

Risks of surgery
----------------

The risk of serious complications developing as a result of cataract surgery is estimated at around 1 in 50 cases.

These can include:

*   blurred vision
*   some loss of vision
*   detached retina – where the the thin layer at the back of your eye (retina) becomes loose

Most of these serious complications can be treated with medicines or further surgery.

There is a very small risk – around 1 in 1,000 – of permanent sight loss in the treated eye as a direct result of the operation.

Video: What are cataracts?
--------------------------

This animation explains in detail what cataracts are and how they affect the eye.

Media last reviewed: 21 April 2023  
Media review due: 21 April 2026

Help us improve our website
---------------------------

Can you answer a few questions about your visit today?

[Take our survey](https://feedback.digital.nhs.uk/jfe/form/SV_8uJlAqDfu8ANPN4)

Page last reviewed: 09 February 2021  
Next review due: 09 February 2024
