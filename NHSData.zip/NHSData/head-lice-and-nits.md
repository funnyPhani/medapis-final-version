Title: Head lice and nits

URL Source: https://www.nhs.uk/conditions/head-lice-and-nits/

Published Time: 19 Oct 2017, 5:05 p.m.

Markdown Content:
**Head lice and nits are very common in young children and their families. They are not caused by dirty hair and are picked up by head-to-head contact.**

Check if it's head lice
-----------------------

![Image 1: A head louse in blonde hair on the scalp of someone with white skin.](https://assets.nhs.uk/nhsuk-cms/images/EX0WEG.width-320.jpg)

Head lice are small insects, up to 3mm long.

![Image 2: A close-up of a head louse in blonde hair on the scalp of someone with white skin. The louse is light brown and shaped like a rice grain.](https://assets.nhs.uk/nhsuk-cms/images/close-up_EX0WEG.width-320.jpg)

They can be difficult to spot in your hair.

![Image 3: Small brown and white head lice eggs attached to brown hair on the scalp.](https://assets.nhs.uk/nhsuk-cms/images/AJBNGP.width-320.jpg)

Head lice eggs (nits) are brown or white and attached to the hair.

Head lice can make your head feel itchy.

The only way to be sure someone has head lice is by finding live lice.

You can do this by combing their hair with a special fine-toothed comb (detection comb). You can buy these online or at pharmacies.

How to get rid of head lice
---------------------------

Treat head lice as soon as you spot them. You can treat head lice without seeing a GP.

Check everyone you live with, or have close contact with, and start treating anyone who has head lice on the same day.

There's no need to keep your child off school if they have head lice. You do not need to wash your laundry on a hot wash.

### Wet combing

Lice and nits can be removed by wet combing.

You can buy a special fine-toothed comb (detection comb) online or from pharmacies to remove head lice and nits.

There may be instructions on the pack, but usually you:

*   wash hair with ordinary shampoo
*   apply lots of conditioner (any conditioner will do)
*   comb the whole head of hair, using the detection comb, from the roots to the ends

It usually takes about 10 minutes to comb short hair, and 20 to 30 minutes for long, frizzy or curly hair. When you've finished combing the hair, comb through all the hair again for a second time.

Do wet combing on days 1, 5, 9 and 13 to catch any newly hatched head lice. Check again that everyone's hair is free of lice on day 17.

### Medicated lotions and sprays

If wet combing has not worked or is not suitable, you could try a medicated lotion or spray. These kill head lice in all types of hair, and you can buy them from pharmacies, supermarkets or online.

Head lice should die within a day. Some lotions and sprays come with a comb to remove dead lice and eggs.

Some treatments need to be repeated after a week to kill any newly hatched lice.

Check the pack to see if they're OK for you or your child to use, and how to use them.

If lotions or sprays do not work, speak to a pharmacist about other treatments.

### Treatments that are not recommended for head lice

Some treatments are not recommended because they're unlikely to work.

For example:

*   products containing permethrin
*   head lice "repellents"
*   electric combs for head lice
*   plant oil treatments, such as tea tree oil, eucalyptus oil and lavender oil herbal remedies

You cannot prevent head lice
----------------------------

There's nothing you can do to prevent head lice.

You can help stop them spreading by wet combing regularly, using a detection comb, to catch them early.

Do not use medicated lotions and sprays to prevent head lice. They can irritate the scalp.

Page last reviewed: 22 April 2024  
Next review due: 22 April 2027
