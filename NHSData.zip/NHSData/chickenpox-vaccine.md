Title: Chickenpox vaccine

URL Source: https://www.nhs.uk/vaccinations/chickenpox-vaccine/

Published Time: 6 Mar 2024, 5:39 p.m.

Markdown Content:
What the chickenpox vaccine is for
----------------------------------

The chickenpox vaccine helps prevent [chickenpox](https://www.nhs.uk/conditions/chickenpox/).

Although chickenpox is usually mild, it can be very serious for some people, including:

*   pregnant women
*   babies
*   those with a weakened immune system

The chickenpox vaccine is recommended to help protect certain people who have a higher risk of getting seriously ill from chickenpox.

Who should have the chickenpox vaccine
--------------------------------------

The chickenpox vaccine is recommended if you're healthy and all the following apply:

*   you're 9 months old or over
*   you've not had chickenpox before
*   you're in regular or close contact with someone who's at risk of getting seriously ill if they get chickenpox, such as a child with leukaemia or an adult having chemotherapy

You should also have the chickenpox vaccine if you've not had chickenpox before and your work involves close contact with patients. This includes:

*   doctors and nurses
*   ambulance staff
*   GP surgery and hospital receptionists
*   hospital ward cleaners
*   catering staff
*   laboratory workers who are exposed to the chickenpox virus

If you're not sure you've had chickenpox before, you may need a blood test to check.

Who cannot have the chickenpox vaccine
--------------------------------------

Most people can have the chickenpox vaccine if they need it.

But as it's a live vaccine (it contains a weakened version of the chickenpox virus), it's not recommended for some people.

People who should not have the chickenpox vaccine include:

*   those with a weakened immune system because of an illness like HIV or a treatment such as chemotherapy
*   pregnant women
*   babies under 9 months old
*   people who've had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a previous dose of the vaccine or an ingredient in the vaccine, including neomycin or gelatin
*   people who've had their MMR vaccine in the previous 4 weeks

If you've had the chickenpox vaccine, you should avoid getting pregnant for 1 month after having the last dose of the vaccine.

Information:

### Getting vaccinated if you're unwell

If you have a high temperature or feel too unwell to do your normal activities, wait until you're feeling better before having the vaccine.

Chickenpox vaccine ingredients
------------------------------

There are 2 types of chickenpox vaccine given in the UK. You can check the ingredients in the patient leaflets:

*   [Varilrix chickenpox vaccine patient leaflet (Electronic Medicines Compendium website; PDF only, 93KB)](https://www.medicines.org.uk/emc/files/pil.1676.pdf)
*   [Varivax chickenpox vaccine patient leaflet (Electronic Medicines Compendium website)](https://www.medicines.org.uk/emc/product/5582/pil)

Where to get the chickenpox vaccine
-----------------------------------

Contact your GP surgery if you think you or other members of your family need the chickenpox vaccine to protect you or someone you live with.

But be aware that not all GP surgeries provide chickenpox vaccines, so you may need to pay for it privately.

Speak to your employer about getting the chickenpox vaccine if you need it because of your job.

How the chickenpox vaccine is given
-----------------------------------

The chickenpox vaccine is given as an injection into your arm.

You need 2 doses, 4 to 8 weeks apart.

Information:

### Having the chickenpox vaccine at the same time as other vaccines

You can have the chickenpox vaccine at the same time as other vaccines, including the MMR vaccine.

Side effects of the chickenpox vaccine
--------------------------------------

Most side effects of the chickenpox vaccine are mild and do not last long.

They can include:

*   swelling or pain where the injection was given
*   a high temperature
*   a rash in the area where the injection was given or more widespread – it usually develops within 1 month of vaccination

More serious side effects, such as a severe allergic reaction, are very rare. The person who vaccinates you will be trained to deal with allergic reactions and treat them immediately.

### Important: Healthcare workers

Tell your employer if you're a healthcare worker and you feel unwell or get a rash after having the chickenpox vaccine.

You may need to avoid contact with patients until you feel better and the rash has scabbed over.

How well the chickenpox vaccine works and how long it lasts
-----------------------------------------------------------

After 2 doses, the chickenpox vaccine provides around 98% protection in children and about 75% protection in adults.

Further booster doses are not needed.

If you get chickenpox after being vaccinated, you'll usually have milder symptoms than someone who has not been vaccinated.
