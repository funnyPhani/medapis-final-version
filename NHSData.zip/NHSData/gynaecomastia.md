Title: Gynaecomastia

URL Source: https://www.nhs.uk/conditions/gynaecomastia/

Published Time: 4 Jun 2024, 2:06 p.m.

Markdown Content:
Gynaecomastia is where men have bigger breasts than usual. It's common and may not need treatment, but can sometimes be caused by other conditions.

Check if you have gynaecomastia
-------------------------------

Gynaecomastia affects men and boys.

The main symptom is getting bigger breasts than usual. Your nipples or breasts may also look swollen or feel sore.

1 or both breasts may be affected.

Non-urgent advice: See a GP if you:
-----------------------------------

*   are worried about the size of your breasts, or how they look
*   have pain in your breast or nipple that is not going away
*   have a lump in your breast or nipple
*   have any changes in the skin of your breast or nipple, such as a rash, dimpling (may look like orange peel), or redness (may be harder to see on black or brown skin)
*   have discharge or bleeding from 1 or both of your nipples

Try not to be embarrassed. The doctor or nurse will be used to talking about these symptoms.

Causes of gynaecomastia
-----------------------

Causes of gynaecomastia can include:

*   hormone changes in men aged over 50, or during puberty
*   being overweight
*   certain medicines
*   conditions such as an [overactive thyroid](https://www.nhs.uk/conditions/overactive-thyroid-hyperthyroidism/), [kidney disease](https://www.nhs.uk/conditions/kidney-disease/), or [cirrhosis](https://www.nhs.uk/conditions/cirrhosis/)
*   drug use, including [anabolic steroids](https://www.nhs.uk/conditions/anabolic-steroid-misuse/)
*   the effect of pregnancy hormones on some newborn babies

Treatments for gynaecomastia
----------------------------

Gynaecomastia is often harmless and may not need treatment, but if it's a problem for you, your GP may recommend:

*   medicines that reduce or increase certain hormones
*   losing weight, if you're overweight

If your gynaecomastia is caused by a condition, getting treatment for the condition may help reduce the size of your breasts.

Surgery can reduce your breasts if other treatments have not worked, but it may not be available on the NHS.

When gynaecomastia happens in newborn babies, or when it's caused by puberty, it usually goes away by itself over time.

Page last reviewed: 31 May 2024  
Next review due: 31 May 2027
