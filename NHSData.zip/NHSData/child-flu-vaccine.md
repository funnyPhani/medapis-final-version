Title: Children's flu vaccine

URL Source: https://www.nhs.uk/vaccinations/child-flu-vaccine/

Published Time: 6 Mar 2024, 5:39 p.m.

Markdown Content:
This page is about the flu vaccine for children. There's separate information about the [flu vaccine for adults](https://www.nhs.uk/vaccinations/flu-vaccine/).

Why children are offered the flu vaccine
----------------------------------------

[Flu](https://www.nhs.uk/conditions/flu/) can be very unpleasant for children and can sometimes cause serious problems, such as [pneumonia](https://www.nhs.uk/conditions/pneumonia/).

Each winter in the UK, thousands of children who do not have a health condition need hospital care because of flu.

Children can catch and spread flu easily. Vaccinating them also helps protect others who are at higher risk of getting seriously ill from flu, such as babies and older people.

Who should have the children's flu vaccine
------------------------------------------

The children's flu vaccine is offered on the NHS every year in autumn or early winter.

It's recommended for:

*   children aged 2 or 3 years
*   school-aged children (Reception to Year 11)
*   children aged 6 months to 17 years with certain long-term health conditions

Health conditions that mean you're eligible for the children's flu vaccine

It's important for children with certain long-term health conditions to have the flu vaccine every year.

This includes children aged 6 months to 17 years who have:

*   conditions that affect their breathing, such as asthma (needing a steroid inhaler or tablets) or cystic fibrosis
*   had a lung or airways infection in the past that meant they needed to stay overnight in hospital
*   serious heart conditions
*   kidney or liver disease
*   some conditions that affect their brain or nerves, such as cerebral palsy
*   diabetes
*   a weakened immune system due to a condition or treatment, such as HIV or AIDS, chemotherapy or steroid medicine
*   problems with their spleen, such as sickle cell disease, or if they've had their spleen removed
*   a learning disability

If your child has a health condition and you're not sure if they're eligible for the flu vaccine, speak to their GP surgery or specialist.

Who cannot have the children's flu vaccine
------------------------------------------

Most children who are eligible for the children's nasal spray flu vaccine can have it.

But some children will be offered the injected flu vaccine instead if they:

*   have had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a previous dose of the nasal spray vaccine
*   have had a serious allergic reaction to an ingredient in the nasal spray vaccine, including gelatine, neomycin or gentamicin
*   have a severe egg allergy that's needed intensive care hospital treatment
*   have a severely weakened immune system, or live with someone who has a severely weakened immune system (for example, someone who has had a bone marrow transplant)
*   have asthma that's being treated with long-term steroid tablets or has needed intensive care treatment in hospital
*   have had a flare-up of asthma symptoms in the past 72 hours, including wheezing or needing to use a reliever inhaler more than usual
*   are having salicylate therapy

If you think your child may need the injected flu vaccine you can speak to your GP, practice nurse or the school immunisation team.

Information:

### Getting vaccinated if your child is unwell

If your child has a high temperature, wait until they're feeling better before having the flu vaccine.

If they have a very blocked or runny nose, they may have to wait to get the nasal spray vaccine until they're feeling better, or they may be offered an injected flu vaccine instead.

Children's flu vaccine ingredients
----------------------------------

Most children are offered the nasal spray flu vaccine. It gives the best protection for children aged 2 to 17 years. You can check the ingredients in the patient leaflet:

[Fluenz Tetra nasal spray flu vaccine patient leaflet (Electronic Medicines Compendium website)](https://www.medicines.org.uk/emc/product/3296/pil)

The nasal spray vaccine contains a small amount of gelatine from pigs (porcine gelatine).

A flu vaccine injection is available that does not contain gelatine. If you do not want your child to have the nasal spray vaccine, speak to the person vaccinating your child or ask for the flu vaccine injection on the school consent form.

Children who cannot have the nasal spray vaccine and children under the age of 2 years will also be offered a flu vaccine injection.

You can check the flu vaccine injection ingredients in the patient leaflet:

[Cell-based quadrivalent influenza vaccine patient leaflet (Electronic Medicines Compendium website)](https://www.medicines.org.uk/emc/product/12882/pil)

How to get the children's flu vaccine
-------------------------------------

There are different ways to get the children's flu vaccine.

Children aged 2 or 3 years

Children who are aged 2 or 3 years on 31 August 2024 (born between 1 September 2020 and 31 August 2022) will get the flu vaccine at their GP surgery.

You should get an invitation from your GP surgery, or be able to contact them, in autumn or early winter to book an appointment.

School-aged children (Reception to Year 11)

Most school-aged children (Reception to Year 11) get their flu vaccine at school.

You should get an invitation from your child's school to get their vaccine, usually during the autumn term.

If your child misses their vaccination at school or if they are home-schooled, they should be offered a flu vaccine at a community clinic.

Children who are 4 years old but have not started school can get the flu vaccine from their GP surgery.

Children with certain long-term health conditions

Children with certain long-term health conditions that put them at higher risk from flu can get a flu vaccine from their:

*   school (if they're in Reception to Year 11)
*   GP surgery

If your child is in Reception to Year 11, they should get an invitation from their school to have the vaccine, usually during the autumn term.

If your child is not in school or you want to vaccinate your child earlier than when it's offered at school, contact their GP surgery in autumn or early winter to book an appointment.

How the children's flu vaccine is given
---------------------------------------

The children's flu vaccine is usually given as a quick and painless nasal spray in each nostril.

Children who cannot have the nasal spray vaccine will get a different flu vaccine, given as an injection into the upper arm or thigh.

Some children with certain long-term health conditions who have not had a flu vaccine before might need to have a 2nd dose 4 weeks later.

Information:

### Having the children's flu vaccine at the same time as other vaccines

Children can get the flu vaccine at the same time as other vaccines.

Side effects of the children's flu vaccine
------------------------------------------

The most common side effects of the children's flu vaccine are mild and get better in 1 to 2 days.

Side effects of the nasal spray flu vaccine can include:

*   a blocked or runny nose
*   loss of appetite
*   feeling tired
*   a headache

Side effects of the flu vaccine injection can include:

*   pain or soreness where the injection was given
*   a slightly raised temperature
*   an aching body

More serious side effects such as a severe allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) are very rare. The person who vaccinates your child will be trained to deal with allergic reactions and treat them immediately.

You cannot get flu from any of the flu vaccines.

How well the children's flu vaccine works and how long it lasts
---------------------------------------------------------------

The children's flu vaccine aims to protect children against the most common types of flu viruses.

There's still a chance your child might get flu after getting vaccinated, but they're less likely to get seriously ill or need to go to hospital.

The vaccine usually takes up to 14 days to work.

Protection from the flu vaccine goes down over time and the types of flu the vaccine protects against are updated each year. This is why it's important to get the flu vaccine every year.
