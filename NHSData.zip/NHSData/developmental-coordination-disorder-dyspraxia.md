Title: Developmental co-ordination disorder (dyspraxia) in children

URL Source: https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia/

Published Time: 3 Oct 2018, 9:02 p.m.

Markdown Content:
**Developmental co-ordination disorder (DCD), also known as dyspraxia, is a condition affecting physical co-ordination. It causes a child to perform less well than expected in daily activities for their age, and appear to move clumsily.**

This topic is about DCD in children, although the condition often causes continued problems into adulthood.

Find out more about [DCD in adults](https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia-in-adults/).

Symptoms of DCD
---------------

Early developmental milestones of crawling, walking, self-feeding and dressing may be delayed in young children with DCD. Drawing, writing and performance in sports are also usually behind what is expected for their age.

Although signs of the condition are present from an early age, children vary widely in their rate of development. This means a definite diagnosis of DCD does not usually happen until a child with the condition is 5 years old or more.

Find out more about [symptoms of DCD in children](https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia/symptoms/).

When to seek medical advice
---------------------------

If you're concerned about your child's health or development, talk to a GP or health visitor, or speak to a nurse, doctor or special educational needs co-ordinator (SENCO) at your child's school.

They may refer your child to an occupational therapist, paediatrician, or another health professional who can assess them and try to identify any developmental problems.

Find out more about [diagnosing DCD in children](https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia/diagnosis/).

Causes of DCD
-------------

Doing co-ordinated movements is a complex process that involves many different nerves and parts of the brain.

Any problem in this process could potentially lead to difficulties with movement and co-ordination.

It's not usually clear why co-ordination doesn't develop as well as other abilities in children with DCD.

However, a number of risk factors that can increase a child's likelihood of developing DCD have been identified.

These include:

*   being born prematurely, before the 37th week of pregnancy
*   being born with a low birth weight
*   having a family history of DCD, although it is not clear exactly which genes may be involved in the condition
*   the mother drinking alcohol or taking illegal drugs while pregnant

Treating DCD
------------

There's no cure for DCD, but a number of therapies can help children to manage their problems.

These include:

*   being taught ways to do activities they find difficult, such as breaking down difficult movements into smaller parts and practicing them regularly
*   adapting tasks to make them easier, such as using special grips on pens and pencils so they are easier to hold

Although DCD does not affect how intelligent a child is, it can make it more difficult for them to learn and they may need extra help to keep up at school.

Treatment for DCD will be tailored to your child and usually involves a number of different healthcare professionals working together.

Although the physical co-ordination of a child with DCD will remain below average, this may be less of a problem as they get older and develop coping strategies. Some children may continue to have problems.

However, difficulties in school – particularly producing written work – can become much more prominent and require extra help from parents and teachers.

Find out more about [treating DCD in children](https://www.nhs.uk/conditions/developmental-coordination-disorder-dyspraxia/treatment/).

Dyspraxia or DCD?
-----------------

While many people in the UK use the term dyspraxia to refer to the difficulties with movement and co-ordination that first develop in young children, this term is used less often by healthcare professionals.

Instead, most healthcare professionals use the term developmental co-ordination disorder (DCD) to describe the condition.

This term is generally preferred by healthcare professionals because dyspraxia can have several meanings.

For example, dyspraxia can be used to describe movement difficulties that happen later in life because of damage to the brain, such as from a [stroke](https://www.nhs.uk/conditions/stroke/) or [head injury](https://www.nhs.uk/conditions/severe-head-injury/).

Some healthcare professionals may also use the term specific developmental disorder of motor function (SDDMF) to refer to DCD.

Video: childhood dyspraxia - James' story
-----------------------------------------

This video is about dyspraxia, a disability that can affect movement and coordination.

Media last reviewed: 1 September 2021  
Media review due: 1 September 2024

Page last reviewed: 08 March 2023  
Next review due: 08 March 2026
