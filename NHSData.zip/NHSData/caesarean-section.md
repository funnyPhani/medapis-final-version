Title: Caesarean section

URL Source: https://www.nhs.uk/conditions/caesarean-section/

Published Time: 19 Oct 2017, 3:59 p.m.

Markdown Content:
**A caesarean section, or C-section, is an operation to deliver your baby through a cut made in your tummy and womb.**

The cut is usually made across your tummy, just below your bikini line.

A caesarean is a major operation that carries a number of risks, so it's usually only done if it's the safest option for you and your baby.

Around 1 in 4 pregnant women in the UK has a caesarean birth.

Why caesareans are carried out
------------------------------

A caesarean may be recommended as a planned (elective) procedure or done in an emergency if it's thought a vaginal birth is too risky.

Planned caesareans are usually done from the 39th week of pregnancy.

A caesarean may be carried out because:

*   your baby is in the [breech position](https://www.nhs.uk/pregnancy/labour-and-birth/what-happens/if-your-baby-is-breech/) (feet first) and your doctor or midwife has been unable to turn them by applying gentle pressure to your tummy, or you'd prefer they did not try this
*   you have a [low-lying placenta](https://www.nhs.uk/pregnancy/labour-and-birth/what-happens/placenta-complications/) (placenta praevia)
*   you have pregnancy-related high blood pressure ([pre-eclampsia](https://www.nhs.uk/conditions/pre-eclampsia/))
*   you have certain infections, such as a first [genital herpes](https://www.nhs.uk/conditions/genital-herpes/) infection occurring late in pregnancy or untreated [HIV](https://www.nhs.uk/conditions/hiv-and-aids/)
*   your baby is not getting enough oxygen and nutrients – sometimes this may mean the baby needs to be delivered immediately
*   your labour is not progressing or there's excessive vaginal bleeding

If there's time to plan the procedure, your midwife or doctor will discuss the benefits and risks of a caesarean compared with a vaginal birth.

Asking for a caesarean
----------------------

Some women choose to have a caesarean for non-medical reasons.

If you ask your midwife or doctor for a caesarean when there are not medical reasons, they'll explain the overall benefits and risks of a caesarean to you and your baby compared with a vaginal birth.

If you're anxious about giving birth, you should be offered the chance to discuss your anxiety with a healthcare professional who can offer support during your pregnancy and labour.

If after discussing all the risks and hearing about all the support on offer you still feel that a vaginal birth is not an acceptable option, you should be offered a planned caesarean. If your doctor is unwilling to perform the operation, they should refer you to a doctor who will.

What happens during a caesarean
-------------------------------

Most caesareans are carried out under spinal or [epidural anaesthetic](https://www.nhs.uk/conditions/epidural/).

This mean you'll be awake, but the lower part of your body is numbed so you will not feel any pain.

During the procedure:

*   a screen is placed across your body so you cannot see what's being done – the doctors and nurses will let you know what's happening
*   a cut about 10 to 20cm long will usually be made across your lower tummy and womb so your baby can be delivered
*   you may feel some tugging and pulling during the procedure
*   you and your birth partner will be able to see and hold your baby as soon as they have been delivered if they're well – a baby born by emergency caesarean because of foetal distress may be taken straight to a paediatrician for resuscitation

The whole operation normally takes about 40 to 50 minutes.

Occasionally, a [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/) (where you're asleep) may be used, particularly if the baby needs to be delivered more quickly.

[Find out more about how a caesarean is carried out](https://www.nhs.uk/conditions/caesarean-section/what-happens/)

Recovering from a caesarean
---------------------------

Recovering from a caesarean usually takes longer than recovering from a vaginal delivery.

Providing there are no complications, most women can go home 1 to 2 days after having a caesarean.

You may experience some discomfort in your tummy for the first few days. You'll be offered painkillers to help with this.

When you go home, you'll need to take things easy at first. You may need to avoid some activities, such as driving, until you have had your postnatal check-up with the doctor at 6 weeks.

The wound in your tummy will eventually form a scar. This may be obvious at first, but it should fade with time and will often be hidden in your pubic hair.

[Find out more about recovering from a caesarean](https://www.nhs.uk/conditions/caesarean-section/recovery/)

Risks of a caesarean
--------------------

A caesarean is generally a very safe procedure, but like any type of surgery it carries a certain amount of risk.

It's important to be aware of the possible complications, particularly if you're considering having a caesarean for non-medical reasons.

Possible complications include:

*   infection of the wound or womb lining
*   [blood clots](https://www.nhs.uk/conditions/blood-clots/)
*   excessive bleeding
*   damage to nearby areas, such as the bladder or the tubes that connect the kidneys and bladder
*   temporary breathing difficulties in your baby
*   accidentally cutting your baby when your womb is opened

[Find out more about the risks of a caesarean](https://www.nhs.uk/conditions/caesarean-section/risks/)

Future pregnancies after a caesarean
------------------------------------

If you have a baby by caesarean, it does not necessarily mean that any babies you have in the future will also have to be delivered this way.

Most women who have had a caesarean section can safely have a vaginal delivery for their next baby, known as vaginal birth after caesarean (VBAC).

But you may need some extra monitoring during labour just to make sure everything is progressing well.

Some women may be advised to have another caesarean if they have another baby.

This depends on whether a caesarean is still the safest option for them and their baby.

For more information, [read the Royal College of Obstetricians and Gynaecologists leaflet on birth options after previous caesarean section](https://www.rcog.org.uk/for-the-public/browse-all-patient-information-leaflets/birth-after-previous-caesarean-patient-information-leaflet/).

Page last reviewed: 04 January 2023  
Next review due: 04 January 2026
