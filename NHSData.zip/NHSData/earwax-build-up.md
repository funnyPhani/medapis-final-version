Title: Earwax build-up

URL Source: https://www.nhs.uk/conditions/earwax-build-up/

Published Time: 18 Oct 2017, 11:10 a.m.

Markdown Content:
**Earwax normally just falls out on its own. When it's blocking your ears, a pharmacist can help.**

Symptoms of earwax build-up
---------------------------

Symptoms of earwax build-up include:

*   hearing loss
*   earache or a feeling that your ears are blocked
*   ringing or buzzing in your ears (tinnitus)
*   vertigo (feeling dizzy and sick)

How you can treat earwax build-up yourself
------------------------------------------

Earwax usually falls out on its own. If it does not, and builds up and blocks your ear, you can try to remove it.

To remove earwax build-up:

1.  Lie on your side with the affected ear facing up.
2.  Put 2 to 3 drops of olive or almond oil in your ear – do not use almond oil if you're allergic to almonds.
3.  Continue to lie on your side for 5 to 10 minutes after putting in the oil.
4.  Repeat 3 to 4 times a day, for 3 to 5 days.

Over about 2 weeks, lumps of earwax should fall out of your ear and your symptoms should improve.

There's no evidence that ear candles or ear vacuums get rid of earwax.

### Important

Do not use your fingers or any objects like cotton buds to remove earwax. This will push it in and make it worse.

A pharmacist can help with earwax build-up
------------------------------------------

Speak to a pharmacist about earwax build-up. They can give advice and suggest treatments.

They might recommend medicines to dissolve the earwax. The earwax should fall out on its own or dissolve after about a week.

Do not use drops if you have a hole in your eardrum (a perforated eardrum).

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a nurse at your GP surgery if:
-----------------------------------------------------

*   you have symptoms of ear wax build-up which have not cleared after 5 days
*   your ear is badly blocked and you cannot hear anything (you could get an infection if it has not cleared)

GP surgery treatment to remove earwax
-------------------------------------

Not all GP surgeries remove earwax build-up.

Some can:

*   flush the wax out with water (ear irrigation)
*   suck the wax out (microsuction)

These treatments are usually painless.

You might have to pay to have them done privately.

Causes of earwax build-up
-------------------------

A build-up of earwax can happen if you have:

*   narrow or damaged ear canals
*   lots of hair in your ear canals
*   a skin condition affecting your scalp or around your ear
*   inflammation of your ear canal (otitis externa or "swimmer's ear")

Preventing earwax build-up
--------------------------

You cannot prevent earwax. It's there to protect your ears from dirt and germs.

But regularly using eardrops, or olive or almond oil, will help soften earwax build-up. This will help it fall out on its own and should stop your ears getting blocked.

Page last reviewed: 05 January 2024  
Next review due: 05 January 2027
