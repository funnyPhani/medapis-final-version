Title: Corns and calluses

URL Source: https://www.nhs.uk/conditions/corns-and-calluses/

Published Time: 23 Oct 2017, 11:09 a.m.

Markdown Content:
**Corns and calluses are hard or thick areas of skin that can be painful. They're not often serious. There are things you can try to ease them yourself.**

Check if you have a corn or callus
----------------------------------

You mostly get corns and calluses on your feet, toes and hands.

![Image 1: A corn on the toe of a person with white skin. There's a small, round, pink lump of hard skin with dry skin in the middle.](https://assets.nhs.uk/nhsuk-cms/images/2F66NY0_copy.width-320.png)

Corns are small lumps of hard skin.

![Image 2: Calluses on the feet of a person with white skin. There are rough, yellow patches of skin on the balls of both feet.](https://assets.nhs.uk/nhsuk-cms/images/A_1218_Callus_on_plantar_feet_D6WMJA.width-320.jpg)

Calluses are larger patches of rough, thick skin.

![Image 3: A corn on the toe of a person with dark brown skin. There's a small, round, skin-coloured lump with darker skin around it.](https://assets.nhs.uk/nhsuk-cms/images/VID_1400.width-320.png)

Corns and calluses can also be tender or painful.

What you can do about corns and calluses
----------------------------------------

Information:

If you have diabetes, heart disease or problems with your circulation, do not try to treat corns and calluses yourself.

These conditions can make foot problems more serious. See a GP or foot specialist.

Corns and calluses are not often serious.

There are some things you can try to get rid of them yourself and stop them coming back.

### Do

*   wear thick, cushioned socks
    
*   wear wide, comfortable shoes with a low heel and soft sole that do not rub
    
*   use soft insoles or heel pads in your shoes
    
*   soak corns and calluses in warm water to soften them
    
*   regularly use a pumice stone or foot file to remove hard skin
    
*   moisturise to help keep skin soft
    

### Don’t

*   do not try to cut off corns or calluses yourself
    
*   do not walk long distances or stand for long periods
    
*   do not wear high heels or tight pointy shoes
    
*   do not go barefoot
    

### A pharmacist can help with corns and calluses

You can ask a pharmacist about:

*   heel pads and insoles
*   products to treat corns and calluses
*   different types of pain relief

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Non-urgent advice: See a GP if:
-------------------------------

You think you have a corn or callus and:

*   you have diabetes
*   you have heart disease or problems with your circulation
*   it bleeds, or has any pus or discharge
*   it has not improved after treating it at home for 3 weeks
*   the pain is severe or stopping you doing your normal activities

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

Treatment for corns and calluses
--------------------------------

A GP can check if you have a corn or callus.

They might:

*   give you antibiotics if a corn or callus is infected
*   refer you to a foot specialist if they think you need further treatment

### Treatment from a foot specialist

A foot specialist, such as a podiatrist, may be able to offer treatments such as:

*   cutting away the corn or callus
*   patches to help soften the hard skin so it can be removed
*   specially made soft pads or insoles to take pressure off the painful area of your foot

Referral to a podiatrist on the NHS may not be available to everyone and waiting times can be long. You can pay to see a podiatrist privately.

[Find a podiatrist](https://www.nhs.uk/service-search/other-health-services/podiatrists-and-chiropodists)

Information:

### Self-refer to a podiatrist

If you have corns or calluses, you might be able to refer yourself directly to a podiatrist without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS podiatrists near you

Common causes of corns or calluses
----------------------------------

Corns and calluses are caused by pressure or rubbing of the skin on the hands or feet.

For example, from:

*   wearing high heels, uncomfortable shoes or shoes that are the wrong size
*   not wearing socks with shoes
*   lifting heavy weights
*   playing a musical instrument

Page last reviewed: 24 August 2022  
Next review due: 24 August 2025
