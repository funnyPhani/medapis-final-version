Title: Actinomycosis

URL Source: https://www.nhs.uk/conditions/actinomycosis/

Published Time: 21 Nov 2017, 10:51 a.m.

Markdown Content:
**Actinomycosis is a rare type of bacterial infection. It can be very serious but can usually be treated with antibiotics.**

How you get actinomycosis
-------------------------

The bacteria that cause actinomycosis normally live harmlessly in the body. They only cause an infection if they get into the lining of areas such as the mouth or gut.

You cannot spread the infection to other people.

Any part of the body can be infected, but the head and neck, chest, tummy and pelvis are most commonly affected.

Possible causes of actinomycosis include:

*   tooth decay and mouth infections
*   mouth injuries
*   inhaling food or liquid
*   intrauterine devices (IUDs)
*   dental or tummy surgery
*   radiotherapy

You're more likely to get actinomycosis if you have type 2 diabetes or a weakened immune system.

Symptoms of actinomycosis
-------------------------

Symptoms of actinomycosis depend on what part of the body is affected.

Actinomycosis symptoms in different areas of the body
| Area of the body | Symptoms |
| --- | --- |
| Jaw or mouth
 | Lumps in your cheek or neck, difficulty chewing, pus leaking from your skin

 |
| Lungs

 | Shortness of breath, chest pain, a cough, pus leaking from the skin on your chest

 |
| Tummy

 | Diarrhoea or constipation, pain, a lump or swelling in your tummy, pus leaking from the skin on your tummy

 |
| Pelvis

 | Pain low down in your tummy, vaginal bleeding or unusual discharge, a lump or swelling in your lower tummy

 |

Non-urgent advice: See a GP if:
-------------------------------

*   you have symptoms of actinomycosis

Treatment for actinomycosis
---------------------------

Actinomycosis is treated with antibiotics. Treatment starts off in hospital with antibiotics given directly into a vein (intravenously).

When you're well enough to go home, you'll be given antibiotic tablets to take for a few months.

It's important to keep taking antibiotics until they're finished, even when you feel better.

You might also need surgery to drain areas of pus (abscesses) and remove the surrounding area of skin if it's infected.

How to prevent actinomycosis
----------------------------

Actinomycosis is very rare, so the chances of getting it are extremely small.

You can help reduce your risk by [looking after your teeth and gums](https://www.nhs.uk/live-well/healthy-teeth-and-gums/take-care-of-your-teeth-and-gums/).

Page last reviewed: 25 July 2023  
Next review due: 25 July 2026
