Title: Hives

URL Source: https://www.nhs.uk/conditions/hives/

Published Time: 23 Oct 2017, 1:26 p.m.

Markdown Content:
Check if it's hives
-------------------

The main symptom of hives is an itchy rash.

The rash can:

*   be raised bumps or patches in many shapes and sizes
*   appear anywhere on the body
*   be on 1 area or spread across the body
*   feel itchy, sting or burn
*   look pink or red when affecting someone with white skin; the colour of the rash can be harder to see on brown and black skin

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: White skin with hives rash (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-1)
*   [2: White skin with hives rash (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-2)
*   [3: Hives rash on light brown skin (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-3)
*   [4: Hives rash on light brown skin (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-4)
*   [5: Hives rash on light brown skin (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-5)
*   [6: Dark brown skin with hives rash (thumbnail).](https://www.nhs.uk/conditions/hives/#gallery-image-6)

![Image 1: Hives rash on the thigh and hand of a child with white skin. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/C0269180-Urticaria-SPL.2e16d0ba.fill-420x280.jpg)

Long description, image 1

Hives rash on the leg and hand of a child with white skin.

The skin on most of their thigh is pink, raised and bumpy. At the side of their thigh, close to their hand, are deep creases in the skin.

Their hand is pink with some red patches between their thumb and finger and on their fingertips.

### If you're not sure it's hives

Find out about other [rashes in babies and children](https://www.nhs.uk/conditions/rashes-babies-and-children/).

A pharmacist can help with hives
--------------------------------

A pharmacist can give you advice about [antihistamine](https://www.nhs.uk/conditions/antihistamines/) treatment to help a hives rash.

Tell the pharmacist if you have a long-term condition, because you might not be able to take antihistamines.

This treatment might not be suitable for young children.

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Non-urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
--------------------------------------------------------------------------------

*   symptoms of hives do not improve after 2 days
*   you're worried about your child's hives
*   the rash is spreading
*   hives keeps coming back (you may be allergic to something)
*   you also have a high temperature and feel unwell
*   you also have swelling under your skin (this might be [angioedema](https://www.nhs.uk/conditions/angioedema/))

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 if:
---------------------------------------

*   your lips, mouth, throat or tongue suddenly become swollen
*   you're breathing very fast or struggling to breathe (you may become very wheezy or feel like you're choking or gasping for air)
*   your throat feels tight or you're struggling to swallow
*   your skin, tongue or lips turn blue, grey or pale (if you have black or brown skin, this may be easier to see on the palms of your hands or soles of your feet)
*   you suddenly become very confused, drowsy or dizzy
*   someone faints and cannot be woken up
*   a child is limp, floppy or not responding like they normally do (their head may fall to the side, backwards or forwards, or they may find it difficult to lift their head or focus on your face)

You or the person who's unwell may also have a rash that's swollen, raised or itchy.

These can be signs of a serious allergic reaction and may need immediate treatment in hospital.

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service)

Treatment for hives from a GP
-----------------------------

A GP might prescribe menthol cream, antihistamines or [steroid tablets](https://www.nhs.uk/conditions/steroid-tablets/).

If hives does not go away with treatment, you may be referred to a skin specialist (dermatologist).

You cannot always prevent hives
-------------------------------

You get hives when something causes high levels of histamine and other chemicals to be released in your skin. This is known as a trigger.

Triggers can include:

*   eating certain foods
*   contact with certain plants, animals, chemicals and latex
*   cold, such as cold water or wind
*   hot, sweaty skin from exercise, emotional stress or eating spicy food
*   a reaction to a medicine, insect bite or sting
*   scratching or pressing on your skin, such as wearing itchy or tight clothing
*   an infection
*   a problem with your immune system
*   water or sunlight, but this is rare

Try to find out what triggers hives for you, so you can avoid those triggers, if possible. This may help prevent an episode of hives.

Page last reviewed: 26 April 2024  
Next review due: 26 April 2027
