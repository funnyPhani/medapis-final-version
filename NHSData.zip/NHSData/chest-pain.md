Title: Chest pain

URL Source: https://www.nhs.uk/conditions/chest-pain/

Published Time: 18 Oct 2017, 9:06 a.m.

Markdown Content:
**Most chest pain is not a sign of anything serious but get medical advice just in case. Get immediate medical help if you think you're having a heart attack.**

Immediate action required: Call 999 if:
---------------------------------------

*   you get sudden pain or discomfort in your chest that does not go away – the pain can feel like squeezing or pressure inside your chest, burning or indigestion
*   you get pain that spreads to your left or right arm, or your neck, jaw, stomach or back
*   you have chest pain and you feel sweaty, sick, light headed or short of breath

You could be having a heart attack. Call 999 straight away as you need immediate treatment in hospital.

Non-urgent advice: See a GP if:
-------------------------------

*   you have chest pain that comes and goes
*   you have chest pain that goes away quickly but you're still worried

It's important to get medical advice to make sure it's nothing serious.

Common causes of chest pain
---------------------------

Chest pain has many different causes. In most cases, chest pain is not caused by a heart problem.

Your symptoms might give you an idea of the cause. Do not self-diagnose – see a GP if you're worried.

Chest pain symptoms and possible causes
| Chest pain symptoms | Possible cause |
| --- | --- |
| Starts after eating, bringing up food or bitter tasting fluids, feeling full and bloated
 | [Heartburn](https://www.nhs.uk/conditions/heartburn-and-acid-reflux/) or [indigestion](https://www.nhs.uk/conditions/indigestion/)

 |
| Starts after chest injury or chest exercise, may get worse when you breathe in, feels better when resting the muscle

 | Chest [sprain or strain](https://www.nhs.uk/conditions/sprains-and-strains)

 |
| An often sharp, continuous pain triggered by worries or a stressful situation, heartbeat gets faster, sweating, dizziness

 | [Anxiety](https://www.nhs.uk/mental-health/conditions/generalised-anxiety-disorder/overview/), [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/overview/) or [panic attack](https://www.nhs.uk/mental-health/conditions/anxiety/)

 |
| Gets worse when you breathe in, coughing up yellow or green mucus, high temperature

 | Chest infection, [pneumonia](https://www.nhs.uk/conditions/pneumonia/) or [pleurisy](https://www.nhs.uk/conditions/pleurisy/)

 |
| Tingling feeling on skin, skin rash appears that turns into blisters

 | [Shingles](https://www.nhs.uk/conditions/shingles/)

 |

Chest pain and heart problems
-----------------------------

The most common heart problems that cause chest pain include:

*   [pericarditis](https://www.nhs.uk/conditions/pericarditis/) – which usually causes a sudden, sharp, stabbing pain that gets worse when you breathe deeply or lie down
*   [angina](https://www.nhs.uk/conditions/angina/) or a [heart attack](https://www.nhs.uk/conditions/heart-attack/) – which have similar symptoms but a heart attack is life-threatening

You're more likely to have heart problems if you're older or are at risk of [coronary heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/).

For example, you may be at risk of coronary heart disease if you:

*   smoke
*   are living with [obesity](https://www.nhs.uk/conditions/obesity/)
*   have [high blood pressure](https://www.nhs.uk/conditions/high-blood-pressure-hypertension/), [diabetes](https://www.nhs.uk/conditions/diabetes/) or [high cholesterol](https://www.nhs.uk/conditions/high-cholesterol/)
*   have a history of heart attacks or angina in family members under 60 years old

Page last reviewed: 08 August 2023  
Next review due: 08 August 2026
