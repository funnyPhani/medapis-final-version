Title: Home oxygen therapy

URL Source: https://www.nhs.uk/conditions/home-oxygen-treatment/

Published Time: 18 Oct 2017, 6:43 p.m.

Markdown Content:
**Home oxygen therapy involves breathing in air that contains more oxygen than normal through a mask or tube connected to** **a device in your home.**

Only use home oxygen therapy if your GP or specialist has prescribed it for you.

Buying oxygen online and using it without a prescription can be dangerous. It could cause damage to your brain, heart and lungs or even death.

Always follow guidance from your GP or specialist about how to use home oxygen therapy.

Who can benefit from home oxygen therapy?
-----------------------------------------

Home oxygen therapy can be useful for people who do not have enough oxygen in their blood.

It can help with conditions such as:

*   [chronic obstructive pulmonary disease (COPD)](https://www.nhs.uk/conditions/chronic-obstructive-pulmonary-disease-copd/)
*   [pulmonary fibrosis](https://www.nhs.uk/conditions/idiopathic-pulmonary-fibrosis/)
*   [heart failure](https://www.nhs.uk/conditions/heart-failure/)
*   severe long-term [asthma](https://www.nhs.uk/conditions/asthma/)
*   [pulmonary hypertension](https://www.nhs.uk/conditions/pulmonary-hypertension/)
*   [cystic fibrosis](https://www.nhs.uk/conditions/cystic-fibrosis/)
*   breathing problems caused by a combination of being [obese](https://www.nhs.uk/conditions/obesity/) and having an underlying condition

Getting assessed for home oxygen therapy
----------------------------------------

Your doctor will refer you to a specialist clinic if they think your symptoms can be helped by home oxygen therapy.

To check the amount of oxygen in your blood, you may have a blood test and an oxygen sensor may be attached to your finger or earlobe (a pulse oximetry test).

You may also be asked to do an exercise or a walking test to check if you'll benefit from home oxygen therapy.

Using home oxygen therapy
-------------------------

The main ways of using home oxygen therapy are through:

*   short tubes placed in your nostrils – this is called a nasal cannula
*   a mask over your nose and mouth

There are 3 types of devices that can be used to give you oxygen:

*   an oxygen concentrator
*   large oxygen cylinders
*   portable cylinders

An engineer will install the equipment and explain how to use it safely.

### Oxygen concentrator machine

An oxygen concentrator is recommended if you need to have oxygen for most of the day (including when you're asleep).

The machine is about the size of a bedside table and plugs into an electrical socket.

### Large oxygen cylinders

Oxygen cylinders will probably be prescribed if you only need oxygen for a short time – for example, if you need to relieve sudden periods of breathlessness.

### Portable oxygen cylinders

It may be possible to use a small, portable oxygen cylinder outside your house or when moving around at home. This is called portable oxygen or ambulatory oxygen.

Most portable oxygen cylinders weigh around 2-3kg and are small enough to fit inside a small backpack or shopping trolley. This size cylinder holds up to 3 hours' worth of oxygen.

Portable oxygen cylinders are not suitable for everyone.

Oxygen suppliers
----------------

There are 4 companies in England that provide home oxygen services for the NHS. Each covers a different geographical area. You can contact your supplier if you have a question about your device.

*   [**Air Liquide**](http://www.uk.airliquide.com/en/home-healthcare.html)**:**
    *   0808 143 9991 for London
    *   0808 143 9999 for the South West of England
*   [**Baywater Healthcare**](http://www.baywater.co.uk/)**:** covers the North West of England, Yorkshire and The Humber, West Midlands and Wales (0800 373 580)
*   [**BOC**](https://help.boconline.co.uk/kb/en)**:** covers the East of England, East Midlands and Northern Ireland
*   [**Vivisol**](https://www.vivisol.co.uk/)**:** covers the North East of England and the South East of England (0800 917 9840)

Going on holiday
----------------

As long as you're well enough to travel and you plan in advance, you should be able to go on holiday while using oxygen.

Speak to staff at your local clinic as soon as possible if you're thinking about going on holiday, particularly if you want to go abroad.

They can advise you about what you need to do to stay safe while you're away.

You will also need travel insurance.

If you're going on holiday in the UK, talk to your oxygen supplier to see if it's possible for oxygen to be delivered to your destination. Try to give them as much notice as possible.

[Find out more about going on holiday with a lung condition on the Asthma and Lung UK website](https://www.asthmaandlung.org.uk/living-with/travel/safely)

Using oxygen safely
-------------------

### Do

*   keep the room you are using the device in well ventilated
    
*   install fire alarms and smoke detectors in your home and make sure they're working
    
*   tell your local fire brigade that you have oxygen at home who can then arrange a free fire safety check
    
*   keep your device at least 3 metres away from any appliances that use an open flame, such as a gas cooker or gas fire
    
*   keep your device at least 1.5 metres away from other electrical appliances, such as a television, hair dryer or heat sources, such as radiators or electrical heaters
    

### Don’t

*   do not smoke, or let anyone smoke near you, when using your device – also smoking will make your oxygen therapy far less effective
    
*   do not use flammable liquids, such as cleaning fluid, paint thinner or aerosols when using your device
    
*   do not use oil-based emollients, such as Vaseline, when using your device as this can be a fire risk – your care team or pharmacist should be able to recommend alternative products
    

Page last reviewed: 02 August 2023  
Next review due: 02 August 2026
