Title: Androgen insensitivity syndrome

URL Source: https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/

Published Time: 20 Oct 2017, 12:58 p.m.

Markdown Content:
**Androgen insensitivity syndrome (AIS) affects the development of a person's genitals and reproductive organs.**

The 2 types of AIS are called complete androgen insensitivity syndrome (CAIS) and partial androgen insensitivity syndrome (PAIS).

The genitals of a person with CAIS appear female.

The genitals of a person with PAIS may appear as female or male. Sometimes PAIS is discovered because a baby's genitals are not as expected for a baby boy or baby girl.

There are specialist healthcare psychologists who can help people with AIS understand their bodies and sex development.

The sex development of people with AIS means they are usually unable to become pregnant or make their partner pregnant. However, there is help and advice on other ways to become parents if that is wanted.

What causes AIS?
----------------

AIS is caused by a genetic alteration that is passed along the female line to the child.

Although people with AIS have XY (usual male pattern) chromosomes, the body does not respond to testosterone (the sex hormone) fully or at all. This prevents the sex development of a typical male.

A penis does not form or is underdeveloped. This means the child's genitals may develop as female, or are underdeveloped as male.

The child may have fully or partially [undescended testicles](https://www.nhs.uk/conditions/undescended-testicles/). But there will be no womb or ovaries.

Women who carry the genetic alteration will not have AIS themselves, but there's a 1 in 4 chance each child they have will be born with AIS.

Read more about the [causes of AIS](https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/causes/).

Types of AIS
------------

There are 2 main types of AIS, which are determined by how much the body is able to use testosterone.

These are:

*   complete androgen insensitivity syndrome (CAIS) – where testosterone has no effect on sex development, so the genitals are entirely female
*   partial androgen insensitivity syndrome (PAIS) – where testosterone has some effect on sex development, so the genitals are often not as expected for boys or girls

PAIS is usually noticed at birth because the genitals appear different.

CAIS can be more difficult to spot, as the genitals usually look like those of any other girl. It's often not diagnosed until puberty, when periods do not start and pubic and underarm hair does not develop.

Read more about the [symptoms of AIS](https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/symptoms/) and [diagnosing AIS](https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/diagnosis/).

Living with AIS
---------------

Children with AIS and their parents are supported by a team of specialists, who will offer ongoing care.

The team will help you understand your child's sex development. In the case of PAIS, they will talk to you about why they recommend raising your child as a boy or a girl.

Children with PAIS will be brought up either as girls or boys, depending mostly on the extent to which their body responds to hormones (androgens), including testosterone.

You and the specialist team will decide together what you think is in the best interests of your child.

Most children with CAIS are raised as girls.

Once you have learned about your child's sex development, and understand how their body will grow and develop, the specialist team can explain the treatment options your child might have in the future.

Read more about [how AIS is treated](https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/treatment/).

Support and advice
------------------

You and your child will be offered psychological support to help you understand and cope with the diagnosis of AIS.

Children may not need psychological support while they're very young. But they will need to grow up understanding their body and how it works.

You'll be given advice about talking to your child about AIS at all ages.

You may also find it helpful to get in touch with a support group, such as [DSD Families](https://www.dsdfamilies.org/).

Gender identity and gender dysphoria
------------------------------------

Most children with AIS continue to feel they are the gender they grew up with.

In a few cases, older children and adults with AIS feel their gender identity does not match the gender they've been raised as. This is known as [gender dysphoria](https://www.nhs.uk/conditions/gender-dysphoria/).

People with gender dysphoria often have a desire to live as a member of the opposite sex or as non-binary.

They may want treatment to make their physical appearance more consistent with their gender identity or how they choose to identify.

If your child is diagnosed with AIS, you should be told about issues of gender identity.

National Congenital Anomaly and Rare Disease Registration Service
-----------------------------------------------------------------

If your child has AIS, your clinical team will pass information about them on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://digital.nhs.uk/ndrs/about/ncardrs).

The NCARDRS helps scientists look for better ways to prevent and treat AIS. You can opt out of the register at any time.

Page last reviewed: 18 March 2024  
Next review due: 18 March 2027
