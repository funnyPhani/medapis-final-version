Title: Developmental dysplasia of the hip

URL Source: https://www.nhs.uk/conditions/developmental-dysplasia-of-the-hip/

Published Time: 18 Oct 2017, 10:42 a.m.

Markdown Content:
**Developmental dysplasia of the hip (DDH) is a condition where the "ball and socket" joint of the hip does not properly form in babies and young children.**

It's sometimes called congenital dislocation of the hip, or hip dysplasia.

The hip joint attaches the thigh bone (femur) to the pelvis. The top of the femur (femoral head) is rounded, like a ball, and sits inside the cup-shaped hip socket.

In DDH, the socket of the hip is too shallow and the femoral head is not held tightly in place, so the hip joint is loose. In severe cases, the femur can come out of the socket (dislocate).

DDH may affect 1 or both hips, but it's more common in the left hip. It's also more common in:

*   girls
*   firstborn children
*   families where there have been childhood hip problems (parents, brothers or sisters)
*   babies born in the [breech position (feet or bottom downwards)](https://www.nhs.uk/pregnancy/labour-and-birth/what-happens/if-your-baby-is-breech/) after 28 weeks of pregnancy

Without early treatment, DDH may lead to:

*   problems moving around, for example a [limp](https://www.nhs.uk/conditions/limp-in-children/)
*   pain
*   [osteoarthritis](https://www.nhs.uk/conditions/osteoarthritis/) of the hip and back

With early diagnosis and treatment, children are less likely to need surgery, and more likely to develop normally.

Diagnosing DDH
--------------

Your baby's hips will be checked as part of the [newborn physical screening examination](https://www.nhs.uk/conditions/baby/newborn-screening/physical-examination/) within 72 hours of being born, and again at 6 to 8 weeks of age.

The examination involves gently moving your baby's hip joints to check if there are any problems. It should not cause them any discomfort.

If a doctor, midwife or nurse thinks your baby's hip feels unstable, they should have an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) of their hip between 4 and 6 weeks old.

Babies should also have an ultrasound scan of their hip between 4 and 6 weeks old if:

*   there have been childhood hip problems in your family
*   your baby was born in the [breech position (feet or bottom downwards)](https://www.nhs.uk/pregnancy/labour-and-birth/what-happens/if-your-baby-is-breech/) after 28 weeks of pregnancy

If you have had twins or multiples and 1 of the babies was in the breech position, each baby should have an ultrasound scan of their hips by the time they're 4 to 6 weeks old.

Sometimes a baby's hip stabilises on its own before the scan is due, but they should still be checked to make sure.

[Get help and support from the charity Steps if your baby's been diagnosed with DDH](https://www.steps-charity.org.uk/conditions/hip-dysplasia-ddh/)

Treating DDH
------------

### Pavlik harness

Babies diagnosed with DDH early in life are usually treated with a fabric splint called a Pavlik harness.

This secures both of your baby's hips in a stable position and allows them to develop normally.

![Image 1: A fabric harness around a baby's feet and legs, holding the baby's hips in an open position.](https://assets.nhs.uk/nhsuk-cms/images/C0294921.width-320.jpg)

The harness needs to be worn constantly for 6 to 12 weeks and should not be removed by anyone except a health professional.

The harness may be adjusted during follow-up appointments. Your clinician will discuss your baby's progress with you.

Your hospital will provide detailed instructions on how to look after your baby while they're wearing a Pavlik harness.

This will include information on:

*   how to change your baby's clothes without removing the harness – nappies can be worn normally
*   cleaning the harness if it's soiled – it still should not be removed, but can be cleaned with detergent and an old toothbrush or nail brush
*   positioning your baby while they sleep – they should be placed on their back and not on their side
*   how to avoid skin irritation around the straps of the harness – you may be advised to wrap some soft, hygienic material around the bands

Eventually, you may be given advice on removing and replacing the harness for short periods of time until it can be permanently removed.

You'll be encouraged to allow your baby to move freely when the harness is off. Swimming is often recommended.

### Surgery

Surgery may be needed if your baby is diagnosed with DDH after they're 6 months old, or if the Pavlik harness has not helped.

The most common surgery is called reduction. This involves placing the femoral head back into the hip socket.

Reduction surgery is done under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/) and may be done as either:

*   closed reduction – the femoral head is placed in the hip socket without making any large cuts
*   open reduction – a cut is made in the groin to allow the surgeon to place the femoral head into the hip socket

Your child may need to wear a cast for at least 12 weeks after the operation.

Their hip will be checked under general anaesthetic again after 6 weeks, to make sure it's stable and healing well.

After this investigation, your child will probably wear a cast for at least another 6 weeks to allow their hip to fully stabilise.

Some children may also require bone surgery (osteotomy) during an open reduction, or at a later date, to correct any bone deformities.

Late-stage signs of DDH
-----------------------

The newborn physical screening examination, and the infant screening examination at 6 to 8 weeks, aim to diagnose DDH early.

But sometimes hip problems can develop or show up after these checks.

It's important to contact a GP as soon as possible if you notice your child has developed any of the following symptoms:

*   1 leg cannot be moved out sideways as far as the other when you change their nappy
*   1 leg seems to be longer than the other
*   1 leg drags when they crawl
*   a limp or "waddling" walk

Your child will be referred to an orthopaedic specialist in hospital for an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) if your doctor thinks there's a problem with their hip.

Hip-healthy swaddling
---------------------

A baby's hips are naturally more flexible for a short period after birth. But if your baby spends a lot of time tightly wrapped (swaddled) with their legs straight and pressed together, there's a risk this may affect their hip development.

Using hip-healthy swaddling techniques can reduce this risk. Make sure your baby is able to move their hips and knees freely to kick.

[Find out more about hip-healthy swaddling on the International Hip Dysplasia Institute website](https://hipdysplasia.org/infant-child/hip-healthy-swaddling/)

Page last reviewed: 08 August 2022  
Next review due: 08 August 2025
