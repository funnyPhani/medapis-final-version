Title: Homeopathy

URL Source: https://www.nhs.uk/conditions/homeopathy/

Published Time: 18 Oct 2017, 4:39 p.m.

Markdown Content:
**Homeopathy is a type of complementary or alternative medicine that’s based on the use of highly diluted substances, which practitioners claim can cause the body to heal itself.**

A [2010 House of Commons Science and Technology Committee report on homeopathy](https://publications.parliament.uk/pa/cm200910/cmselect/cmsctech/45/4502.htm) said that homeopathic remedies perform no better than placebos (dummy treatments).

In 2017 NHS England said it would no longer fund homeopathy on the NHS as the lack of any evidence for its effectiveness did not justify the cost. This was backed by a High Court judgement in 2018.

What is homeopathy?
-------------------

Homeopathy is a [complementary or alternative medicine](https://www.nhs.uk/conditions/complementary-and-alternative-medicine/). This means it's different from treatments that are part of conventional Western medicine in important ways.

Homeopathy is based on a series of ideas developed in the 1790s by a German doctor called Samuel Hahnemann.

Hahnemann’s thinking was based on the belief that a substance that causes certain symptoms can also help to remove those symptoms.

A second central belief is based around a process of dilution and shaking called succussion.

Practitioners believe that the more a substance is diluted in this way, the greater its power to treat symptoms.

Many homeopathic remedies consist of substances that have been diluted many times in water until there's none, or almost none, of the original substance left.

Practitioners of homeopathy claim that it can treat an extremely wide range of conditions, including physical conditions such as asthma and psychological conditions such as depression.

Does homeopathy work?
---------------------

There's been extensive investigation of the effectiveness of homeopathy. There's no good-quality evidence that homeopathy is effective as a treatment for any health condition.

What should I expect if I try it?
---------------------------------

When you first see a homeopath, they'll usually ask you about any specific health conditions and your general wellbeing, emotional state, lifestyle and diet.

Based on this, the homeopath will decide on the course of treatment, which often takes the form of homeopathic remedies given as a pill, capsule or tincture (solution).

Your homeopath may recommend that you attend one or more follow-up appointments so the remedy's effects on your health can be assessed.

When is it used?
----------------

Homeopathy is used for an extremely wide range of health conditions. Many practitioners believe it can help with any condition.

Among the most common conditions that people seek homeopathic treatment for are:

*   asthma
*   ear infections
*   hay fever
*   mental health conditions, such as depression, stress and anxiety
*   allergies, such as food allergies
*   dermatitis (an allergic skin condition)
*   arthritis
*   high blood pressure

There's no good-quality evidence that homeopathy is an effective treatment for these or any other health conditions.

Some practitioners also claim homeopathy can prevent malaria or other diseases. There's no evidence to support this, and no scientifically plausible way that homeopathy can prevent diseases.

The National Institute for Health and Care Excellence (NICE), which advises the NHS on the use of treatments, doesn't recommend using homeopathy in the treatment of any health condition.

What are the regulation issues?
-------------------------------

There's no legal regulation of homeopathic practitioners in the UK. This means that anyone can practise as a homeopath, even if they have no qualifications or experience.

Voluntary regulation aims to protect patient safety, but it doesn't mean there's scientific evidence that a treatment is effective.

Is homeopathy safe?
-------------------

Homeopathic remedies are generally safe, and the risk of a serious adverse side effect arising from taking these remedies is thought to be small.

Some homeopathic remedies may contain substances that aren't safe or interfere with the action of other medicines.

You should talk to a GP if you take prescribed medicine and you're thinking about using homeopathy. Also see a GP if you're considering stopping prescribed treatments or avoiding procedures such as vaccination, in favour of homeopathy.

The evidence on the effects of homeopathy
-----------------------------------------

There have been several reviews of the scientific evidence on the effectiveness of homeopathy.

The most recent review, carried out by the EU in 2017, concluded that there was no evidence to show homeopathy is effective as a treatment for any health condition.

There's no evidence behind the idea that substances that cause certain symptoms can also help treat them.

Nor is there any evidence behind the idea that diluting and shaking substances in water can turn those substances into medicines.

The ideas that underpin homeopathy aren't accepted by mainstream science, and aren't consistent with long-accepted principles about the way the physical world works.

For example, many homeopathic remedies are diluted to such an extent that it's unlikely there's a single molecule of the original substance remaining in the final remedy. In cases like these, homeopathic remedies consist of nothing but water.

Some homeopaths believe that, as a result of the succussion process, the original substance leaves an imprint of itself on the water. But there's no known mechanism by which this can occur.

Some people who use homeopathy may see an improvement in their health condition as the result of a phenomenon known as the placebo effect.

If you choose health treatments that provide only a placebo effect, you may miss out on other treatments that have been proven to be more effective.

Page last reviewed: 30 April 2024  
Next review due: 30 April 2027
