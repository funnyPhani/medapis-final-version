Title: Broken or bruised ribs

URL Source: https://www.nhs.uk/conditions/broken-or-bruised-ribs/

Published Time: 17 Oct 2017, 5:44 p.m.

Markdown Content:
**Bruised or broken ribs can be very painful, but usually heal by themselves.**

Check if you have a bruised or broken rib
-----------------------------------------

Broken or bruised ribs are usually caused by a fall, a blow to the chest or severe coughing.

Symptoms include:

*   strong pain in your chest area, particularly when you breathe in or cough
*   swelling or tenderness around the affected ribs
*   sometimes bruising on the skin
*   feeling or hearing a crack if it's a broken rib

Ribs cannot be easily splinted or supported like other bones, so they're usually left to heal naturally.

There's often no need for an X-ray.

How to treat broken or bruised ribs yourself
--------------------------------------------

Broken or bruised ribs usually get better by themselves within 2 to 6 weeks.

There are things you can do to help ease pain and speed up healing.

### Do

*   use painkillers, such as [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) gel (or ibuprofen tablets if needed)
    
*   hold an ice pack (or a bag of frozen peas) wrapped in a tea towel to the affected ribs regularly in the first few days to bring down swelling
    
*   rest and take time off work if you need to
    
*   breathe normally and cough when you need to – this helps clear mucus from your lungs to prevent chest infections
    
*   hold a pillow against your chest if you need to cough
    
*   walk around and sometimes move your shoulders to help you breathe and clear mucus from your lungs
    
*   regularly take slow, deep breaths to help clear your lungs
    
*   try to sleep more upright for the first few nights
    

### Don’t

*   do not lie down or stay still for a long time
    
*   do not strain yourself or lift heavy objects
    
*   do not play any sports or do any exercise that makes your pain worse
    
*   do not smoke
    

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

You have a broken or bruised rib and:

*   your pain has not improved within a few weeks
*   you're coughing up yellow or green mucus
*   you have a very high temperature or feel hot and shivery

You might need stronger painkillers or have a chest infection that needs antibiotics.

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You have a broken or bruised rib and:

*   your injury was caused by a serious accident, such as a car accident
*   you have shortness of breath that's getting worse
*   the chest pain is getting worse
*   you have pain in your tummy or shoulder
*   you're coughing up blood

It could mean a broken rib has damaged something else, like your lung, liver or spleen.

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Page last reviewed: 10 January 2024  
Next review due: 10 January 2027
