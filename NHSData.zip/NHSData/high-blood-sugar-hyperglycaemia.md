Title: High blood sugar (hyperglycaemia)

URL Source: https://www.nhs.uk/conditions/high-blood-sugar-hyperglycaemia/

Published Time: 18 Oct 2017, 5:21 p.m.

Markdown Content:
**High blood sugar (hyperglycaemia) is where the level of sugar in your blood is too high. It mainly affects people with diabetes and can be serious if not treated.**

People with diabetes can also have blood sugar that's too low. This is called [low blood sugar (hypoglycaemia)](https://www.nhs.uk/conditions/low-blood-sugar-hypoglycaemia/).

High blood sugar levels
-----------------------

If you have diabetes, you can find out if your blood sugar level is high by having a blood sugar (blood glucose) test.

You may have regular tests by your care team or GP surgery, or you may have tests you can do at home.

Types of diabetes test and high blood sugar levels.
| Type of test | High level |
| --- | --- |
| Test done by a health professional to check your blood sugar level over the last 2 or 3 months (HbA1c test) | 48 mmol/mol or over (6.5% if you're given a percentage) |
| Test done by a health professional after not eating for a few hours (fasting glucose test) | Over 7 mmol/L |
| Home test done after waking up or before eating | Over 7 mmol/L |
| Home test done at any other time | Over 11 mmol/L |

### Important

These blood sugar levels are a guide. Your levels may be different depending on your age and the type of diabetes you have. Check with your doctor or care team.

Symptoms of high blood sugar
----------------------------

Symptoms of high blood sugar usually come on gradually and may only start when your blood sugar level gets very high.

Common symptoms include:

*   feeling very thirsty
*   peeing a lot
*   feeling weak or tired
*   blurred vision
*   losing weight

Causes of high blood sugar
--------------------------

Common causes of high blood sugar in people with diabetes include:

*   being unwell
*   feeling stressed
*   eating too much sugary or starchy food
*   being less active than usual
*   missing doses of diabetes medicine

You can also get high blood sugar if your diabetes medicine is not working well, you're taking certain medicines (such as steroids) or you recently had an operation.

How to lower your blood sugar
-----------------------------

If you have diabetes, it's important to try to stop your blood sugar level getting too high.

### Do

*   take any diabetes medicine you've been prescribed, as advised by your doctor or care team
    
*   avoid eating too much sugary or starchy food
    
*   try to find ways to manage stress
    
*   exercise regularly
    
*   lose weight if you're overweight
    
*   follow advice from your doctor or care team about what to do while you're ill (sometimes called "sick day rules")
    

### Don’t

*   do not skip or change doses of your diabetes medicine unless advised by your doctor or care team
    

Non-urgent advice: Speak to your care team or GP surgery if:
------------------------------------------------------------

*   you've tried to lower your blood sugar but your blood sugar level is still high or you still have symptoms
*   you have symptoms of high blood sugar and you have not been diagnosed with diabetes

Problems caused by high blood sugar
-----------------------------------

It's not usually a serious problem if your blood sugar is sometimes slightly high for a short time.

But high blood sugar can cause serious problems if it stays high for a long time or gets to a very high level.

It can lead to:

*   permanent damage to the nerves in your hands and feet ([peripheral neuropathy](https://www.nhs.uk/conditions/peripheral-neuropathy/))
*   permanent damage to your eyes and problems with your sight ([diabetic retinopathy](https://www.nhs.uk/conditions/diabetic-retinopathy/))
*   life-threatening conditions such as [diabetic ketoacidosis](https://www.nhs.uk/conditions/diabetic-ketoacidosis/)

If you have high blood sugar, your doctor or care team may ask you to test your blood or pee to check for ketones. A high level of ketones is a sign of diabetic ketoacidosis.

Urgent advice: Call your care team immediately or get help from NHS 111 if:
---------------------------------------------------------------------------

You think you have high blood sugar and:

*   you're feeling sick, being sick or have stomach pain
*   you're breathing more quickly than usual or your heart is beating faster than usual
*   you feel drowsy or are struggling to stay awake
*   your breath has a fruity smell (like pear drop sweets)
*   you feel confused or have difficulty concentrating
*   you have a high level of ketones in your blood or pee

These could be signs you're becoming seriously unwell.

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Page last reviewed: 26 May 2022  
Next review due: 26 May 2025
