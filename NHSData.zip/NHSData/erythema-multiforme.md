Title: Erythema multiforme

URL Source: https://www.nhs.uk/conditions/erythema-multiforme/

Published Time: 18 Oct 2017, 2:58 p.m.

Markdown Content:
**Erythema multiforme is a skin condition that can be caused by an infection or some medicines. It usually gets better on its own in 2 to 4 weeks.**

Check if it's erythema multiforme
---------------------------------

The main symptom of erythema multiforme is a rash.

![Image 1: Erythema multiforme on white skin. There are over 20 red, round spots on a hand. Some spots have pink rings around them.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_Erythema_multiforme_C0115508.width-320.jpg)

The rash usually appears on your hands and feet, and spreads to your tummy, chest, back or face. It might feel itchy or like it's burning.

![Image 2: Erythema multiforme on white skin. Close-up of a yellow and red raised spot with a pink-red ring around it.](https://assets.nhs.uk/nhsuk-cms/images/CT0DMD_copy.width-320.png)

The rash usually starts as round, slightly raised spots. Some spots develop rings around them and can turn into blisters.

![Image 3: Erythema multiforme on dark brown skin. There's a round, raised spot that's darker than the skin with a pink ring around it.](https://assets.nhs.uk/nhsuk-cms/images/A8FF21_copy.width-320.png)

Depending on your skin tone, the rash may be red, pink or purple, or it may be darker than surrounding skin.

Sometimes you can get the rash inside your mouth or on your lips, eyes, anus or genitals. This can be painful.

### Other symptoms

You may also have other symptoms such as:

*   a high temperature
*   headache
*   body aches and pains
*   feeling generally unwell

Non-urgent advice: See a GP if:
-------------------------------

*   you have symptoms of erythema multiforme
*   erythema multiforme keeps coming back

It may be possible to treat the cause of your symptoms.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

You think you have erythema multiforme and:

*   the rash is inside your mouth or on your lips, eyes, anus or genitals
*   the rash is painful
*   you're finding it difficult to eat or pee
*   you have a high temperature or body aches and pain
*   the rash appeared after your started taking a new medicine

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   you have a rash and the skin is red, swollen, blistered or peeling – redness may be harder to see on brown and black skin
*   you're wheezing
*   you get tightness in your chest or throat
*   you have trouble breathing or talking
*   your mouth, face, lips, tongue or throat start swelling

These may be signs of a serious reaction and may need immediate treatment in hospital.

[Find your nearest A&E](https://www.nhs.uk/Service-Search/other-services/Accident%20and%20emergency%20services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Treatment for erythema multiforme
---------------------------------

Erythema multiforme usually gets better on its own in 2 to 4 weeks.

Sometimes, you may need:

*   moisturisers or steroid creams to speed up recovery and help ease symptoms like itching
*   treatment for the infection that's causing it, such as antiviral medicine for a virus

Causes of erythema multiforme
-----------------------------

Erythema multiforme is usually caused by an infection, such as the herpes simplex virus (which also causes [cold sores](https://www.nhs.uk/conditions/cold-sores/)) or a bacteria that causes lung conditions like [pneumonia](https://www.nhs.uk/conditions/pneumonia/).

It can sometimes be caused by some vaccines or medicines such as [non-steroidal anti-inflammatory drugs (NSAIDs)](https://www.nhs.uk/conditions/nsaids/), antibiotics, [statins](https://www.nhs.uk/conditions/statins/) and medicines for epilepsy.

If it's caused by a medicine, you usually need to stop taking it. But do not stop taking any medicines without talking to a doctor first.

Page last reviewed: 11 April 2023  
Next review due: 11 April 2026
