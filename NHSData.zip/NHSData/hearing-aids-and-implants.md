Title: Hearing aids and implants

URL Source: https://www.nhs.uk/conditions/hearing-aids-and-implants/

Published Time: 20 Dec 2021, 10:43 p.m.

Markdown Content:
**A GP can help you get hearing aids if you think you need them.**

The earlier you get them, the more you'll get out of them – so do not wait until your hearing gets really bad before seeing a GP.

Benefits of hearing aids
------------------------

Hearing aids will not make your hearing perfect, but they make sounds louder and clearer, reducing the impact [hearing loss](https://www.nhs.uk/conditions/hearing-loss/) has on your life.

Hearing aids can:

*   help you hear everyday sounds such as the doorbell and phone
*   improve your ability to hear speech
*   make you feel more confident when talking to people and make it easier for you to follow conversations in different environments
*   help you to enjoy listening to music and the TV, at a volume that's comfortable for those around you

But hearing aids only help if you still have some hearing left, so do not put off getting help if your hearing is getting worse.

How to get hearing aids
-----------------------

See a GP if you're having problems with your hearing. They may refer you to a hearing specialist for an assessment if they think you might need a hearing aid.

If your specialist recommends hearing aids, talk to them about the different types available and which is best for you. You may be able to try a few types before choosing.

Some types may be available to use straight away. Others may need to be custom made after your ear has been measured or a cast of your ear has been taken. These will usually be ready in a few weeks.

When your hearing aid is ready, it will be programmed to suit your level of hearing loss. You'll be shown how to use it and how to look after it.

Another appointment will be arranged for a few weeks later to check how things are going.

Types of hearing aids
---------------------

A variety of hearing aids are available.

Behind the ear (BTE) hearing aids

![Image 1: A hearing aid attached behind the ear. A plastic tube connects the device behind the ear to a mould inside the ear.](https://assets.nhs.uk/nhsuk-cms/images/S_1023_Hearing-aid_C0467208.width-320.png)

Behind the ear (BTE) hearing aids are the most common type.

They're made up of a small plastic device that sits behind your ear.

This is attached with a tube to a piece of plastic that fits in your ear (an earmould) or a soft tip that goes into the opening of your ear (an open fitting).

BTE hearing aids are one of the easiest types to use and are suitable for most people with hearing loss. They're available in a range of colours.

Receiver in the ear (RITE) hearing aids

Receiver in the ear (RITE) hearing aids are similar to BTE hearing aids.

The main difference is that with RITE hearing aids, the part of the hearing aid that sits behind the ear is smaller and is connected by a thin wire to a speaker placed inside the opening of the ear.

RITE hearing aids are less visible than BTE hearing aids and are suitable for most people with hearing loss, but they can be more fiddly to use than BTE hearing aids.

In the ear (ITE) hearing aids

In the ear (ITE) hearing aids fill the area just outside the opening of your ear.

They cannot be seen from behind, unlike BTE or RITE hearing aids, but they are visible from the side.

ITE hearing aids are suitable for most people with hearing loss, although they can be trickier to use than BTE or RITE hearing aids.

In the canal (ITC) hearing aids

In the canal (ITC) hearing aids are similar to ITE aids, but are a bit smaller and just fill the opening of the ear.

They're less visible than many other types of hearing aid but can be trickier to use and are not usually powerful enough for people with severe hearing loss.

Completely in the canal (CIC) and invisible in the canal (IIC) hearing aids

Completely in the canal (CIC) and invisible in the canal (IIC) hearing aids are the smallest types available.

They fit further into the opening of your ear than ITC hearing aids and are barely visible.

But these hearing aids are not usually powerful enough for people with severe hearing loss. They're also quite fiddly and some can only be put in and taken out by a hearing aid specialist.

CROS and BiCROS hearing aids

CROS and BiCROS hearing aids can help if you've lost hearing in one ear.

They come as a pair. The hearing aid in the ear with hearing loss picks up sound and sends it to a hearing aid in your good ear. This can be done wirelessly or through a wire around the back of your neck.

Body worn hearing aids

Body worn hearing aids are made up of a small box connected to earphones.

The box can be clipped to your clothes or put inside a pocket.

This type of hearing aid may be best if you have severe hearing loss and need a powerful hearing aid, or if you find the controls on smaller hearing aids tricky to use. However, they're not commonly used and may not always be available.

Hearing aids on the NHS
-----------------------

Hearing aids are available on the NHS.

Your GP can refer you to an NHS hearing aid provider if they think you might need a hearing aid.

The benefits of getting a hearing aid on the NHS include:

*   hearing aids are provided for free as a long-term loan
*   batteries and repairs are free (there may be a charge if you lose or break your hearing aid and it needs to be replaced)
*   you do not have to pay for any follow-up appointments or aftercare

But while several modern hearing aids are available on the NHS, these are usually the behind the ear (BTE) or, very occasionally, the receiver in the ear (RITE) type. You may need to pay for private treatment if you want one of the other types.

The waiting time for getting a hearing aid on the NHS can sometimes be longer than the wait for private treatment.

Paying for hearing aids
-----------------------

If you do not mind paying for treatment, you can choose to go to a private hearing aid provider directly.

This may mean you can pick from a wider range of hearing aids, including the smaller, less visible models.

Not all hearing aids are suitable for everyone, but the hearing specialist (audiologist) will tell you which hearing aids are suitable within your budget.

If you choose to pay for private treatment:

*   make sure you research typical costs of hearing aids and any aftercare – you can pay anything from £500 to £3,500 or more for a single hearing aid
*   shop around to see what types of hearing aid are available from different providers
*   consider the cost of batteries and if you can change them easily

Batteries, repairs and replacements
-----------------------------------

If you have an NHS hearing aid, you can get free batteries and repairs from the NHS hearing aid service who fitted your hearing aids.

Ask your audiologist about how to obtain batteries and request servicing and repairs.

You may need to come in for an appointment, or you may be able to send off for batteries or a repair in the post.

Your local hearing aid service can also replace hearing aids that have been lost or damaged, although there may be a charge for this.

If you have a private hearing aid, contact your hearing aid provider if you need it repaired or replaced.

You may have to pay for this service if it's not already included in your payment plan.

Help and support if you wear hearing aids
-----------------------------------------

Adjusting to hearing aids can be difficult at first. It may take a few weeks or months to get used to them.

You'll have follow-up appointments after they're fitted to check how things are going, but get in touch with your audiologist at any point if you're having problems.

Several hearing loss organisations can also provide help and support if you're adapting to hearing loss or life with a hearing aid.

[Royal National Institute for Deaf People (RNID) has information about local support services](https://rnid.org.uk/information-and-support/local-support-services/)

Other organisations that can provide information and advice include:

*   [Hearing Link Services](https://www.hearinglink.org/)
*   [National Deaf Children's Society (NDCS)](https://www.ndcs.org.uk/)

Hearing implants
----------------

For some people, hearing aids do not help and instead they need to have a special device fitted inside or to their skull during an operation. These are known as hearing implants.

Common types of implant include bone anchored hearing aids, cochlear implants, auditory brainstem implants and middle ear implants.

Bone anchored hearing aids

![Image 2: A small, square, plastic bone anchored hearing aid attached just above and behind the ear.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_Bone-anchored-hearing-aid_M3620093.width-320.jpg)

A bone anchored hearing aid (BAHA) may be an option if you have hearing loss caused by sound being unable to reach your inner ear.

This type of hearing aid is attached to your skull during a minor operation. It picks up sound and sends it to the inner ear by vibrating the bones near your ear.

It can be clipped on and off – for example, it's removed at night and when you swim or take a shower. Some newer types are held onto the head with magnets instead of a connector through the skin.

Cochlear implants

![Image 3: A round, plastic cochlear implant device attached to the side of the head, connected to a microphone worn behind their ear.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_cochlear_implants_C0105229.width-320.jpg)

A cochlear implant may be an option if you have severe, permanent hearing loss that is not helped by hearing aids.

They work by turning sound into electrical signals and sending them to part of the inner ear called the cochlea. From here, the signals travel to the brain and are heard as sound.

The implant has 2 main parts:

*   a microphone behind the ear that picks up sound and changes it into electrical signals, which are sent along a wire to a device on the skin
*   a device placed inside the skull that picks up the electrical signals from the device on the skin and sends them along wires to the cochlea

Before having a cochlear implant, you'll have an assessment to find out if it will help. The implant will only work if the nerve that sends sound to the brain (auditory nerve) is working properly.

[RNID has more information about cochlear implants](https://rnid.org.uk/information-and-support/hearing-loss/hearing-implants/cochlear-implants/)

Auditory brainstem implants

![Image 4: A round, plastic auditory brainstem implant device attached just above and behind the ear, connected to a microphone worn behind the ear.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_Auditory-brainstem-implants_C0072702.width-320.jpg)

An auditory brainstem implant (ABI) may be an option if you have severe, permanent hearing loss and a problem with your auditory nerve.

An ABI works in a similar way to a cochlear implant, but the electrical sound signals are sent directly to the brain along wires, instead of the cochlea.

An ABI will not usually fully restore your hearing, but it can improve it to some degree.

[Hearing Link Services has more information about auditory brainstem implants](https://www.hearinglink.org/your-hearing/implants/auditory-brainstem-implants/)

Middle ear implants

A middle ear implant (MEI) may be an option if you cannot use a regular hearing aid – for example, because you're allergic to the materials they're made from or they do not fit in your ear correctly.

An MEI has 2 main parts:

*   a device attached to the skin that picks up sound and turns it into an electrical signal
*   a device under the skin that picks up these signals and sends them along a wire to the small hearing bones deep in the ear, which causes them to vibrate

Vibrating the hearing bones means that sound can travel into your inner ear and brain. This will not fully restore your hearing, but it can help make sounds louder and clearer.

[Hearing Link Services has more information about middle ear implants](https://www.hearinglink.org/your-hearing/implants/middle-ear-implants/)

Assistive listening devices (ALDs)
----------------------------------

There are many sorts of listening devices, other than hearing aids, to help boost your hearing in everyday situations in the home and out and about.

Assistive listening devices (ALDs), which can be used with a hearing aid or on their own, include:

*   personal hearing loops, like neckloops, that allow you to hear music or phone calls directly through your hearing aid
*   personal communicators (or conversation listeners): portable devices to help you hear over a long distance or in noisy places
*   TV amplifiers: devices that allow you to hear sound clearly through your hearing aid without needing to turn up the volume
*   smoke alarms appropriate for your level of hearing, such as vibrating devices

Your GP or hearing specialist will tell you about organisations that provide advice on obtaining ALDs, such as:

*   social services
*   fire service
*   [Access to Work government programme – find out more on GOV.UK](https://www.gov.uk/access-to-work)
*   [Disabled Students' Allowance government programme – find out more on GOV.UK](https://www.gov.uk/disabled-students-allowance-dsa)

Page last reviewed: 18 October 2023  
Next review due: 18 October 2026
