Title: Food poisoning

URL Source: https://www.nhs.uk/conditions/food-poisoning/

Published Time: 21 Nov 2017, 8:33 a.m.

Markdown Content:
**Food poisoning is rarely serious and usually gets better within a week. You can normally treat yourself or your child at home.**

Check if you have food poisoning
--------------------------------

Symptoms of food poisoning include:

*   feeling sick (nausea)
*   diarrhoea
*   being sick (vomiting)
*   stomach cramps
*   a high temperature of 38C or above
*   feeling generally unwell – such as feeling tired or having aches and chills

The symptoms usually start within a few days of eating the food that caused the infection.

Sometimes they start after a few hours or not for a few weeks.

How to treat food poisoning yourself
------------------------------------

You can usually treat yourself or your child at home.

The symptoms usually pass within a week.

The most important thing is to have lots of fluids, such as water or squash, to avoid dehydration.

### Important: Diarrhoea and sickness

Stay off school or work until you have not been sick or had diarrhoea for at least 2 days.

How you get food poisoning
--------------------------

Food poisoning is caused by eating something that has been contaminated with germs.

This can happen if food:

*   is not cooked or reheated thoroughly
*   is not stored correctly – for example, it's not been frozen or chilled
*   is left out for too long
*   is handled by someone who's ill or has not washed their hands
*   is eaten after its "use by" date

Any type of food can cause food poisoning.

Read tips to avoid food poisoning

Infections that cause food poisoning

Food poisoning is usually caused by:

*   campylobacter bacteria – the most common cause of food poisoning in the UK
*   salmonella bacteria
*   E. coli bacteria
*   [norovirus (vomiting bug)](https://www.nhs.uk/conditions/norovirus/)

Page last reviewed: 18 June 2021  
Next review due: 18 June 2024
