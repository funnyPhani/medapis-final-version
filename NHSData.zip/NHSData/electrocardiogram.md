Title: Electrocardiogram (ECG)

URL Source: https://www.nhs.uk/conditions/electrocardiogram/

Published Time: 18 Oct 2017, 11:18 a.m.

Markdown Content:
**An ECG (electrocardiogram) is a test that records the electrical activity of your heart, including the rate and rhythm. It's usually quick and painless.**

Why an ECG (electrocardiogram) is done
--------------------------------------

You'll usually have an ECG (electrocardiogram) if a doctor or healthcare professional thinks you're having symptoms of:

*   a heart attack
*   coronary heart disease
*   problems with how quickly or regularly your heart beats (arrhythmia)

You also may have an ECG:

*   if you've been diagnosed with a heart condition or another condition that affects how well your heart works
*   before and while taking certain medicines

Preparing for an ECG (electrocardiogram)
----------------------------------------

There are some things you can do to help you prepare for an ECG (electrocardiogram), such as:

*   wearing a top that's easy to take on and off
*   not putting body lotions, oils or talcum powder on your skin before the test
*   not eating a heavy meal or having caffeine before an exercise ECG (stress test)

Some people may also need to have their chest shaved and cleaned before the test.

Information:

Let the person doing the ECG know if you'd like someone else to be in the room with you (a chaperone). This could be someone you know, another nurse or a trained member of staff.

What happens during an ECG (electrocardiogram)
----------------------------------------------

An ECG (electrocardiogram) is done by a specially trained healthcare professional at a hospital, clinic or GP surgery.

There are 3 different ways an ECG may be done:

*   while resting
*   over a period of time, while wearing a portable ECG
*   while doing exercise or after being given medicine that changes your heart rate (stress test)

The type of ECG you have will depend on your symptoms or condition. The doctor or specialist will explain which you will have and why.

How a resting ECG is done

1.  You'll be asked to take off the clothes on the top half of your body, behind a screen.
2.  You'll be asked you to lie back and the healthcare professional will attach sticky patches (called electrodes) on your arms, legs and chest. These are attached to the ECG machine.
3.  You'll need to lie still for a few minutes while the ECG machine records the electrical signals that are created when your heart beats.
4.  The healthcare professional will remove the sticky patches from your skin. You might feel some slight discomfort when the patches are taken off your skin, a bit like when you take off a plaster.

You may get a slight rash where the patches were placed on your skin.

How a portable ECG is done

1.  You'll be asked to take off the clothes on the top half of your body, behind a screen.
2.  The healthcare professional will attach sticky patches, called electrodes, to your chest and tape them down. These are attached to a small portable ECG recorder, which you wear on a belt around your waist.
3.  You'll usually be asked to wear it for 24 to 48 hours, but it can be up to 7 days.
4.  You'll be given a date and time to take the recorder back when the test is finished so the results can be looked at by a specialist.

Information:

You cannot have a bath or shower while wearing the portable ECG recorder. You may be shown how to disconnect and reconnect it if you have to wear it for more than 24 hours.

How an exercise ECG is done

An exercise ECG (sometimes called an exercise tolerance test or stress test) will be done in hospital.

1.  You'll be asked to take off the clothes on the top half of your body, behind a screen. You may be given a hospital gown to wear.
2.  The healthcare professional will attach sticky patches, called electrodes, to your chest, which are attached to an ECG machine.
3.  You'll be asked to walk on a treadmill or cycle on an exercise bike.
4.  The exercise will start slowly and then gradually get faster and more difficult. It'll be stopped when you start having symptoms or feel too tired. It usually lasts between 40 and 60 minutes.
5.  When the test is over, the healthcare professional will remove the sticky patches from your skin. You might feel some slight discomfort when the patches are taken off, a bit like when you take off a plaster.

Information:

If you're not able to run or cycle, you'll be given a medicine that raises your heart rate instead of having to do exercise.

Getting your ECG (electrocardiogram) results
--------------------------------------------

You may get your ECG (electrocardiogram) results on the same day, but it can take a few weeks depending on the type of ECG you had.

You may need a follow-up appointment to talk about your ECG results.

If you've not heard anything after a few weeks, contact the doctor who referred you.

The GP, nurse or specialist should talk to you about your results and explain what happens next.

Sometimes you may need other tests.

Ask to talk to a healthcare professional if you have questions about your results, or do not understand them.

Page last reviewed: 09 November 2023  
Next review due: 09 November 2026
