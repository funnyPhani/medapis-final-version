Title: Cough

URL Source: https://www.nhs.uk/conditions/cough/

Published Time: 18 Oct 2017, 10:02 a.m.

Markdown Content:
**A cough will usually clear up on its own within 3 to 4 weeks.**

How you can treat a cough yourself
----------------------------------

There's usually no need to see a GP if you have a cough.

You should:

*   rest
*   drink plenty of fluids
*   try to stay at home and avoid contact with other people if you have a high temperature or you do not feel well enough to do your normal activities

You could also try:

*   [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to treat any pain
*   hot lemon and honey (not suitable for babies under 1 year old)
*   a herbal medicine called pelargonium (suitable for people aged 12 or over)

But there's limited evidence to show these work. Hot lemon with honey has a similar effect to cough medicines.

How to make a hot lemon and honey drink

1.  Squeeze half a lemon into a mug of boiled water.
2.  Add 1 to 2 teaspoons of honey.
3.  Drink while still warm (do not give hot drinks to small children).

Information:

Some medicines and herbal treatments are not safe for everyone (for example, if you're pregnant). Always check the leaflet or speak to a pharmacist before taking them.

A pharmacist can help if you have a cough
-----------------------------------------

If you have a cough, you can ask a pharmacist about:

*   cough syrup
*   cough medicine (some cough medicines should not be given to children under 12 years old)
*   cough sweets

These will not stop your cough, but may help you cough less.

Decongestants and cough medicines containing codeine will not stop your cough.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   you've had a cough for more than 3 weeks (persistent cough)
*   you're losing weight for no reason
*   you have a weakened immune system – for example, because of chemotherapy or diabetes

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   your cough is very bad or quickly gets worse – for example, you have a hacking cough or cannot stop coughing
*   you feel very unwell
*   you have chest pain
*   the side of your neck feels swollen and painful (swollen glands)
*   you find it hard to breathe
*   you're coughing up blood

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

What happens at your appointment
--------------------------------

To find out what's causing your cough, the GP might:

*   listen to your chest with a stethoscope
*   take a sample of any mucus you might be coughing up
*   order an X-ray, allergy test, or a test to see how well your lungs work
*   refer you to hospital to see a specialist, but this is rare

### Important

[Antibiotics](https://www.nhs.uk/conditions/antibiotics/) are not normally prescribed for coughs. A GP will only prescribe them if you need them – for example, if you have a bacterial infection or you're at risk of complications.

What causes coughs
------------------

Most coughs are caused by a cold or flu.

Other causes include:

*   smoking
*   heartburn (acid reflux)
*   allergies – for example, hay fever
*   infections like bronchitis or COVID-19
*   mucus dripping down the throat from the back of the nose

A cough is rarely a sign of something serious like lung cancer.

Video: Coughs
-------------

In this video, a GP describes the most common causes of coughs and how they can be treated.

Media last reviewed: 1 May 2021  
Media review due: 1 May 2024

Help us improve our website
---------------------------

Page last reviewed: 08 December 2023  
Next review due: 08 December 2026
