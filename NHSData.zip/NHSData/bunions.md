Title: Bunions

URL Source: https://www.nhs.uk/conditions/bunions/

Published Time: 21 Dec 2017, 11:43 a.m.

Markdown Content:
**Bunions are bony lumps that form on the side of the feet. Surgery is the only way to get rid of them, but there are things you can do to ease any pain they cause.**

Check if you have bunions
-------------------------

![Image 1: Bunions on both feet. There are lumps on the sides of the feet below the big toes, but the one on the right foot is bigger.](https://assets.nhs.uk/nhsuk-cms/images/ATB58F_resize.width-320.png)

The main symptoms of bunions are hard lumps on the sides of your feet, by your big toes.

![Image 2: A bunion on a person's right foot. All the toes are pointing at a 45 degree angle to the right.](https://assets.nhs.uk/nhsuk-cms/images/S_0817_bunion_C0024856.width-320.jpg)

Your big toe may point towards your other toes.

![Image 3: Bunion on right foot shown on white skin. The bunion appears swollen and red.](https://assets.nhs.uk/nhsuk-cms/images/S_0817_Hallux-valgus_C0218921.width-320.jpg)

You may have hard or swollen skin. The bunion may look red or darker than the skin around it.

You may also have pain along the side or bottom of your feet. This is usually worse when wearing shoes and walking.

If you're not sure it's a bunion

Foot symptoms and possible causes
| Foot symptoms | Possible cause |
| --- | --- |
| Red, hot, swollen skin over the affected joint that comes and goes
 | [Gout](https://www.nhs.uk/conditions/gout/)

 |
| Aching, swollen and stiff joints that are usually worse in the morning

 | [Arthritis](https://www.nhs.uk/conditions/arthritis/)

 |
| Pain, bruising and swelling after hurting your toe

 | [Broken toe](https://www.nhs.uk/conditions/broken-toe/)

 |

How to ease bunion pain yourself
--------------------------------

You cannot get rid of bunions or stop them getting worse yourself, but there are things you can do to ease any pain.

### Do

*   wear wide shoes with a low heel and soft sole
    
*   hold an ice pack (or a bag of frozen peas) wrapped in a tea towel to the bunion for up to 5 minutes at a time
    
*   try bunion pads (soft pads you put in shoes to stop them rubbing on a bunion) – you can buy these from pharmacies
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
    
*   try to lose weight if you're overweight
    

### Don’t

*   do not wear high heels or tight, pointy shoes
    

Non-urgent advice: See a GP if:
-------------------------------

*   pain from a bunion has not improved after trying home treatments for a few weeks
*   the pain is stopping you doing your normal activities
*   your bunions are getting worse
*   you have bunions and diabetes – foot problems can be more serious if you have diabetes

Treatments for bunions
----------------------

If you have bunions, a GP will look at your foot and ask you about your symptoms.

They might refer you to a foot specialist (podiatrist).

A GP or podiatrist can advise you about:

*   things you can do to ease your symptoms
*   things you can buy or have specially made to reduce bunion pain, such as insoles (orthotics), toe spacers and toe supports (splints)

You can also pay to see a foot specialist privately.

[Find a podiatrist](https://www.nhs.uk/service-search/other-health-services/podiatrists-and-chiropodists)

### Surgery

A GP may refer you for surgery if your bunions are very painful or they're having a big effect on your life.

Surgery is not done just to improve how your feet look.

What happens during bunion surgery

The most common surgery for bunions is an osteotomy.

This involves:

1.  Making a small cut in the skin over your big toe.
2.  Cutting or scraping away the bunion.
3.  Straightening your toe bone.
4.  Fixing your toe bone in place with metal screws or staples put under your skin. These are often left in permanently.

Surgery is usually done when you're asleep under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/).

Most people go home the same day.

It can take a while to recover from bunion surgery.

You'll usually need to:

*   rest and keep your feet raised as much as possible for at least 2 weeks
*   avoid driving for 6 to 8 weeks
*   stay off work for 2 to 12 weeks
*   avoid sports for 3 to 6 months

After the operation:

*   your toes might be weaker or stiffer than before
*   your toes may not be perfectly straight
*   your feet may still be painful

Bunions sometimes come back after surgery.

Information:

### Self-refer to a podiatrist

If you have bunions, you might be able to refer yourself directly to a podiatrist without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS podiatrists near you

How to prevent bunions
----------------------

The cause of bunions is not always known, but you may be more likely to get them if you wear shoes that do not fit properly.

It might help to:

*   make sure your shoes are the correct size and have enough room for your toes
*   avoid shoes with high heels or pointy toes

Page last reviewed: 12 June 2023  
Next review due: 12 June 2026
