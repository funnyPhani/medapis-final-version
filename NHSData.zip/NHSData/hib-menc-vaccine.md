Title: Hib/MenC vaccine

URL Source: https://www.nhs.uk/vaccinations/hib-menc-vaccine/

Published Time: 6 Mar 2024, 5:40 p.m.

Markdown Content:
What the Hib/MenC vaccine is for
--------------------------------

The Hib/MenC vaccine helps prevent [Haemophilus influenzae type b (Hib)](https://www.nhs.uk/conditions/hib/) and the type of [meningitis](https://www.nhs.uk/conditions/meningitis/) caused by group C bacteria.

These infections can be serious and life-threatening.

The Hib/MenC vaccine is given to 1 year old babies after they've had 3 doses of the [6-in-1 vaccine](https://www.nhs.uk/vaccinations/6-in-1-vaccine/), which also protects against Hib.

Who should have the Hib/MenC vaccine
------------------------------------

The Hib/MenC vaccine is given to babies when they're 1 year old as part of the [NHS vaccination schedule](https://www.nhs.uk/vaccinations/nhs-vaccinations-and-when-to-have-them/).

If your child has missed their Hib/MenC vaccine, contact their GP surgery.

It's best to have the Hib/MenC vaccine on time, but your child can still have it up to the age of 10 if they've had all 3 doses of the 6-in-1 vaccine.

Who cannot have the Hib/MenC vaccine
------------------------------------

Most babies and young children can have the Hib/MenC vaccine.

The only reasons they cannot have the vaccine are if either:

*   they had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a dose of the 6-in-1 vaccine
*   they've had a serious allergic reaction to an ingredient used in the Hib/MenC vaccine

Information:

### Getting vaccinated if you're unwell

Your child can have the Hib/MenC vaccine if they're unwell but do not have a high temperature.

If they have a high temperature, wait until they're feeling better before taking them to have the vaccine.

Hib/MenC vaccine ingredients
----------------------------

There is 1 type of Hib/MenC vaccine used in the UK. You can check the ingredients in the patient leaflet:

[Menitorix patient information leaflet (Electronic Medicines Compendium website; PDF only, 239KB)](https://www.medicines.org.uk/emc/files/pil.167.pdf)

How to get the Hib/MenC vaccine
-------------------------------

Your GP surgery will usually contact you about your child's Hib/MenC vaccination. This may be by letter, text, phone call or email.

It's best if your child has the Hib/MenC vaccine on time, but they can still have it up to the age of 10.

### Non-urgent advice: Speak to your GP surgery if:

*   you've not been contacted to get your child's Hib/MenC vaccine
*   your child has missed their Hib/MenC vaccination, or you're not sure if they've been vaccinated
*   your child is unwell – they may need to wait until they're feeling better before having the vaccine
*   you need to change a vaccination appointment

Your GP surgery can book or rearrange an appointment.

How the Hib/MenC vaccine is given
---------------------------------

The Hib/MenC vaccine is given as an injection into the upper arm or thigh.

Only 1 dose is needed to boost protection against Haemophilus influenzae type b (Hib) and help protect against meningitis C.

Children are also given a vaccine when they're 13 or 14 years old (school year 9 or 10) to boost protection against meningitis C.

Information:

### Having the Hib/MenC vaccine at the same time as other vaccines

The Hib/MenC vaccine can be given at the same time as other vaccines, such as the pneumococcal and MMR vaccines.

Side effects of the Hib/MenC vaccine
------------------------------------

Most side effects of the Hib/MenC vaccine are mild and do not last long.

Common side effects of the vaccine include:

*   pain and swelling where the injection was given
*   a slightly high temperature
*   feeling irritable

More serious side effects such as a severe allergic reaction are very rare. The person who vaccinates your child will be trained to deal with allergic reactions and treat them immediately.

The vaccine does not contain live bacteria, so there's no risk of getting the infections from the vaccine.
