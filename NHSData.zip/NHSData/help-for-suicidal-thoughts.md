Title: Help for suicidal thoughts

URL Source: https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/behaviours/help-for-suicidal-thoughts/

Published Time: 3 Feb 2021, 10:55 a.m.

Markdown Content:
**If you're feeling like you want to end your life, it's important to tell someone.**

Help and support is available right now if you need it. You do not have to struggle with difficult feelings alone.

Phone a helpline
----------------

These free helplines are there to help when you're feeling down or desperate.

Unless it says otherwise, they're open 24 hours a day, every day.

You can also call these helplines for advice if you're worried about someone else.

Information:

NHS 111  
**Call 111** – 24 hours every day

Information:

[Samaritans](https://www.samaritans.org/) – for everyone  
**Call 116 123**  
**Email** [jo@samaritans.org](mailto:jo@samaritans.org)

Information:

[Campaign Against Living Miserably (CALM)](https://www.thecalmzone.net/)  
**Call 0800 58 58 58** – 5pm to midnight every day  
**Visit** the [webchat page](https://www.thecalmzone.net/help/webchat/)

Information:

[Childline](https://www.childline.org.uk/) – for children and young people under 19  
**Call 0800 1111** – the number will not show up on your phone bill

Information:

[SOS Silence of Suicide](https://sossilenceofsuicide.org/) – for everyone  
**Call 0808 115 1505** – 8pm to midnight Monday to Friday, 4pm to midnight Saturday and Sunday  
**Email** [contact@sossilenceofsuicide.org](mailto:contact@sossilenceofsuicide.org)

Message a text line
-------------------

If you do not want to talk to someone over the phone, this text line is open 24 hours a day, every day.

Information:

[Shout](https://giveusashout.org/) – for everyone

**Text "SHOUT" to 85258**

Talk to someone you trust
-------------------------

Let family or friends know what's going on for you. They may be able to offer support and help keep you safe.

There's no right or wrong way to talk about suicidal feelings – starting the conversation is what's important.

Who else you can contact
------------------------

If you find it difficult to talk to someone you know, you could:

*   **call a GP** – ask for an emergency appointment
*   **call NHS 111 or** [**get help from NHS 111 online**](https://111.nhs.uk/guided-entry/mental-health-help) – they will help you find the support and help you need
*   **contact your mental health crisis team** – if you have one

### Important

Is your life in danger?
-----------------------

If you have seriously harmed yourself – for example, by taking a drug overdose – or you feel that you may be about to harm yourself, call 999 for an ambulance or go straight to A&E.

Or ask someone else to call 999 or take you to A&E.

Tips for coping right now
-------------------------

*   try not to think about the future – just focus on getting through today
*   stay away from drugs and alcohol
*   get yourself to a safe place, like a friend's house
*   be around other people
*   do something you usually enjoy, such as spending time with a pet

[See more tips from Rethink](https://www.rethink.org/advice-and-information/about-mental-illness/learn-more-about-symptoms/suicidal-thoughts-how-to-cope/)

Worried about someone else?
---------------------------

If you're worried about someone, try to get them to talk to you. Ask open-ended questions like: "How do you feel about...?"

Do not worry about having the answers. Just listening to what someone has to say and taking it seriously can be more helpful.

[See Samaritans' tips on how to support someone you're worried about](https://www.samaritans.org/how-we-can-help/if-youre-worried-about-someone-else/how-support-someone-youre-worried-about/)

[Read Rethink's advice on how to support someone who is having suicidal thoughts](https://www.rethink.org/advice-and-information/carers-hub/suicidal-thoughts-how-to-support-someone/)

Information:

**Making a safety plan**
------------------------

If you struggle with suicidal thoughts or are supporting someone else, it may help to make a safety plan to use if you need it:

*   the [Staying Safe website](https://stayingsafe.net/) provides information on how to make a safety plan, including video tutorials and online templates to guide you through the process
*   you can also get information on [planning for a mental health crisis from mental health charity Mind](https://www.mind.org.uk/information-support/guides-to-support-and-services/crisis-services/planning-for-a-crisis/)
