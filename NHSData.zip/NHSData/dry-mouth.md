Title: Dry mouth

URL Source: https://www.nhs.uk/conditions/dry-mouth/

Published Time: 18 Oct 2017, 11:58 a.m.

Markdown Content:
**A dry mouth is rarely a sign of anything serious. There are things you can do to help ease it yourself. See a GP if these do not work or you also have other symptoms.**

Causes of a dry mouth
---------------------

The main causes of a dry mouth are:

*   [dehydration](https://www.nhs.uk/conditions/dehydration/) – for example, from not drinking enough, sweating a lot or being ill
*   medicines – check the leaflet that comes with your medicine to see if dry mouth is a side effect
*   breathing through your mouth at night – this can happen if you have a blocked nose or you sleep with your mouth open
*   anxiety
*   cancer treatment ([radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) or [chemotherapy](https://www.nhs.uk/conditions/chemotherapy/))
*   [oral thrush (mouth thrush)](https://www.nhs.uk/conditions/oral-thrush-mouth-thrush/)

Sometimes a dry mouth that does not go away may be caused by a condition like [diabetes](https://www.nhs.uk/conditions/diabetes/) or [Sjögren's syndrome](https://www.nhs.uk/conditions/sjogrens-syndrome/).

How to help ease a dry mouth yourself
-------------------------------------

### Do

*   drink plenty of cold water – take regular sips during the day and keep some water by your bed at night
    
*   suck on ice cubes or ice lollies
    
*   sip on cold unsweetened drinks
    
*   chew sugar-free gum or suck on sugar-free sweets
    
*   use lip balm if your lips are also dry
    
*   brush your teeth twice a day and use alcohol-free mouthwash – you're more likely to get [tooth decay](https://www.nhs.uk/conditions/tooth-decay/) if you have a dry mouth
    

### Don’t

*   do not drink lots of alcohol, caffeine (such as tea and coffee) or fizzy drinks
    
*   do not eat foods that are acidic (like lemons), spicy, salty or sugary
    
*   do not smoke
    
*   do not sleep with dentures in
    
*   do not use acidic artificial saliva products if you have your own teeth
    
*   do not stop taking a prescribed medicine without getting medical advice first – even if you think it might be causing your symptoms
    

A pharmacist can help if you have a dry mouth
---------------------------------------------

If you have a dry mouth, ask a pharmacist about treatments you can buy to help keep your mouth moist.

You can get:

*   gels
*   sprays
*   tablets or lozenges

Not all products are suitable for everyone. Ask a pharmacist for advice about the best one for you.

If your dry mouth might be caused by a blocked nose, a pharmacist may suggest [decongestants](https://www.nhs.uk/conditions/decongestants/) to unblock it.

Non-urgent advice: See a GP if:
-------------------------------

You have a dry mouth and:

*   it makes it difficult when talking or eating
*   your mouth is still dry after trying home or pharmacy treatments for a few weeks
*   you're struggling to eat regularly
*   you're having problems with your sense of taste that are not going away
*   your mouth is painful, red, swollen or bleeding
*   you have sore white patches in your mouth
*   you think a prescribed medicine might be causing your dry mouth
*   you have other symptoms, like needing to pee a lot or dry eyes

The GP can check what the cause might be and recommend treatment for it.

A pharmacist may be able to suggest things to provide relief from your symptoms while you're waiting to talk to a GP.

Page last reviewed: 29 November 2023  
Next review due: 29 November 2026
