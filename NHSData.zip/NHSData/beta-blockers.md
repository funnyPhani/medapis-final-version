Title: Beta blockers

URL Source: https://www.nhs.uk/conditions/beta-blockers/

Published Time: 17 Oct 2017, 5:13 p.m.

Markdown Content:
**Beta blockers work mainly by slowing down the heart. They do this by blocking the action of hormones like adrenaline.**

Beta blockers usually come as tablets.

They are prescription-only medicines, which means they can only be prescribed by a GP or another suitably qualified healthcare professional.

Commonly used beta blockers include:

*   [atenolol](https://www.nhs.uk/medicines/atenolol/) (also called Tenormin)
*   [bisoprolol](https://www.nhs.uk/medicines/bisoprolol/) (also called Cardicor or Emcor)
*   [carvedilol](https://www.nhs.uk/medicines/carvedilol/)
*   [labetalol](https://www.nhs.uk/medicines/labetalol/) (also called Trandate)
*   [metoprolol](https://www.nhs.uk/medicines/metoprolol/) (also called Betaloc or Lopresor)
*   [propranolol](https://www.nhs.uk/medicines/propranolol/) (also called Inderal or Angilol)
*   [sotalol](https://www.nhs.uk/medicines/sotalol/)

Uses for beta blockers
----------------------

Beta blockers may be used to treat:

*   [angina](https://www.nhs.uk/conditions/angina/) – chest pain caused by narrowing of the arteries supplying the heart
*   [heart failure](https://www.nhs.uk/conditions/heart-failure/) – failure of the heart to pump enough blood around the body
*   [atrial fibrillation](https://www.nhs.uk/conditions/atrial-fibrillation/) – irregular heartbeat
*   [heart attack](https://www.nhs.uk/conditions/heart-attack/) – an emergency where the blood supply to the heart is suddenly blocked
*   [high blood pressure](https://www.nhs.uk/conditions/high-blood-pressure-hypertension/) – when other medicines have been tried, or in addition to other medicines

Less commonly, beta blockers are used to prevent [migraine](https://www.nhs.uk/conditions/migraine/) or treat:

*   an [overactive thyroid (hyperthyroidism)](https://www.nhs.uk/conditions/overactive-thyroid-hyperthyroidism/)
*   [anxiety](https://www.nhs.uk/mental-health/conditions/generalised-anxiety-disorder/overview/) 
*   [tremor](https://www.nhs.uk/conditions/tremor-or-shaking-hands/)
*   [glaucoma](https://www.nhs.uk/conditions/glaucoma/) – as eyedrops

There are several types of beta blocker, and each one has its own characteristics. The type prescribed for you will depend on your health condition.

Who can take beta blockers
--------------------------

Beta blockers are not suitable for everyone. Tell your doctor if you have:

*   uncontrolled heart failure
*   had an allergic reaction to a beta blocker or any other medicine in the past
*   low blood pressure or certain conditions that affect the rhythm of your heart
*   metabolic acidosis – when there's too much acid in your blood
*   lung disease or [asthma](https://www.nhs.uk/conditions/asthma/)

Tell your doctor if you're trying to get pregnant, are already pregnant or breastfeeding.

It's important not to stop taking beta blockers without seeking your doctor's advice. In some cases, suddenly stopping the medicine may make your health condition worse.

Cautions with other medicines
-----------------------------

There are some medicines that may interfere with the way that beta blockers work, including beta blocker eyedrops.

Tell your doctor if you're taking:

*   other medicines for high blood pressure. The combination with beta blockers can sometimes lower your blood pressure too much. This may make you feel dizzy or faint
*   other medicines for an irregular heartbeat such as amiodarone or flecainide
*   other medicines that can lower your blood pressure. These include some antidepressants, nitrates (for chest pain), [baclofen](https://www.nhs.uk/medicines/baclofen/) (a muscle relaxant), medicines for an enlarged prostate gland like [tamsulosin](https://www.nhs.uk/medicines/tamsulosin/), or Parkinson's disease medicines such as levodopa
*   medicines for asthma or chronic obstructive pulmonary disease (COPD)
*   medicines for diabetes, particularly insulin – beta blockers may make it more difficult to recognise the warning signs of low blood sugar
*   medicines to treat nose or sinus congestion, or other cold remedies (including those you can buy in the pharmacy)
*   medicines for allergies, such as ephedrine, noradrenaline or adrenaline
*   non-steroidal anti-inflammatory medicines (NSAIDs), such as [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/). These medicines may increase your blood pressure, so it's best to keep them to a minimum

Side effects of beta blockers
-----------------------------

Most people taking beta blockers have either no or very mild side effects that become less troublesome with time.

Contact your GP if you're having symptoms that bother you or last more than a few days.

Side effects commonly reported by people taking beta blockers include:

*   feeling tired, dizzy or lightheaded (these can be signs of a slow heart rate)
*   cold fingers or toes (beta blockers may affect the blood supply to your hands and feet)
*   difficulties sleeping or nightmares
*   difficulty getting an erection or other difficulties with sex
*   feeling sick

It happens rarely, but some people have serious side effects when taking beta blockers.

Tell a doctor straight away if you have:

*   shortness of breath and a cough that gets worse when you exercise (like walking up stairs), swollen ankles or legs, or an irregular heartbeat – these can be signs of heart problems
*   shortness of breath, wheezing and tightening of your chest – these can be signs of lung problems
*   yellowish skin or the whites of your eyes turn yellow, although this may be less obvious on brown or black skin – these can be signs of liver problems

These are not all the side effects of beta blockers. For a full list, see the leaflet inside your medicine packet.

You can report suspected side effects using the Yellow Card Scheme – [find out more on the Yellow Card website](https://yellowcard.mhra.gov.uk/).

For more information on the side effects of beta blockers, read about the specific medicine you take in our [Medicines A to Z](https://www.nhs.uk/medicines/).

Missed or extra doses
---------------------

Depending on your beta blocker, you can take it up to 4 times a day. Some must be taken once a day, others between 2 and 3 times a day. Check the information included with your medicine.

### What if I forget to take it?

If you forget to take a dose of your beta blocker, take it as soon as you remember, unless it is nearly time for your next dose. In this case, just leave out the missed dose and take your next dose as normal.

Never take 2 doses at the same time. Never take an extra dose to make up for a forgotten one.

If you often forget doses, it may help to set an alarm to remind you. You could also ask your pharmacist for advice on other ways to help you remember to take your medicine.

### What if I take too much?

If you take more than your prescribed dose, beta blockers can slow down your heart rate and make it difficult to breathe. It can also cause dizziness and trembling.

The amount of beta blocker that can lead to an overdose varies from person to person.

Call your doctor, [contact 111](https://111.nhs.uk/triage/check-your-symptoms) or [go to A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428) straight away if you take too much of your beta blocker.

Page last reviewed: 02 December 2022  
Next review due: 02 December 2025
