Title: Antifungal medicines

URL Source: https://www.nhs.uk/conditions/antifungal-medicines/

Published Time: 19 Oct 2017, 8:12 a.m.

Markdown Content:
**Antifungal medicines are used to treat fungal infections, which most commonly affect your skin, hair and nails.**

You can get some antifungal medicines from a pharmacy without needing a GP prescription.

Infections antifungals can treat
--------------------------------

Fungal infections commonly treated with antifungals include:

*   [ringworm](https://www.nhs.uk/conditions/ringworm/)
*   [athlete's foot](https://www.nhs.uk/conditions/athletes-foot/)
*   [fungal nail infection](https://www.nhs.uk/conditions/fungal-nail-infection/)
*   [vaginal thrush](https://www.nhs.uk/conditions/vaginal-thrush/)
*   some types of severe [dandruff](https://www.nhs.uk/conditions/dandruff/)

Some fungal infections can grow inside the body and need to be treated in hospital.

Examples include:

*   [aspergillosis](https://www.nhs.uk/conditions/aspergillosis/), which affects the lungs
*   fungal [meningitis](https://www.nhs.uk/conditions/meningitis/), which affects the brain

You're more at risk of getting one of these more serious fungal infections if you have a weakened immune system – for example, if you're taking medicines to suppress your immune system.

Types of antifungal medicines
-----------------------------

You can get antifungal medicines as:

*   a cream, gel, ointment or spray
*   a capsule, tablet or liquid
*   an injection
*   a pessary: a small and soft tablet you put inside the vagina

Common names for antifungal medicines include:

*   [clotrimazole](https://www.nhs.uk/medicines/clotrimazole/) (Canesten)
*   econazole
*   miconazole
*   [terbinafine](https://www.nhs.uk/medicines/terbinafine/) (Lamisil)
*   [fluconazole](https://www.nhs.uk/medicines/fluconazole/) (Diflucan)
*   [ketoconazole](https://www.nhs.uk/medicines/ketoconazole/) (Daktarin)
*   [nystatin](https://www.nhs.uk/medicines/nystatin/) (Nystan)
*   amphotericin

How antifungal medicines work
-----------------------------

Antifungal medicines work by either:

*   killing the fungus
*   preventing the fungus from growing

When to see a pharmacist or GP
------------------------------

See a pharmacist or GP if you think you have a fungal infection. They can advise you on which antifungal medicine is best for you.

If you take too much antifungal medicine, call 111 or speak to a pharmacist or GP.

If you're advised to go to hospital, take the medicine's packaging with you so the healthcare professionals who treat you know what you've taken.

Things to consider when using antifungal medicines
--------------------------------------------------

Before taking antifungal medicines, speak to a pharmacist or GP about:

*   any existing conditions or allergies that may affect your treatment for fungal infection
*   the possible side effects of antifungal medicines
*   whether the antifungal medicine may interact with other medicines you may already be taking
*   whether your antifungal medicine is suitable to take during pregnancy or while breastfeeding – many are not suitable

You can also check the patient information leaflet that comes with your antifungal medicine for more information.

Side effects of antifungal medicines
------------------------------------

Antifungal medicines may cause side effects. These are usually mild and do not last long.

They can include:

*   itching or burning
*   redness
*   feeling sick
*   tummy (abdominal) pain
*   [diarrhoea](https://www.nhs.uk/conditions/diarrhoea-and-vomiting/)
*   a rash

Occasionally, antifungal medicines may cause a more severe reaction, such as:

*   an allergic reaction – your face, neck or tongue may swell and you may have difficulty breathing
*   a severe skin reaction – such as peeling or blistering skin
*   liver damage (very rarely) – you may have loss of appetite, vomiting, nausea, [jaundice](https://www.nhs.uk/conditions/jaundice/), dark pee or pale poo, tiredness or weakness

Stop using the medicine if you have these severe side effects, and see a GP or pharmacist to find an alternative.

If you're having difficulty breathing, go to [A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428) or call 999.

Reporting side effects
----------------------

If you think a medicine has made you unwell, you can report this side effect through the [Yellow Card Scheme](https://yellowcard.mhra.gov.uk/).

Antifungal medicines for children
---------------------------------

Some antifungal medicines can be used to treat children and babies – for example, miconazole oral gel can be used for [oral thrush](https://www.nhs.uk/conditions/oral-thrush-mouth-thrush/) in babies.

But different doses are usually needed for children of different ages. Speak to a pharmacist or GP for more advice.

Page last reviewed: 03 April 2023  
Next review due: 03 April 2026
