Title: Amniocentesis

URL Source: https://www.nhs.uk/conditions/amniocentesis/

Published Time: 20 Oct 2017, 12:41 p.m.

Markdown Content:
**Amniocentesis is a test you may be offered during pregnancy to check if your baby has a genetic or chromosomal condition, such as Down's syndrome, Edwards' syndrome or Patau's syndrome.**

It involves removing and testing a small sample of cells from amniotic fluid, the fluid that surrounds the baby in the womb (uterus).

When amniocentesis is offered
-----------------------------

Amniocentesis is not offered to all pregnant women. It's only offered if there's a higher chance your baby could have a genetic condition.

This could be because:

*   an antenatal screening test has suggested your baby may be born with a condition, such as [Down's syndrome](https://www.nhs.uk/conditions/downs-syndrome/), [Edwards' syndrome](https://www.nhs.uk/conditions/edwards-syndrome/) or [Patau's syndrome](https://www.nhs.uk/conditions/pataus-syndrome/)
*   you have had a previous pregnancy that was affected by a genetic condition
*   you have a family history of a genetic condition, such as [sickle cell disease](https://www.nhs.uk/conditions/sickle-cell-disease/), [thalassaemia](https://www.nhs.uk/conditions/thalassaemia/), [cystic fibrosis](https://www.nhs.uk/conditions/cystic-fibrosis/) or [muscular dystrophy](https://www.nhs.uk/conditions/muscular-dystrophy/)

It's important to remember that you do not have to have amniocentesis if it's offered. It's up to you to decide whether you want it.

A midwife or doctor will speak to you about what the test involves and let you know what the possible benefits and risks are to help you make a decision.

[Find out about why amniocentesis is offered and deciding whether to have it](https://www.nhs.uk/conditions/amniocentesis/why-its-done/)

How amniocentesis is performed
------------------------------

Amniocentesis is usually carried out between the 15th and 20th weeks of pregnancy, but you can have it later if necessary.

It can be performed earlier, but this may increase the risk of [complications of amniocentesis](https://www.nhs.uk/conditions/amniocentesis/risks/) and is usually avoided.

During the test, a long, thin needle is inserted through your abdominal wall, guided by an ultrasound image.

The needle is passed into the amniotic sac that surrounds your baby and a small sample of amniotic fluid is removed for analysis.

The test itself usually takes about 10 minutes, although the whole consultation may take about 30 minutes.

Amniocentesis is usually described as being uncomfortable rather than painful.

Some women describe experiencing a pain similar to [period pain](https://www.nhs.uk/conditions/period-pain/) or feeling pressure when the needle is taken out.

[Find out more about what happens during amniocentesis](https://www.nhs.uk/conditions/amniocentesis/what-happens/)

Getting your results
--------------------

The first results of the test should be available within 3 working days and will tell you whether Down's syndrome, Edwards' syndrome or Patau's syndrome has been discovered.

If rarer conditions are also being tested for, it can take 3 weeks or more for the results to come back.

If your test shows that your baby has a genetic or chromosomal condition, the implications will be fully discussed with you.

There's no cure for most of the conditions amniocentesis finds, so you'll need to consider your options carefully.

You may choose to continue with your pregnancy, while gathering information about the condition so you're fully prepared.

[Find out more about having a baby that might be born with a condition](https://www.nhs.uk/pregnancy/support/having-a-baby-that-might-be-born-with-a-condition/)

Or you may consider [ending your pregnancy](https://www.nhs.uk/pregnancy/support/termination-for-foetal-anomaly/) (having a termination).

[Find out more about the results of amniocentesis](https://www.nhs.uk/conditions/amniocentesis/results/)

What are the risks of amniocentesis?
------------------------------------

Before you decide to have amniocentesis, the risks and possible complications will be discussed with you.

One of the main risks associated with amniocentesis is [miscarriage](https://www.nhs.uk/conditions/miscarriage/), which is the loss of the pregnancy in the first 23 weeks.

This is estimated to occur in up to 1 out of every 200 women who have amniocentesis.

There are also some other risks, such as infection or needing to have the procedure again because it was not possible to accurately test the first sample.

The risk of amniocentesis causing complications is higher if it's carried out before the 15th week of pregnancy, which is why the test is only done after this point.

[Find out more about the possible complications of amniocentesis](https://www.nhs.uk/conditions/amniocentesis/risks/)

What are the alternatives?
--------------------------

An alternative to amniocentesis is a test called [chorionic villus sampling (CVS)](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/).

This is where a small sample of cells from the placenta, the organ that links the mother's blood supply with her baby's, is removed for testing.

It's usually carried out between the 11th and 14th weeks of pregnancy, although it can be performed later than this if necessary.

With CVS, the risk of miscarriage is similar to the risk of miscarriage for amniocentesis (up to 1 out of every 200).

As the test can be carried out earlier, you'll have more time to consider the results.

If you're offered tests to look for a genetic or chromosomal condition in your baby, a specialist involved in carrying out the test will be able to discuss the different options with you and help you make a decision.

Page last reviewed: 12 October 2022  
Next review due: 12 October 2025
