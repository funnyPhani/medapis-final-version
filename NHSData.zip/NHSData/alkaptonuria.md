Title: Alkaptonuria

URL Source: https://www.nhs.uk/conditions/alkaptonuria/

Published Time: 24 Oct 2017, 11:34 a.m.

Markdown Content:
**Alkaptonuria, or black urine disease, is a very rare inherited disorder that prevents the body fully breaking down two protein building blocks (amino acids) called tyrosine and phenylalanine.**

It results in a build-up of a chemical called homogentisic acid in the body.

This can turn urine and parts of the body a dark colour and lead to a range of health problems over time.

Amino acids are usually broken down in a series of chemical reactions. But in alkaptonuria a substance produced along the way, homogentisic acid, cannot be broken down any further.

This is because the enzyme that normally breaks it down does not work properly. Enzymes are proteins that make chemical reactions happen.

One of the earliest signs of the condition is dark-stained nappies, as homogentisic acid causes urine to turn black when exposed to air for a few hours.

If this sign is missed or overlooked in a baby or child, the disorder may go unnoticed until adulthood, as there are usually no other noticeable symptoms until the person reaches their late 20s to early 30s.

Signs and symptoms in adults
----------------------------

Over the course of many years, homogentisic acid slowly builds up in tissues throughout the body.

It can build up in almost any area of the body, including the cartilage, tendons, bones, nails, ears and heart. It stains the tissues dark and causes a wide range of problems.

### Joints and bones

When a person with alkaptonuria reaches their 30s, they may start to experience joint problems.

Typically, they'll have lower back pain and stiffness, followed by knee, hip and shoulder pain. These are similar to the early symptoms of [osteoarthritis](https://www.nhs.uk/conditions/osteoarthritis/).

Eventually, cartilage – a tough, flexible tissue found throughout the body – may become brittle and break, leading to joint and spinal damage. Joint replacement operations may be needed.

### Eyes and ears

Many people develop brown or black spots on the whites of their eyes.

Another sign in many adults with alkaptonuria is thickening of ear cartilage. The cartilage may also look blue, grey or black. This is called ochronosis.

The earwax may be black or reddish-brown.

![Image 1: Close-up of an eye. The iris is blue, with a medium-sized pupil. There is a dark brown spot in the white of the eye, to the left of the iris, and a smaller brown dot to the right.](https://assets.nhs.uk/nhsuk-cms/images/AKU_eye.width-320.jpg)

Alkaptonuria can cause dark spots in the whites of the eyes

![Image 2: Close-up of an ear. The skin is mostly pale, with the cartilage in the outer part of the ear looking blueish-grey. Brownish-orange earwax is visible near the centre of the ear.](https://assets.nhs.uk/nhsuk-cms/images/MS_1017_alkaptonuria-ear.width-320.jpg)

Alkaptonuria can thicken the ear cartilage and make it look blue-black

### Skin and nails

Alkaptonuria can result in discoloured sweat, which can stain clothes and cause some people to have blue or black speckled areas of skin. Nails may also turn a bluish or brownish colour.

The skin colour changes are most obvious on areas exposed to the sun and where sweat glands are found – the cheeks, forehead, armpits and genital area.

### Breathing difficulties

If the bones and muscles around the lungs become stiff, it can prevent the chest expanding and lead to [shortness of breath](https://www.nhs.uk/conditions/shortness-of-breath/) or difficulty breathing.

### Heart, kidney and prostate problems

Deposits of homogentisic acid around heart valves can cause them to narrow, harden and turn brittle and black. Blood vessels can also become stiff and weaken.

This can lead to heart disease and may require heart valve replacements.

The deposits can also lead to [kidney stones](https://www.nhs.uk/conditions/kidney-stones/), [bladder stones](https://www.nhs.uk/conditions/bladder-stones/) and prostate stones.

How alkaptonuria is inherited
-----------------------------

Each cell in the body contains 23 pairs of chromosomes. These carry the genes you inherit from your parents.

One of each pair of chromosomes is inherited from each parent, which means (with the exception of the sex chromosomes) there are two copies of each gene in each cell.

The gene involved in alkaptonuria is the HGD gene. This provides instructions for making an enzyme called homogentisate oxidase, which is needed to break down homogentisic acid.

You need to inherit two copies of the faulty HGD gene (one from each parent) to develop alkaptonuria. The chances of this are slim, which is why the condition is very rare.

The parents of a person with alkaptonuria will often only carry one copy of the faulty gene themselves, which means they will not have any signs or symptoms of the condition.

How alkaptonuria is managed
---------------------------

Alkaptonuria is a lifelong condition.

A medicine called nitisinone is used to slow the advance of alkaptonuria in adults.

Painkillers and lifestyle changes may help you cope with the symptoms.

### Nitisinone

Nitisinone reduces the level of homogentisic acid in the body. It’s offered at the National Alkaptonuria Centre, the treatment centre for all alkaptonuria patients, based at Royal Liverpool University Hospital.

[Find out about the National Alkaptonuria Centre and nitisinone treatment on the Alkaptonuria Society website](https://akusociety.org/information-and-support/aku-national-aku-centre/)

### Diet

A protein-controlled diet can be useful in reducing the risk of potential side effects when taking nitisinone for alkaptonuria during adulthood. Your doctor or dietitian will assess and advise you about this.

### Exercise

If alkaptonuria causes pain and stiffness, you may think exercise will make your symptoms worse. But regular gentle exercise can actually help by building muscle and strengthening your joints.

Exercise is also good for relieving stress, losing weight and improving your posture, all of which can ease your symptoms.

But avoid exercise that puts additional strain on the joints, such as boxing, football and rugby. Gentle exercise such as yoga and pilates might help in the early stages, while cycling, walking and swimming may be more suitable for advanced alkaptonuria.

Your GP or a physiotherapist can help you come up with a suitable exercise plan to follow at home. It's important to follow this plan as there's a risk the wrong sort of exercise may damage your joints.

### Pain relief

Speak to a doctor about painkillers and other techniques to manage pain.

Find tips for managing your pain levels about with [10 ways to reduce pain](https://www.nhs.uk/live-well/pain/10-ways-to-ease-pain/).

### Emotional support

A diagnosis of alkaptonuria can be confusing and overwhelming at first. Like many people with a long-term health condition, those who find out they have alkaptonuria may feel anxious or depressed.

But there are people you can talk to who can help. Talk to your GP if you feel you need support to cope with your illness. You could also [visit the AKU Society website](http://www.akusociety.org/), a charity offering support to patients, their families and carers.

### Surgery

Sometimes surgery may be necessary if joints are damaged and need replacing, or if heart valves or vessels have hardened.

Your doctor may recommend:

*   [hip replacement](https://www.nhs.uk/conditions/hip-replacement-old/)
*   [knee replacement](https://www.nhs.uk/conditions/knee-replacement/)
*   [aortic valve replacement](https://www.nhs.uk/conditions/aortic-valve-replacement/)

Outlook
-------

People with alkaptonuria have a normal life expectancy. However, they will eventually experience symptoms, such as pain and loss of movement in the joints and spine, which can affect quality of life.

Working and carrying out strenuous physical activity will usually become very difficult, and eventually you may need mobility aids such as a wheelchair to get around.

Visit the [AKU Society website](http://www.akusociety.org/) for more information and support.

Sharing your information
------------------------

If you or your child have alkaptonuria, your clinical team will pass relevant patient information on to the National Congenital Anomaly and Rare Disease Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the NCARDRS register on GOV.UK](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet)

Page last reviewed: 10 March 2022  
Next review due: 10 March 2025
