Title: Hearing loss

URL Source: https://www.nhs.uk/conditions/hearing-loss/

Published Time: 20 Oct 2017, 10:22 a.m.

Markdown Content:
**Hearing loss is common, particularly as you get older. See a GP if you have problems with your hearing. It could be caused by something that can be easily treated.**

Signs of hearing loss
---------------------

It's not always easy to tell if you're losing your hearing.

Common signs include:

*   difficulty hearing other people clearly and misunderstanding what they say, especially in noisy places
*   asking people to repeat themselves
*   listening to music or watching TV with the volume higher than other people need
*   difficulty hearing on the phone
*   finding it hard to keep up with a conversation
*   feeling tired or stressed from having to concentrate while listening

Sometimes someone else might notice problems with your hearing before you do.

Hearing loss can affect a child's speech development and progress at school.

Information:

### Hearing loss in babies

Hearing loss can be harder to spot in babies. There is a [checklist for how a baby makes and reacts to sound on GOV.UK](https://www.gov.uk/government/publications/newborn-hearing-screening-making-sounds-checklist/newborn-hearing-screening-making-sounds-checklist) that can help you notice the signs.

Causes of hearing loss
----------------------

There are lots of possible causes of hearing loss. It may be caused by something treatable or it may be permanent.

Your symptoms may give you an idea what could be causing it. But do not self-diagnose, see a GP for advice.

Common causes of hearing loss and related symptoms.
| Symptoms | Possible cause |
| --- | --- |
| Gradual hearing loss in both ears | Aging or damage from loud noise over many years |
| Difficulty hearing in 1 ear, earache, a feeling of pressure in your ear, discharge coming out of the ear | [Ear infection](https://www.nhs.uk/conditions/ear-infections/) |
| Difficulty hearing in 1 ear, itchiness, feeling like your ear is blocked | [Earwax build-up](https://www.nhs.uk/conditions/earwax-build-up/) |
| Sudden hearing loss after an ear infection, a very loud noise or a change in air pressure (for example, from flying) | [Perforated eardrum](https://www.nhs.uk/conditions/perforated-eardrum/) |
| Sudden hearing loss along with dizziness, a spinning sensation (vertigo) or ringing in your ears (tinnitus) | [Labyrinthitis](https://www.nhs.uk/conditions/labyrinthitis/) or [Ménière's disease](https://www.nhs.uk/conditions/menieres-disease/) |

Non-urgent advice: See a GP if:
-------------------------------

*   you think your hearing is getting gradually worse
*   you've had treatment for an ear infection or earwax build-up but your hearing has not come back

You can also sometimes get a free hearing test at some pharmacies and opticians.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you have sudden hearing loss in 1 or both ears
*   your hearing has been getting worse over the last few days or weeks
*   you have hearing loss along with other symptoms, such as earache or discharge coming out of the ear

It might not be anything serious, but it's best to get help as it may need to be treated quickly.

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Treatments for hearing loss
---------------------------

Treatment for hearing loss depends on what's causing it.

Sometimes a GP may be able to treat the cause, for example:

*   an ear infection might be treated with antibiotics
*   an earwax build-up might be treated with ear drops or removed

If your hearing loss is not caused by something a GP can treat, they may refer you to a hearing specialist for further tests and treatment.

### Hearing aids and implants

If you have permanent hearing loss, a specialist will often recommend hearing aids. These will not make your hearing perfect, but they make sounds louder and clearer.

Some people may need a hearing implant. These are devices that are attached to your skull or placed deep inside your ear.

[Find out more about hearing aids and implants](https://www.nhs.uk/conditions/hearing-aids-and-implants/)

Things you can do if you have hearing loss
------------------------------------------

If you have hearing loss, there are things you can do to help you communicate with others and avoid more damage to your hearing.

### Do

*   reduce background noise or move to a quieter area when talking to other people
    
*   face people when they're talking to you, so you can see their mouth, facial expressions and gestures
    
*   ask people to repeat themselves, speak more slowly or write things down if you need to
    
*   wear ear protection when exposed to loud noises
    

### Don’t

*   do not listen to music too loudly – the volume should be just high enough for you to hear it comfortably
    
*   do not put your fingers or any objects like cotton buds in your ears, even if you think they might be blocked
    

Page last reviewed: 06 December 2021  
Next review due: 06 December 2024
