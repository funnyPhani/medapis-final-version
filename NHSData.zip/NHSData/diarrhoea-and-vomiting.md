Title: Diarrhoea and vomiting

URL Source: https://www.nhs.uk/conditions/diarrhoea-and-vomiting/

Published Time: 16 Apr 2018, 2:43 p.m.

Markdown Content:
**Diarrhoea and vomiting are common in adults, children and babies. They're often caused by a stomach bug and should stop in a few days.**

The advice is the same if you have diarrhoea and vomiting together or separately.

How to treat diarrhoea and vomiting yourself
--------------------------------------------

Diarrhoea and vomiting can usually be treated at home. The most important thing is to have lots of fluids to avoid dehydration.

### Do

*   stay at home and get plenty of rest
    
*   drink lots of fluids, such as water or squash – take small sips if you feel sick
    
*   carry on breast or bottle feeding your baby – if they're being sick, try giving small feeds more often than usual
    
*   give babies on formula or solid foods small sips of water between feeds
    
*   eat when you feel able to – it may help to avoid foods that are fatty or spicy
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) if you're in discomfort – check the leaflet before giving it to your child
    

### Don’t

*   do not have fruit juice or fizzy drinks – they can make diarrhoea worse
    
*   do not make baby formula weaker – use it at its usual strength
    
*   do not give children under 12 medicine to stop diarrhoea
    
*   do not give aspirin to children under 16
    

How long diarrhoea and vomiting last
------------------------------------

In adults and children:

*   diarrhoea usually stops within 5 to 7 days
*   vomiting usually stops in 1 or 2 days

Diarrhoea and vomiting can spread easily
----------------------------------------

Stay off school or work until you've not been sick or had diarrhoea for at least 2 days.

If you have a high temperature or do not feel well enough to do your normal activities, try to stay at home and avoid contact with other people until you feel better.

To help avoid spreading an infection:

*   [wash your hands](https://www.nhs.uk/live-well/best-way-to-wash-your-hands/) with soap and water frequently
*   wash any clothing or bedding that has poo or vomit on it separately on a hot wash
*   clean toilet seats, flush handles, taps, surfaces and door handles every day
*   do not prepare food for other people, if possible
*   do not share towels, flannels, cutlery or utensils
*   do not use a swimming pool until at least 48 hours after your symptoms stop

A pharmacist can help with diarrhoea and vomiting
-------------------------------------------------

Speak to a pharmacist if:

*   you or your child (over 5 years) have signs of [dehydration](https://www.nhs.uk/conditions/dehydration/), such as dark, smelly pee or peeing less than usual
*   you're an older person, have a weakened immune system, or have other health conditions that increase your risk of dehydration
*   you need to stop diarrhoea for a few hours

They may recommend:

*   oral rehydration powder that you mix with water to make a drink
*   medicine to stop diarrhoea for a few hours, like [loperamide](https://www.nhs.uk/medicines/loperamide/) (not suitable for children under 12)

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy)

Urgent advice: Call 111 now if:
-------------------------------

*   you're worried about a baby under 12 months
*   your child stops breast or bottle feeding while they're ill
*   a child under 5 years has signs of [dehydration](https://www.nhs.uk/conditions/dehydration/), such as fewer wet nappies
*   you or your child (over 5 years) still have signs of dehydration after using oral rehydration sachets
*   you or your child keep being sick and cannot keep fluid down
*   you or your child have bloody diarrhoea or bleeding from the bottom
*   you or your child have diarrhoea for more than 7 days or vomiting for more than 2 days

111 will tell you what to do. They can arrange a phone call from a nurse or doctor if you need one.

Immediate action required: Call 999 or go to A&E if you or your child:
----------------------------------------------------------------------

*   vomit blood or have vomit that looks like ground coffee
*   have green vomit (adults)
*   have yellow-green or green vomit (children)
*   may have swallowed something poisonous
*   have a stiff neck and pain when looking at bright lights
*   have a sudden, severe headache
*   have a sudden, severe tummy ache
*   have blue, grey, pale or blotchy skin, lips or tongue - on brown or black skin this may be easier to see on the palms of the hands or soles of the feet
*   are having severe difficulty breathing, or taking lots of quick, short breaths
*   are confused or not responding as usual

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Causes of diarrhoea and vomiting
--------------------------------

The most common causes of diarrhoea and vomiting are:

*   a stomach bug
*   [food poisoning](https://www.nhs.uk/conditions/food-poisoning/)

Other causes of diarrhoea or vomiting

**Diarrhoea can also be caused by:**

*   medicines – check the leaflet to see if it's a side effect
*   a [food intolerance](https://www.nhs.uk/conditions/food-intolerance/) or [food allergy](https://www.nhs.uk/conditions/food-allergy/)
*   [irritable bowel syndrome (IBS)](https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs/)
*   [anxiety](https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/feelings-and-symptoms/anxiety-fear-panic/)
*   [appendicitis](https://www.nhs.uk/conditions/appendicitis/)
*   [inflammatory bowel disease](https://www.nhs.uk/conditions/inflammatory-bowel-disease/)
*   [coeliac disease](https://www.nhs.uk/conditions/coeliac-disease/)
*   [diverticular disease](https://www.nhs.uk/conditions/diverticular-disease-and-diverticulitis/)
*   radiation treatment in the pelvic area

**Vomiting can also be caused by:**

*   pregnancy
*   [migraine](https://www.nhs.uk/conditions/migraine/)
*   [motion sickness](https://www.nhs.uk/conditions/motion-sickness/)
*   inner ear infections, such as [labyrinthitis](https://www.nhs.uk/conditions/labyrinthitis/)
*   medicines – check the leaflet to see if it's a side effect
*   [reflux](https://www.nhs.uk/conditions/reflux-in-babies/) – where a baby brings feeds back up ("spitting up")
*   other infections, such as a [urinary tract infection (UTI)](https://www.nhs.uk/conditions/urinary-tract-infections-utis/)

Page last reviewed: 21 December 2023  
Next review due: 21 December 2026
