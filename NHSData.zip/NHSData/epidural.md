Title: Epidural

URL Source: https://www.nhs.uk/conditions/epidural/

Published Time: 23 Oct 2017, 12:45 p.m.

Markdown Content:
**An epidural is an injection in your back to stop you feeling pain in part of your body.**

This page covers epidural anaesthesia, a type of epidural commonly given for pain relief in childbirth and in some types of surgery.

When epidurals are used
-----------------------

Epidurals can be used:

*   [during labour and childbirth](https://www.nhs.uk/pregnancy/labour-and-birth/what-happens/pain-relief-in-labour/), including caesareans
*   during some types of surgery
*   after some types of surgery

Steroid medicine can also be given with an epidural injection, to treat pain in your back or leg that's caused by sciatica, or a slipped (prolapsed) disc.

Preparing for an epidural
-------------------------

If you have any concerns or questions about having an epidural, discuss these with your doctor. Let them know about any medicines you're taking.

You may be given specific advice about eating, drinking and medicines before the epidural.

You will not be able to drive for 24 hours after having an epidural, so you'll need to arrange for someone to take you home.

How an epidural is given
------------------------

Epidurals are given by a specialist doctor called an anaesthetist.

You're usually awake during an epidural, but for some types of surgery you may have it while under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/).

*   A drip will be placed in your arm so you can be given fluids while you're having the epidural.
*   You'll be asked to sit down and lean forwards, or lie on your side with your knees up close your chest.
*   You'll be given an injection of [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) to numb the skin where the epidural will be inserted.
*   A needle is used to insert a fine plastic tube called an epidural catheter into your back (spine) near the nerves that carry pain messages to your brain.
*   The needle is then removed, leaving just the catheter in your spine.
*   You may feel mild discomfort when the epidural needle is positioned and the catheter is inserted.

The epidural can be inserted at different levels of your spine, depending on the area of your body that needs pain relief.

Pain relief medicines are then given through the catheter. These take about 20 to 30 minutes to take full effect.

Your chest, tummy and legs may feel numb while the epidural medicines are being used, and your legs may not feel as strong as usual.

While the catheter remains in your back, it can be used to top up your pain relief medicines manually or using an automatic pump.

This can be for several hours (during childbirth) or for a few days (after major surgery).

Mobile epidurals, which use a lower dose of pain relief medicines, are sometimes used in childbirth, allowing you to walk around during labour.

Recovering from an epidural
---------------------------

When the epidural is stopped, the numbness usually lasts for a few hours before its effects begin to wear off.

While the medicine wears off, you'll probably be advised to rest in a lying or sitting position until the feeling in your legs returns.

This can take a couple of hours, and you may feel a slight tingling sensation in your skin.

Tell the doctor or nurse if you feel any pain. They can give you medicines to help control it.

Do not drive, operate machinery or drink alcohol for 24 hours after having an epidural.

Risks and side effects of an epidural
-------------------------------------

Epidurals are usually safe, but there's a small risk of side effects and complications, including:

*   [low blood pressure](https://www.nhs.uk/conditions/low-blood-pressure-hypotension/), which can make you feel lightheaded or nauseous
*   temporary loss of bladder control
*   itchy skin
*   feeling sick
*   headaches
*   nerve damage

[Read more about the side effects and complications of an epidural](https://www.nhs.uk/conditions/epidural/side-effects/)

Page last reviewed: 01 February 2023  
Next review due: 01 February 2026
