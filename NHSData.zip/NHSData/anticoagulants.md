Title: Anticoagulant medicines

URL Source: https://www.nhs.uk/conditions/anticoagulants/

Published Time: 6 Feb 2018, 8:50 a.m.

Markdown Content:
**Anticoagulants are medicines that help prevent blood clots. They're given to people at a high risk of getting clots, to reduce their chances of developing serious conditions such as strokes and heart attacks.**

A [blood clot](https://www.nhs.uk/conditions/blood-clots/) is a seal created by the blood to stop bleeding from wounds. While they're useful in stopping bleeding, they can block blood vessels and stop blood flowing to organs such as the brain, heart or lungs if they form in the wrong place.

Anticoagulants work by interrupting the process involved in the formation of blood clots. They're sometimes called "blood-thinning" medicines, although they don't actually make the blood thinner.

Although they're used for similar purposes, anticoagulants are different to antiplatelet medicines, such as [low-dose aspirin](https://www.nhs.uk/medicines/low-dose-aspirin/) and [clopidogrel](https://www.nhs.uk/medicines/clopidogrel/).

Types of anticoagulants
-----------------------

The most commonly prescribed anticoagulant is [warfarin](https://www.nhs.uk/medicines/warfarin/).

Newer types of anticoagulants are also available and are becoming increasingly common. These include:

*   [rivaroxaban](https://www.nhs.uk/medicines/rivaroxaban/) (Xarelto)
*   [dabigatran](https://www.nhs.uk/medicines/dabigatran/) (Pradaxa)
*   [apixaban](https://www.nhs.uk/medicines/apixaban/) (Eliquis)
*   [edoxaban](https://www.nhs.uk/medicines/edoxaban/) (Lixiana)

Warfarin and the newer alternatives are taken as tablets or capsules. There's also an anticoagulant called heparin that can be given by injection. [Read more about heparin on the Electronic Medicines Compendium (EMC) website](https://www.medicines.org.uk/emc/ingredient/211/heparin%20sodium).

When anticoagulants are used
----------------------------

If a blood clot blocks the flow of blood through a blood vessel, the affected part of the body will become starved of oxygen and will stop working properly.

Depending on where the clot forms, this can lead to serious problems such as:

*   [strokes](https://www.nhs.uk/conditions/stroke/) or [transient ischaemic attacks](https://www.nhs.uk/conditions/transient-ischaemic-attack-tia/) ("mini-strokes")
*   [heart attacks](https://www.nhs.uk/conditions/heart-attack/)
*   [deep vein thrombosis (DVT)](https://www.nhs.uk/conditions/deep-vein-thrombosis-dvt/)
*   [pulmonary embolism](https://www.nhs.uk/conditions/pulmonary-embolism/)

Treatment with anticoagulants may be recommended if your doctor feels you're at an increased risk of developing one of these problems. This may be because you've had blood clots in the past or you've been diagnosed with a condition such as [atrial fibrillation](https://www.nhs.uk/conditions/atrial-fibrillation/) that can cause blood clots to form.

You may also be prescribed an anticoagulant if you've recently had surgery, as the period of rest and inactivity you need during your recovery can increase your risk of developing a blood clot.

Read more about [when anticoagulants are used](https://www.nhs.uk/conditions/anticoagulants/uses/).

How to take anticoagulants
--------------------------

Your doctor or nurse should tell you how much of your anticoagulant medicine to take and when to take it.

Most people need to take their tablets or capsules once or twice a day with water or food.

The length of time you need to keep taking your medicine for depends on why it's been prescribed. In many cases, treatment will be lifelong.

If you're unsure how to take your medicine, or are worried that you missed a dose or have taken too much, check the patient information leaflet that comes with it or ask your GP, anticoagulant clinic or pharmacist what to do. You can also call NHS 111 for advice.

Read more about [anticoagulant dosage](https://www.nhs.uk/conditions/anticoagulants/dosage/).

Things to consider when taking anticoagulants
---------------------------------------------

There are several things you need to be aware of when taking anticoagulant medicines.

If you're going to have surgery or a test such as an [endoscopy](https://www.nhs.uk/conditions/endoscopy/), make sure your doctor or surgeon is aware that you're taking anticoagulants, as you may have to stop taking them for a short time.

Speak to your GP, anticoagulant clinic or pharmacist before taking any other medicines, including prescription and over-the-counter medicines, as some medicines can affect how your anticoagulant works.

If you're taking warfarin, you'll also need to avoid making significant changes to what you normally eat and drink, as this can affect your medicine.

Most anticoagulant medicines aren't suitable for pregnant women. Speak to your GP or anticoagulant clinic if you become pregnant or are planning to try for a baby while taking anticoagulants.

Read more about [things to consider when taking anticoagulants](https://www.nhs.uk/conditions/anticoagulants/considerations/).

Side effects of anticoagulants
------------------------------

Like all medicines, there's a risk of experiencing side effects while taking anticoagulants.

The main side effect is that you can bleed too easily, which can cause problems such as:

*   passing [blood in your urine](https://www.nhs.uk/conditions/blood-in-urine/)
*   passing blood when you poo or having black poo
*   severe bruising
*   prolonged [nosebleeds](https://www.nhs.uk/conditions/nosebleed/)
*   bleeding gums
*   [vomiting blood](https://www.nhs.uk/conditions/vomiting-blood/) or [coughing up blood](https://www.nhs.uk/conditions/coughing-up-blood/)
*   [heavy periods](https://www.nhs.uk/conditions/heavy-periods/) in women

For most people, the benefits of taking anticoagulants will outweigh the risk of excessive bleeding.

Read more about the [side effects of anticoagulants](https://www.nhs.uk/conditions/anticoagulants/side-effects/).

Page last reviewed: 26 July 2021  
Next review due: 26 July 2024
