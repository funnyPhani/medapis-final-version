Title: Double vision

URL Source: https://www.nhs.uk/conditions/double-vision/

Published Time: 20 Oct 2017, 3:45 p.m.

Markdown Content:
**Double vision (diplopia) is not usually serious, but it's important to get it checked, even if it comes and goes.**

Check if you have double vision
-------------------------------

Double vision is when you look at 1 object but can see 2 images. It may affect 1 eye or both eyes.

Children often cannot tell if they have double vision. Signs that your child may have problems with their vision include:

*   narrowing or squinting their eyes to try to see better
*   closing 1 eye or covering 1 eye with their hand
*   turning their head in unusual ways (for example, tilting their head)
*   looking at you sideways instead of facing forward

Non-urgent advice: Go to an optician or see a GP if:
----------------------------------------------------

*   you think you or your child might have double vision, even if it comes and goes

[Find an NHS sight test](https://www.nhs.uk/service-search/find-an-NHS-sight-test/location)

What happens at your appointment
--------------------------------

If you have double vison, an optician or GP can ask about your symptoms and do some simple, painless eye tests.

They may refer you to an eye specialist in hospital for tests and treatment.

The optician can also let you know if you need to see a GP instead.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you have eye pain and double vision
*   you have double vision that has started suddenly

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   you have a severe headache or an enlarged (dilated) pupil with blurred or double vision
*   you have double vision after a head injury

Treating double vision
----------------------

Your eyecare team or GP can advise you about the best treatment for double vision once they work out the cause.

In some cases, this may be simple treatments such as eye exercises, wearing an eye patch or being prescribed glasses or contact lenses.

Some conditions that cause double vision may require eye surgery to correct the problem.

Causes of double vision
-----------------------

Double vision has many possible causes, depending on whether 1 eye or both eyes are affected.

Information:

Try covering 1 eye at a time to see if your double vision goes away.

If your double vision goes away with 1 eye covered, it's probably affecting both eyes (binocular).

If you still have double vision in the eye that is not covered, it's probably only affecting that eye (monocular).

### Double vision affecting both eyes (binocular)

Double vision affecting both eyes is usually a symptom of a [squint](https://www.nhs.uk/conditions/squint/).

This is where problems with the eye muscles or nerves cause the eyes to look in slightly different directions.

Squints are more common in children, but they do not always cause double vision. An untreated squint in children under 7 causes a [lazy eye](https://www.nhs.uk/conditions/lazy-eye/) instead.

Squints or binocular double vision in adults can be a sign of a more serious condition.

### Double vision affecting 1 eye (monocular)

Double vision affecting 1 eye is less common. It's usually caused by eye problems such as:

*   [dry eyes](https://www.nhs.uk/conditions/dry-eyes/) – where the eyes do not produce enough tears
*   [astigmatism](https://www.nhs.uk/conditions/astigmatism/) – a common condition where part of the eye is not a perfect shape
*   [cataracts](https://www.nhs.uk/conditions/cataracts/) – cloudy patches over the front of the eyes
*   keratoconus – where the clear outer layer of the eye (cornea) gets thinner and changes shape

Page last reviewed: 12 January 2024  
Next review due: 12 January 2027
