Title: Aortic valve replacement

URL Source: https://www.nhs.uk/conditions/aortic-valve-replacement/

Published Time: 20 Oct 2017, 1:19 p.m.

Markdown Content:
**An aortic valve replacement is a type of open heart surgery used to treat problems with the heart's aortic valve.**

The aortic valve controls the flow of blood out from the heart to the rest of the body.

An aortic valve replacement involves removing a faulty or damaged valve and replacing it with a new valve made from synthetic materials or animal tissue.

It's a major operation that isn't suitable for everyone and can take a long time to recover from.

When is it necessary to replace the aortic valve?
-------------------------------------------------

The aortic valve may need to be replaced for 2 reasons:

*   the valve has become narrowed (aortic stenosis) – the opening of the valve becomes smaller, obstructing the flow of blood out of the heart
*   the valve is leaky (aortic regurgitation) – the valve allows blood to flow back through into the heart

The problems can get worse over time and in severe cases can lead to life-threatening problems such as [heart failure](https://www.nhs.uk/conditions/heart-failure/) if left untreated.

There are no medicines to treat aortic valve problems, so replacing the valve will be recommended if you're at risk of serious complications but are otherwise well enough to have surgery.

[Find out more about why aortic valve replacements are carried out](https://www.nhs.uk/conditions/aortic-valve-replacement/whyitsdone/)

How is an aortic valve replacement carried out?
-----------------------------------------------

An aortic valve replacement is carried out under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/).

This means you'll be asleep during the operation and won't feel any pain while it's carried out.

During the procedure:

*   a large cut (incision) about 25cm long is made in your chest to access your heart – although sometimes a smaller cut may be made
*   your heart is stopped and a heart-lung (bypass) machine is used to take over the job of your heart during the operation
*   the damaged or faulty valve is removed and replaced with the new one
*   your heart is restarted and the opening in your chest is closed

The operation usually takes a few hours.

You'll have a discussion with your doctor or surgeon before the procedure to decide whether a synthetic or animal tissue replacement valve is most suitable for you.

[Find out what happens during an aortic valve replacement](https://www.nhs.uk/conditions/aortic-valve-replacement/what-happens/)

Recovering from an aortic valve replacement
-------------------------------------------

You'll usually need to stay in hospital for about a week after an aortic valve replacement, although it may be 2 to 3 months before you fully recover.

You should take things easy when you first get home, but you can start to gradually return to your normal activities over the next few weeks.

You'll be given specific advice about any side effects you can expect while you recover and any activities you should avoid.

You won't usually be able to drive for around 6 weeks and you'll probably need 6 to 12 weeks off work, depending on your job.

Read more about [recovering from an aortic valve replacement](https://www.nhs.uk/conditions/aortic-valve-replacement/recovery/).

Risks of an aortic valve replacement
------------------------------------

An aortic valve replacement is a big operation and, like any type of surgery, carries a risk of complications.

Some of the main risks of an aortic valve replacement include:

*   wound, lung, bladder or heart valve infections
*   [blood clots](https://www.nhs.uk/conditions/blood-clots/)
*   [strokes](https://www.nhs.uk/conditions/stroke/)
*   a temporarily [irregular heartbeat (arrhythmia)](https://www.nhs.uk/conditions/arrhythmia/)
*   reduced kidney function for a few days

The risk of dying from an aortic valve replacement is around 2%, although this risk is much smaller than that of leaving severe aortic valve problems untreated.

Most people who survive surgery have a life expectancy close to normal.

Read more about the [risks of aortic valve replacement](https://www.nhs.uk/conditions/aortic-valve-replacement/risks/).

Alternatives to an aortic valve replacement
-------------------------------------------

An aortic valve replacement is the most effective treatment for aortic valve conditions.

Alternative procedures are usually only used if open heart surgery is too risky.

Possible alternatives include:

*   transcatheter aortic valve implantation (TAVI) – the replacement valve is guided into place through the blood vessels, rather than through a large incision in the chest
*   aortic valve balloon valvuloplasty – the valve is widened using a balloon
*   sutureless aortic valve replacement – the valve is not secured using stitches (sutures) to minimise the time spent on a heart-lung machine

Read more about the [alternatives to an aortic valve replacement](https://www.nhs.uk/conditions/aortic-valve-replacement/alternatives/).

Page last reviewed: 23 December 2021  
Next review due: 23 December 2024
