Title: Acute myeloid leukaemia

URL Source: https://www.nhs.uk/conditions/acute-myeloid-leukaemia/

Published Time: 20 Oct 2017, 12:27 p.m.

Markdown Content:
**Leukaemia is cancer of the white blood cells. Acute leukaemia means it progresses quickly and aggressively, and usually requires immediate treatment.**

Acute leukaemia is classified according to the type of white blood cells affected.

The 2 main types of white blood cells are:

*   monocytes and granulocytes, which come from myeloid stem cells
*   lymphocytes, which come from lymphoid stem cells

This topic focuses on acute myeloid leukaemia (AML), which is an aggressive cancer of the monocyte or granulocyte cells.

The following types of leukaemia are covered separately:

*   [acute lymphoblastic leukaemia](https://www.nhs.uk/conditions/acute-lymphoblastic-leukaemia/)
*   [chronic myeloid leukaemia](https://www.nhs.uk/conditions/chronic-myeloid-leukaemia/)
*   [chronic lymphocytic leukaemia](https://www.nhs.uk/conditions/chronic-lymphocytic-leukaemia/)

Symptoms of AML
---------------

The [symptoms of AML](https://www.nhs.uk/conditions/acute-myeloid-leukaemia/symptoms/) usually develop over a few weeks and become worse over time.

Symptoms can include:

*   looking pale or "washed out"
*   feeling tired or weak
*   [breathlessness](https://www.nhs.uk/conditions/shortness-of-breath/)
*   frequent infections
*   unusual and frequent bruising or bleeding, such as bleeding gums or [nosebleeds](https://www.nhs.uk/conditions/nosebleed/)
*   losing weight without trying to

Seeking medical advice
----------------------

Speak to a GP if you or your child have possible symptoms of AML.

Although it's highly unlikely that leukaemia is the cause, these symptoms should be investigated.

If your GP thinks you may have leukaemia, they'll arrange [blood tests](https://www.nhs.uk/conditions/blood-tests/) to check your blood cells.

If the tests suggest there's a problem, you'll be urgently referred to a specialist in treating blood conditions (haematologist) for further tests and treatment.

[Find out more about diagnosing AML](https://www.nhs.uk/conditions/acute-myeloid-leukaemia/diagnosis/)

What causes AML?
----------------

It's not clear exactly what causes AML and, in most cases, there's no identifiable cause.

But some things can increase your risk of getting AML, including:

*   previous [chemotherapy](https://www.nhs.uk/conditions/chemotherapy/) or [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/)
*   exposure to very high levels of radiation (including previous radiotherapy treatment)
*   smoking and other exposure to benzene, a chemical used in manufacturing that's also found in cigarette smoke
*   having a blood disorder or some genetic conditions, such as [Down's syndrome](https://www.nhs.uk/conditions/downs-syndrome/)

[Find out more about the causes of AML](https://www.nhs.uk/conditions/acute-myeloid-leukaemia/causes/)

Who's affected
--------------

AML is a rare type of cancer, with around 3,100 people diagnosed with it each year in the UK.

The risk of developing AML increases with age. It's most common in people over 75.

How AML is treated
------------------

Treatment for AML needs to begin as soon as possible, as it can develop quickly.

[Chemotherapy](https://www.nhs.uk/conditions/chemotherapy/) is the main treatment for AML. It's used to kill as many leukaemia cells in your body as possible and reduce the risk of the condition coming back (relapsing).

In some cases, intensive chemotherapy and radiotherapy may be needed, in combination with a [bone marrow or stem cell transplant](https://www.nhs.uk/conditions/stem-cell-transplant/).

[Find out more about treating AML](https://www.nhs.uk/conditions/acute-myeloid-leukaemia/treatment/)

Help and support
----------------

There are organisations that offer information, advice and support if you or a family member has been diagnosed with AML.

These include:

*   [Leukaemia Care](http://www.leukaemiacare.org.uk/support-and-information/) – you can also call their freephone helpline on 08088 010 444, or email [support@leukaemiacare.org.uk](mailto:support@leukaemiacare.org.uk)
*   [Cancer Research UK](https://www.cancerresearchuk.org/about-cancer/acute-myeloid-leukaemia-aml)
*   [Macmillan Cancer Support](https://www.macmillan.org.uk/information-and-support/leukaemia/leukaemia-acute-myeloid)

Page last reviewed: 04 October 2022  
Next review due: 04 October 2025
