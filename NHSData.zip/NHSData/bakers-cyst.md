Title: Baker's cyst

URL Source: https://www.nhs.uk/conditions/bakers-cyst/

Published Time: 23 Oct 2017, 3:51 p.m.

Markdown Content:
**A Baker's cyst, also called a popliteal cyst, is a fluid-filled swelling that develops at the back of the knee.**

![Image 1: Lower legs of a person with white skin, on black background. The leg on the left has large lump at the back, below the knee.](https://assets.nhs.uk/nhsuk-cms/images/C0110412.width-320.jpg)

A Baker's cyst on a leg

It's caused when the tissue behind the knee joint becomes swollen and inflamed. The swelling and inflammation can cause:

*   pain in the knee and calf
*   a build-up of fluid around the knee
*   occasional locking or clicking in the knee joint

However, sometimes a Baker's cyst may not cause any symptoms other than the fluid-filled swelling at the back of the knee.

A Baker's cyst can sometimes burst (rupture), resulting in fluid leaking down into your calf. This can cause sharp pain, swelling and redness in your calf, but redness can be harder to see on brown and black skin.

What causes a Baker's cyst?
---------------------------

Knee damage caused by a [sports injury](https://www.nhs.uk/conditions/sports-injuries/) or a blow to the knee can lead to a Baker's cyst developing.

A Baker's cyst can also sometimes occur if you have a health condition such as:

*   [**osteoarthritis**](https://www.nhs.uk/conditions/osteoarthritis/) – usually caused by age-related "wear and tear" of joints; it particularly affects the knees, hips, hands and big toe
*   **inflammatory arthritis** – including [rheumatoid arthritis](https://www.nhs.uk/conditions/rheumatoid-arthritis/), which is a less common type of [arthritis](https://www.nhs.uk/conditions/arthritis/) and is caused by the immune system attacking the joints
*   [**gout**](https://www.nhs.uk/conditions/gout/) – a type of arthritis that usually affects the big toe and is caused by a build-up of the waste product uric acid in the blood

Baker's cysts usually develop in people aged 30 to 70, although they can affect people of any age, including children.

When to see your GP
-------------------

See your GP if you have a lump behind your knee that's causing problems and does not clear up on its own. They'll usually be able to diagnose a Baker's cyst by examining the back of your knee and asking about your symptoms.

Your GP will ask you whether you have any associated health conditions, such as [arthritis](https://www.nhs.uk/conditions/arthritis/).

Tests may be recommended to rule out other more serious conditions, such as a tumour, an aneurysm (bulge in a section of a blood vessel) or [DVT (deep vein thrombosis)](https://www.nhs.uk/conditions/deep-vein-thrombosis-dvt/) (a blood clot in one of the deep veins of the body). You may need an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) or a [MRI scan](https://www.nhs.uk/conditions/mri-scan/).

Treating a Baker's cyst
-----------------------

Treatment will not usually be necessary if you have a Baker's cyst that is not causing any symptoms.

Painkillers such as [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) and [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) can be used to reduce the swelling and relieve any pain. A knee support or an ice pack may also help. A bag of frozen peas wrapped in a tea towel works well as an ice pack.

If you have an underlying condition that's causing your cyst, it's important that the condition is properly managed. The cyst may disappear when the condition causing it has been treated.

In some cases, it may be possible to drain the cyst. Surgery may also be needed to repair any significant damage around the knee joint.

Read more about [treating a Baker's cyst](https://www.nhs.uk/conditions/bakers-cyst/treatment/).

Page last reviewed: 04 October 2021  
Next review due: 04 October 2024
