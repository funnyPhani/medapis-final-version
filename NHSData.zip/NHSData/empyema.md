Title: Empyema

URL Source: https://www.nhs.uk/conditions/empyema/

Published Time: 18 Oct 2017, 4:52 p.m.

Markdown Content:
**Empyema is the medical term for pockets of pus that have collected inside a body cavity.**

They can form if a bacterial infection is left untreated, or if it fails to fully respond to treatment.

The term empyema is most commonly used to refer to pus-filled pockets that develop in the pleural space.

This is the slim space between the outside of the lungs and the inside of the chest cavity.

Empyema is a serious condition that requires treatment. It can cause fever, chest pains, breathlessness and coughing up mucus.

Although it can occasionally be life threatening, it's not a common condition, as most bacterial infections are effectively treated with antibiotics before they get to this stage.

What causes empyema?
--------------------

The lungs and inside of the chest cavity are lined with a smooth layer called the pleura.

These layers are almost in contact, but separated by a thin space (the pleural space) filled with a small amount of lubricant called pleural fluid.

The pleural fluid can sometimes build up and become infected, and a collection of pus forms.

This can thicken and cause areas of the pleura to stick together, creating pockets of pus.

Empyema can worsen to become many more pockets of pus, with thick deposits coating the outer layer of the lungs.

These deposits prevent the lungs expanding properly.

### Pneumonia and other possible causes

The most common cause of empyema is [pneumonia](https://www.nhs.uk/conditions/pneumonia/) caused by a bacterial infection of the lungs.

An empyema can form when pneumonia fails to fully respond to treatment in a straightforward way.

Other possible causes are:

*   [bronchiectasis](https://www.nhs.uk/conditions/bronchiectasis/) – a long-term condition where the airways of the lungs become abnormally widened, leading to a build-up of mucus that can make the lungs more vulnerable to infection
*   a blood clot or another blockage – this can prevent blood flow to the lungs, causing some of the lung tissue to die (known as a pulmonary infarction)
*   surgery to the chest – empyema is a rare complication
*   an [endoscopy](https://www.nhs.uk/conditions/endoscopy/) – empyema is a rare complication
*   serious injury to the chest
*   an infection elsewhere in the body that's spread through the bloodstream
*   an infection caused by inhaled food if you have [swallowing problems](https://www.nhs.uk/conditions/swallowing-problems-dysphagia/) – this is rare
*   [tuberculosis](https://www.nhs.uk/conditions/tuberculosis-tb/) – this is rare in the UK

You're more at risk of developing an empyema if you:

*   have diabetes
*   have a weakened immune system
*   have acid reflux
*   [drink too much alcohol](https://www.nhs.uk/live-well/alcohol-advice/) or take a lot of recreational drugs

Both adults and children can be affected.

What are the symptoms?
----------------------

An empyema can be distressing and uncomfortable.

It can cause:

*   a fever and night sweats
*   a lack of energy
*   difficulty breathing
*   weight loss
*   chest pain
*   a cough and coughing up mucus containing pus

How is it diagnosed?
--------------------

An empyema is usually suspected when a person with severe pneumonia doesn't improve with treatment and they start to show some of the symptoms of empyema .

If the patient is coughing up mucus, a sample of this should be taken to be inspected under a microscope.

The type of bacteria causing the infection is identified so the most effective antibiotics can be given.

A blood sample will also be taken to count the number of white blood cells and other markers of infection.

An [X-ray](https://www.nhs.uk/conditions/x-ray/) or [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) will show whether there's a collection of fluid building up around the lungs and how much there is. If there is fluid a sample will be taken and sent for analysis.

Often a [CT scan](https://www.nhs.uk/conditions/ct-scan/) may also be used to give a more detailed assessment.

How is it treated?
------------------

### Antibiotics

Some patients will just need [antibiotics](https://www.nhs.uk/conditions/antibiotics/) given directly into a vein through a drip (intravenously).

But they may need to stay in hospital for a long period.

### Chest drain

Some patients may need both antibiotics and a chest drain.

A chest drain is a flexible plastic tube that's inserted through the chest wall and into the affected area to drain it of fluid.

The area where the tube is inserted is numbed, and the patient may also be given a light sedative before having the drain inserted.

Painkillers are given to ease any pain while the chest drain is in.

The chest tube usually stays in place until an X-ray or ultrasound scan shows all the fluid has drained from the chest and the lungs are fully expanded.

Sometimes injections may be given through the chest drain to help clear the infected pockets of pus.

The patient may need to stay in hospital until the tube is removed.

Some patients may be able to go home with the chest tube still in place, in which case a specialist nurse will offer support and advice on how to manage this at home.

The nurse will demonstrate how to position, empty and change the bag until the family or patient feels confident they can do this themselves.

For more information, read this [NHS factsheet on chest drains (PDF, 60kb)](https://www.guysandstthomas.nhs.uk/resources/patient-information/acute/chestdrain.pdf).

### Surgery to remove the lung lining

Surgery may be needed if the condition doesn't improve.

This involves making a cut in the chest to access the lungs and removing the thick layer coating the lungs so they can expand properly again.

This is only carried out if other treatments haven't worked.

Your surgeon or specialist will explain the benefits and risks of the procedure.

[Find out more about lung surgery](http://www.rbht.nhs.uk/patients/condition/lung-surgery/)

### Stoma

A chest drain isn't suitable for all patients. Some will instead opt to have an opening made in their chest, known as a stoma.

A special bag is placed over the stoma to collect the fluid that leaks from the empyema.

This is worn on the body, and may be more discreet and interfere less with your lifestyle than a chest drain.

But with modern treatments, getting a stoma is uncommon.

Page last reviewed: 12 January 2022  
Next review due: 12 January 2025
