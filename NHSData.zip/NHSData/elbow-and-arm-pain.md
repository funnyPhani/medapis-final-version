Title: Elbow and arm pain

URL Source: https://www.nhs.uk/conditions/elbow-and-arm-pain/

Published Time: 18 Oct 2017, 10:51 a.m.

Markdown Content:
**Elbow and arm pain is not usually a sign of anything serious. If it does not go away after a few weeks, see a GP.**

How you can ease elbow and arm pain yourself
--------------------------------------------

To ease elbow and arm pain, try these things for a couple of days:

*   put a heat pack or a pack of frozen peas wrapped in a tea towel on your arm – do this for 10 to 15 minutes, every few hours
*   take painkillers like [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
*   raise your arm if it's swollen

Non-urgent advice: See a GP if:
-------------------------------

*   elbow or arm pain does not go away after a few weeks

Urgent advice: Get help from NHS 111 if your arm:
-------------------------------------------------

*   hurts when you exercise but the pain goes away when you rest
*   is swollen and you have a very high temperature or feel hot and shivery

Go to an urgent treatment centre or A&E if:

*   you have severe pain in your arm and it's difficult to move
*   you've injured your arm and you heard a snapping noise or your arm has changed shape
*   your arm tingles or feels numb

Immediate action required: Call 999 if:
---------------------------------------

*   arm pain has come on suddenly and it occurs with pressure, heaviness or squeezing across your chest

This could be a sign of a [heart attack](https://www.nhs.uk/conditions/heart-attack/).

Causes of elbow and arm pain
----------------------------

Apart from an injury, these things can cause arm and elbow pain.

Do not self-diagnose. See a GP if you're worried.

Common causes of elbow and arm pain
| Main symptoms | Possible cause |
| --- | --- |
| Pain on the outside of the elbow, difficulty to fully extend the arm
 | [Tennis elbow](https://www.nhs.uk/conditions/tennis-elbow/)

 |
| Joint pain, stiffness, swelling, difficulty moving the affected area

 | [Tendonitis](https://www.nhs.uk/conditions/tendonitis/) or [bursitis](https://www.nhs.uk/conditions/bursitis/)

 |
| Pain, tenderness, bruising, swelling

 | [Sprains and strains](https://www.nhs.uk/conditions/sprains-and-strains/)

 |
| Pain, stiffness coming down from the shoulder

 | [Frozen shoulder](https://www.nhs.uk/conditions/frozen-shoulder/)

 |
| Pain and stiffness in the joints

 | [Arthritis](https://www.nhs.uk/conditions/arthritis/)

 |
| Swelling around a joint, a high temperature or feeling hot and shivery

 | Joint infection ([septic arthritis](https://www.nhs.uk/conditions/septic-arthritis/))

 |

Information:

Self-refer for treatment
------------------------

If you have elbow or arm pain, you might be able to refer yourself directly to services for help with your condition without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS treatment for elbow or arm pain near you

Page last reviewed: 26 January 2024  
Next review due: 26 January 2027
