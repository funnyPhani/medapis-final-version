Title: Acupuncture

URL Source: https://www.nhs.uk/conditions/acupuncture/

Published Time: 17 Oct 2017, 4:41 p.m.

Markdown Content:
**Acupuncture is a treatment derived from ancient Chinese medicine. Fine needles are inserted at certain sites in the body for therapeutic or preventative purposes.**

It is used in many NHS GP practices, as well as in most pain clinics and hospices in the UK.

Acupuncture is often seen as a form of [complementary or alternative medicine (CAM)](https://www.nhs.uk/conditions/complementary-and-alternative-medicine/).

How acupuncture works
---------------------

Western medical acupuncture (dry needling) is the use of acupuncture following a medical diagnosis. It involves stimulating sensory nerves under the skin and in the muscles.

This results in the body producing natural substances, such as pain-relieving endorphins. It's likely that these naturally released substances are responsible for the beneficial effects experienced with acupuncture.

A course of acupuncture is usually recommended because it can take a few sessions for you to see improvements.

Traditional acupuncture is based on the belief that an energy, or "life force", flows through the body in channels called meridians. This life force is known as Qi (pronounced "chee").

Practitioners who use acupuncture in the traditional way believe that when Qi does not flow freely through the body, this can cause illness. They also believe acupuncture can restore the flow of Qi, and so restore health.

Uses of acupuncture
-------------------

Acupuncture practitioners – sometimes called acupuncturists – use acupuncture to treat a wide range of health conditions. However, the use of acupuncture is not always based on rigorous scientific evidence.

The National Institute for Health and Care Excellence (NICE) provides guidelines for the NHS on the use of treatments and care of patients.

Currently, NICE only recommends considering acupuncture as a treatment option for:

*   chronic (long-term) pain
*   chronic [tension-type headaches](https://www.nhs.uk/conditions/tension-headaches/)
*   [migraines](https://www.nhs.uk/conditions/migraine/)
*   [prostatitis](https://www.nhs.uk/conditions/prostatitis/) symptoms
*   hiccups

Acupuncture is also often used to treat other conditions and symptoms, including:

*   joint and muscle pain
*   jaw pain
*   cancer symptoms such as pain
*   side effects of cancer treatment such as feeling or being sick from chemotherapy
*   feeling sick or being sick after surgery

However, the evidence on the effectiveness of acupuncture compared with other treatments is unclear.

Acupuncture on the NHS
----------------------

Acupuncture is sometimes available on the NHS, most often from GP surgeries or physiotherapists, although access is limited.

Most acupuncture patients pay for private treatment. The cost of acupuncture varies widely between practitioners.

If you're being treated by an acupuncture practitioner for a health condition or are considering having acupuncture, it's advisable to discuss this with your GP.

How acupuncture is performed
----------------------------

An initial acupuncture session usually lasts 20 minutes to 1 hour and involves an assessment of your general health, medical history and a physical examination, followed by insertion of the acupuncture needles.

Courses of treatment often involve several separate sessions, but this can vary.

### Insertion of the needles

![Image 1: Close up of a woman's lower back and someone putting acupuncture needles into it.](https://assets.nhs.uk/nhsuk-cms/images/AG51JA.width-320.jpg)

The needles are inserted into specific places on the body, which practitioners call acupuncture points.

During the session, you'll usually be asked to sit or lie down. You may also be asked to remove some clothes so the practitioner can access certain parts of your body.

The needles used are very fine and are usually a few centimetres long. They should be single-use, pre-sterilised needles that are disposed of immediately after use.

Acupuncture practitioners choose specific points to place the needles based on your condition. Several points may be used during a typical session, depending on the number of symptoms you have.

The needles may be inserted just under the skin, or deeper so they reach muscle. Once the needles are in place, they may be left in position for a length of time lasting from a few minutes up to around 30 minutes.

You may feel a tingling or a dull ache when the needles are inserted but you should not experience any significant pain. If you do, let your practitioner know straight away.

Acupuncture safety and regulation
---------------------------------

There's no statutory regulation of acupuncture in England.

If you choose to have acupuncture, it is recommended that you check the acupuncture practitioner is either a regulated healthcare professional such as a doctor, nurse or physiotherapist or a member of a national acupuncture organisation.

You can [find an accredited acupuncturist on the Professional Standards Authority for Health and Social Care website](https://www.professionalstandards.org.uk/check-practitioners/practitioner/acupuncturist).

When it's done by a qualified practitioner, acupuncture is generally very safe.

Some people experience mild, short-term side effects such as:

*   pain where the needles puncture the skin
*   bleeding or bruising where the needles puncture the skin
*   drowsiness
*   feeling sick
*   feeling [dizzy or faint](https://www.nhs.uk/conditions/dizziness/)

Serious side effects such as a punctured lung or infection are very rare.

If you have a bleeding disorder, such as [haemophilia](https://www.nhs.uk/conditions/haemophilia/), or are taking any medicines such as [anticoagulant medicine](https://www.nhs.uk/conditions/anticoagulants/), talk to your GP or acupuncture practitioner before you have acupuncture.

Acupuncture is also not usually advised if you have a metal [allergy](https://www.nhs.uk/conditions/allergies/) or an infection in the area where needles may be inserted.

It's generally safe to have acupuncture when you're pregnant. However, let your acupuncture practitioner know if you're pregnant because certain acupuncture points cannot be used safely during pregnancy.

Read more about [the safety of complementary therapies in pregnancy](https://www.nhs.uk/pregnancy/keeping-well/medicines/).

Page last reviewed: 28 February 2023  
Next review due: 28 February 2026
