Title: Breath-holding in babies and children

URL Source: https://www.nhs.uk/conditions/breath-holding-in-babies-and-children/

Published Time: 17 Oct 2017, 5:48 p.m.

Markdown Content:
**Breath-holding is when a baby or child stops breathing for up to 1 minute and may faint. It can happen when a child is frightened, upset, angry, or has a sudden shock or pain. It's usually harmless but can be scary for parents, particularly when it happens for the first time.**

Immediate action required: Call 999 if:
---------------------------------------

*   your child faints and cannot be woken up
*   your child is stiff, shaking or jerking (this may be a fit)
*   your child’s lips, tongue, face or skin suddenly turn pale, blue or grey (on black or brown skin this may be easier to see on the palms of the hands or the soles of the feet)

These could be symptoms of breath-holding, but could also be related to other, more serious conditions.

If a doctor has not previously told you it's breath-holding, it's important to get it checked immediately.

What happens during breath-holding
----------------------------------

During breath-holding, your child may:

*   cry and then be silent while holding their breath
*   open their mouth as if going to cry but make no sound
*   turn pale, blue or grey
*   be floppy or stiff, or their body may jerk
*   faint for 1 or 2 minutes

Your child may be sleepy or confused for a short while afterwards.

### Breath-holding is usually harmless

Breath-holding can be scary for parents, but it's usually harmless and your child should grow out of it by the age of 4 or 5.

Breath-holding episodes:

*   usually last for less than 1 minute (if the child faints, they'll usually regain consciousness within 1 or 2 minutes)
*   are not epileptic seizures

Your child is not holding their breath on purpose and cannot control what happens when they have a breath-holding episode.

What to do when a child has a breath-holding episode
----------------------------------------------------

There are some things you can do when a child has a breath-holding episode.

### Do

*   stay calm – it should pass in less than 1 minute
    
*   lie the child on their side – do not pick them up
    
*   stay with them until the episode ends
    
*   make sure they cannot hit their head, arms or legs on anything
    
*   act normally after an episode, reassure them and ensure they get plenty of rest
    

### Don’t

*   do not shake your child or splash them with water
    
*   do not put anything in their mouth (including your fingers)
    
*   do not give them mouth-to-mouth or CPR
    
*   do not tell them off (they're not doing it deliberately)
    

Non-urgent advice: See a GP if:
-------------------------------

Your child has already been diagnosed with breath-holding and:

*   has episodes more often than before or they seem worse
*   their breath-holding episodes are affecting everyday life

The GP will try to find out if there's a more serious underlying condition. They may suggest your child has an [ECG](https://www.nhs.uk/conditions/electrocardiogram/) to check their heart rhythm.

Treatments for breath-holding
-----------------------------

There's no specific treatment for breath-holding. It should eventually stop by the time your child is 4 or 5 years old.

Medicines are rarely used to treat breath-holding.

Breath-holding is sometimes related to [iron deficiency anaemia](https://www.nhs.uk/conditions/iron-deficiency-anaemia/).

Your child's blood iron levels may be checked. They may need iron supplements if their iron levels are low.

Causes of breath-holding
------------------------

Breath-holding is not something a child does deliberately.

It's usually triggered by a sudden shock or pain, or strong emotions like fear, upset or anger.

There are 2 types of breath-holding:

*   blue breath-holding spells – this is the most common type of breath-holding and happens when a child's breathing pattern changes
*   reflex anoxic seizures – this type of breath-holding happens when a child's heart rate slows down

Page last reviewed: 02 March 2023  
Next review due: 02 March 2026
