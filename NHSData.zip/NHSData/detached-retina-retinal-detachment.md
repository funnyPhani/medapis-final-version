Title: Detached retina (retinal detachment)

URL Source: https://www.nhs.uk/conditions/detached-retina-retinal-detachment/

Published Time: 11 Jan 2018, 12:23 p.m.

Markdown Content:
**A detached retina is when the thin layer at the back of your eye (retina) becomes loose. It needs to be treated quickly to stop it permanently affecting your sight.**

Check if you have a detached retina
-----------------------------------

Symptoms of a detached retina include:

*   [floaters (dots and lines) or flashes of light in your eye](https://www.nhs.uk/conditions/floaters-and-flashes-in-the-eyes/)
*   a dark "curtain" or shadow in your vision
*   changes to your eyesight, such as blurred vision

Urgent advice: Get help from NHS 111 if:
----------------------------------------

*   floaters (dots and lines) suddenly appear in your vision or suddenly increase in number
*   you get flashes of light in your vision
*   you have a dark "curtain" or shadow moving across your vision
*   your vision gets suddenly blurred

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Treatment for a detached retina
-------------------------------

You'll be referred to hospital for surgery if tests show your retina may be detached or has started to come away (retinal tear).

Surgery will usually stop your vision getting worse.

What happens during surgery for a detached retina or tear

Surgery to re-attach the retina or fix a retinal tear may involve:

*   removing and replacing the jelly inside your eye (vitrectomy)
*   attaching a small band around your eye to push the wall of your eye and retina closer together (scleral buckling)
*   injecting a bubble of gas into your eye to push the retina against the back of your eye (pneumatic retinopexy)
*   sealing the tear in your retina with laser or freezing treatment (cryotherapy)

It's usually done with local anaesthetic, so you're awake but your eye is numbed.

You do not normally need to stay in hospital overnight.

You may be asked to lie or sit in a particular position for up to 7 days after the surgery. This is so that your retina is in the correct position to help it heal.

Recovering from a detached retina
---------------------------------

Recovery time after surgery for a detached retina varies. But as a general guide, for 2 to 6 weeks after surgery:

*   your vision may be blurry
*   your eye may be sore and red – take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) if you need to
*   you may need to take time off work
*   you may not be able to drive
*   you may need to avoid flying (if you've had a bubble of gas put into your eye)

Most people are eventually able to return to all their normal activities.

### Important

Call the hospital or go to A&E if the pain, redness or blurriness gets worse after surgery. You may need further treatment.

Causes of a detached retina
---------------------------

A detached retina is usually caused by changes to the jelly inside your eye, which can happen as you get older. This is called posterior vitreous detachment (PVD).

It's not clear exactly why PVD can lead to retinal detachment in some people and there's nothing you can do to prevent it. But it's more likely to happen if you:

*   are short-sighted
*   have had an eye operation (such as cataract surgery)
*   have had an eye injury
*   have a family history of retinal detachment

[Find out more about posterior vitreous detachment from RNIB](https://www.rnib.org.uk/your-eyes/eye-conditions-az/posterior-vitreous-detachment/)

Important: If your symptoms come back
-------------------------------------

You can get a detached retina more than once. Get medical help as soon as possible if the symptoms come back.

Page last reviewed: 04 August 2023  
Next review due: 04 August 2026
