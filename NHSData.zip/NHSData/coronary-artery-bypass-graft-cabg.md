Title: Coronary artery bypass graft (CABG)

URL Source: https://www.nhs.uk/conditions/coronary-artery-bypass-graft-cabg/

Published Time: 24 Oct 2017, 8:49 a.m.

Markdown Content:
**A coronary artery bypass graft (CABG) is a surgical procedure used to treat coronary heart disease.**

It diverts blood around narrowed or clogged parts of the major arteries to improve blood flow and oxygen supply to the heart.

Why it's carried out
--------------------

Like all organs in the body, the heart needs a constant supply of blood.

This is supplied by 2 large blood vessels called the left and right coronary arteries.

Over time, these arteries can become narrowed and hardened by the build-up of fatty deposits called plaques.

This process is known as [atherosclerosis](https://www.nhs.uk/conditions/atherosclerosis/).

People with atherosclerosis of the coronary arteries are said to have [coronary heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/).

Your chances of developing coronary heart disease increase with age.

You're also much more likely to be affected if:

*   you smoke
*   you're overweight or [obese](https://www.nhs.uk/conditions/obesity/)
*   you have a high-fat diet

Coronary heart disease can cause [angina](https://www.nhs.uk/conditions/angina/), which is chest pain that happens when the supply of oxygen-rich blood to the heart becomes restricted.

While angina can often be treated with medicine, severe angina may require a coronary artery bypass graft to improve the blood supply to the heart.

Another risk associated with coronary heart disease is the possibility of one of the plaques in the coronary artery rupturing (splitting), creating a blood clot.

If the blood clot blocks the blood supply to the heart, it can trigger a [heart attack](https://www.nhs.uk/conditions/heart-attack/).

A coronary artery bypass graft may be recommended to reduce your chances of having a heart attack.

The procedure
-------------

A coronary artery bypass graft involves taking a blood vessel from another part of the body (usually the chest, leg or arm) and attaching it to the coronary artery above and below the narrowed area or blockage.

This new blood vessel is known as a graft. The number of grafts needed will depend on how severe your coronary heart disease is and how many of the coronary blood vessels are narrowed.

A coronary artery bypass graft is carried out under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/), which means you'll be unconscious during the operation. It usually takes between 3 and 6 hours.

Recovery
--------

Most people will need to stay in hospital for about 6 to 8 days after having a coronary artery bypass graft.

You should have a follow-up appointment, typically about 6 to 8 weeks after your operation.

Recovering takes time and everyone recovers at slightly different speeds.

Generally, you should be able to sit in a chair after 1 day, walk after 3 days, and walk up and down stairs after 5 or 6 days.

When you go home, you'll need to take things easy for a few weeks.

You should be able to return to most of your normal activities after about 6 weeks, including working, driving and having sex. If you have a heavy manual job, you may need to stay off work longer.

Most people make a full recovery within 12 weeks.

Risks of surgery
----------------

As with all types of surgery, a coronary artery bypass graft carries a risk of complications.

These are usually relatively minor and treatable, such as an irregular heartbeat or a wound infection, but there's also a risk of serious complications, such as a [stroke](https://www.nhs.uk/conditions/stroke/) or heart attack.

After surgery
-------------

After having a coronary artery bypass graft, most people will experience a significant improvement in symptoms such as [breathlessness](https://www.nhs.uk/conditions/shortness-of-breath/) and [chest pain](https://www.nhs.uk/conditions/chest-pain/), and their heart attack risk will be lowered.

But a coronary artery bypass graft isn't a cure for coronary heart disease.

If you don't make lifestyle changes, such as eating a healthy diet and exercising regularly, your grafted arteries will also eventually become hardened and narrowed.

Sometimes, a coronary artery bypass graft may need to be repeated or you may need a procedure to widen your arteries using a small balloon and a tube called a stent [(coronary angioplasty)](https://www.nhs.uk/conditions/coronary-angioplasty/).

Alternatives
------------

A coronary angioplasty is the main alternative to a coronary artery bypass graft.

It's a less invasive operation where a long, flexible, hollow plastic tube called a catheter is inserted into a blood vessel in your arm or groin.

The tip of the catheter is guided under X-ray to the arteries that supply your heart, to the point where the narrowing of the artery has occurred.

A balloon attached to the catheter is then inflated to widen the artery and a small metal tube called a stent is often used to help keep the artery open.

It usually takes less time to recover from a coronary angioplasty than from a coronary artery bypass graft, but there's a higher chance that the procedure will need to be repeated.

Also, a coronary angioplasty may not be recommended if multiple coronary arteries have become blocked and narrowed or the structure of the blood vessels near your heart is abnormal.

How long will I have to wait for surgery?
-----------------------------------------

The length of time you'll have to wait to have a coronary artery bypass graft will vary from area to area.

Your GP or cardiac surgeon should be able to tell you what the waiting lists are like in your area or at the hospital you have chosen.

Ideally, you should be treated within 3 months of the decision to operate.

Video: what is a heart bypass
-----------------------------

This animation explains in detail how a coronary artery bypass, a surgical procedure, is performed.

Media last reviewed: 24 April 2023  
Media review due: 24 April 2026

Page last reviewed: 23 November 2021  
Next review due: 23 November 2024
