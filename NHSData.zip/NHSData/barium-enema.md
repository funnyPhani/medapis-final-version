Title: Barium enema

URL Source: https://www.nhs.uk/conditions/barium-enema/

Published Time: 17 Oct 2017, 5:09 p.m.

Markdown Content:
**A barium enema is a test that helps to highlight the large bowel so it can be clearly seen on an** [**X-ray**](https://www.nhs.uk/conditions/x-ray/)**.**

During the test, a white liquid called barium is passed into your bowel through your bottom.

A barium enema may be requested by any doctor who thinks you might have a problem with your bowel, including your GP.

The test will usually be carried out at a hospital radiology department by a radiologist or radiographer.

When barium enemas are used
---------------------------

Nowadays, barium enemas aren't carried out very often, as alternative tests such as a [colonoscopy](https://www.nhs.uk/conditions/colonoscopy/) or [CT scan](https://www.nhs.uk/conditions/ct-scan/) are usually preferred.

But a barium enema can sometimes be a useful way of finding the cause of problems like blood in your stools or a constant change in your bowel habits.

Conditions that can be detected during a barium enema include:

*   [bowel cancer](https://www.nhs.uk/conditions/bowel-cancer-old/)
*   growths in the bowel ([bowel polyps](https://www.nhs.uk/conditions/bowel-polyps/))
*   inflammation of the bowel ([ulcerative colitis](https://www.nhs.uk/conditions/ulcerative-colitis/)) or [Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/)
*   pouches in the bowel ([diverticular disease](https://www.nhs.uk/conditions/diverticular-disease-and-diverticulitis/))

Preparing for a barium enema
----------------------------

To ensure the X-ray images taken during a barium enema are clear, your bowel must be empty before the test.

The hospital should send you instructions on what you need to do to prepare.

You'll normally be asked to:

*   eat a light diet – for a few days leading up to the test, only eat low-fibre foods such as clear soup, white bread and lean meat
*   take [laxatives](https://www.nhs.uk/conditions/laxatives/) – you'll be given medication that makes you empty your bowels frequently to take from the day before the test
*   drink plenty of fluids – this will help to replace the fluids you lose each time you empty your bowels

It's usually a good idea to stay at home the day before the test, as the laxative medication will make you go to the toilet frequently.

Contact the hospital as soon as you receive your appointment letter if you have [diabetes](https://www.nhs.uk/conditions/diabetes/) or are pregnant (or think you could be pregnant).

Barium enemas aren't done during pregnancy because the X-rays may harm the baby.

If you have diabetes, you'll need to follow special instructions to ensure your blood sugar level is kept under control.

Having a barium enema
---------------------

When you arrive at hospital, you'll be asked to change into a hospital gown.

You can take someone with you to the hospital, but they're not usually allowed into the X-ray room.

During the test:

*   you'll be asked to lie on your side on an X-ray table, and an injection of a medication called Buscopan may be given into your arm or hand to prevent involuntary bowel movements
*   a small, soft tube will be gently inserted a few centimetres into your bottom, where it will remain throughout the test
*   the barium is passed through the tube and into your bowel – try to keep the muscles in your bottom tight to prevent it coming back out, but don't worry if some leaks out
*   you may be asked to move around a bit to help the barium spread along your bowel, and air may be pumped into your bowel to expand it and help push the barium around
*   several X-rays will be taken with you in different positions

The whole process usually takes around 30 to 45 minutes.

What happens after a barium enema
---------------------------------

When the test is finished, the tube will be removed from your bottom and you can go to the toilet to empty your bowels.

You should be able to go home shortly afterwards, although it's a good idea to take things easy for a few hours before returning to your normal activities.

If you had a Buscopan injection, your vision may be blurry for a short while afterwards, so you won't be able to drive. It's best to arrange for someone to drive you home.

When you get home:

*   stay close to a toilet for the next few hours, as you may find you need to empty your bowels quite often at first
*   your poo may be a whitish colour for a few days – this is normal and is just the remaining barium passing out of your body
*   you can eat and drink as normal – drink plenty of fluids and eat high-fibre foods for the first few days to help stop the barium causing [constipation](https://www.nhs.uk/conditions/constipation/)

The X-ray images taken during the test will be analysed by a specialist. A report will be sent to the doctor who referred you for the test and you can discuss the results at your next appointment.

Does a barium enema hurt?
-------------------------

Having a barium enema may be a bit embarrassing and unpleasant, but it shouldn't be painful.

You'll probably feel uncomfortable when the air is pumped into your bowel during the test, similar to the feeling of having trapped wind.

You may have some bloating, wind or stomach cramps for a short while afterwards.

Are there any risks or side effects?
------------------------------------

A barium enema is generally a very safe procedure, although there a few risks and side effects that you should be aware of.

These include:

*   laxative side effects – side effects such as feeling sick, a mild [headache](https://www.nhs.uk/conditions/headaches/) and bloating are common, but shouldn't last long
*   barium side effects – barium is usually harmless, but it can cause an upset stomach or constipation, and can cause an [allergic reaction](https://www.nhs.uk/conditions/anaphylaxis/) in very rare cases
*   radiation exposure – you'll be exposed to a small amount of radiation during the test; this is about the equivalent to what you would receive naturally from the environment over 3 years (for more information, see [GOV.UK: patient dose information](https://www.gov.uk/government/publications/medical-radiation-patient-doses/patient-dose-information-guidance))
*   bowel perforation – there's a risk of a small hole developing in your bowel as a result of the procedure, but this is very rare

Your doctor can help you weigh up the risks of the procedure against the benefits of identifying any problem in your bowel.

Page last reviewed: 13 May 2022  
Next review due: 13 May 2025
