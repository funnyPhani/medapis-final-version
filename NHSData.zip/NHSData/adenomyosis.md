Title: Adenomyosis

URL Source: https://www.nhs.uk/conditions/adenomyosis/

Published Time: 21 Jul 2023, 8:11 a.m.

Markdown Content:
**Adenomyosis is a condition where the lining of the womb (uterus) starts growing into the muscle in the wall of the womb. There are treatments that can help with any symptoms.**

Adenomyosis is more commonly diagnosed in women over the age of 30. It can affect anyone who has periods.

![Image 1: Diagram of the tummy area with labels showing the womb, wall of the womb and womb lining, the vagina and cervix. Small patches of adenomyosis are growing in the wall of the womb.](https://assets.nhs.uk/nhsuk-cms/images/VID-1734_-_Adenomyosis_Illustration_copy.width-320.png)

Symptoms of adenomyosis
-----------------------

Some symptoms of adenomyosis affect your periods, such as:

*   painful periods
*   heavy bleeding during your period

Other symptoms can happen any time in your menstrual cycle, such as:

*   pelvic pain (pain in the lower part of your tummy)
*   bloating, heaviness or fullness in your tummy (abdomen)
*   pain during sex

Some people with adenomyosis have no symptoms.

Information:

[Endometriosis](https://www.nhs.uk/conditions/endometriosis/) is a different condition where tissue similar to the lining of the womb grows in other places, such as the ovaries or fallopian tubes.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   your pelvic pain or period pain is severe or worse than usual, and painkillers have not helped

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms/).

Non-urgent advice: See a GP if:
-------------------------------

*   your periods become more painful, heavier or irregular
*   you have pain during sex
*   heavy periods are affecting your life or you've had them for some time
*   you've been feeling bloated for a while (about 3 weeks)
*   you bleed between periods or after sex

What happens at your GP appointment
-----------------------------------

The GP may ask about your periods if you have symptoms of adenomyosis. They may feel your tummy to see if there’s any swelling or bloating.

You can ask for a female doctor when you book your appointment.

The doctor might also ask to do an internal examination, to check your vagina and cervix (the opening between the vagina and the womb).

You can have a friend, family member or other member of staff in the room with you during your examination if you want.

Sometimes further tests are needed to find out what’s causing your symptoms, or to rule out similar conditions such as endometriosis.

Tests may include:

*   [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/)
*   [MRI scan](https://www.nhs.uk/conditions/mri-scan/)

Treatments for adenomyosis
--------------------------

If you’re diagnosed with adenomyosis, there are treatments that can help ease your symptoms.

Treatments include:

*   the [IUS](https://www.nhs.uk/conditions/contraception/ius-intrauterine-system/) (intrauterine system, also called Mirena or hormonal coil), which thins the womb lining, making your periods lighter and less painful
*   other types of hormonal contraception if you cannot or do not want to have an IUS, such as the [progestogen-only pill](https://www.nhs.uk/conditions/contraception/the-pill-progestogen-only/), the [combined pill](https://www.nhs.uk/conditions/contraception/combined-contraceptive-pill/) or the [contraceptive patch](https://www.nhs.uk/conditions/contraception/contraceptive-patch/)
*   medicines such as [tranexamic acid](https://www.nhs.uk/medicines/tranexamic-acid/) or [NSAIDs](https://www.nhs.uk/conditions/nsaids/)

If these treatments do not work, you may need surgery.

This could be a [hysterectomy](https://www.nhs.uk/conditions/hysterectomy/), or surgery to remove the lining of your womb (endometrial ablation).

How to ease symptoms of adenomyosis
-----------------------------------

There are things that can help with period pain or pelvic pain caused by adenomyosis.

### Do

*   use a heat pad or hot water bottle wrapped in a tea towel on your tummy
    
*   try a [TENS machine](https://www.nhs.uk/conditions/transcutaneous-electrical-nerve-stimulation-tens/) – a small device that uses mild electrical impulses to reduce pain
    
*   take painkillers like [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
    

Who is more likely to get adenomyosis?
--------------------------------------

It's not clear what causes adenomyosis.

You may be more likely to get it if you are over the age of 30 and have given birth.

Page last reviewed: 17 July 2023  
Next review due: 17 July 2026
