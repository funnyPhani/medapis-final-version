Title: Headaches

URL Source: https://www.nhs.uk/conditions/headaches/

Published Time: 8 Jan 2018, 5:41 p.m.

Markdown Content:
Most headaches go away on their own and are not a sign of something more serious.

How you can ease headaches yourself
-----------------------------------

Headaches can last 30 minutes, several hours, or sometimes several days.

### Do

*   drink plenty of water
    
*   get plenty of rest if you have a cold or the flu
    
*   try to relax – stress can make headaches worse
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
    
*   try to stay at home and avoid contact with other people if you have a high temperature or you do not feel well enough to do your normal activities
    

### Don’t

*   do not drink alcohol
    
*   do not skip meals (even if you might not feel like eating anything)
    
*   do not sleep more than you usually would – it can make the headache worse
    
*   do not strain your eyes for a long time – for example, by looking at a screen
    

Non-urgent advice: See a GP if:
-------------------------------

*   your headache keeps coming back
*   painkillers do not help and your headache gets worse
*   you have a bad throbbing pain at the front or side of your head – it could be a [migraine](https://www.nhs.uk/conditions/migraine/) or, more rarely, a [cluster headache](https://www.nhs.uk/conditions/cluster-headaches/)
*   you feel sick, vomit and find light or noise painful

Urgent advice: Get an urgent GP appointment or call 111 if:
-----------------------------------------------------------

You or your child has a severe headache and:

*   jaw pain when eating
*   blurred or double vision
*   a sore scalp
*   other symptoms, such as numbness or weakness in the arms or legs

Also get an urgent GP appointment or call 111 if your child is under 12 and has any 1 of the following:

*   a headache that wakes them at night
*   a headache when they wake up in the morning
*   a headache that gets progressively worse
*   a headache triggered or made worse by coughing, sneezing or bending down
*   a headache with vomiting
*   a headache with a [squint](https://www.nhs.uk/conditions/squint/) (where the eyes point in different directions) or an inability to look upward

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if you or your child:
----------------------------------------------------------------------

*   has a head injury – for example, from a fall or accident
*   has a headache that came on suddenly and is extremely painful

You or your child has an extremely painful headache and:

*   sudden problems speaking or remembering things
*   loss of vision
*   feel drowsy or confused
*   has a very high temperature and [symptoms of meningitis](https://www.nhs.uk/conditions/meningitis/symptoms/)
*   the white part of the eye is red

Also call 999 or go to A&E if your child is under 12 and has any 1 of the following:

*   a headache with vision problems or difficulty speaking, swallowing, balancing or walking
*   a headache with drowsiness or a persistent lack of energy
*   a headache that starts within 5 days of a head injury

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

What can cause headaches
------------------------

Common causes of headaches include:

*   having a [cold](https://www.nhs.uk/conditions/common-cold/) or [flu](https://www.nhs.uk/conditions/flu/)
*   stress
*   drinking too much alcohol
*   bad posture
*   eyesight problems
*   not eating regular meals
*   not drinking enough fluids (dehydration)
*   taking too many painkillers
*   having your period or during menopause

Page last reviewed: 17 April 2024  
Next review due: 17 April 2027
