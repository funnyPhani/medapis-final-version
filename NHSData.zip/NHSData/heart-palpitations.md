Title: Heart palpitations

URL Source: https://www.nhs.uk/conditions/heart-palpitations/

Published Time: 18 Oct 2017, 2:44 p.m.

Markdown Content:
**Heart palpitations are when your heartbeat becomes more noticeable. They're usually harmless, but get help if you keep getting them or you also have other symptoms.**

What heart palpitations feel like
---------------------------------

When you have heart palpitations, your heartbeat feels uncomfortable or unusual. You may feel it in your chest, neck or throat.

Your heartbeat may feel like it is:

*   racing or beating very fast
*   irregular, with skipped or extra beats (ectopic beats)
*   pounding or thumping
*   fluttering

Heart palpitations can last seconds, minutes or longer.

Causes of heart palpitations
----------------------------

Heart palpitations are common and not usually a sign of anything serious.

Common causes include:

*   strenuous exercise
*   lack of sleep
*   stress and anxiety
*   medicines (check the leaflet that comes with the medicine)
*   alcohol, caffeine, nicotine and recreational drugs

Sometimes heart palpitations can be a sign you're going through the [menopause](https://www.nhs.uk/conditions/menopause/). Some people get them during pregnancy.

Less often, they can be caused by a condition such as [iron deficiency anaemia](https://www.nhs.uk/conditions/iron-deficiency-anaemia/), an [overactive thyroid (hyperthyroidism)](https://www.nhs.uk/conditions/overactive-thyroid-hyperthyroidism/) or a [heart rhythm problem (arrhythmia)](https://www.nhs.uk/conditions/arrhythmia/).

Non-urgent advice: See a GP if:
-------------------------------

You have heart palpitations and:

*   they keep coming back or they're getting worse
*   they last longer than a few minutes
*   you have a heart condition
*   you have a history of heart problems in your family

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You currently have heart palpitations with any of these symptoms:

*   chest pain
*   shortness of breath
*   feeling faint or fainting

[Find your nearest A&E](https://www.nhs.uk/Service-Search/other-services/Accident%20and%20emergency%20services/LocationSearch/428)

Information:

If you've had these symptoms but they've now stopped, ask your GP surgery for an urgent appointment, call 111 or [get help from 111 online](https://111.nhs.uk/).

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Treatment for heart palpitations
--------------------------------

Treatment for heart palpitations depends on the cause. They often do not need to be treated.

Avoiding things that can trigger palpitations, such as stress, smoking, caffeine and alcohol, can help.

You may have an [electrocardiogram (ECG)](https://www.nhs.uk/conditions/electrocardiogram/) to help find out what the cause might be. This is a test where small pads are stuck to your skin to check the electrical signals coming from your heart.

If your palpitations are caused by a heart problem, you may need medicines or a procedure to help correct your heartbeat.

Page last reviewed: 07 June 2022  
Next review due: 07 June 2025
