Title: Ichthyosis

URL Source: https://www.nhs.uk/conditions/ichthyosis/

Published Time: 18 Oct 2017, 3:01 p.m.

Markdown Content:
**Ichthyosis is a group of rare skin conditions that** **cause** **dry,** **scaly skin.** **It's usually something you're born with, but it can happen later in life. It cannot usually be** **cured, but there are treatments to help the symptoms.**

Check if it's ichthyosis
------------------------

The main symptom of ichthyosis is very dry, scaly skin that may also be thick and rough.

It usually affects large areas of the body including the arms, legs, torso, ears, face, or the whole body.

The symptoms are often there from birth, but they can also appear after a few months or years. Sometimes the symptoms appear later in life because of another health condition, or from taking certain medicines.

![Image 1: A close-up showing the scale-like dryness of ichthyosis on white skin.](https://assets.nhs.uk/nhsuk-cms/images/A8FF52.width-320.jpg)

![Image 2: A close-up showing thickened and dry skin with ichthyosis scaling on brown skin.](https://assets.nhs.uk/nhsuk-cms/images/C0528158-X-linked_ichthyosis_copy.width-320.png)

Ichthyosis can sometimes have more severe symptoms, including:

*   blistered skin
*   a thin yellow, shiny layer on the skin at birth that dries out and flakes off
*   hair loss
*   tight skin which can make moving the affected area painful
*   skin infections
*   sweating less, which can lead to overheating
*   problems with hearing or eyesight

Non-urgent advice: See a GP if:
-------------------------------

*   you or your child have symptoms of ichthyosis

The GP may refer you to a skin specialist if they think you have ichthyosis.

Treatments for ichthyosis
-------------------------

Most types of ichthyosis cannot be cured, but there are treatments to help the symptoms.

Treatments may include:

*   moisturising treatments ([emollients](https://www.nhs.uk/conditions/emollients/)), such as lotions, creams, ointments and bath oils
*   peeling creams, such as salicylic acid

A skin specialist will talk to you about the different options.

For more severe ichthyosis symptoms treatment can also include:

*   antibiotics to treat or prevent skin infections
*   retinoid tablets or creams to help improve the appearance of scaly skin

If the ichthyosis symptoms are caused by another health condition or medicine, treating the condition or changing the medicine can improve the symptoms.

How to ease ichthyosis symptoms at home
---------------------------------------

There are things you can do to help ease ichthyosis symptoms at home.

### Do

*   use emollients on affected skin at least once a day – ideally when your skin is still wet after having a bath or shower
    
*   try different types of emollient to find 1 that works best
    
*   use a comb on wet hair to remove scaly skin on the scalp
    
*   talk to your skin specialist if any treatments cause irritation
    

### Don’t

*   do not smoke or go near flames if using an emollient that contains paraffin
    
*   do not use soap on affected skin – use an emollient instead of soap
    

Types of ichthyosis
-------------------

There are at least 20 different types of ichthyosis.

Most types are passed on from your parents in your genes, and you have symptoms from birth or soon after.

These include:

*   ichthyosis vulgaris – the most common type of ichthyosis, it's usually mild and can get better as you get older
*   X-linked ichthyosis – only happens in boys, tends to be better in sunny or warm weather
*   autosomal recessive congenital ichthyosis – tends to have more severe symptoms

You can also get ichthyosis in later life because of another health condition, such as kidney disease, or as a reaction to certain medicines.

Information:

More information
----------------

*   [The Ichthyosis Support Group](https://www.ichthyosis.org.uk/)

Page last reviewed: 04 May 2023  
Next review due: 04 May 2026
