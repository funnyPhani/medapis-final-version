Title: Heat exhaustion and heatstroke

URL Source: https://www.nhs.uk/conditions/heat-exhaustion-heatstroke/

Published Time: 18 Oct 2017, 2:49 p.m.

Markdown Content:
**Heat exhaustion does not usually need emergency medical help if you can cool down within 30 minutes. If it turns into heatstroke, it needs to be treated as an emergency.**

Check for signs of heat exhaustion
----------------------------------

The signs of heat exhaustion include:

*   tiredness
*   dizziness
*   headache
*   feeling sick or being sick
*   excessive sweating and skin becoming pale and clammy or getting a [heat rash](https://www.nhs.uk/conditions/heat-rash-prickly-heat/), but a change in skin colour can be harder to see on brown and black skin
*   cramps in the arms, legs and stomach
*   fast breathing or heartbeat
*   a high temperature
*   being very thirsty
*   weakness

The symptoms of heat exhaustion are often the same in adults and children, although children may become irritable too.

If someone is showing signs of heat exhaustion they need to be cooled down and given fluids.

Things you can do to cool someone down
--------------------------------------

If someone has heat exhaustion, follow these 4 steps:

1.  Move them to a cool place.
2.  Remove all unnecessary clothing like a jacket or socks.
3.  Get them to drink a sports or rehydration drink, or cool water.
4.  Cool their skin – spray or sponge them with cool water and fan them. Cold packs, wrapped in a cloth and put under the armpits or on the neck are good too.

Stay with them until they're better.

They should start to cool down and feel better within 30 minutes.

Urgent advice: Contact 111 if:
------------------------------

*   you or someone else have symptoms of heat exhaustion that you're struggling to treat or you need advice about

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Immediate action required: Call 999 now if:
-------------------------------------------

You or someone else have signs of heatstroke, including:

*   still unwell after 30 minutes of resting in a cool place, being cooled and drinking fluids
*   a very high temperature
*   hot skin that's not sweating and might look red (this can be harder to see on brown and black skin)
*   a fast heartbeat
*   fast breathing or shortness of breath
*   confusion and lack of coordination
*   a seizure or fit
*   loss of consciousness

Put the person in the [recovery position](https://www.nhs.uk/conditions/first-aid/recovery-position/) if they lose consciousness while you're waiting for help.

Information:

Do not drive yourself to A&E.

The person you speak to at 999 will give you advice about what to do.

Preventing heat exhaustion and heatstroke
-----------------------------------------

There's a high risk of heat exhaustion or heatstroke during hot weather or exercise.

To help prevent heat exhaustion or heatstroke:

*   drink more cold drinks, especially if you're active or exercising
*   wear light-coloured, loose clothing
*   avoid the sun between 11am and 3pm
*   avoid excess alcohol
*   avoid extreme exercise
*   if you're inside on a very hot day, close curtains, close windows if it's hotter outside than in your home and turn off electrical equipment and lights that get hot

This will also prevent dehydration and help your body keep itself cool.

Children, older people and people with long-term health conditions (such as diabetes or heart problems) are more at risk of heat exhaustion or heatstroke.

Read more about what do to and [how to cope in hot weather](https://www.nhs.uk/live-well/seasonal-health/heatwave-how-to-cope-in-hot-weather/).

[Find out about dehydration](https://www.nhs.uk/conditions/dehydration/)

Page last reviewed: 12 August 2022  
Next review due: 12 August 2025
