Title: Gastroscopy

URL Source: https://www.nhs.uk/conditions/gastroscopy/

Published Time: 21 Mar 2018, 8:49 a.m.

Markdown Content:
Gastroscopy - NHS
===============
                                    

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/gastroscopy/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

What is a gastroscopy? \- Gastroscopy
=====================================

Contents
--------

1.  What is a gastroscopy?
2.  [Why it’s done](https://www.nhs.uk/conditions/gastroscopy/why-its-done/)
3.  [Getting ready](https://www.nhs.uk/conditions/gastroscopy/getting-ready/)
4.  [What happens on the day](https://www.nhs.uk/conditions/gastroscopy/what-happens/)
5.  [Results](https://www.nhs.uk/conditions/gastroscopy/results/)

*   A gastroscopy is a test to check inside your throat, food pipe (oesophagus) and stomach, known as the upper part of your digestive system.
*   This test can help find what's causing your symptoms.
*   A long, thin, flexible tube with a small camera inside it is passed into your mouth then down your throat and into your stomach.
*   A gastroscopy can also be used to remove tissue for testing ([biopsy](https://www.nhs.uk/conditions/biopsy/)) and treat some conditions such as stomach ulcers.

Important: Your pain relief options
-----------------------------------

You’ll be offered medicine called sedation which can make you feel very relaxed and sleepy. You’ll also be offered medicine to numb your throat.

Page last reviewed: 07 April 2022  
Next review due: 07 April 2025

*   [Next : Why it’s done](https://www.nhs.uk/conditions/gastroscopy/why-its-done/)

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
