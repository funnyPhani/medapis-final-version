Title: Discoid eczema

URL Source: https://www.nhs.uk/conditions/discoid-eczema/

Published Time: 19 Oct 2017, 5:02 p.m.

Markdown Content:
**Discoid eczema, also known as nummular or discoid dermatitis, is a long-term (chronic) skin condition that causes skin to become itchy, swollen and cracked in circular or oval patches.**

Without treatment, discoid eczema can last for weeks, months or even years. It may also keep coming back – often in the same area that was affected previously.

Symptoms of discoid eczema
--------------------------

Discoid eczema causes distinctive circular or oval patches of eczema. It can affect any part of the body, although it does not usually affect the face or scalp.

![Image 1: A large patch of red flaky skin surrounded by several smaller red patches and bumps](https://assets.nhs.uk/nhsuk-cms/images/E5RG4J.width-320.jpg)

The first sign of discoid eczema is usually a group of small spots or bumps on the skin. These then quickly join up to form larger patches that can range from a few millimetres to several centimetres in size.

On lighter skin these patches will be pink or red. On darker skin these patches can be a dark brown or they can be paler than the skin around them.

Initially, these patches are often swollen, blistered (covered with small fluid-filled pockets) and ooze fluid. They also tend to be very itchy, particularly at night.

Over time, the patches may become dry, crusty, cracked and flaky. The centre of the patch also sometimes clears, leaving a ring of discoloured skin that can be mistaken for [ringworm](https://www.nhs.uk/conditions/ringworm/).

You may just have 1 patch of discoid eczema, but most people get several patches. The skin between the patches is often dry.

Patches of discoid eczema can sometimes become infected. Signs of an infection can include:

*   the patches oozing a lot of fluid
*   a yellow crust developing over the patches
*   the skin around the patches becoming hot, swollen and tender or painful
*   feeling sick
*   feeling hot or shivery
*   feeling unwell

When to seek medical advice
---------------------------

See a pharmacist or GP if you think you may have discoid eczema. They can recommend a suitable treatment.

You should also seek medical advice if you think your skin may be infected. You may need to use an [antibiotic](https://www.nhs.uk/conditions/antibiotics/) cream or, in severe cases, take antibiotics as a tablet or capsule.

A GP should be able to make a diagnosis just by examining the affected areas of skin. In some cases they may also ask questions or arrange some tests to rule out other conditions.

A GP may refer you to a doctor who specialises in skin conditions (dermatologist) if they're unsure of the diagnosis or if you need a patch test.

Causes of discoid eczema
------------------------

The cause of discoid eczema is unknown, although it may happen as a result of having particularly dry skin.

When your skin is very dry it cannot provide an effective barrier against substances that come into contact with it. This could allow a previously harmless substance, such as soap, to irritate your skin.

It's important to look carefully at all the chemicals in cosmetics and toiletries that may have come into contact with your skin. [Contact dermatitis](https://www.nhs.uk/conditions/contact-dermatitis/), a type of eczema caused by coming into contact with a particular irritant, may have a role in discoid eczema.

Some people with discoid eczema also have a history of [atopic eczema](https://www.nhs.uk/conditions/atopic-eczema/), which often happens in people who are prone to [asthma](https://www.nhs.uk/conditions/asthma/) and [hay fever](https://www.nhs.uk/conditions/hay-fever/). However, unlike atopic eczema, discoid eczema does not seem to run in families.

### Other possible triggers 

An outbreak of discoid eczema may sometimes be triggered by a minor skin injury, such as an [insect bite](https://www.nhs.uk/conditions/insect-bites-and-stings/) or a [burn](https://www.nhs.uk/conditions/burns-and-scalds/).

Some medicines have been linked to discoid eczema. You should not stop taking any prescribed medicine without talking to the doctor who prescribed it for you.

Dry environments and cold climates can make discoid eczema worse, and sunny or damp (humid) environments may make your symptoms better.

Treating discoid eczema
-----------------------

Discoid eczema is usually a long-term problem, but medicines are available to help relieve the symptoms and keep the condition under control.

Treatments include:

*   [emollients](https://www.nhs.uk/conditions/emollients/) – moisturisers applied to the skin to stop it becoming dry
*   [topical corticosteroids](https://www.nhs.uk/conditions/topical-steroids/) – ointments and creams containing a steroid that are applied to the skin and may relieve severe symptoms
*   [antihistamines](https://www.nhs.uk/conditions/antihistamines/) – medicines that can reduce itching

There are also things you can do yourself to help, such as avoiding all the irritating chemicals in soaps, detergents, bubble baths and shower gels.

Additional medicine can be prescribed if your eczema is infected or particularly severe.

Occasionally, areas of skin affected by discoid eczema can be left permanently discoloured after the condition has cleared up.

Find out more about [treating discoid eczema](https://www.nhs.uk/conditions/discoid-eczema/treatment/).

Other types of eczema 
----------------------

Eczema is the name for a group of skin conditions that cause dry, irritated skin. Other types of eczema include:

*   [atopic eczema](https://www.nhs.uk/conditions/atopic-eczema/) (also called atopic dermatitis) – the most common type of eczema, it often runs in families and is linked to other conditions such as [asthma](https://www.nhs.uk/conditions/asthma/) and [hay fever](https://www.nhs.uk/conditions/hay-fever/)
*   [contact dermatitis](https://www.nhs.uk/conditions/contact-dermatitis/) – a type of eczema that happens when the skin comes into contact with a particular substance
*   [varicose eczema](https://www.nhs.uk/conditions/varicose-eczema/) – a type of eczema that usually affects the lower legs and is caused by problems with the flow of blood through the leg veins

Page last reviewed: 23 March 2023  
Next review due: 23 March 2026
