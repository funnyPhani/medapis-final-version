Title: Conjunctivitis

URL Source: https://www.nhs.uk/conditions/conjunctivitis/

Published Time: 19 Oct 2017, 4:42 p.m.

Markdown Content:
Check if you have conjunctivitis
--------------------------------

Conjunctivitis is also known as red or pink eye.

It usually affects both eyes and makes them:

*   red
*   burn or feel gritty
*   produce pus that sticks to lashes
*   itch
*   water

![Image 1: An eye with sticky yellow pus on the eyelashes.](https://assets.nhs.uk/nhsuk-cms/images/C0284481-Bacterial_conjunctivitis-SPL_copy.width-320.jpg)

Conjunctivitis that produces sticky pus is contagious.

![Image 2: An eye that's red, caused by conjunctivitis](https://assets.nhs.uk/nhsuk-cms/images/C0269241-Viral_conjunctivitis-SPL.width-320.jpg)

If eyes are red and feel gritty, the conjunctivitis is also usually contagious.

![Image 3: An eye that's red, caused by conjunctivitis. Shown on brown skin.](https://assets.nhs.uk/nhsuk-cms/images/2D12E7H.width-320.png)

![Image 4: A red and watery eye caused by conjunctivitis](https://assets.nhs.uk/nhsuk-cms/images/C0230722-Allergic_conjunctivitis-SPL.width-320.jpg)

Conjunctivitis caused by allergies, like hay fever, makes eyes red and watery but is not contagious.

How to treat conjunctivitis yourself
------------------------------------

There are things you can do to help ease the symptoms of conjunctivitis.

*   Wash your eyelids with clean water. Boil the water and let it cool down, then gently wipe your eyelashes with a clean cotton wool pad to clean off crusts (1 piece for each eye).
*   Hold a cold flannel on your eyes for a few minutes to cool them down.

Do not wear contact lenses until your eyes are better.

### A pharmacist can help with conjunctivitis

Speak to a pharmacist about conjunctivitis. They can give you advice and suggest eyedrops or [antihistamines](https://www.nhs.uk/conditions/antihistamines/) to help with your symptoms.

If you need treatment for a child under 2 years old, you'll need a prescription from a GP.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Stop infectious conjunctivitis from spreading
---------------------------------------------

There are things you can do to stop conjunctivitis spreading to other people.

### Do

*   wash your hands regularly with warm soapy water
    
*   wash your pillow cases and face cloths in hot water and detergent
    
*   cover your mouth and nose when sneezing and put used tissues in the bin
    

### Don’t

*   do not share towels and pillows
    
*   do not rub your eyes
    

### Staying away from work or school

You do not need to stay away from work or school unless you or your child are feeling very unwell.

Non-urgent advice: See a GP if:
-------------------------------

*   your baby has red, sticky eyes – get an urgent appointment if your baby is less than 30 days old
*   you wear contact lenses and have conjunctivitis symptoms as well as spots on your eyelids – you might be allergic to the lenses
*   you have conjunctivitis and your symptoms have not cleared up within 7 days

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if you have:
-------------------------------------------------------------------------------------

*   pain in your eyes
*   sensitivity to light
*   changes in your vision, like wavy lines or flashing
*   very red eyes (1 eye or both eyes)
*   a baby less than 30 days old with red, sticky eyes

These can be signs of a more serious eye problem.

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms). Call 111 if you need help for a child under 5.

Treatment for conjunctivitis
----------------------------

Treatment will depend on the cause of your conjunctivitis.

If it's a bacterial infection, you might be prescribed [antibiotics](https://www.nhs.uk/conditions/antibiotics/). But these will not work if it's caused by a virus (viral conjunctivitis) or an allergy.

Some sexually transmitted infections (STIs) can cause conjunctivitis. This type takes longer to get better.

Page last reviewed: 23 April 2024  
Next review due: 23 April 2027
