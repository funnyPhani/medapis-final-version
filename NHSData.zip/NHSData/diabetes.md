Title: Diabetes

URL Source: https://www.nhs.uk/conditions/diabetes/

Published Time: 18 Oct 2017, 10:33 a.m.

Markdown Content:
**Diabetes is a condition that causes a person's blood sugar level to become too high.**

There are 2 main types of diabetes:

*   [type 1 diabetes](https://www.nhs.uk/conditions/type-1-diabetes/) – a lifelong condition where the body's immune system attacks and destroys the cells that produce insulin
*   [type 2 diabetes](https://www.nhs.uk/conditions/type-2-diabetes/) – where the body does not produce enough insulin, or the body's cells do not react to insulin properly

Type 2 diabetes is far more common than type 1. In the UK, over 90% of all adults with diabetes have type 2.

High blood sugar that develops during pregnancy is known as [gestational diabetes](https://www.nhs.uk/conditions/gestational-diabetes/). It usually goes away after giving birth.

Non-diabetic hyperglycaemia (pre-diabetes)
------------------------------------------

Many people have blood sugar levels above the normal range, but not high enough to be diagnosed as having diabetes. This is known as non-diabetic hyperglycaemia, or pre-diabetes.

People with non-diabetic hyperglycaemia are at greater risk of developing type 2 diabetes, but the risk can be reduced through lifestyle changes.

If you have non-diabetic hyperglycaemia, you may be eligible for the [NHS Diabetes Prevention Programme](https://www.england.nhs.uk/diabetes/diabetes-prevention/). The programme helps people make lasting lifestyle changes and has been shown to help prevent type 2 diabetes.

People with non-diabetic hyperglycaemia are also recommended to have a blood test every year to monitor their blood sugar levels.

It's very important for diabetes to be diagnosed as early as possible because it's likely to get worse if left untreated and can cause long-term health problems.

When to see a GP
----------------

Visit your GP as soon as possible if you experience the main symptoms of diabetes, which include:

*   feeling very [thirsty](https://www.nhs.uk/conditions/thirst/)
*   peeing more frequently than usual, particularly at night
*   feeling very tired
*   weight loss and loss of muscle bulk
*   itching around the penis or vagina, or frequent episodes of [thrush](https://www.nhs.uk/conditions/thrush-in-men-and-women/)
*   blurred vision

Type 1 diabetes can develop quickly over weeks or even days.

Weight loss is common in people with type 1 diabetes when it first develops and before it's treated, but it's less common in people with type 2 diabetes.

Many people have type 2 diabetes for years without realising because the early symptoms tend to be general, or there are no symptoms at all.

Causes of diabetes
------------------

The amount of sugar in the blood is controlled by a hormone called insulin, which is produced by the pancreas (a gland behind the stomach).

When food is digested and enters your bloodstream, insulin moves glucose out of the blood and into cells, where it's broken down to produce energy.

However, if you have diabetes, your body is unable to break down glucose into energy. This is because there's either not enough insulin to move the glucose, or the insulin produced does not work properly.

There are no lifestyle changes you can make to lower your risk of type 1 diabetes.

You can reduce the risk of type 2 diabetes through healthy eating, regular exercise and achieving a healthy body weight.

You may be more at risk of type 2 diabetes if you:

*   are living with overweight or obesity
*   do not have a healthy diet
*   have a family history of type 2 diabetes
*   are of Asian, Black African or African Caribbean origin
*   take certain medicines such as steroids for a long time
*   have high blood pressure
*   have had gestational diabetes during pregnancy

Living with diabetes
--------------------

If you're diagnosed with diabetes, you'll need to [eat healthily](https://www.nhs.uk/live-well/eat-well/), take [regular exercise](https://www.nhs.uk/live-well/exercise/) and have regular checks including blood tests.

You can use the [BMI healthy weight calculator](https://www.nhs.uk/live-well/healthy-weight/bmi-calculator/) to check whether you're a healthy weight.

Try to [quit smoking](https://www.nhs.uk/live-well/quit-smoking/) if you smoke, and [cut down on alcohol](https://www.nhs.uk/live-well/alcohol-advice/tips-on-cutting-down-alcohol/).

People diagnosed with type 1 diabetes also require regular insulin injections for the rest of their life.

Type 2 diabetes can get worse over time and people living with type 2 diabetes often need medicine, usually in the form of tablets or injections.

However, some people can put their type 2 diabetes into remission by losing weight, where their blood sugar is reduced below the diabetes range. Some people are able to do this through a low-calorie diet, but this is not suitable for everyone, so it's important to get medical advice first.

Read about:

*   [insulin](https://www.nhs.uk/medicines/insulin/)
*   [insulin for type 1 diabetes](https://www.nhs.uk/medicines/insulin/insulin-for-type-1-diabetes/)
*   [medicines for type 2 diabetes](https://www.nhs.uk/conditions/type-2-diabetes/understanding-medication/)
*   [type 2 diabetes remission – information from Diabetes UK](https://www.diabetes.org.uk/guide-to-diabetes/managing-your-diabetes/treating-your-diabetes/type2-diabetes-remission)
*   [treating gestational diabetes](https://www.nhs.uk/conditions/gestational-diabetes/treatment/)

Diabetic eye screening
----------------------

Everyone with diabetes aged 12 years old or over should be invited to have their eyes screened regularly.

If you have diabetes, your eyes are at risk from diabetic retinopathy, a condition that can lead to sight loss if it's not treated.

Screening, which includes a 30-minute check to examine the back of the eyes, is a way of diagnosing diabetic retinopathy and detecting the condition early where possible so it can be treated more effectively. In many people, this can stop it affecting their vision or reduce the chance of it getting worse.

It's important to see a doctor if you notice any problems with your eyesight. Do not wait for your next screening appointment.

Read more about [diabetic eye screening](https://www.nhs.uk/conditions/diabetic-eye-screening/).

Diabetic foot problems
----------------------

Diabetes can damage the nerves in your feet and cause a loss of feeling. It can also reduce the blood supply to your feet. This means you may not notice if your foot is sore or injured, and foot injuries do not heal as well. This can lead to ulcers and infections, and sometimes amputations can be needed in serious cases.

Adults with diabetes should have their feet checked every year by a healthcare professional.

It's important to see a healthcare professional as soon as possible if you notice any problems with your feet.

You can read more about [diabetes and foot problems on the Diabetes UK website](https://www.diabetes.org.uk/guide-to-diabetes/complications/feet).

Page last reviewed: 06 March 2023  
Next review due: 06 March 2026
