Title: Hay fever

URL Source: https://www.nhs.uk/conditions/hay-fever/

Published Time: 23 Oct 2017, 11:09 a.m.

Markdown Content:
Check if you have hay fever
---------------------------

Symptoms of hay fever include:

*   sneezing and coughing
*   a runny or blocked nose
*   itchy, red or watery eyes
*   itchy throat, mouth, nose and ears
*   loss of smell
*   pain around the sides of your head and your forehead
*   headache
*   feeling tired

Symptoms are usually worse between late March and September, especially when it's warm, humid and windy. This is when the pollen count is at its highest.

Hay fever can last for weeks or months, unlike a cold, which usually goes away after 1 to 2 weeks.

How to treat hay fever yourself
-------------------------------

There's currently no cure for hay fever and you cannot prevent it. But you can do things to ease your symptoms when the pollen count is high.

### Do

*   put petroleum jelly (such as Vaseline) around your nostrils to trap pollen
    
*   wear wraparound sunglasses, a mask or a wide-brimmed hat to stop pollen getting into your nose and eyes
    
*   shower and change your clothes after you have been outside to wash pollen off
    
*   keep windows and doors shut as much as possible
    
*   vacuum regularly and dust with a damp cloth
    
*   try to use a pollen filter in the air vents of your car, if you have one, and a HEPA filter in your vaccum cleaner
    

### Don’t

*   do not cut grass or walk on grass
    
*   do not spend too much time outside
    
*   do not keep fresh flowers in the house
    
*   do not smoke or be around smoke – it makes your symptoms worse
    
*   do not dry clothes outside – they can catch pollen
    
*   do not let pets into the house if possible – they can carry pollen indoors
    

### A pharmacist can help with hay fever

Speak to a pharmacist if you have hay fever. they can give you advice and suggest the best treatments to help with symptoms, such as:

*   [antihistamine](https://www.nhs.uk/conditions/antihistamines/) drops, tablets or nasal sprays
*   steroid nasal sprays

Some antihistamines can make you very sleepy, so speak to your pharmacist about non-drowsy antihistamines if you need to.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

[Find out more about hay fever and allergic rhinitis from Allergy UK](https://www.allergyuk.org/types-of-allergies/hayfever/)

Non-urgent advice: See a GP if:
-------------------------------

*   your symptoms are getting worse
*   your symptoms do not improve after taking medicines from the pharmacy

Treatments for hay fever from a GP
----------------------------------

The GP might prescribe a steroid treatment if you have hay fever.

If steroids and other hay fever treatments do not work, the GP may refer you for immunotherapy.

This means you'll be given small amounts of pollen as an injection or tablet to slowly build up your immunity to pollen.

This kind of treatment usually starts a few months before the hay fever season begins.

Immunotherapy is a specialist service that may not be available everywhere.

Causes of hay fever
-------------------

Hay fever is an allergic reaction to the fine powder that plants produce, called pollen, usually when it comes into contact with your mouth, nose, eyes and throat.

[Find out more about the pollen forecast from the Met Office](http://www.metoffice.gov.uk/health/public/pollen-forecast)

Video: Hay fever advice
-----------------------

In this video, an expert explains how hay fever is diagnosed, as well as the symptoms and treatment.

Media last reviewed: 4 April 2023  
Media review due: 4 April 2026

Help us improve our website
---------------------------

Page last reviewed: 21 March 2024  
Next review due: 21 March 2027
