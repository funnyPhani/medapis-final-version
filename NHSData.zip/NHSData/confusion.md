Title: Sudden confusion (delirium)

URL Source: https://www.nhs.uk/conditions/confusion/

Published Time: 18 Oct 2017, 9:54 a.m.

Markdown Content:
**Sudden confusion (delirium) can have many different causes. Get medical help immediately if someone suddenly becomes confused (delirious).**

How to tell if someone is confused
----------------------------------

If a person is confused, they may:

*   not be able to think or speak clearly or quickly
*   not know where they are (feel disorientated)
*   struggle to pay attention or remember things
*   see or hear things that are not there ([hallucinations](https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/feelings-and-symptoms/hallucinations-hearing-voices/))

Try asking the person their name, their age and today's date. If they seem unsure or cannot answer you, they probably need medical help.

Non-urgent advice: See a GP if:
-------------------------------

*   you're worried that you or a relative are becoming increasingly forgetful or confused

It may not be anything serious, but it's best to get checked.

In older people, forgetfulness and confusion are sometimes signs of dementia.

Immediate action required: Go to A&E or call 999 if:
----------------------------------------------------

*   someone suddenly becomes confused

Many causes of sudden confusion need to be assessed and treated as soon as possible. Sometimes it may be life threatening.

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Things you can do while waiting for an ambulance
------------------------------------------------

If you're with someone who has suddenly become confused, there are things you can do while waiting for medical help.

### Do

*   stay with the person – tell them who you are and where they are, and keep reassuring them
    
*   use simple words and short sentences
    
*   make a note of any medicines they're taking, if possible
    

### Don’t

*   do not ask lots of questions while they're feeling confused
    
*   do not stop the person moving around, unless they're in danger
    

Causes of sudden confusion
--------------------------

Sudden confusion can be caused by many different things. Do not try to self-diagnose. Get medical help if someone suddenly becomes confused or delirious.

Some of the most common causes of sudden confusion include:

*   an infection – [urinary tract infections (UTIs)](https://www.nhs.uk/conditions/urinary-tract-infections-utis/) are a common cause in elderly people or people with dementia
*   a [stroke](https://www.nhs.uk/conditions/stroke/) or [TIA ("mini-stroke")](https://www.nhs.uk/conditions/transient-ischaemic-attack-tia/)
*   a [low blood sugar level](https://www.nhs.uk/conditions/low-blood-sugar-hypoglycaemia/) in people with diabetes
*   a [head injury](https://www.nhs.uk/conditions/severe-head-injury/)
*   some types of prescription medicine
*   [alcohol poisoning](https://www.nhs.uk/conditions/alcohol-poisoning/) or alcohol withdrawal
*   taking drugs
*   [carbon monoxide poisoning](https://www.nhs.uk/conditions/carbon-monoxide-poisoning/) – especially if other people you live with become unwell
*   a severe [asthma attack](https://www.nhs.uk/conditions/asthma/asthma-attack/) or other problems with the lungs or heart
*   certain types of seizures caused by [epilepsy](https://www.nhs.uk/conditions/epilepsy/)

Page last reviewed: 14 June 2021  
Next review due: 14 June 2024
