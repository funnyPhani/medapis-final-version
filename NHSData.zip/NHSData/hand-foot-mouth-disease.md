Title: Hand, foot and mouth disease

URL Source: https://www.nhs.uk/conditions/hand-foot-mouth-disease/

Published Time: 18 Oct 2017, 2:35 p.m.

Markdown Content:
Hand, foot and mouth disease is not the same as foot and mouth disease that affects farm animals.

Check if it's hand, foot and mouth disease
------------------------------------------

The 1st symptoms of hand, foot and mouth disease can be:

*   a sore throat
*   a high temperature
*   not wanting to eat

The 2nd stage usually starts a few days later and symptoms can include:

*   [mouth ulcers](https://www.nhs.uk/conditions/mouth-ulcers/), which can be painful
*   a raised rash of spots on the hands and feet, and sometimes the groin area and bottom

The rash of spots can look pink, red, or darker than the surrounding skin, depending on your skin tone.

The spots can turn into blisters, which might be grey or lighter than surrounding skin and can be painful.

Symptoms are usually mild and are the same in adults and children.

### Mouth ulcers

![Image 1: A round, red ulcer with a lighter pink centre on the side of a child's tongue. The tongue has a creamy white coating on top.](https://assets.nhs.uk/nhsuk-cms/images/1.width-320.jpg)

### Spots on the hands and feet

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: Hand, foot and mouth disease spots on white skin (thumbnail).](https://www.nhs.uk/conditions/hand-foot-mouth-disease/#gallery-image-1)
*   [2: Hand, foot and mouth disease spots and patches on medium brown skin (thumbnail).](https://www.nhs.uk/conditions/hand-foot-mouth-disease/#gallery-image-2)
*   [3: Hand, foot and mouth disease blister on white skin (thumbnail).](https://www.nhs.uk/conditions/hand-foot-mouth-disease/#gallery-image-3)

![Image 2: Hand, foot and mouth disease spots on a baby's hand and wrist on white skin. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/2AB6A1W.2e16d0ba.fill-420x280.png)

Long description, image 1.

Hand, foot and mouth disease spots on the wrist and hand of a baby with white skin.

There are 3 round, raised spots and several smaller, flat spots.

The large spots vary in size from around 2mm to 5mm. 1 spot is near the knuckle of the index finger, the other 2 are near the wrist. The skin around each spot is pink. The centre of each large spot is light pink or similar to the baby's skin tone. The spots look like they have fluid in them.

There are patches of pink skin on the fingers and back of the hand.

### If you're not sure your child has hand, foot and mouth disease

Look at other [rashes in babies and children](https://www.nhs.uk/conditions/rashes-babies-and-children/).

How to treat hand, foot and mouth disease yourself
--------------------------------------------------

Hand, foot and mouth disease usually gets better on its own in 7 to 10 days. You cannot take antibiotics or other medicines to cure it.

To help the symptoms:

*   drink cool fluids to soothe the mouth and prevent dehydration (but avoid acidic drinks, such as fruit juice)
*   eat soft foods like yoghurt and avoid hot, salty and spicy foods
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-children/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-children/) to help ease a sore mouth or throat

### A pharmacist can help with hand, foot and mouth disease

Ask a pharmacist for advice about treatments, such as mouth ulcer gels, sprays and mouthwashes, to relieve pain.

They can tell you which ones are suitable for children.

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Non-urgent advice: See a GP if:
-------------------------------

*   symptoms of hand, foot and mouth disease do not improve after 7 to 10 days
*   you're pregnant and get hand, foot and mouth disease

Hand, foot and mouth disease can be spread to other people.

Check with your GP surgery before going. They may suggest a phone consultation.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you or your child has a very high temperature, or feel hot and shivery
*   you're worried about your child's hand, foot and mouth disease symptoms
*   your child has hand, foot and mouth disease and is peeing less than usual (they may be becoming dehydrated)

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

How to stop hand, foot and mouth disease spreading
--------------------------------------------------

Hand, foot and mouth disease is easily passed on to other people. It's spread in coughs, sneezes, poo and the fluid in the blisters. You can get it more than once.

You can start spreading it from a few days before you have any symptoms, but you're most likely to spread it to others in the first 5 days after symptoms start.

To reduce the risk of spreading hand, foot and mouth disease:

*   wash your hands often with soap and water, and children's hands too
*   use tissues to trap germs when you cough or sneeze
*   bin used tissues as quickly as possible
*   do not share towels or household items like cups or cutlery
*   wash soiled bedding and clothing on a hot wash

### Staying off school or nursery

Keep your child off school or nursery while they're feeling too unwell to go.

But as soon as they're feeling better, they can go back to school or nursery. There's no need to wait until all the blisters have healed.

Keeping your child away from other children for longer is unlikely to stop the illness spreading.

Hand, foot and mouth disease in pregnancy
-----------------------------------------

Although there's usually no risk to the pregnancy or baby, it's best to avoid close contact with anyone who has hand, foot and mouth disease.

This is because getting hand, foot and mouth disease shortly before giving birth can mean your baby is born with a mild version of it.

Speak to a GP or your midwife if you have been in contact with someone with hand, foot and mouth disease.

Page last reviewed: 10 May 2024  
Next review due: 10 May 2027
