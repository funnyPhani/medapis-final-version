Title: BCG vaccine for tuberculosis (TB)

URL Source: https://www.nhs.uk/vaccinations/bcg-vaccine-for-tuberculosis-tb/

Published Time: 6 Mar 2024, 5:39 p.m.

Markdown Content:
What the BCG vaccine is for
---------------------------

The BCG vaccine helps protect against an infection called [tuberculosis (TB)](https://www.nhs.uk/conditions/tuberculosis-tb/).

TB mainly affects the lungs, but can affect other parts of the body. It can become very serious if not treated.

The vaccine is particularly helpful in protecting babies and young children against more serious forms of TB, such as TB meningitis (TB that affects the brain).

Who should have the BCG vaccine
-------------------------------

The BCG vaccine is not routinely given as part of the NHS vaccination schedule.

It is only recommended for people at higher risk of getting tuberculosis (TB), such as some babies and children, some travellers and people at risk through their work.

You only need to have the BCG vaccine once.

Newborn babies

It's recommended that your baby has the BCG vaccine if any of the following apply:

*   they live in an area of the UK where there is a higher risk of getting TB
*   they have a parent or grandparent born in a country where there is a higher risk of getting TB
*   they'll be going to live or stay in a country where there is a higher risk of getting TB
*   they have been living with, or in regular close contact with, someone who has or had TB

If your baby needs the vaccine, they will usually be given it at around 28 days old.

Toddlers and children

The BCG vaccine is recommended for children aged 1 to 16 if any of the following apply:

*   they have a parent or grandparent born in a country where there is a higher risk of getting TB
*   they were born or lived for at least 3 months in a country where there is a higher risk of getting TB
*   they have been living with, or in regular close contact with, someone who has or had TB

People at risk of TB through their work

You may need the BCG vaccine if you're at risk of getting TB because of your work, for example:

*   you're a health worker who works with people with TB
*   you work in a laboratory where you may come into contact with TB bacteria
*   you work with animals that could be infected with TB (such as people who work at a vets or abattoir)
*   you work with people who may be more at risk of TB such as some homeless people, asylum seekers and refugees, people who misuse drugs and people in prison

People travelling abroad

The BCG vaccine is recommended if you're staying for more than 3 months in a country where there is a higher risk of getting TB and either:

*   you're aged 16 or under and you'll be staying with friends, family or local people
*   you're over 16 years of age and you're a health worker who is likely to be in contact with people with TB

Adults arriving into the UK from certain countriesYou may need the BCG vaccine if you've come to live in the UK from sub-Saharan Africa or a country where there is a very high risk of getting TB.

Who cannot have the BCG vaccine
-------------------------------

Most people who are eligible for the BCG vaccine can have it.

But it's a live vaccine, which means it contains a weakened form of the tuberculosis (TB) bacteria, and it is not suitable for everyone.

The BCG vaccine is not given to:

*   anyone who is pregnant
*   anyone who has already had the BCG vaccine
*   anyone who has TB or has had it before – you can have a test to check this if needed
*   anyone who has had a severe allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to any ingredients in the BCG vaccine
*   babies whose mother had biological medicines to suppress their immune system during pregnancy
*   babies who may have a weakened immune system, for example if there is a family history of HIV or severe combined immunodeficiency (SCID)
*   children and adults with a weakened immune system, either because of a health condition such as HIV, or treatments such as chemotherapy or steroid tablets

Information:

### **Getting vaccinated if you or your child are unwell**

If you have a high temperature or a skin infection, you'll need to wait until you've recovered before you can have the BCG vaccine.

BCG vaccine ingredients
-----------------------

There is 1 type of BCG vaccine given in the UK. You can check the ingredients in the patient leaflet:

[BCG vaccine patient leaflet (Electronic Medicines Compendium website; PDF only, 272 KB)](https://www.medicines.org.uk/emc/files/pil.9890.pdf)

How to get the BCG vaccine
--------------------------

Your midwife, health visitor, local health centre or hospital will usually let you know if the BCG vaccine is recommended for your baby.

Your baby will usually be offered it at around 28 days old, after they've had results from the [newborn blood spot test](https://www.nhs.uk/conditions/baby/newborn-screening/blood-spot-test/), which tests for severe combined immunodeficiency (SCID). If they have SCID then they will not be given the BCG vaccine.

For other children and adults, speak to your GP surgery if you think you or your child may need the BCG vaccine.

How the BCG vaccine is given
----------------------------

The BCG vaccine is given as an injection into the upper part of your left arm. You only need 1 dose.

### Skin test

Some children and adults need to have a skin test (called the tuberculin skin test or Mantoux test) a few days before having the BCG vaccine. This is to see if they already have TB or have had it before.

A small amount of liquid is injected under the skin in your arm. This liquid will cause a small reaction on your skin if you have or had TB.

If the test shows you're likely to have TB or have had it before, you should not have the BCG vaccine.

Information:

### **Having the BCG vaccine at the same time as other vaccines**

You can have the BCG vaccine at the same time as other vaccines.

But you should not have another injection in the same arm for at least 3 months after the BCG vaccine, as it can cause swelling in your glands.

For babies, ask the person giving the BCG vaccine to fill out your child's personal child health record (red book) so you can show it to anyone giving your child an injection in the next 3 months.

Side effects of the BCG vaccine
-------------------------------

Like all medicines, the BCG vaccine can cause side effects.

### Blister

The main side effect of the BCG vaccine is a blister where the injection was given.

This may appear as a raised bubble straight after the injection and then turn into a blister or a sore after 2 weeks.

It then forms a scab and can take a few weeks or months to heal, leaving a small flat scar.

During this time, try to leave the site uncovered. If the blister starts to ooze or weep, you can use a dry dressing until a scab forms, but do not use a plaster.

If you're worried or you think the blister has become infected, see a GP.

### Other side effects

Other side effects of the BCG vaccine are uncommon and usually mild. They can include:

*   a high temperature (fever)
*   a headache
*   swollen glands under the armpit on the side of your body where the injection was given

More serious side effects are rare and include:

*   a severe allergic reaction (anaphylaxis) – the person who vaccinates you will be trained to deal with allergic reactions and treat them immediately
*   an abscess (build-up of pus) where the injection was given
