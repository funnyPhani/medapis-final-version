Title: Early menopause

URL Source: https://www.nhs.uk/conditions/early-menopause/

Published Time: 9 Jan 2018, 10:44 a.m.

Markdown Content:
**Early menopause is when your periods stop before the age of 45. It can happen naturally or be caused by treatment for other conditions.**

Check if it's early menopause
-----------------------------

The main symptom of early menopause is not having your period regularly or your periods stopping completely.

Other symptoms include:

*   hot flushes and night sweats
*   vaginal dryness
*   difficulty sleeping
*   low mood or anxiety
*   reduced sex drive
*   problems with memory or concentration

[Find out more about the symptoms of menopause](https://www.nhs.uk/womens-health/menopause/)

Non-urgent advice: See a GP if:
-------------------------------

*   you think you have early menopause symptoms

Causes of early menopause
-------------------------

You have a higher chance of going through the menopause early if other women in your mother's family also had an early menopause.

It's also more likely if you:

*   started your periods early (before the age of 8)
*   have never given birth or have only given birth once or twice
*   smoke
*   are underweight

Early menopause can also be brought on when you have treatment for other conditions.

This includes treatments such as:

*   radiotherapy or chemotherapy
*   certain hormone medicines
*   surgery to remove your ovaries

Treatment for early menopause
-----------------------------

If a GP thinks you're going through early menopause, they'll ask you about your symptoms and ask if early menopause runs in your family.

You'll also have blood tests to look at your hormone levels.

The main treatment for early menopause is taking medicines such as the [combined contraceptive pill](https://www.nhs.uk/contraception/methods-of-contraception/combined-pill/) or [HRT](https://www.nhs.uk/medicines/hormone-replacement-therapy-hrt/about-hormone-replacement-therapy-hrt/) to replace your missing hormones.

[Find out more about how menopause is treated](https://www.nhs.uk/conditions/menopause/treatment/)

You can also try making lifestyle changes to help manage your symptoms.

[Find out more about things you can do if you're going through early menopause](https://www.nhs.uk/conditions/menopause/things-you-can-do/)

Information:

If these treatments and making lifestyle changes do not help and you're still getting symptoms, you can be referred to a specialist menopause centre.

[Find your nearest NHS or private menopause specialist on the British Menopause Society website](https://thebms.org.uk/find-a-menopause-specialist/)

Complications of early menopause
--------------------------------

Early menopause can affect both your physical and mental health.

Your fertility will be affected and you'll no longer be able to have a baby.

You'll also have a higher chance of developing conditions such as [osteoporosis](https://www.nhs.uk/conditions/osteoporosis/) and [cardiovascular disease](https://www.nhs.uk/conditions/cardiovascular-disease/).

If you're finding going through early menopause difficult and it's affecting your mental health, help and support is available.

You can get NHS talking therapies without seeing a GP first.

[Find an NHS talking therapies service](https://www.nhs.uk/service-search/mental-health/find-an-nhs-talking-therapies-service)

Find out more
-------------

*   [Help and support if you're going through the menopause](https://www.nhs.uk/conditions/menopause/help-and-support/)
*   [The Daisy Network](http://www.daisynetwork.org.uk/)

Page last reviewed: 02 February 2021  
Next review due: 02 February 2024
