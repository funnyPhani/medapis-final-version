Title: Endoscopy

URL Source: https://www.nhs.uk/conditions/endoscopy/

Published Time: 18 Oct 2017, 12:53 p.m.

Markdown Content:
Endoscopy - NHS
===============
                                    

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/endoscopy/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

Endoscopy
=========

An endoscopy is a test to look inside your body.

A long, thin tube with a small camera inside, called an endoscope, is passed into your body through a natural opening such as your mouth.

Your GP may refer you for an endoscopy if you're having certain symptoms. It will usually be done at an endoscopy unit in a hospital.

There are different types of endoscopy that look at different parts of the body.

The type of endoscopy you have will depend on your symptoms.

Types of endoscopy
------------------

Find out about:

*   [colonoscopy](https://www.nhs.uk/conditions/colonoscopy/): in your bottom to check your bowels
*   [colposcopy](https://www.nhs.uk/conditions/colposcopy/): in your vagina to check your cervix (the opening to your womb)
*   [cystoscopy](https://www.nhs.uk/conditions/cystoscopy/): in your urethra (tube where pee comes out) to check your bladder
*   [gastroscopy](https://www.nhs.uk/conditions/gastroscopy/): in your mouth to check your oesophagus (food pipe), stomach and part of the small intestine
*   [hysteroscopy](https://www.nhs.uk/conditions/hysteroscopy/): in your vagina to check your womb

Page last reviewed: 08 February 2022  
Next review due: 08 February 2025

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
