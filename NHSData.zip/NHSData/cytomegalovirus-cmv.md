Title: Cytomegalovirus (CMV)

URL Source: https://www.nhs.uk/conditions/cytomegalovirus-cmv/

Published Time: 23 Oct 2017, 12:01 p.m.

Markdown Content:
**Cytomegalovirus (CMV) is a common virus that's usually harmless. Sometimes it causes problems in babies and people with a weakened immune system.**

Symptoms of cytomegalovirus (CMV)
---------------------------------

Cytomegalovirus (CMV) does not usually cause any symptoms and most people do not realise they have it.

Some people get flu-like symptoms the first time they get CMV, including:

*   a high temperature
*   aching muscles
*   tiredness
*   a skin rash
*   feeling sick
*   a sore throat
*   swollen glands

They usually get better without treatment within about 3 weeks.

### Non-urgent advice: See a GP if:

You have symptoms of cytomegalovirus (CMV) and:

*   you're pregnant
*   you have a weakened immune system – for example, because you're having chemotherapy

The GP may arrange tests to find out if you've been infected with CMV.

Complications of cytomegalovirus (CMV)
--------------------------------------

When a baby is born with a CMV infection, it's known as congenital CMV.

Most babies with congenital CMV do not have any symptoms.

But congenital CMV can sometimes cause problems, including:

*   a rash
*   yellowing of the skin and the whites of the eyes (jaundice)
*   a low birth weight
*   a smaller head than usual (microcephaly)
*   seizures (fits)
*   hearing problems in 1 or both ears
*   problems with the eyes
*   problems with the liver and spleen

Babies born with congenital CMV may have tests to check their kidneys, liver, brain, eyes and hearing, and regular follow-up appointments until they're around 5 years old.

Information:

### Find out more

*   [CMV Action](http://cmvaction.org.uk/)

How cytomegalovirus (CMV) is spread
-----------------------------------

Cytomegalovirus (CMV) is mainly spread through close contact with someone who already has it.

You can pass it on through contact with body fluids, including saliva, blood, breast milk, pee and poo, and through sex.

CMV can only be passed on when it's active. The virus is active when:

*   you get CMV for the first time – young children often get CMV for the first time at nursery
*   the virus has reactivated because you have a weakened immune system
*   you've been reinfected with a different type (strain) of CMV

Congenital CMV is caused by passing on an active CMV infection to your unborn baby during pregnancy.

Treatment for cytomegalovirus (CMV)
-----------------------------------

If cytomegalovirus (CMV) is not causing symptoms, you or your baby may not need any treatment.

There's currently no treatment for CMV in pregnancy, but in most cases the virus does not cause any problems.

Antiviral medicine may be used to treat:

*   babies diagnosed with congenital CMV after they're born
*   people with a weakened immune system
*   people who have had a stem cell transplant or organ transplant

Treatment weakens the virus and lowers the chance of serious problems, but it does not cure the CMV infection.

Things you can do to lower the chance of getting cytomegalovirus (CMV) in pregnancy
-----------------------------------------------------------------------------------

The best way to lower the chance of getting cytomegalovirus (CMV) during pregnancy is to:

*   wash your hands using soap and water – especially after changing nappies, feeding young children or wiping their nose
*   regularly wash toys or other items that may have young children's saliva or pee on them
*   avoid sharing food, cutlery and drinking glasses, or putting a child's dummy in your mouth
*   avoid kissing young children on their mouth

There's currently no vaccine for CMV.

Important
---------

Pregnant women who work closely with children or already have a young family are more at risk of getting CMV.

Page last reviewed: 20 July 2023  
Next review due: 20 July 2026
