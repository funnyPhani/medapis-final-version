Title: Carcinoembryonic antigen (CEA) test

URL Source: https://www.nhs.uk/conditions/cea-test/

Published Time: 24 Sep 2018, 4:11 p.m.

Markdown Content:
**A carcinoembryonic antigen (CEA) test is used to check how well treatment is working in certain types of cancer, particularly** [**bowel cancer**](https://www.nhs.uk/conditions/bowel-cancer/)**.**

Carcinoembryonic antigens are proteins produced by some types of [cancer](https://www.nhs.uk/conditions/cancer/).

In response to the antigens, the body produces antibodies to help fight them.

A CEA test is often carried out after surgery to check carcinoembryonic antigen levels.

As well as being a useful marker for bowel cancer, CEA tests can be used to assess other types of cancer, including:

*   [lung cancer](https://www.nhs.uk/conditions/lung-cancer/)
*   [breast cancer](https://www.nhs.uk/conditions/breast-cancer/)
*   [liver cancer](https://www.nhs.uk/conditions/liver-cancer/)
*   [pancreatic cancer](https://www.nhs.uk/conditions/pancreatic-cancer/)
*   [stomach cancer](https://www.nhs.uk/conditions/stomach-cancer/)
*   [ovarian cancer](https://www.nhs.uk/conditions/ovarian-cancer/)

CEA levels may also be raised in non-cancerous conditions, such as [liver disease](https://www.nhs.uk/conditions/liver-disease/) and [inflammatory bowel disease](https://www.nhs.uk/conditions/inflammatory-bowel-disease/) ([Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/) and [ulcerative colitis](https://www.nhs.uk/conditions/ulcerative-colitis/)).

Find out more about a [CEA test on Lab Tests Online-UK](https://labtestsonline.org.uk/tests/carcinoembryonic-antigen-cea).

Page last reviewed: 30 September 2021  
Next review due: 30 September 2024
