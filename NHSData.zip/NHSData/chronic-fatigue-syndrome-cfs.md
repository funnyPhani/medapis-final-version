Title: Myalgic encephalomyelitis or chronic fatigue syndrome (ME/CFS)

URL Source: https://www.nhs.uk/conditions/chronic-fatigue-syndrome-cfs/

Published Time: 20 Oct 2017, 10:50 a.m.

Markdown Content:
**Myalgic encephalomyelitis, also called chronic fatigue syndrome or ME/CFS, is a long-term condition** **that can affect different parts of the body. The most common symptom is extreme tiredness. The cause of ME/CFS is unknown.**

ME/CFS can affect anyone, including children.

Symptoms of ME/CFS
------------------

The 4 main symptoms of ME/CFS are:

*   feeling extremely tired all the time (fatigue), which can make daily activities like taking a shower, or going to work or school, difficult
*   sleep problems, including insomnia, sleeping too much, feeling like you have not slept properly and feeling exhausted or stiff when you wake up
*   problems with thinking, concentration and memory (brain fog)
*   symptoms getting worse after physical or mental activity, and possibly taking weeks to get better (also called post-exertional malaise, or PEM)

Some people with ME/CFS may also have pain in different parts of the body or flu-like symptoms, such as high temperature, headache and aching joints or muscles.

The symptoms of ME/CFS are similar to the symptoms of some other illnesses, so it’s important to see a GP to get a correct diagnosis.

[Find out more about the symptoms of ME/CFS](https://www.nhs.uk/conditions/chronic-fatigue-syndrome-cfs/symptoms/)

Diagnosing ME/CFS
-----------------

There's no specific test for ME/CFS, so it's diagnosed based on your symptoms and by ruling out other conditions that could be causing your symptoms.

The GP will ask about your symptoms and medical history. You may also have blood and urine tests.

As the symptoms of ME/CFS are similar to those of many common illnesses that usually get better on their own, a diagnosis of ME/CFS may be considered if you do not get better as quickly as expected.

[Find out more about diagnosing ME/CFS](https://www.nhs.uk/conditions/chronic-fatigue-syndrome-cfs/diagnosis/)

Treating ME/CFS
---------------

While there's currently no cure for ME/CFS, there are treatments that may help you manage the condition and relieve the symptoms.

Treatments include:

*   energy management – where you're given advice about how to make best use of the energy you have without making your symptoms worse
*   [cognitive behavioural therapy (CBT)](https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/talking-therapies-and-counselling/cognitive-behavioural-therapy-cbt/overview/)
*   medicine to control symptoms such as pain and sleeping problems

People with ME/CFS will need to adapt their daily routine and pattern of activities on a long-term basis. There may be periods when your symptoms get better or worse.

[Find out more about treatments for ME/CFS](https://www.nhs.uk/conditions/chronic-fatigue-syndrome-cfs/treatment/)

Living with ME/CFS
------------------

Living with ME/CFS can be difficult. Extreme tiredness and other physical symptoms can make it hard to carry out everyday activities. You may have to make some major lifestyle changes.

ME/CFS can also affect your mental and emotional health, and have a negative effect on your self-esteem.

As well as asking your family and friends for support, you may find it useful to talk to other people with ME/CFS.

[ME Association](http://www.meassociation.org.uk/) is a charity that provides information, support and practical advice for people affected by the condition.

[You can find a local support group on the ME Association website](http://www.meassociation.org.uk/information-and-support-line/localsupportgroups/)

Page last reviewed: 28 May 2024  
Next review due: 28 May 2027
