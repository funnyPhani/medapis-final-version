Title: Gonorrhoea

URL Source: https://www.nhs.uk/conditions/gonorrhoea/

Published Time: 3 Apr 2018, 1:20 p.m.

Markdown Content:
**Gonorrhoea is a** [**sexually transmitted infection (STI)**](https://www.nhs.uk/conditions/sexually-transmitted-infections-stis/) **caused by bacteria called Neisseria gonorrhoeae or gonococcus. It used to be known as "the clap".**

How gonorrhoea is spread
------------------------

The bacteria that cause gonorrhoea are mainly found in discharge from the penis and in vaginal fluid.

Gonorrhoea is easily passed between people through:

*   unprotected vaginal, oral or anal sex
*   sharing vibrators or other sex toys that have not been washed or covered with a new condom each time they're used

The bacteria can infect the entrance to the womb (cervix), the tube that passes urine out of the body (urethra), the rectum and, less commonly, the throat or eyes.

The infection can also be passed from a pregnant woman to her baby. If you're pregnant and may have gonorrhoea, it's important to get tested and treated before your baby is born.

Without treatment, gonorrhoea can cause permanent blindness in a newborn baby.

Gonorrhoea is not spread by hugging, swimming pools, toilet seats or sharing baths, towels, cups, plates or cutlery. The bacteria cannot survive outside the human body for long.

Symptoms of gonorrhoea
----------------------

Typical symptoms of gonorrhoea include a thick green or yellow discharge from the vagina or penis, pain when peeing and, in women, bleeding between [periods](https://www.nhs.uk/conditions/periods/).

But around 1 in 10 infected men and almost half of infected women do not experience any symptoms.

Getting tested
--------------

If you have any of the symptoms of gonorrhoea or you're worried you may have an STI, you should visit a sexual health clinic for a sexual health test.

[Find a sexual health clinic](https://www.nhs.uk/service-search/find-a-sexual-health-clinic/)

You can also contact the national sexual health helpline free on 0300 123 7123:

*   Monday to Friday: 9am to 8pm
*   Saturday and Sunday: 11am to 4pm

Gonorrhoea can be easily diagnosed by testing a sample of discharge picked up using a swab. In men, testing a sample of urine can also diagnose the condition.

It's important to get tested as soon as possible because gonorrhoea can lead to more serious long-term health problems if it's not treated, including [pelvic inflammatory disease (PID)](https://www.nhs.uk/conditions/pelvic-inflammatory-disease-pid/) in women or [infertility](https://www.nhs.uk/conditions/infertility/).

Read more about:

*   [diagnosing gonorrhoea](https://www.nhs.uk/conditions/gonorrhoea/diagnosis/) 
*   possible [complications of gonorrhoea](https://www.nhs.uk/conditions/gonorrhoea/complications/)
*   [visiting an STI clinic](https://www.nhs.uk/live-well/sexual-health/visiting-an-sti-clinic/)

Treating gonorrhoea
-------------------

Gonorrhoea is usually treated with a single antibiotic injection (usually in the buttocks or thigh). With effective treatment, most of your symptoms should improve within a few days.

It's usually recommended you attend a follow-up appointment a week or 2 after treatment so another test can be carried out to see if you're clear of infection.

You should avoid having sex until you have been told you no longer have the infection.

Previous successful treatment for gonorrhoea does not make you immune to catching it again.

Who's affected
--------------

Anyone who's sexually active can catch gonorrhoea, particularly people who change partners frequently or do not use a barrier method of contraception, such as a [condom](https://www.nhs.uk/conditions/contraception/male-condoms/), when having sex. (See [Your contraception guide.](https://www.nhs.uk/conditions/contraception/))

Gonorrhoea is the second most common bacterial STI in the UK after [chlamydia](https://www.nhs.uk/conditions/chlamydia/).

In 2019, more than 70,000 people were diagnosed with gonorrhoea in England, with most cases affecting gay, bisexual and other men who have sex with men.

Preventing gonorrhoea
---------------------

Gonorrhoea and other STIs can be successfully prevented by using appropriate contraception and taking other precautions, such as:

*   using male [condoms](https://www.nhs.uk/conditions/contraception/male-condoms/) or [female condoms](https://www.nhs.uk/conditions/contraception/female-condoms/) every time you have vaginal sex, or male condoms during anal sex
*   using a condom to cover the penis or a latex or plastic square (dam) to cover the female genitals if you have oral sex
*   not sharing sex toys, or washing them and covering them with a new condom before anyone else uses them

If you're worried you may have an STI, visit a sexual health clinic for advice.

[Find a sexual health clinic](https://www.nhs.uk/service-search/find-a-sexual-health-clinic/)

Get more advice about [sexual health](https://www.nhs.uk/live-well/sexual-health/).

Page last reviewed: 15 September 2021  
Next review due: 15 September 2024
