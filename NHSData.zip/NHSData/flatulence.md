Title: Farting (flatulence)

URL Source: https://www.nhs.uk/conditions/flatulence/

Published Time: 19 Dec 2017, 3:09 p.m.

Markdown Content:
**Farting, also known as flatulence or wind, is normal. There are things you can do if you fart a lot or it's smelly. Sometimes it can be a sign of a health condition.**

Check if your farting is normal
-------------------------------

Farting is usually nothing to worry about. Everyone farts, some people more than others.

What's normal is different for everyone. If you notice a change or it's affecting your life, there are things you can do.

Things you can do to cut down excessive or smelly farts
-------------------------------------------------------

### Do

*   eat smaller meals, more often
    
*   drink or chew food slowly, with your mouth closed
    
*   exercise regularly to improve how your body digests food
    
*   drink peppermint tea
    

### Don’t

*   do not chew gum, smoke, or suck pen tops or hard sweets (to avoid swallowing air)
    
*   do not wear loose-fitting dentures
    
*   do not eat too many foods that are difficult to digest and make you fart
    
*   do not drink too much beer, wine or fruit juice
    

Food and drinks that can make you fart

*   cabbage
*   broccoli
*   cauliflower
*   brussels sprouts
*   pulses, like beans or lentils
*   dried fruit, like raisins or apricots
*   onions
*   food or drinks containing the sweetener sorbitol
*   fizzy drinks and beer

### A pharmacist can help with excessive or smelly farts

Speak to a pharmacist about excessive or smelly farts.

They might be able to tell you:

*   if you can buy something to help – for example, charcoal tablets or special underwear and pads that absorb smells
*   if you should see a GP

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   farting is affecting your life and self help and pharmacy treatments have not worked
*   you have a stomach ache or bloating that will not go away or comes back
*   you keep getting constipation or diarrhoea
*   you have lost weight without trying
*   you've had blood in your poo for 3 weeks

What causes excessive or smelly farts
-------------------------------------

Excessive or smelly farts can be caused when you swallow air or eat foods that are difficult to digest. It can also sometimes be a sign of a health condition.

Do not self-diagnose. See a GP if you're worried about your farting.

Excessive or smelly wind can also be a side effect of some medicines, including:

*   non-steroidal anti-inflammatory drugs (NSAIDS), like [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
*   some [laxatives](https://www.nhs.uk/conditions/laxatives/)
*   [antifungal medicines](https://www.nhs.uk/conditions/antifungal-medicines/)
*   [statins](https://www.nhs.uk/conditions/statins/)

Do not stop or change your medicine without speaking to a GP first.

Page last reviewed: 07 June 2022  
Next review due: 07 June 2025
