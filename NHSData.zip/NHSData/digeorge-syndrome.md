Title: DiGeorge syndrome (22q11 deletion) - NHS

URL Source: https://www.nhs.uk/conditions/digeorge-syndrome/

Published Time: 18 Oct 2017, 10:07 a.m.

Markdown Content:
**DiGeorge syndrome is a condition present from birth that can cause a range of lifelong problems, including heart defects and learning difficulties.**

The severity of the condition varies. Some children can be severely ill and very occasionally may die from it, but many others may grow up without realising they have it.

DiGeorge syndrome is caused by a problem with a person's genes, called 22q11 deletion. It is not usually passed on to a child by their parents, but it is in a few cases.

It's often diagnosed soon after birth with a blood test to check for the genetic fault.

Symptoms of DiGeorge syndrome
-----------------------------

DiGeorge syndrome can cause a range of problems, but most people will not have all of these.

Some of the most common issues are:

*   learning and behaviour problems – including delays in learning to walk or talk, [learning disabilities](https://www.nhs.uk/conditions/learning-disabilities/) and problems such as [attention deficit hyperactivity disorder (ADHD)](https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd/) or [autism](https://www.nhs.uk/conditions/autism/)
*   speech and hearing problems – including temporary hearing loss due to frequent ear infections, being slow to start talking and having a "nasal-sounding" voice
*   mouth and feeding problems – including a gap in the top of the mouth or lip [(cleft lip or palate)](https://www.nhs.uk/conditions/cleft-lip-and-palate/), difficulty feeding and sometimes bringing food back up through the nose
*   heart problems – some children and adults have heart defects from birth [(congenital heart disease)](https://www.nhs.uk/conditions/congenital-heart-disease/)
*   hormone problems – underdeveloped parathyroid glands produce too little parathyroid hormone [(hypoparathyroidism)](https://www.nhs.uk/conditions/hypoparathyroidism/), which can lead to problems such as shaking [(tremors)](https://www.nhs.uk/conditions/tremor-or-shaking-hands/) and seizures (fits)

Other possible problems include:

*   a higher risk of getting infections – such as [ear infections](https://www.nhs.uk/conditions/ear-infections/), [oral thrush](https://www.nhs.uk/conditions/oral-thrush-mouth-thrush/) and [chest infections](https://www.nhs.uk/conditions/chest-infection/) – because the immune system (the body's natural defence against illness) is weaker than normal
*   bone, muscle and joint problems – including leg pains that keep coming back, an unusually curved spine [(scoliosis)](https://www.nhs.uk/conditions/scoliosis/) and [rheumatoid arthritis](https://www.nhs.uk/conditions/rheumatoid-arthritis/)
*   short stature – children and adults may be shorter than average
*   mental health problems – adults are more likely to have problems such as [schizophrenia](https://www.nhs.uk/conditions/schizophrenia/) and anxiety disorders

Causes of DiGeorge syndrome
---------------------------

DiGeorge syndrome is caused by a problem called 22q11 deletion. This is where a small piece of genetic material is missing from a person's DNA.

In about 9 in 10 cases (90%), the bit of DNA was missing from the egg or sperm that led to the pregnancy. This can happen by chance when sperm and eggs are made. It is not a result of anything you did before or during the pregnancy.

In these cases, there's usually no family history of DiGeorge syndrome and the risk of it happening again to other children is very small.

In around 1 in 10 cases (10%), the 22q11 deletion is passed on to a child by a parent who has DiGeorge syndrome, although they may not realise they have it if it's mild.

What are the chances of my next child having DiGeorge syndrome?
---------------------------------------------------------------

If neither parent has DiGeorge syndrome, the risk of having another child with it is thought to be less than 1 in 100 (1%).

If 1 parent has the condition, they have a 1 in 2 (50%) chance of passing it on to their child. This applies to each pregnancy.

Speak to a GP if you're planning a pregnancy and you have a family history of DiGeorge syndrome, or you have a child with it.

They may refer you for a [genetic test](https://www.nhs.uk/conditions/genetic-and-genomic-testing/) and talk about your level of risk and discuss your options. These may include:

*   having a blood test to check if you or your partner carry the genetic problem that causes DiGeorge syndrome
*   having tests during pregnancy ([chorionic villus sampling](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/) or [amniocentesis](https://www.nhs.uk/conditions/amniocentesis/)) to check if your baby has the genetic problem that causes the condition – although this cannot show how severely your child will be affected
*   [pre-implantation genetic diagnosis](http://www.hfea.gov.uk/preimplantation-genetic-diagnosis.html) – a type of [IVF](https://www.nhs.uk/conditions/ivf/) where eggs are fertilised in a laboratory and embryos are tested for genetic problems before they're implanted in the womb (this is not always available on the NHS)

Treatment and support for DiGeorge syndrome
-------------------------------------------

There's currently no cure for DiGeorge syndrome. Children and adults with the condition will be closely monitored to check for problems, and these can be treated as they happen, if needed.

For example, someone with DiGeorge syndrome may have:

*   regular [hearing tests](https://www.nhs.uk/conditions/hearing-tests/), [blood tests](https://www.nhs.uk/conditions/blood-tests/), heart scans and measurements of their height and weight
*   an assessment of their development and learning ability before starting school – if your child has a learning disability, they may need extra support at a mainstream school, or they may benefit from attending a special school (read more about [education for children with learning disabilities](https://www.nhs.uk/conditions/learning-disabilities/))
*   speech therapy to help with speech problems and dietary changes (or sometimes a temporary feeding tube) to help with feeding problems
*   [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) for problems with strength and movement
*   treatment from a podiatrist for foot and leg problems, and devices such as shoe inserts (orthoses) for leg pain
*   surgery for more severe problems – for example, surgery to repair heart defects or an operation to repair a cleft palate

You may find it useful to speak to a social worker, psychologist or counsellor, who you can contact directly or through a doctor.

Charities such as [Max Appeal!](http://www.maxappeal.org.uk/) may also be a good source of support.

Read more advice about [caring for a disabled child](https://www.nhs.uk/conditions/social-care-and-support-guide/caring-for-children-and-young-people/how-to-care-for-a-disabled-child/).

Outlook for DiGeorge syndrome
-----------------------------

Everyone with DiGeorge syndrome is affected differently and it's difficult to predict how severe the condition will be. Most children survive into adulthood.

As someone with DiGeorge syndrome gets older, some symptoms, such as heart and speech problems, tend to become less of an issue. However, behavioural, learning, and mental health problems can continue to affect their daily life.

Many people with DiGeorge syndrome who reach adulthood will have a relatively normal life span, but ongoing health problems can sometimes mean their life expectancy is a bit lower than usual. It's important to attend regular check-ups so that any problems can be found and treated early.

Adults with DiGeorge syndrome are often able to live independently.

Information about you or your child
-----------------------------------

If your child has DiGeorge syndrome, your clinical team will pass information about them to the National Congenital Anomaly and Rare Disease Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the register](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet)

Page last reviewed: 02 April 2020  
Next review due: 02 April 2023
