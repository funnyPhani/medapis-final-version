Title: Hepatitis C

URL Source: https://www.nhs.uk/conditions/hepatitis-c/

Published Time: 24 Oct 2017, 3:41 p.m.

Markdown Content:
**Hepatitis C is a virus that can infect the liver. If left untreated, it can sometimes cause serious and potentially life-threatening damage to the liver over many years.**

But with modern treatments, it's usually possible to cure the infection, and most people with it will have a normal life expectancy.

It's estimated around 118,000 people in the UK had chronic hepatitis C in 2019.

You can become infected with it if you come into contact with the blood of an infected person.

Symptoms of hepatitis C
-----------------------

Hepatitis C often does not have any noticeable symptoms until the liver has been significantly damaged.

This means many people have the infection without realising it.

When symptoms do occur, they can be mistaken for another condition.

Symptoms can include:

*   [flu-like symptoms](https://www.nhs.uk/conditions/flu/), such as muscle aches and a high temperature (fever)
*   feeling tired all the time
*   loss of appetite
*   [stomach ache](https://www.nhs.uk/conditions/stomach-ache/)
*   feeling and being sick

The only way to know for certain if these symptoms are caused by hepatitis C is to get tested.

How do you get hepatitis C?
---------------------------

The hepatitis C virus is usually spread through blood-to-blood contact.

Some ways the infection can be spread include:

*   sharing unsterilised needles – particularly needles used to inject recreational drugs
*   sharing razors or toothbrushes
*   from a pregnant woman to her unborn baby
*   through unprotected sex – although this is very rare

In the UK, most hepatitis C infections happen in people who inject drugs or have injected them in the past.

It's estimated around half of those who inject drugs have been infected with the virus.

### Hepatitis C from infected blood 1996

If you received a blood transfusion or blood products before 1996, there's a chance you may have been infected with hepatitis C.

Information:

If you have contracted hepatitis C from infected blood help and support is available.

Find out more about [support for people who may have been affected by infected blood](https://www.nhs.uk/conditions/support-for-people-who-may-have-been-affected-by-infected-blood/).

Getting tested for hepatitis C
------------------------------

Seek medical advice if you have persistent symptoms of hepatitis C or there's a risk you're infected, even if you do not have any symptoms.

A [blood test](https://www.nhs.uk/conditions/blood-tests/) can be carried out to see if you have the infection.

You can do a finger-prick test at home to find out if you have hepatitis C.

GPs, sexual health clinics, genitourinary medicine (GUM) clinics or drug treatment services also offer testing for hepatitis C.

Early diagnosis and treatment can help prevent or limit any damage to your liver, as well as help ensure the infection is not passed on to other people.

[Find out how to get a free home test for hepatitis C](https://hepctest.nhs.uk/)

[Find out more about testing for hepatitis C](https://www.nhs.uk/conditions/hepatitis-c/diagnosis/)

Treatments for hepatitis C
--------------------------

Hepatitis C can be treated with medicines that stop the virus multiplying inside the body. These usually need to be taken for several weeks.

Until recently, most people would have taken 2 main medicines called pegylated interferon (a weekly injection) and ribavirin (a capsule or tablet).

Tablet-only treatments are now available.

These new hepatitis C medicines have been found to make treatment more effective, are easier to tolerate, and have shorter treatment courses.

They include sofosbuvir and daclatasvir.

Using the latest medications, more than 90% of people with hepatitis C may be cured.

But it's important to be aware that you will not be immune to the infection and should take steps to reduce your risk of becoming infected again.

Complications of hepatitis C
----------------------------

If the infection is left untreated for many years, some people with hepatitis C will develop scarring of the liver ([cirrhosis](https://www.nhs.uk/conditions/cirrhosis/)).

Over time, this can cause the liver to stop working properly.

In severe cases, life-threatening problems, such as liver failure, where the liver loses most or all of its functions, or [liver cancer](https://www.nhs.uk/conditions/liver-cancer/), can eventually develop.

Treating hepatitis C as early as possible can help reduce the risk of these problems happening.

[Find out more about the complications of hepatitis C](https://www.nhs.uk/conditions/hepatitis-c/complications/)

Preventing hepatitis C
----------------------

There's no vaccine for hepatitis C, but there are ways to reduce your risk of becoming infected.

These include:

*   not sharing any drug-injecting equipment with other people – including needles and other equipment, such as syringes, spoons and filters
*   not sharing razors or toothbrushes that might be contaminated with blood

The risk of getting hepatitis C through sex is very low. But it may be higher if blood is present, such as menstrual blood or from minor bleeding during anal sex.

Condoms are not usually necessary to prevent hepatitis C for long-term heterosexual couples, but it's a good idea to use them when having anal sex or sex with a new partner.

Page last reviewed: 27 October 2021  
Next review due: 27 October 2024
