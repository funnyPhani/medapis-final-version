Title: Diverticular disease and diverticulitis

URL Source: https://www.nhs.uk/conditions/diverticular-disease-and-diverticulitis/

Published Time: 18 Oct 2017, 10:59 a.m.

Markdown Content:
**Diverticular disease and diverticulitis are conditions that affect the large intestine (bowel), causing tummy (abdominal) pain and other symptoms. They're caused by small bulges or pouches in the walls of the intestine called diverticula.**

Information:

Diverticulosis is when there are diverticula in your bowel, but they're not causing any symptoms.

Most people will get some diverticula as they get older, but most people will not get any symptoms.

Symptoms of diverticular disease and diverticulitis
---------------------------------------------------

The symptoms of diverticular disease include:

*   pain in the lower left side of your tummy (abdomen) – a small number of people get pain on the right side
*   tummy pain that gets worse after you eat, and gets better after you poo or fart
*   constipation
*   diarrhoea
*   blood in your poo
*   bloating

If your intestine becomes infected or inflamed, it's called diverticulitis. You may also have symptoms such as:

*   severe, constant tummy pain
*   high temperature
*   bleeding or passing slime (mucus) from your bottom

Information:

The symptoms of diverticular disease and diverticulitis are similar to those of other conditions such as [irritable bowel syndrome (IBS)](https://www.nhs.uk/conditions/irritable-bowel-syndrome-ibs/).

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   there is blood or slime (mucus) in your poo
*   you have tummy pain that's getting worse or does not go away
*   you have a high temperature, or you feel hot or shivery
*   you keep being sick and cannot keep fluid down
*   you have diarrhoea for more than 7 days or are being sick for more than 2 days

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Tests for diverticular disease and diverticulitis
-------------------------------------------------

The GP will ask questions to find out what's causing your symptoms. You may need a blood test or to give a poo sample to help find what's wrong.

You may need further tests to confirm if you have diverticular disease or diverticulitis and rule out other conditions. Further tests you may have include:

*   a [colonoscopy](https://www.nhs.uk/conditions/colonoscopy/) or flexible sigmoidoscopy, where a thin tube with a small camera on it is used to check inside your bowels
*   a [CT scan](https://www.nhs.uk/conditions/ct-scan/)

Treating diverticular disease and diverticulitis
------------------------------------------------

Treatments that can help with the symptoms of diverticular disease include:

*   painkillers such as paracetamol
*   bulk-forming [laxatives](https://www.nhs.uk/conditions/laxatives/) for constipation and diarrhoea
*   medicines to help with stomach cramps (antispasmodics)

Diverticulitis is treated with:

*   [antibiotics](https://www.nhs.uk/conditions/antibiotics/) if the diverticulitis is caused by an infection
*   painkillers such as paracetamol

Things you can do to help with diverticular disease and diverticulitis
----------------------------------------------------------------------

If you have diverticular disease or diverticulitis there are things you can do to reduce the risk of your symptoms getting worse in the future.

### Do

*   eat a healthy, balanced diet including whole grains, fruits and vegetables – there are no specific foods you need to avoid
    
*   slowly [increase how much fibre you eat](https://www.nhs.uk/live-well/eat-well/digestive-health/how-to-get-more-fibre-into-your-diet/) if you do not eat much fibre – and make sure to also drink plenty of water
    
*   [stop smoking](https://www.nhs.uk/live-well/quit-smoking/) if you smoke
    
*   maintain a healthy weight
    

### Don’t

*   do not take [NSAIDs](https://www.nhs.uk/conditions/nsaids/) (such as ibuprofen) or opioid painkillers (such as [codeine](https://www.nhs.uk/medicines/codeine/)) – they can cause stomach problems or constipation, and increase the risk of getting a hole (perforation) in your bowel
    

Complications of diverticulitis
-------------------------------

Rarely, diverticulitis can lead to serious complications such as:

*   a build-up of pus (abscess) in your bowel
*   a blockage in your bowel
*   an opening from your bowel to another organ, such as your bladder, called a fistula
*   a hole (perforation) in your bowel, which can cause a severe infection called [peritonitis](https://www.nhs.uk/conditions/peritonitis/)

These problems can sometimes be treated with antibiotics or surgery.

For example, you may need surgery to drain an abscess or remove an infected part of the bowel.

Some people will need to have a [colostomy](https://www.nhs.uk/conditions/colostomy/) (where your bowel is brought out of a hole in your tummy and a bag is attached to collect your poo).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You or someone you care for:

*   has severe tummy pain and is either vomiting, has a swollen tummy, or cannot poo or fart
*   is bleeding heavily from their bottom
*   is acting confused, has pale or blotchy skin, has a very high or low temperature, or is breathless or breathing rapidly – these could all be signs of [sepsis](https://www.nhs.uk/conditions/sepsis/)

Page last reviewed: 07 September 2023  
Next review due: 07 September 2026
