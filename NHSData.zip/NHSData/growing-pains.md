Title: Growing pains

URL Source: https://www.nhs.uk/conditions/growing-pains/

Published Time: 18 Oct 2017, 2:49 p.m.

Markdown Content:
**Growing pains is a term used for leg pain that is common in children aged 3 to 12. It's harmless and usually gets better on its own. The pain can be treated with painkillers like paracetamol.**

Check if it's growing pains
---------------------------

The symptoms of growing pains can come and go over months, even years.

The pain is usually:

*   an aching or throbbing in both legs
*   in the muscles, not the joints
*   in the evening or night-time (and goes away by morning)

Things you can do to ease growing pains
---------------------------------------

### Do

*   gently massage your child's legs
    
*   put a covered hot water bottle or heat pack on the painful area
    
*   give children's [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-children/) or [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-children/) to ease the pain
    

### Don’t

*   do not give aspirin to a child under the age of 16 unless a doctor prescribes it
    

Non-urgent advice: See a GP if your child:
------------------------------------------

*   has pain in 1 leg
*   has leg pain in the morning, or when walking or taking part in activities
*   has leg pain that’s bad enough to stop them walking or makes them limp
*   has pain in a joint, such as their knees or ankles
*   has a rash, swelling or unusual bruising on the legs
*   has leg pain and a high temperature
*   feels unusually tired or sleepy a lot of the time
*   does not want to eat or is losing weight

Causes of growing pains
-----------------------

It's not known what causes growing pains.

They are not caused by growing and they are not a sign of anything serious.

Growing pains are more common in active children and can happen after playing lots of sport.

They are also common in children with very flexible joints ([joint hypermobility syndrome](https://www.nhs.uk/conditions/joint-hypermobility-syndrome/))

Page last reviewed: 24 November 2022  
Next review due: 24 November 2025
