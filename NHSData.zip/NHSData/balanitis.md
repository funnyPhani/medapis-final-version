Title: Balanitis

URL Source: https://www.nhs.uk/conditions/balanitis/

Published Time: 17 Oct 2017, 5:07 p.m.

Markdown Content:
**Balanitis is when the head of the penis is swollen and sore. It's not usually serious but it's important to see a GP to find out what's causing it.**

Check if you have balanitis
---------------------------

With balanitis, the head of your penis is usually swollen, itchy and sore. It usually looks red, but this may be less obvious on brown or black skin.

Other symptoms can include:

*   pain when peeing
*   a thick discharge that comes from under your foreskin
*   bleeding around your foreskin
*   an unpleasant smell
*   difficulty pulling back your foreskin – though in young children it's normal to have a tight foreskin

Non-urgent advice: See a GP if:
-------------------------------

*   you or your child have symptoms of balanitis, such as the head of your penis being swollen, itchy, sore or red
*   you or your child have balanitis and treatment has not worked

Adults can also go to a sexual health clinic for assessment.

Information:

### Sexual health clinics can help with balanitis

Sexual health clinics treat problems with the genitals.

Many sexual health clinics offer a walk-in service, where you do not need an appointment.

They'll often get test results quicker than GP surgeries.

[Find a sexual health clinic](https://www.nhs.uk/service-search/sexual-health/find-a-sexual-health-clinic)

What happens at your appointment
--------------------------------

If you have symptoms of balanitis, a doctor or nurse will look at your penis and ask you a few questions.

If your symptoms are severe, they may suggest a blood test to check for conditions that can lead to balanitis, such as diabetes.

They may also wipe a cotton bud over the head of your penis to test for infections.

Treatment for balanitis
-----------------------

Treatment for balanitis depends on what's causing it.

A GP may prescribe:

*   a mild [steroid cream or ointment](https://www.nhs.uk/conditions/topical-steroids/)
*   an [antifungal cream or ointment](https://www.nhs.uk/conditions/antifungal-medicines/)
*   [antibiotics](https://www.nhs.uk/conditions/antibiotics/)

If you or your child keeps getting balanitis and medicine has not helped, [circumcision](https://www.nhs.uk/conditions/circumcision-in-boys/) (surgery to remove the foreskin) may be considered.

Things you can do to help with balanitis
----------------------------------------

### If you have balanitis

#### Do

*   wash your penis every day using just water or an emollient (moisturising treatment)
    
*   gently pull back your foreskin and wash the area with warm water
    
*   dry gently after washing
    
*   if you use condoms, choose condoms for sensitive skin
    
*   wash your hands before peeing or touching your penis
    

#### Don’t

*   do not use soap or shower gel
    

### If your child has balanitis

#### Do

*   gently wash your child's penis every day
    
*   use warm water and then dry it gently
    
*   if they wear nappies, change your child's nappies often
    

#### Don’t

*   do not use soap, bubble bath or baby wipes
    
*   do not pull your child's foreskin back if it's fixed in place
    

Causes of balanitis
-------------------

Causes of balanitis include:

*   not washing your penis properly
*   some young boys have a very [tight foreskin (phimosis)](https://www.nhs.uk/conditions/phimosis/), which means they cannot pull it back to clean under it
*   [thrush](https://www.nhs.uk/conditions/thrush-in-men-and-women/)
*   a sexually transmitted infection (STI) such as [gonorrhoea](https://www.nhs.uk/conditions/gonorrhoea/) or [chlamydia](https://www.nhs.uk/conditions/chlamydia/) – if a STI is suspected you may be referred to a sexual health clinic
*   substances such as soap, shower gels or condoms may irritate the skin
*   [diabetes](https://www.nhs.uk/conditions/diabetes/) – high levels of sugar in your pee can cause thrush

Page last reviewed: 30 May 2023  
Next review due: 30 May 2026
