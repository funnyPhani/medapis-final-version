Title: Dupuytren's contracture

URL Source: https://www.nhs.uk/conditions/dupuytrens-contracture/

Published Time: 19 Oct 2017, 4:54 p.m.

Markdown Content:
**Dupuytren's contracture is when 1 or more fingers bend in towards your palm. There's no cure, but your fingers can be straightened if it's severe.**

Check if you have Dupuytren's contracture
-----------------------------------------

Dupuytren's contracture mainly affects the ring and little fingers. You can have it in both hands at the same time.

It tends to get slowly worse over many months or years. Treatment cannot usually help in the early stages.

![Image 1: White hand held out flat, with middle finger sticking upwards slightly and a raised ridge along the palm below it.](https://assets.nhs.uk/nhsuk-cms/images/A_0318_Dupuytrens-Contracture_KH6M15.width-320.jpg)

It starts with lumps, dimples or ridges on your palm.

![Image 2: White right hand held out flat with ring finger bent in towards the palm.](https://assets.nhs.uk/nhsuk-cms/images/A_0318_Dupuytrens-contracture_C0284447.width-320.jpg)

Eventually, your finger may get stuck in a bent position.

If you're not sure it's Dupuytren's contracture

Other conditions can have similar symptoms.

Other conditions that have similar symptoms
| Symptom | Possible cause |
| --- | --- |
| Small, soft lump on the wrist or finger joints | [ganglion](https://www.nhs.uk/conditions/ganglion/) |
| Hard, raised, rough skin on the palms | [calluses](https://www.nhs.uk/conditions/corns-and-calluses/) |
| Finger "catching" or getting stuck when you move it | [trigger finger](https://www.nhs.uk/conditions/trigger-finger/) |

### Non-urgent advice: See a GP if 1 or more of your fingers are bent and:

*   you cannot put your hand down flat
*   you're having difficulty with daily activities

You'll probably be offered treatment. The GP may refer you to a surgeon to discuss your options.

Information:

You can ask to be referred to a hospital of your choice.

[Find and compare hospitals for Dupuytren's contracture](https://www.nhs.uk/Service-Search/Surgery-for-Dupuytrens-contracture/LocationSearch/1386)

Treatments for Dupuytren's contracture
--------------------------------------

Speak to a specialist about the options, what the benefits and risks are, and what to expect afterwards.

Your finger may not be completely straight after treatment, and might not be as strong and flexible as it used to be.

The contracture could also come back after a few years.

There are 3 main types of treatment.

### Surgery to straighten the fingers

#### Fasciectomy

A cut is made along your palm and finger so the surgeon can straighten it.

*   general anaesthetic (you're asleep) or local anaesthetic (your hand is numbed)
*   you can leave hospital the same day
*   recovery time: 4 to 12 weeks
*   lowest risk of contracture coming back
*   risks include bleeding, numbness and infection

### Using a needle to straighten the fingers

#### Needle fasciotomy

A needle is inserted into several places along your palm and finger to loosen and straighten it.

*   local anaesthetic (your hand is numbed)
*   you can leave hospital the same day
*   recovery time: up to 2 weeks
*   contracture more likely to come back than with surgery
*   risks include a cut opening up in your skin, pain and numbness

### Using surgery and a skin graft to straighten the fingers

### Dermafasciectomy

Similar to a fasciectomy, except an additional area of skin is removed; a skin graft from elsewhere in the body can be used to replace the removed skin.

*   general anaesthetic (you're asleep) or local anaesthetic (your hand is numbed)
*   2 procedures are needed – 1 to straighten the fingers and then around 4 days later, another procedure to add the skin graft
*   contractures less likely to come back than with a standard fasciectomy but recovery times can be longer
*   risks include bleeding, numbness and infection

Information:

### Self-refer for treatment

If you have Dupuytren's contracture, you might be able to refer yourself directly to services for help with your condition without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS treatment for Dupuytren's contracture near you

Causes and preventing Dupuytren's contracture
---------------------------------------------

Dupuytren's contracture happens when the tissue under the skin near your fingers becomes thicker and less flexible.

The exact cause is unknown, but it's been linked to:

*   having a family history of the condition
*   smoking
*   drinking lots of alcohol
*   having diabetes or epilepsy

It's not known if you can prevent it or stop it coming back.

Page last reviewed: 15 June 2021  
Next review due: 15 June 2024
