Title: Boils

URL Source: https://www.nhs.uk/conditions/boils/

Published Time: 17 Oct 2017, 5:16 p.m.

Markdown Content:
**A boil is a hard and painful lump that fills with pus. Most boils go away on their own. See a GP if you keep getting them.**

Check if you have a boil
------------------------

![Image 1: A boil in its early stages on white skin. It is a raised dark pink lump with a raised yellow and white centre.](https://assets.nhs.uk/nhsuk-cms/images/C0018534-Boil_crop.width-320.png)

A boil often starts as an itchy or tender spot.

![Image 2: A boil on white skin leaking pus. The lump is raised, with yellow pus at the centre. The surrounding skin is red and bleeding.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_boil_M1200077.width-320.jpg)

Boils can sometimes leak pus.

![Image 3: A boil about 2cm wide on the wrist of a person with dark brown skin. It is raised and the skin around it is darker.](https://assets.nhs.uk/nhsuk-cms/images/M1200014-Boil_in_the_skin_of_the_wrist_2nd_edi.width-320.png)

Boils can appear anywhere on your body.

![Image 4: A group of boils growing together (carbuncle) on the neck on white skin. It's leaking yellow pus and the surrounding skin is red.](https://assets.nhs.uk/nhsuk-cms/images/A_1017_carbuncle_A7911G.width-320.jpg)

When lots of boils form together it's called a carbuncle.

Things you can do to help boils
-------------------------------

There are things you can do to treat boils yourself and stop them coming back.

### Do

*   soak a clean cloth in warm water and hold it against the boil for 10 minutes 4 times a day
    
*   clean the area around the boil with antibacterial soap if pus comes out
    
*   cover the area with a dressing or gauze until it heals
    
*   bathe or shower every day and wash your hands regularly
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to ease the pain
    
*   wash your towels and bedding at least once a week at high temperature
    
*   try to lose weight if you are very overweight and have boils between folds of your skin
    

### Don’t

*   do not pick, squeeze or pierce a boil
    
*   do not share your towel with other people until the boil has gone
    
*   do not go to a swimming pool or gym until the boil has gone –⁠ you could pass the infection on to others
    

Non-urgent advice: See a GP if:
-------------------------------

*   you've had a boil for 2 weeks and the things you've tried are not helping
*   you keep getting boils
*   you have a group of boils (carbuncle)

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if you have a boil and:
------------------------------------------------------------------------------------------------

*   it is on your face
*   the skin around your boil feels hot, painful and swollen
*   you feel hot and shivery
*   you have a weakened immune system – this could be from taking treatments such as steroids, or having a condition like diabetes

You can call 111 or [get help from NHS 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Treatment for boils
-------------------

A GP can check if you need treatment.

You may need:

*   a small procedure to drain the boil to get rid of the pus
*   antibiotics

Causes of boils
---------------

You may be more likely to get boils if you have a long-term condition that affects your immune system, such as diabetes or HIV.

You may also be more likely to get boils if:

*   you're a man
*   you've been in close contact with someone with boils
*   you have certain skin conditions, such as eczema
*   you take certain medicines, such as steroids
*   you’re living with obesity or malnutrition

Carbuncles are less common and mostly affect middle-aged men.

Page last reviewed: 20 June 2023  
Next review due: 20 June 2026
