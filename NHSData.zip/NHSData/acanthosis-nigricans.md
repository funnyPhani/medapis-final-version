Title: Acanthosis nigricans

URL Source: https://www.nhs.uk/conditions/acanthosis-nigricans/

Published Time: 24 Oct 2017, 9:48 a.m.

Markdown Content:
**Acanthosis nigricans is the name for dry, dark patches of skin that usually appear in the armpits, neck or groin. It could be a sign of an underlying condition, so it needs to be checked by a GP.**

Check if you have acanthosis nigricans
--------------------------------------

The main symptom of acanthosis nigricans is patches of skin that are darker and thicker than usual.

They can appear anywhere on the body.

![Image 1: Dark patches of skin that form a band around the lower part of the neck on a person with medium brown skin.](https://assets.nhs.uk/nhsuk-cms/images/A_0917_acanthosis-nigricans_C5HE23.width-320.jpg)

The patches are dry and feel similar to velvet.

![Image 2: A dark patch of skin on the armpit of a person with white skin. The patch covers most of the person's armpit.](https://assets.nhs.uk/nhsuk-cms/images/S_0318_Acanthosis-nigricans_C0131055.width-320.jpg)

They're most common in skin folds, such as the armpits, neck or groin.

![Image 3: Dark patches of skin covering the armpit of someone with medium brown skin. There are also about 50 small skin tags.](https://assets.nhs.uk/nhsuk-cms/images/S_0318_Acanthosis_nigricans_C0373908.width-320.jpg)

Some people also have tiny growths (skin tags) on the patches.

The patches often appear gradually without any other symptoms.

Sometimes the skin may be itchy.

### Non-urgent advice: See a GP if you have:

*   new dark patches on your skin
*   any skin changes you're unsure about

### What happens at your appointment

Although acanthosis nigricans is usually harmless, it's best to get any skin changes checked out.

Rarely, it can be a sign of something more serious, such as cancer.

A GP can usually tell if it's acanthosis nigricans by looking at your skin.

You may need some tests to find out what's causing the patches.

Causes of acanthosis nigricans
------------------------------

The most common cause of acanthosis nigricans is being [very overweight](https://www.nhs.uk/conditions/obesity/).

Other causes include:

*   [type 2 diabetes](https://www.nhs.uk/conditions/type-2-diabetes/)
*   conditions that affect hormone levels – such as [Cushing's syndrome](https://www.nhs.uk/conditions/cushings-syndrome/), [polycystic ovary syndrome](https://www.nhs.uk/conditions/polycystic-ovary-syndrome-pcos/) or an [underactive thyroid](https://www.nhs.uk/conditions/underactive-thyroid-hypothyroidism/)
*   taking certain medicines – including [steroids](https://www.nhs.uk/conditions/steroids/) or hormone treatments like the contraceptive pill
*   rarely, cancer – usually [stomach cancer](https://www.nhs.uk/conditions/stomach-cancer/)
*   rarely, a faulty gene inherited from your parents

Sometimes healthy people with no other conditions get acanthosis nigricans. This is more common in people with black or brown skin.

Treating acanthosis nigricans
-----------------------------

Once a GP knows what's causing acanthosis nigricans, they can recommend the best treatment.

The patches should fade over time once the cause is treated.

If you're very overweight, a GP may recommend [losing weight](https://www.nhs.uk/better-health/lose-weight/).

Depending on the cause, they may also recommend:

*   medicine to balance your hormones
*   medicine to balance your insulin levels
*   changing your medicine to one that does not cause the patches

There's no specific treatment for the patches themselves. A skin specialist (dermatologist) may be able to suggest treatments to improve their appearance, but finding and treating the cause is usually recommended first.

Page last reviewed: 20 June 2021  
Next review due: 20 June 2024
