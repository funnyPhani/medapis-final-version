Title: Bad breath

URL Source: https://www.nhs.uk/conditions/bad-breath/

Published Time: 3 Oct 2018, 9 p.m.

Markdown Content:
**Bad breath (sometimes called halitosis) is very common. You can usually treat it yourself.**

How to treat bad breath yourself
--------------------------------

The best way of making sure you do not have bad breath is to keep your teeth, tongue and mouth clean.

### Do

*   gently brush your teeth and gums at least twice a day for 2 minutes
    
*   use a fluoride toothpaste
    
*   gently clean your tongue once a day using a tongue scraper or cleaner
    
*   clean between your teeth with interdental brushes or floss at least once a day
    
*   get regular [dental check-ups](https://www.nhs.uk/live-well/healthy-teeth-and-gums/dental-check-ups/)
    
*   keep [dentures](https://www.nhs.uk/conditions/dentures/) clean and remove them at night
    
*   use sugar-free mints or chewing gum after having strong-smelling food and drinks
    
*   try using an antibacterial mouthwash or toothpaste
    

### Don’t

*   [do not smoke](https://www.nhs.uk/live-well/quit-smoking/nhs-stop-smoking-services-help-you-quit/)
    
*   do not rinse your mouth with water straight after brushing your teeth
    
*   do not have lots of sugary foods and drinks
    
*   do not brush so hard your gums or tongue bleed
    

Causes of bad breath
--------------------

Causes of bad breath include:

*   eating or drinking strong-smelling or spicy foods and drinks
*   problems with your teeth or gums, such as [gum disease](https://www.nhs.uk/conditions/gum-disease/), holes in your teeth or an infection
*   crash dieting
*   some medical conditions, like [dry mouth](https://www.nhs.uk/conditions/dry-mouth/), [tonsillitis](https://www.nhs.uk/conditions/tonsillitis/) and [acid reflux](https://www.nhs.uk/conditions/heartburn-and-acid-reflux/)
*   smoking

Non-urgent advice: See a dentist if you have:
---------------------------------------------

*   bad breath that does not go away after treating it yourself for a few weeks
*   painful, bleeding or swollen gums
*   toothache or wobbly adult teeth
*   problems with your dentures

Page last reviewed: 07 December 2021  
Next review due: 07 December 2024
