Title: Brugada syndrome

URL Source: https://www.nhs.uk/conditions/brugada-syndrome/

Published Time: 17 Oct 2017, 5:48 p.m.

Markdown Content:
**Brugada syndrome is a rare heart condition that's usually inherited. It can affect your heart rhythm and can be life-threatening, but there are things you can do to reduce the risk of serious problems.**

Symptoms of Brugada syndrome
----------------------------

Brugada syndrome does not usually cause any symptoms. Sometimes it's found when you have an [electrocardiogram (ECG)](https://www.nhs.uk/conditions/electrocardiogram/) for another reason.

If you do get symptoms they can include:

*   [fainting](https://www.nhs.uk/conditions/fainting/) or blackouts
*   feeling dizzy or lightheaded
*   [heart palpitations](https://www.nhs.uk/conditions/heart-palpitations/)
*   seizures or fits
*   [shortness of breath](https://www.nhs.uk/conditions/shortness-of-breath/)

Symptoms usually start in adulthood, but it can happen at any age.

Brugada syndrome can also cause a dangerously fast or irregular heartbeat. This can lead to a cardiac arrest, where your heart beats so fast that not enough blood gets to your brain, so you become unconscious and stop breathing.

Immediate action required: Call 999 if:
---------------------------------------

*   someone's not breathing normally and not moving or responding – they could be having a cardiac arrest
*   someone's having a seizure or fit
*   someone's fainted or had a blackout and cannot be woken up within 1 minute

Follow the instructions from the 999 operator until an ambulance arrives.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

You've been diagnosed with Brugada syndrome or you're worried you have it and:

*   you've fainted or had a blackout and have now recovered
*   you have dizziness that does not go away or keeps coming back
*   you have heart palpitations that keep coming back, last longer than a few minutes or are getting worse
*   you've had a seizure or fit and have now recovered

Also ask for an urgent GP appointment if your parent, child, brother or sister has been diagnosed with Brugada syndrome, or died unexpectedly (you may also need tests to check your heart).

You can call [111](tel:111) or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Tests for Brugada syndrome
--------------------------

If a GP thinks you could have Brugada syndrome or another heart condition they'll refer you to a heart specialist (cardiologist).

You'll have tests such as:

*   an [electrocardiogram (ECG)](https://www.nhs.uk/conditions/electrocardiogram/), where sensors are put on your chest to check your heart
*   a provocation test, where you're given a medicine while having an ECG

As Brugada syndrome is usually inherited, you may also be offered [genetic testing](https://www.nhs.uk/conditions/genetic-and-genomic-testing/) to see if you have genes linked to the condition.

### Important

If you're diagnosed with Brugada syndrome, your immediate family should also be offered testing as there's a chance they could also have the condition.

Treatments for Brugada syndrome
-------------------------------

If you have Brugada syndrome but you've not had any symptoms, you will not usually need any medical treatment. Most people with the condition have a low risk of serious problems.

You'll be monitored regularly to check the health of your heart.

### Implantable cardioverter defibrillator (ICD)

Doctors may recommend that you're fitted with an implantable cardioverter defibrillator (ICD).

This is a small device that's put under your skin in your chest, in a similar way to a [pacemaker](https://www.nhs.uk/conditions/pacemaker-implantation/). It monitors your heart rhythm and sends an electrical shock to your heart when it's needed to correct the rhythm.

You'll only need an ICD if either:

*   you've had symptoms such as a cardiac arrest, heart palpitations or fainting
*   doctors think you're at high risk of getting a dangerous heart rhythm based on your electrocardiogram (ECG) results

How to reduce the risk of heart rhythm problems if you have Brugada syndrome
----------------------------------------------------------------------------

If you have Brugada syndrome it's important to avoid triggers that can cause problems with your heart rhythm. Your care team will give you advice about this.

### Do

*   check with a doctor or pharmacist before taking any medicines – some medicines can cause problems in people with Brugada syndrome
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/about-paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/about-ibuprofen-for-adults/) to help prevent a [high temperature](https://www.nhs.uk/conditions/fever-in-adults/) if you're unwell
    

### Don’t

*   do not drink too much alcohol – keep to the recommended guidelines of no more than 14 units a week, spread over 3 days or more
    
*   do not get [dehydrated](https://www.nhs.uk/conditions/dehydration/) – you may need rehydration solutions if you're being sick or have diarrhoea
    
*   do not take part in very strenuous exercise or sports
    

### Urgent advice: Get help from NHS 111 if:

*   you have Brugada syndrome and you get a high temperature that does not go down after taking paracetamol or ibuprofen

You may be advised to go to A&E to be monitored.

You can call [111](tel:111) or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

How you get Brugada syndrome
----------------------------

Brugada syndrome is usually caused by the genes you inherit from your parents.

Less commonly, it can be caused by:

*   problems with the structure of your heart
*   taking certain medicines
*   using drugs such as cocaine

It's more common in men and in people of south east Asian origin.

Help and support for Brugada syndrome
-------------------------------------

If you or someone in your family has Brugada syndrome you can get help and support from charities, including:

*   [British Heart Foundation: support](https://www.bhf.org.uk/informationsupport/support)
*   [Cardiac Risk in the Young: support](https://www.c-r-y.org.uk/support/)

Recording information about you and your condition
--------------------------------------------------

If you have Brugada syndrome, your care team will pass information on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://digital.nhs.uk/ndrs/about/ncardrs).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

Page last reviewed: 13 December 2023  
Next review due: 13 December 2026
