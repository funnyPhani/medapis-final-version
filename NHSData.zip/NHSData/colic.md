Title: Colic

URL Source: https://www.nhs.uk/conditions/colic/

Published Time: 20 Oct 2017, 5 p.m.

Markdown Content:
**Colic is when a baby cries a lot but there's no obvious cause. It's a common problem that should get better by around 3 or 4 months of age. But call NHS 111 or see a GP if you're worried.**

Check if your baby has colic
----------------------------

All babies cry, but your baby may have colic if they cry more than 3 hours a day, 3 days a week for at least 1 week but are otherwise healthy.

They may cry more often in the afternoon and evening.

It may also be colic if, while they are crying:

*   it's hard to soothe or settle your baby
*   they clench their fists
*   they go red in the face
*   they bring their knees up to their tummy or arch their back
*   their tummy rumbles or they're very windy

It can start when a baby is a few weeks old. It usually stops by the time they're 3 to 4 months old.

If you're not sure it's colic

There are other reasons why your baby may be crying.

It could be they:

*   are hungry
*   have a dirty nappy
*   have wind
*   have [reflux](https://www.nhs.uk/conditions/reflux-in-babies/)
*   have [constipation](https://www.nhs.uk/conditions/constipation/)

If you're not sure what's wrong, it's best to speak to your health visitor, call NHS 111 or see a GP to be sure.

Things you can try to soothe your baby
--------------------------------------

Your baby does not usually need to see a doctor if they have colic. Speak to your health visitor for advice and support.

Health visitors and doctors will usually advise you to:

*   hold or cuddle your baby when they're crying a lot
*   sit or hold your baby upright during feeding to stop them swallowing air
*   wind your baby after feeds
*   gently rock your baby over your shoulder
*   gently rock your baby in their Moses basket or crib, or push them in their pram
*   bath your baby in a warm bath
*   have some gentle white noise like the radio or TV in the background to distract them
*   keep feeding your baby as usual

Other things you may hear about include:

*   anti-colic drops and herbal and probiotic supplements
*   changes to your diet if you're breastfeeding
*   applying gentle pressure to your baby's spine (spinal manipulation) or skull (cranial osteopathy)

But there's very little evidence these things work. Speak to your health visitor for further advice.

Non-urgent advice: Call NHS 111 or see a GP if:
-----------------------------------------------

*   you're worried about your baby's crying
*   your baby has colic and nothing seems to be working
*   you're finding it hard to cope
*   your baby is not growing or putting on weight as expected
*   your baby still has symptoms of colic after 4 months of age

A GP will check for possible causes of your baby's crying.

Immediate action required: Go to A&E or call 999 if:
----------------------------------------------------

*   your baby has a weak or high-pitched cry
*   your baby's cry does not sound like their normal cry

You know better than anyone else what your child is usually like. Trust your instincts if you think something is seriously wrong, particularly if they have other worrying symptoms.

[Find your nearest A&E](https://www.nhs.uk/Service-Search/Accident-and-emergency-services/LocationSearch/428)

Information:

You do not have to drive to A&E. You can ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines your baby takes with you.

How to cope if you have a colicky baby
--------------------------------------

Looking after a colicky baby can be upsetting, but it's usually nothing to worry about and will pass with time.

Ask for support:

*   from other parents, family or friends
*   by calling the [Cry-sis helpline](http://www.cry-sis.org.uk/) free on 0800 448 0737 (9am to 10pm, 7 days a week)
*   from your health visitor, by calling NHS 111 or seeing a GP

Causes of colic
---------------

It's not known exactly what causes some babies to get colic. But it may be because babies find it harder to digest food when they're young.

Or they may be crying because they have problems with food allergies, such as a [cows' milk allergy](https://www.allergyuk.org/resources/does-my-child-have-a-cows-milk-allergy/).

Page last reviewed: 26 April 2022  
Next review due: 26 April 2025
