Title: Chronic pancreatitis

URL Source: https://www.nhs.uk/conditions/chronic-pancreatitis/

Published Time: 11 Jan 2018, 1:01 p.m.

Markdown Content:
**Chronic pancreatitis is a condition where the pancreas has become permanently damaged from inflammation and stops working properly.**

The pancreas is a small organ, located behind the stomach, that helps with digestion.

Chronic pancreatitis can affect people of any age. It is more common in men.

It's different from [acute pancreatitis](https://www.nhs.uk/conditions/acute-pancreatitis/), where the inflammation is only short term.

Most people with chronic pancreatitis have had 1 or more attacks of acute pancreatitis.

Symptoms of chronic pancreatitis
--------------------------------

The most common symptom of chronic pancreatitis is repeated episodes of severe pain in your tummy (abdomen).

The pain usually develops in the middle or left side of your tummy and can move along your back.

It's been described as a burning or shooting pain that comes and goes, but may last for several hours or days.

Although the pain sometimes comes on after eating a meal, there's often no trigger. Some people might feel sick and vomit.

As the condition progresses, the painful episodes may become more frequent and severe.

Eventually, a constant dull pain can develop in your tummy, between episodes of severe pain.

This is most common in people who continue to drink alcohol after being diagnosed with chronic pancreatitis.

Some people who stop drinking alcohol and stop smoking may find the pain is less severe.

### Advanced chronic pancreatitis

Other symptoms develop as the damage to the pancreas progresses and it becomes unable to produce digestive juices, which help to break down food.

The absence of digestive juices means it's harder to break down fats and some proteins. This can cause your poo to become very smelly and greasy, and make it difficult to flush down the toilet.

The pancreas usually only loses these functions many years after the first symptoms started.

You may also experience:

*   weight loss
*   loss of appetite
*   [yellowing of the skin and eyes (jaundice)](https://www.nhs.uk/conditions/jaundice/)
*   symptoms of [diabetes](https://www.nhs.uk/conditions/diabetes/) – such as feeling very thirsty, needing to pee more often than usual and feeling very tired
*   ongoing nausea and sickness (vomiting)

When to get medical advice
--------------------------

See a GP immediately if you're experiencing severe pain, as this is a warning sign that something is wrong.

If this is not possible, contact [NHS 111](https://www.nhs.uk/using-the-nhs/nhs-services/urgent-and-emergency-care/nhs-111/) for advice.

You should also see a GP as soon as you can if:

*   your skin or the whites of your eyes turn yellow [(jaundice)](https://www.nhs.uk/conditions/jaundice/)
*   you keep being sick

Jaundice can have a range of causes other than pancreatitis, but it's usually a sign there's something wrong with your digestive system.

Diagnosing chronic pancreatitis
-------------------------------

A GP will ask about your symptoms and may examine you.

They'll refer you to a specialist for further tests if they think you have chronic pancreatitis.

The specialist will be able to confirm whether you have the condition.

### Tests

Tests and scans are usually carried out in your local hospital.

They may include:

*   an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) – where sound waves are used to create a picture of your pancreas
*   a [CT scan](https://www.nhs.uk/conditions/ct-scan/) – where a series of X-rays are taken to build up a more detailed 3D image of your pancreas
*   an endoscopic ultrasound scan – where a long, thin tube containing a camera is passed through your mouth and down into your stomach to take pictures of your pancreas
*   magnetic resonance cholangiopancreatography (MRCP) – a type of [MRI scan](https://www.nhs.uk/conditions/mri-scan/) that takes a detailed image of your pancreas and the organs around it

### Biopsy

Sometimes the symptoms of chronic pancreatitis can be very similar to pancreatic cancer.

You may need a [biopsy](https://www.nhs.uk/conditions/biopsy/), where a small sample of cells is taken from the pancreas and sent to a laboratory to be checked, to rule this out.

Causes of chronic pancreatitis
------------------------------

The most common cause of chronic pancreatitis is drinking excessive amounts of alcohol over many years.

This can cause repeated episodes of [acute pancreatitis](https://www.nhs.uk/conditions/acute-pancreatitis/), which results in increasing damage to the organ.

[Find out more about alcohol misuse](https://www.nhs.uk/conditions/alcohol-misuse/)

In children the most common cause is [cystic fibrosis](https://www.nhs.uk/conditions/cystic-fibrosis/).

Less common causes include:

*   smoking
*   the immune system attacking the pancreas (autoimmune chronic pancreatitis)
*   inheriting a faulty gene that stops the pancreas working properly
*   injury to the pancreas
*   gallstones blocking the openings (ducts) of the pancreas
*   [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) to the tummy

In some cases, no cause can be identified. This is called idiopathic chronic pancreatitis.

Treatment for chronic pancreatitis
----------------------------------

The damage to the pancreas is permanent, but treatment can help control the condition and manage any symptoms.

People with chronic pancreatitis are usually advised to make lifestyle changes, such as stopping drinking alcohol and stopping smoking. They're also given medicine to relieve pain.

Surgery may also be an option for those experiencing severe pain.

Complications
-------------

Living with chronic pain can cause mental as well as physical strain.

See a GP if you're experiencing [stress](https://www.nhs.uk/conditions/stress-anxiety-depression/understanding-stress/), [anxiety](https://www.nhs.uk/conditions/generalised-anxiety-disorder/) or [depression](https://www.nhs.uk/conditions/clinical-depression/) caused by chronic pancreatitis.

Some people with chronic pancreatitis will eventually develop a type of diabetes known as type 3c diabetes.

This occurs when the pancreas can no longer produce insulin because it's become so damaged.

People with chronic pancreatitis can sometimes develop sacs of fluid on the surface of their pancreas (pseudocysts). These can cause bloating, indigestion and dull tummy pain.

These cysts often disappear on their own. But sometimes they need to be drained using a technique called endoscopic ultrasound drainage, or endoscopic transpapillary drainage.

Chronic pancreatitis increases your risk of [pancreatic cancer](https://www.nhs.uk/conditions/pancreatic-cancer/), although the chance is still small.

Support for people living with chronic pancreatitis
---------------------------------------------------

Any long-term health condition, particularly one that causes recurring episodes of pain or constant pain, can affect your emotional and psychological health.

See a GP if you're experiencing psychological and emotional difficulties. There are medicines available that can help with stress, anxiety and depression.

Talking to other people with the same condition can often reduce feelings of isolation and stress.

The charity [Guts UK](https://gutscharity.org.uk/), may be able to put you in touch with a local support group.

Page last reviewed: 26 May 2022  
Next review due: 26 May 2025
