Title: Food allergy

URL Source: https://www.nhs.uk/conditions/food-allergy/

Published Time: 19 Oct 2017, 5:13 p.m.

Markdown Content:
**A food allergy is where your body reacts to certain foods. It's often mild, but can be very serious for some people.**

Check if it's a food allergy
----------------------------

Symptoms of a food allergy can affect any part of the body, including different parts of the body at the same time.

Common symptoms of a food allergy include:

*   feeling dizzy or lightheaded
*   itchy skin or a raised rash ([hives](https://www.nhs.uk/conditions/hives/))
*   swelling of the lips, face and eyes ([angioedema](https://www.nhs.uk/conditions/angioedema/))
*   coughing, wheezing, breathlessness, noisy breathing or a hoarse voice
*   sneezing or an itchy, runny or blocked nose
*   feeling sick or being sick
*   tummy pain
*   diarrhoea

You may get symptoms straight after eating the food you're allergic to, or days later.

Information:

A food allergy is different from having a [food intolerance](https://www.nhs.uk/conditions/food-intolerance/), which causes symptoms such as bloating and tummy pain, usually a few hours after eating the food you're intolerant to.

Immediate action required: Call 999 if:
---------------------------------------

*   your lips, mouth, throat or tongue suddenly become swollen
*   you're breathing very fast or struggling to breathe (you may become very wheezy or feel like you're choking or gasping for air)
*   your throat feels tight or you're struggling to swallow
*   your skin, tongue or lips turn blue, grey or pale (if you have black or brown skin, this may be easier to see on the palms of your hands or soles of your feet)
*   you suddenly become very confused, drowsy or dizzy
*   someone faints and cannot be woken up
*   a child is limp, floppy or not responding like they normally do (their head may fall to the side, backwards or forwards, or they may find it difficult to lift their head or focus on your face)

You or the person who's unwell may also have a rash that's swollen, raised or itchy.

These can be signs of a serious allergic reaction and may need immediate treatment in hospital.

Information:

### If you have an adrenaline auto-injector

If you or someone you're with is having a serious allergic reaction and has an adrenaline auto-injector (such as an EpiPen), you should use it immediately.

Instructions are included on the side of the injector if you forget how to use it or someone else needs to give you the injection.

Call 999 for an ambulance after using the injector, even if you or the person you're with seems to be feeling better.

Non-urgent advice: See a GP if:
-------------------------------

*   you think you or your child may have a food allergy

Causes of food allergy
----------------------

A food allergy is caused by your immune system overreacting to certain types of food.

It's not clear why this happens, but certain foods are more likely to cause an allergic reaction in some people.

The most common allergic foods include:

*   cows' milk
*   eggs
*   peanuts, soybeans, peas and chickpeas
*   tree nuts, such as walnuts, almonds, hazelnuts, pecans, cashews, pistachios and Brazil nuts
*   shellfish, such as prawns, crab and lobster
*   wheat

But you can be allergic to any type of food, including celery, mustard, sesame seeds and lupin flour found in some baked goods.

You have a slightly higher chance of getting a food allergy if you or a close family member have other allergies, asthma or eczema.

Information:

### Oral allergy syndrome

Some people get an itchy mouth and throat after eating raw fruit or vegetables. This is called oral allergy syndrome.

It's not usually serious and eating fruit and vegetables that have been well cooked helps.

[Find out more about oral allergy syndrome on Allergy UK](https://www.allergyuk.org/resources/oral-allergy-syndrome-pollen-food-syndrome-factsheet/)

Tests for food allergy
----------------------

You may be referred to a specialist for tests if a GP thinks you have a food allergy.

Tests you may have include:

*   a skin-prick test (where a drop of liquid containing a food you may be allergic to is put on your skin to see if it reacts)
*   blood tests
*   a special diet where you avoid eating the food you might be allergic to, to see if your symptoms get better

You may also be asked to keep a food and symptoms diary to help work out what may be triggering your symptoms.

[Find out more about keeping a food and symptoms diary on Allergy UK](https://www.allergyuk.org/resources/food-and-symptoms-diary/)

Treatments for a food allergy
-----------------------------

If you have a food allergy, you will not be able to eat the food you're allergic to, including foods where you're allergic to any of the ingredients.

You'll be given medicines to help manage your symptoms or use in case of an emergency.

These include:

*   antihistamines for mild allergic reactions
*   emergency medicines called adrenaline auto-injectors, such as an EpiPen, for severe allergic reactions

Your specialist will give you an allergy management plan that will explain how to manage your allergy.

Children with a peanut allergy may have immunotherapy to help their bodies become less sensitive to peanuts, but they should still avoid eating peanuts.

Things you can do if you have a food allergy
--------------------------------------------

There are steps you can take to help manage your food allergy.

### Do

*   check food labels and restaurant menus carefully to make sure they do not contain the food you're allergic to
    
*   tell friends, family, nursery, school and work about your allergy
    
*   carry 2 adrenaline auto-injectors with you at all times, if you need them
    
*   tell staff at restaurants and cafés about your allergy
    
*   tell airlines and cabin staff about your allergy before you fly
    
*   wipe down surfaces in public before eating
    

### Don’t

*   do not eat foods without checking what ingredients are in them first
    
*   do not cut foods out of your diet without speaking to a GP
    

Page last reviewed: 05 January 2023  
Next review due: 05 January 2026
