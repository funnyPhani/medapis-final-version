Title: Prosopagnosia (face blindness)

URL Source: https://www.nhs.uk/conditions/face-blindness/

Published Time: 3 Apr 2018, 2:36 p.m.

Markdown Content:
**Prosopagnosia, also called face blindness, is a condition where you have difficulty recognising people's faces. There is no treatment, but there are things you can do to help you recognise people.**

Check if you have prosopagnosia (face blindness)
------------------------------------------------

The main symptom of prosopagnosia is having difficulty recognising faces. You'll still see the parts of a face normally, but all faces may look the same to you.

It affects people differently. Some people may not be able to tell the difference between strangers or people they do not know well. Others may not recognise the faces of friends and family, or even their own face.

Other symptoms of prosopagnosia can include difficulty with:

*   recognising emotions on people's faces
*   recognising people's age and gender
*   recognising characters and following plots in TV programmes or films
*   recognising other things, such as cars or animals
*   finding your way around

Difficulty recognising faces may make it harder to form relationships, or cause problems at work or school.

This may affect your mental health and may lead to [social anxiety](https://www.nhs.uk/mental-health/conditions/social-anxiety/) or [depression](https://www.nhs.uk/mental-health/conditions/depression/).

Non-urgent advice: See a GP if:
-------------------------------

*   you're struggling to recognise people's faces and it's affecting your life

They may refer you to a specialist for an assessment.

Things you can try to help with prosopagnosia (face blindness)
--------------------------------------------------------------

There's no treatment for prosopagnosia, but there are things you can do to help recognise people.

### Do

*   tell people about the condition before you meet them
    
*   ask people you're close to for help identifying others
    
*   ask people to introduce themselves when you greet them
    
*   use people's voices or body language to tell them apart
    
*   make a note of distinctive features about a person such as hairstyle, jewellery or accessories
    
*   use name tags or write down the names of colleagues and where they sit at work
    

Causes of prosopagnosia (face blindness)
----------------------------------------

Prosopagnosia is caused by a problem with the part of the brain that processes information about faces.

It can happen:

*   if you do not develop the ability to recognise faces – this is the most common type and may run in families
*   from brain damage, such as following a [stroke](https://www.nhs.uk/conditions/stroke/), head injury, inflammation of the brain ([encephalitis](https://www.nhs.uk/conditions/encephalitis/)), or [Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/)
*   if you're [autistic](https://www.nhs.uk/conditions/autism/)

Find out more:
--------------

Page last reviewed: 30 January 2023  
Next review due: 30 January 2026
