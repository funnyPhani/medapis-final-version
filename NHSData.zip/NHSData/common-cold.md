Title: Common cold

URL Source: https://www.nhs.uk/conditions/common-cold/

Published Time: 18 Oct 2017, 10:50 a.m.

Markdown Content:
Check if you have a cold
------------------------

Cold symptoms come on gradually over 2 to 3 days.

The main symptoms include:

*   a blocked or runny nose
*   sneezing
*   a sore throat
*   a hoarse voice
*   a cough
*   feeling tired and unwell

You may also have:

*   a high temperature
*   aching muscles
*   a loss of taste and smell
*   a feeling of pressure in your ears and face

Symptoms of a cold can last longer in young children. They may also be irritable, have difficulty feeding and sleeping, breathe through their mouth, and get sick after coughing.

Telling the difference between cold and flu

Cold and [flu](https://www.nhs.uk/conditions/flu/) symptoms are similar, but flu tends to be more severe.

Difference between cold and flu
| Cold | Flu |
| --- | --- |
| Appears gradually
 | Appears quickly within a few hours

 |
| Affects mainly your nose and throat

 | Affects more than just your nose and throat

 |
| Makes you feel unwell, but you're OK to carry on as normal (for example, you can normally go to work)

 | Makes you feel exhausted and too unwell to carry on as normal

 |

How you can treat a cold yourself
---------------------------------

You can usually treat a cold at home without seeing a GP.

There are things you can do to help you get better more quickly.

### Do

*   get plenty of rest
    
*   drink lots of fluid, such as water, to avoid [dehydration](https://www.nhs.uk/conditions/dehydration/)
    
*   eat healthy food (it's common for small children to lose their appetite for a few days)
    
*   gargle salt water to soothe a [sore throat](https://www.nhs.uk/conditions/sore-throat/) (not suitable for children)
    
*   drink a hot lemon and honey drink to soothe a sore throat
    
*   breathe in steam to ease a blocked nose – try sitting in the bathroom with a hot shower running
    

### Don’t

*   do not let children breathe in steam from a bowl of hot water because of the risk of scalding
    
*   do not give aspirin to children under the age of 16
    
*   do not smoke as it can make your symptoms worse
    

How to make a hot lemon and honey drink

1.  Squeeze half a lemon into a mug of boiled water
2.  Add 1 to 2 teaspoons of honey
3.  Drink while still warm

Do not give hot drinks to small children.

Do not give honey to children under 12 months old.

If you have a high temperature or do not feel well enough to do your normal activities, try to stay at home and avoid contact with other people until you feel better.

### A pharmacist can help with cold medicines

You can buy cough and cold medicines from pharmacies or supermarkets.

A pharmacist can advise you on the best medicine, such as:

*   medicines like [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to ease aches or lower a temperature
*   [decongestant nasal sprays, drops or tablets](https://www.nhs.uk/conditions/decongestants/) to unblock your nose (decongestants should not be used by children under 6)
*   vapour rubs to help ease chesty coughs in babies and small children

You can buy nasal sprays without a prescription, but they should not be used for more than a week as this can make your symptoms worse.

Do not use other cough and cold medicines if you're also taking paracetamol and ibuprofen tablets as you may take more medicine than you should.

Some cough and cold medicines are also not suitable for babies, children and pregnant women.

There's little evidence that supplements such as vitamin C, echinacea or garlic prevent colds or help you get better more quickly.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   you have a high temperature for more than 3 days
*   your cold symptoms get worse
*   your temperature is very high or you feel hot and shivery
*   you feel short of breath or have chest pain
*   you're worried about your child's cold symptoms
*   your cold symptoms do not get better after 10 days
*   you have a cough for more than 3 weeks
*   you get cold symptoms and you have a long-term medical condition (for example, diabetes, or a heart, lung or kidney condition)
*   you get cold symptoms and you have a weakened immune system (for example, because you're having chemotherapy)

Information:

GPs do not recommend antibiotics for colds because they will not relieve your symptoms or speed up your recovery.

Antibiotics only work if you have a bacterial infection, but colds are caused by viruses.

How to avoid spreading a cold
-----------------------------

Colds are caused by viruses and easily spread to other people.

You're infectious until all your symptoms have gone. This usually takes 1 to 2 weeks. It can be longer in babies and young children.

Colds are spread by germs from coughs and sneezes, which can live on hands and surfaces for 24 hours.

To reduce the risk of spreading a cold:

*   wash your hands often with warm water and soap
*   use tissues to trap germs when you cough or sneeze
*   bin used tissues as quickly as possible

How to prevent catching a cold
------------------------------

A person with a cold can start spreading it from a few days before their symptoms begin until the symptoms have finished.

The best ways to avoid catching a cold are:

*   washing your hands with warm water and soap
*   not sharing towels or household items (like cups or children's toys) with someone who has a cold
*   not touching your eyes or nose in case you've come into contact with the virus
*   staying fit and healthy

The flu vaccine does not prevent colds.

See how to wash your hands correctly

### Video: How to wash your hands

Watch this video to find out the best way to wash your hands.

Media last reviewed: 15 March 2023  
Media review due: 15 March 2026

Page last reviewed: 22 March 2024  
Next review due: 22 March 2027
