Title: Food colours and hyperactivity

URL Source: https://www.nhs.uk/conditions/food-colours-and-hyperactivity/

Published Time: 18 Oct 2017, 3:04 p.m.

Markdown Content:
**Research has found a possible link between certain artificial colours used in food and problems with hyperactivity in children.**

If your child is overactive and struggles to concentrate, it might help to cut down on these colours in their diet. But speak to their GP first.

Food colours linked to hyperactivity
------------------------------------

All food additives, including artificial colours have an E number, which means they've passed safety tests and are approved for use in the EU.

According to research funded by the Food Standards Agency, the 6 food colours most closely linked to hyperactivity in children are:

*   E102 (tartrazine)
*   E104 (quinoline yellow)
*   E110 (sunset yellow FCF)
*   E122 (carmoisine)
*   E124 (ponceau 4R)
*   E129 (allura red)

These colours are used in several foods, including soft drinks, sweets, cakes and ice cream.

[Find out more about food additives, including E numbers and hyperactivity, on the Food Standards Agency website](https://www.food.gov.uk/safety-hygiene/food-additives)

Should my child avoid these food colours?
-----------------------------------------

If your child is hyperactive, or has [attention deficit hyperactivity disorder (ADHD)](https://www.nhs.uk/conditions/attention-deficit-hyperactivity-disorder-adhd/), there's some evidence to suggest that avoiding these 6 food colours may help.

But it's important to be aware that:

*   hyperactivity can have many different causes, including genetics, and food colours are probably only a small part of the problem
*   removing food colours from your child's diet will not necessarily lead to an improvement in their behaviour
*   the link between food colours and hyperactivity is not completely certain; more research is needed to confirm it
*   you do not need to avoid all E numbers; there are hundreds of different E numbers and most are not linked to hyperactivity

If you think your child's diet may be affecting their behaviour, it might help to keep a diary of what they eat and how their behaviour changes, so you can see any patterns.

If you notice a possible link between food colours and their behaviour, you may want to see if avoiding these colours helps. But do not make changes to your child's diet without getting advice from their GP first.

How to avoid these food colours
-------------------------------

You can avoid food colours linked to hyperactivity by checking food labels and looking for alternative products that do not contain them.

All artificial food colours should be included in the list of ingredients, with either their E number or full name.

If any of the 6 food colours mentioned on this page are included, the label must also have a warning saying the colour "may have an adverse effect on activity and attention in children".

If you buy food or drink without packaging, you'll need to ask the manufacturer or the person selling the product if it contains artificial colours.

Page last reviewed: 12 May 2023  
Next review due: 12 May 2026
