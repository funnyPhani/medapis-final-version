Title: Hearing tests

URL Source: https://www.nhs.uk/conditions/hearing-tests/

Published Time: 16 Nov 2017, 4:12 p.m.

Markdown Content:
**There are several ways you can get your hearing tested.**

How to get an NHS hearing test
------------------------------

You can get a free hearing test on the NHS. A GP may refer you to a hearing specialist (audiologist) who can do the test.

It could take a few weeks to see a specialist so it might be quicker to get tested somewhere else, like at a large pharmacy or opticians. This is often free.

### Important

Always see a GP first if:

*   you also have other symptoms, like earache or discharge – this could be something easily treatable like an [earwax build-up](https://www.nhs.uk/conditions/earwax-build-up/) or [ear infection](https://www.nhs.uk/conditions/middle-ear-infection/)
*   you have sudden hearing loss in one ear
*   you're worried about your child's hearing

Other ways to get a hearing test
--------------------------------

### Online hearing test

There are simple hearing tests online.

This can tell you if you need to have a face-to-face hearing test.

[Check your hearing with the RNID's free online hearing test](https://rnid.org.uk/information-and-support/take-online-hearing-check/)

### Pharmacies and opticians

Lots of large pharmacies and opticians can do hearing tests.

The test is often free, but you'll normally have to pay for any treatment you might need (such as hearing aids).

What happens during a hearing test

You may have a few different tests during your appointment to check if you have hearing loss and find out the cause.

Common hearing tests include:

Different types of hearing tests and how they are done
| Test | What happens |
| --- | --- |
| Pure tone audiometry | you listen to different sounds through headphones and press a button or raise your hand each time you hear something |
| Speech perception test | similar to a pure tone audiometry test but you listen to speech rather than sounds |
| Tympanometry | a small device is placed in your ear to check for fluid behind your eardrum |

These are hearing tests for adults. [Newborn hearing tests](https://www.nhs.uk/conditions/pregnancy-and-baby/newborn-hearing-test/) and some [hearing tests for children](https://www.nhs.uk/conditions/hearing-tests-children/) are different.

### Help us improve our information

Can you answer some questions about your experiences with hearing tests to help us improve our information?

[Take our survey](https://feedback.digital.nhs.uk/jfe/form/SV_0q7zuDBk3d3SiKW)

Page last reviewed: 30 November 2020  
Next review due: 30 November 2023
