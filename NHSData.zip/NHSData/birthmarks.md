Title: Birthmarks

URL Source: https://www.nhs.uk/conditions/birthmarks/

Published Time: 20 Oct 2017, 10:36 a.m.

Markdown Content:
**Birthmarks are coloured marks on the skin that are present at birth or soon afterwards. Most are harmless and disappear without treatment, but some may need to be treated.**

Types of birthmark
------------------

There are many different types of birthmark.

### Flat, red or pink areas of skin (salmon patches or stork marks)

![Image 1: A baby's face with pink patches on their eyelids and forehead.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_stork-bite_M2700355.width-320.jpg)

Salmon patches:

*   are red or pink patches, often on a baby's eyelids, head or neck
*   are very common
*   look red or pink on white, brown and black skin
*   are easier to see when a baby cries
*   usually fade by the age of 2 when on the forehead or eyelids
*   can take longer to fade when on the back of the head or neck

### Raised red lumps (strawberry marks or haemangiomas)

![Image 2: A large, red, raised mark with a bumpy texture, on pale skin.](https://assets.nhs.uk/nhsuk-cms/images/A_1017_haemangioma_ATB09D.width-320.jpg)

Strawberry marks:

*   are blood vessels that form a raised red lump on the skin
*   appear soon after birth
*   usually look red on white, brown and black skin
*   are more common in girls, premature babies (born before 37 weeks), low birthweight babies, and multiple births, such as twins
*   get bigger for the first 6 to 12 months, and then shrink and disappear by the age of 7
*   sometimes appear under the skin, making it look blue or purple
*   may need treatment if they affect vision, breathing, or feeding

### Red, purple or dark marks (port wine stains)

![Image 3: A large area of purple skin covering most of the cheek, nose and upper lip on a person with white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_1019_port_wine_stain_C0461030.width-320.jpg)

Port wine stains:

*   are red, purple or dark marks and usually on the face and neck
*   are present from birth
*   look like very dark patches on brown or black skin
*   usually affect 1 side of the body, but can affect both
*   can sometimes be made lighter using laser treatment (it's most effective on young children)
*   can become darker and lumpier if not treated
*   can be a sign of Sturge-Weber syndrome and Klippel-Trenaunay syndrome, or macrocephaly-capillary malformation, but this is rare

### Flat, light or dark brown patches (cafe-au-lait spots)

![Image 4: Close-up of a small, flat, light brown patch on white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_1019_cafe_au_lait_M2200030.width-320.jpg)

Cafe-au-lait spots:

*   are light or dark brown patches that can be anywhere on the body
*   are common, with many children often having 1 or 2
*   look darker on brown or black skin
*   can be different sizes and shapes
*   may be a sign of [neurofibromatosis type 1](https://www.nhs.uk/conditions/neurofibromatosis-type-1/) if a child has 6 or more spots

### Blue-grey spots

![Image 5: Large, dark blue-grey patch that looks like a bruise on a baby's thigh.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_mongolian_blue_spot_C0166926.width-320.jpg)

These birthmarks:

*   can look blue-grey on the skin like a bruise
*   are often on the lower back, bottom, arms or legs
*   are there from birth
*   are most common on babies with brown or black skin
*   do not need treating and will usually go away by the age of 4
*   are not a sign of a health condition

If your baby is born with a blue-grey spot it should be recorded on their medical record.

### Brown or black moles (congenital moles or congenital melanocytic naevi)

![Image 6: A close-up of a large, light brown patch, with a wrinkled texture and irregular edges, on white skin.](https://assets.nhs.uk/nhsuk-cms/images/A_1017_Congenital-melanocytic-naevi_CT579F.width-320.jpg)

Congenital moles:

*   are brown or black moles caused by an overgrowth of pigment cells in the skin
*   look darker on brown or black skin
*   can become darker, raised and hairy, particularly during puberty
*   may develop into skin cancer if they're large (the risk increases the larger they are)
*   do not need to be treated unless there's a risk of skin cancer

Information:

### Find out about other types of birthmark

*   [Birthmark Support Group: types of birthmark](http://www.birthmarksupportgroup.org.uk/types-of-birthmark.aspx)

### Non-urgent advice: See a GP if:

*   you're worried about a birthmark
*   a birthmark is close to the eye, nose, or mouth
*   a birthmark has got bigger, darker or lumpier
*   a birthmark is sore or painful
*   your child has 6 or more cafe-au-lait spots
*   you or your child has a large congenital mole

The GP may ask you to check the birthmark for changes, or they may refer you to a skin specialist (dermatologist).

Treatment for birthmarks
------------------------

Most birthmarks do not need treatment, but some do. This is why it's important to get a birthmark checked if you're worried about it.

A birthmark can be removed on the NHS if it's affecting a person's health. If you want a birthmark removed for cosmetic reasons, you'll have to pay to have it done privately.

Possible treatments for birthmarks include:

*   medicines – to reduce blood flow to the birthmark, which can slow down its growth and make it lighter in colour
*   laser therapy – where heat and light are used to make the birthmark smaller and lighter (it works best if started between 6 months and 1 year of age)
*   surgery – to remove the birthmark (but it can leave scarring)

Page last reviewed: 28 April 2023  
Next review due: 28 April 2026
