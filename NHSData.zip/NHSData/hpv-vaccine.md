Title: HPV vaccine

URL Source: https://www.nhs.uk/vaccinations/hpv-vaccine/

Published Time: 6 Mar 2024, 5:40 p.m.

Markdown Content:
What the HPV vaccine is for
---------------------------

The HPV vaccine reduces your chances of getting [human papillomavirus (HPV)](https://www.nhs.uk/conditions/human-papilloma-virus-hpv/), a common virus that's spread through skin contact (usually when having sex).

Most types of HPV are harmless. But some types are linked to an increased risk of certain types of cancer, including:

*   [cervical cancer](https://www.nhs.uk/conditions/cervical-cancer/)
*   [mouth cancer](https://www.nhs.uk/conditions/mouth-cancer/)
*   [anal cancer](https://www.nhs.uk/conditions/anal-cancer/)
*   [penile cancer](https://www.nhs.uk/conditions/penile-cancer-1/)
*   [vulval cancer](https://www.nhs.uk/conditions/vulval-cancer/)
*   [vaginal cancer](https://www.nhs.uk/conditions/vaginal-cancer/)

HPV can also cause [genital warts](https://www.nhs.uk/conditions/genital-warts/).

Who should have the HPV vaccine
-------------------------------

The HPV vaccine is recommended for children aged 12 to 13 years old and people at higher risk from HPV.

Children aged 12 to 13

All children aged 12 to 13 (school year 8) are offered the HPV vaccine.

If you missed getting vaccinated when you were 12 or 13, the HPV vaccine is available for free on the NHS for:

*   all girls under 25
*   boys born after 1 September 2006

Contact your school nurse, school vaccination team or GP surgery if you or your child were eligible for the HPV vaccine but did not get vaccinated.

Men under 45 who have sex with men

Gay, bisexual and other men who have sex with men are at higher risk from HPV.

If you're a man under 45 who has sex with men and you attend a sexual health or HIV clinic, you can get vaccinated against HPV.

You're eligible for the vaccine up until your 45th birthday.

Other people at higher risk from HPV

The HPV vaccine is also sometimes recommended for other people at higher risk from HPV, such as:

*   any transgender people who are felt to have the same risk as men who have sex with men
*   sex workers
*   people with HIV

Who cannot have the HPV vaccine
-------------------------------

Most people who are eligible for the HPV vaccine can have it.

You only cannot have the vaccine if you've had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a previous dose of the vaccine, or an ingredient in the vaccine.

There's no evidence the vaccine is harmful if you're pregnant, but sometimes you may be advised to wait until you're no longer pregnant before having the vaccine.

You can have the HPV vaccine while breastfeeding.

Information:

### Getting vaccinated if you're unwell

If you have a high temperature or feel too unwell to do your normal activities, wait until you're feeling better before having the vaccine.

HPV vaccine ingredients
-----------------------

There is 1 type of HPV vaccine given in the UK. You can check the ingredients in the patient leaflet:

[Gardasil 9 HPV vaccine patient leaflet (Electronic Medicines Compendium website)](https://www.medicines.org.uk/emc/product/7330/pil)

How to get the HPV vaccine
--------------------------

There are different ways to get the HPV vaccine.

Where to get the HPV vaccine
| Who should have it | Where to get it |
| --- | --- |
| Children aged 12 to 13 (school year 8)
 | Secondary school (or community clinics for those not in school)

 |
| Girls under 25 and boys born after 1 September 2006 who missed having the vaccine at school

 | Check with your school nurse, school vaccination team or GP surgery

 |
| Men under 45 who have sex with men, and other people at higher risk of HPV

 | [Sexual health clinics](https://www.nhs.uk/service-search/find-a-sexual-health-clinic) or [HIV clinics](https://www.nhs.uk/service-search/other-health-services/hiv-sexual-health-services)

 |

How the HPV vaccine is given
----------------------------

The HPV vaccine is given as an injection into your arm.

The number of doses you need depends on your age and how well your immune system works:

*   people under 25 usually have 1 dose
*   people aged 25 to 45 usually have 2 doses (given between 6 months and 2 years apart)
*   people with a weakened immune system have 3 doses (given over a 12-month period)

Side effects of the HPV vaccine
-------------------------------

The most common side effects of the HPV vaccine are mild and do not last long.

They can include:

*   swelling or pain where the injection was given
*   a headache
*   a high temperature
*   dizziness
*   feeling sick
*   tiredness

More serious side effects such as a severe allergic reaction are very rare. The person who vaccinates you will be trained to deal with allergic reactions and treat them immediately.

How well the HPV vaccine works
------------------------------

The HPV vaccine works very well in reducing your risk of getting HPV.

Since the vaccine has been used, there has been a big drop in the number of young people getting conditions linked to HPV, such as cervical cancer and genital warts.

Research suggests that over time the HPV vaccine will help save thousands of lives in the UK.

### Important

It's still important to attend [cervical screening](https://www.nhs.uk/conditions/cervical-screening/) appointments if you've been vaccinated against HPV, as there's still a small chance you could get cervical cancer.
