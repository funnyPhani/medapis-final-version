Title: Corticobasal degeneration

URL Source: https://www.nhs.uk/conditions/corticobasal-degeneration/

Published Time: 23 Oct 2017, 10:58 a.m.

Markdown Content:
**Corticobasal degeneration (CBD) is a rare condition that can cause gradually worsening problems with movement, speech, memory and swallowing.**

It's often also called corticobasal syndrome (CBS).

CBD is caused by increasing numbers of brain cells becoming damaged or dying over time.

Most cases of CBD develop in adults aged between 50 and 70.

CBD symptoms
------------

The symptoms of CBD get gradually worse over time. They are very variable and many people only have a few of them.

Symptoms can include:

*   difficulty controlling your limb on one side of the body (a "useless" hand)
*   muscle stiffness
*   shaking ([tremors](https://www.nhs.uk/conditions/tremor-or-shaking-hands/)), jerky movements and spasms ([dystonia](https://www.nhs.uk/conditions/dystonia/))
*   problems with balance and co-ordination
*   slow and slurred speech
*   [symptoms of dementia](https://www.nhs.uk/conditions/dementia/symptoms-and-diagnosis/symptoms/), such as memory and visual problems
*   slow, effortful speech
*   [difficulty swallowing](https://www.nhs.uk/conditions/swallowing-problems-dysphagia/)

One limb is usually affected at first, before spreading to the rest of the body. The rate at which the symptoms progress varies widely from person to person.

Read more about the [symptoms of CBD](https://www.nhs.uk/conditions/corticobasal-degeneration/symptoms/).

What causes CBD?
----------------

CBD occurs when brain cells in certain parts of the brain are damaged as a result of a build-up of a protein called tau.

The surface of the brain (cortex) is affected, as well as a deep part of the brain called the basal ganglia.

Tau occurs naturally in the brain and is usually broken down before it reaches high levels. In people with CBD, it isn't broken down properly and forms harmful clumps in brain cells.

CBD has been linked to changes in certain genes, but these genetic links are weak and the risk to other family members is very low.

Diagnosing CBD
--------------

There's no single test for CBD. Instead, the diagnosis is based on the pattern of your symptoms. Your doctor will try to rule out other conditions that can cause similar symptoms, such as [Parkinson's disease](https://www.nhs.uk/conditions/parkinsons-disease/) or a [stroke](https://www.nhs.uk/conditions/stroke/).

You may need to have a brain scan to look for other possible causes of your symptoms, as well as tests of your memory, concentration and ability to understand language.

You will usually see a neurologist (a specialist in conditions affecting the brain and nerves).

Read more about [how CBD is diagnosed](https://www.nhs.uk/conditions/corticobasal-degeneration/diagnosis/).

Treatments for CBD
------------------

As someone with CBD can be affected in many different ways, treatment and care is best provided by a team of health and social care professionals working together. Treatments may include:

*   medication – to improve stiffness and muscle spasms, sleep and mood, pain or memory
*   [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) – to help with movement and balance difficulties
*   speech and language therapy – to help with communication and swallowing problems
*   [occupational therapy](https://www.nhs.uk/conditions/occupational-therapy/) – to improve the skills and abilities needed for daily activities at home
*   palliative care and advanced care planning

Read more about [treatment for CBD](https://www.nhs.uk/conditions/corticobasal-degeneration/treatment/).

Outlook
-------

There is currently no treatment that has been shown to stop CBD getting gradually worse, although treatments can reduce many of the symptoms.

Good care and assistance can help someone with CBD be more independent and enjoy a better quality of life, but the condition will eventually put them at risk of serious complications.

CBD usually changes very slowly. Many people find it helpful to plan ahead with their doctors (GP and specialist) to make decisions about what to do in later stages of the illness.

Difficulty swallowing can cause choking, or inhaling food or liquid into the airways. This can lead to [pneumonia](https://www.nhs.uk/conditions/pneumonia/), which can be life-threatening.

As a result of these complications, the average life expectancy for someone with CBD is around 6 to 8 years from when their symptoms start. However, this is only an average and CBD is very variable.

Information about you
---------------------

If you have CBD, your clinical team will pass information about you on to the National Congenital Anomaly and Rare Diseases Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the register on the National Disease Registration Service website](https://www.ndrs.nhs.uk/).

Page last reviewed: 27 September 2022  
Next review due: 27 September 2025
