Title: Bladder cancer

URL Source: https://www.nhs.uk/conditions/bladder-cancer/

Published Time: 17 May 2018, 12:13 p.m.

Markdown Content:
**Bladder cancer is where a growth of abnormal tissue, known as a tumour, develops in the bladder lining. In some cases, the tumour spreads into the bladder muscle.**

The most common symptom of bladder cancer is [blood in urine](https://www.nhs.uk/conditions/blood-in-urine/), which is usually painless.

If you notice blood in your urine, even if it comes and goes, you should visit your GP, so the cause can be investigated.

Read about the [symptoms of bladder cancer](https://www.nhs.uk/conditions/bladder-cancer/symptoms/).

Types of bladder cancer
-----------------------

Once diagnosed, bladder cancer can be classified by how far it has spread.

If the cancerous cells are contained inside the lining of the bladder, doctors describe it as non-muscle-invasive bladder cancer (early bladder cancer). This is the most common type of bladder cancer.

When the cancerous cells spread beyond the lining, into the surrounding bladder muscle, it's referred to as muscle-invasive bladder cancer (or invasive bladder cancer). This is less common, but has a higher chance of spreading to other parts of the body.

If bladder cancer has spread to other parts of the body, it's known as advanced or metastatic bladder cancer.

Read more about [diagnosing bladder cancer](https://www.nhs.uk/conditions/bladder-cancer/diagnosis/).

Causes of bladder cancer
------------------------

Most cases of bladder cancer appear to be caused by exposure to harmful substances, which lead to abnormal changes in the bladder's cells over many years.

Tobacco smoke is a common cause and it's estimated that more than 1 in 3 cases of bladder cancer are caused by smoking.

Contact with certain chemicals previously used in manufacturing is also known to cause bladder cancer. However, these substances have since been banned.

Read more about the [causes of bladder cancer](https://www.nhs.uk/conditions/bladder-cancer/causes/).

Treating bladder cancer
-----------------------

In cases of non-muscle-invasive bladder cancer, it's usually possible to remove the cancerous cells while leaving the rest of the bladder intact.

This is done using a surgical technique called transurethral resection of a bladder tumour (TURBT). This is followed by a dose of chemotherapy medicines directly into the bladder, to reduce the risk of the cancer returning.

In cases with a higher risk of recurrence, medicine known as Bacillus Calmette-Guérin (BCG) may be injected into the bladder to reduce the risk of the cancer returning.

Treatment for high-risk non-muscle-invasive bladder cancer, or muscle-invasive bladder cancer may involve surgically removing the bladder in an operation known as a cystectomy.

Most patients will have a choice of either surgery or a course of [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/).

When the bladder is removed, you'll need another way of collecting your urine. Possible options include making an opening in the abdomen so urine can be passed into an external bag, or constructing a new bladder out of a section of bowel. This will be done at the same time as a cystectomy.

After treatment for all types of bladder cancer, you'll have regular follow-up tests to check for signs of recurrence.

Read more about [treating bladder cancer](https://www.nhs.uk/conditions/bladder-cancer/treatment/).

Who is affected?
----------------

About 10,000 people are diagnosed with bladder cancer every year and it's the 11th most common cancer in the UK.

The condition is more common in older adults, with most new cases diagnosed in people aged 60 and above.

Bladder cancer is also more common in men than in women, possibly because in the past, men were more likely to smoke and work in the manufacturing industry.

Page last reviewed: 01 July 2021  
Next review due: 01 July 2024
