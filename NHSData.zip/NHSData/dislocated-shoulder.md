Title: Dislocated shoulder

URL Source: https://www.nhs.uk/conditions/dislocated-shoulder/

Published Time: 18 Oct 2017, 12:11 p.m.

Markdown Content:
**A dislocated shoulder is when your upper arm bone comes out of place from your shoulder socket.**

Get medical help as soon as possible if you think you’ve dislocated your shoulder. Do not try to treat it yourself.

### Immediate action required: Go to A&E if:

You've injured your shoulder and:

*   you cannot move your arm
*   your shoulder looks out of place or has changed shape
*   your shoulder is painful, bruised or swollen

Call 999 for an ambulance if you cannot get to A&E by yourself.

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

What to do while you’re waiting for treatment
---------------------------------------------

If you think you’ve dislocated your shoulder, there are some things you can do while you’re waiting for treatment.

### Do

*   gently hold an ice pack (or a bag of frozen peas wrapped in a tea towel) to your shoulder for up to 20 minutes every 2 to 3 hours
    
*   put your arm in a sling or use a towel to support the affected arm
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) for the pain – always follow the dosage advice on the packet
    

### Don’t

*   do not move your upper arm
    
*   do not try to put your arm back in yourself
    

Treatment for a dislocated shoulder
-----------------------------------

You will usually have an [X-ray](https://www.nhs.uk/conditions/x-ray/) to check your shoulder is dislocated.

If it is dislocated, a doctor will rotate your arm back into place.

You will be given a [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) or a sedative so you do not feel any pain.

Once your arm is back in place, you’ll be given a sling to support your arm

Sometimes you may also need surgery to reduce your risk of dislocating the same shoulder again.

Recovering from a dislocated shoulder
-------------------------------------

It usually takes up to 12 weeks to recover from a dislocated shoulder. It may take up to 16 weeks to fully return to playing some sports, but for some recovery can take longer.

You’ll need to wear a sling to support your arm for the first few weeks.

A physiotherapist may recommend some regular shoulder exercises to help reduce pain and stiffness.

Your doctor or physiotherapist will advise you on when you can return to daily tasks like driving or playing sport.

Reducing the risk of dislocating your shoulder again
----------------------------------------------------

Once you dislocate your shoulder, there’s an increased risk it could happen again.

The risk depends on your age and how well your shoulder joint healed.

You may be offered a scan to check if your shoulder has been damaged.

It’s important to follow any advice you’re given by the hospital or doctor.

The hospital may recommend regular [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) appointments to help make your shoulder muscles stronger and reduce the risk of dislocating your shoulder again.

Page last reviewed: 17 May 2023  
Next review due: 17 May 2026
