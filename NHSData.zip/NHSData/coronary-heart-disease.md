Title: Coronary heart disease

URL Source: https://www.nhs.uk/conditions/coronary-heart-disease/

Published Time: 3 Oct 2018, 9:01 p.m.

Markdown Content:
**Coronary heart disease (CHD) is a major cause of death in the UK and worldwide. CHD is sometimes called ischaemic heart disease or coronary artery disease.**

Symptoms of coronary heart disease (CHD)
----------------------------------------

The main symptoms of coronary heart disease are:

*   chest pain [(angina)](https://www.nhs.uk/conditions/angina/)
*   shortness of breath
*   pain in your neck, shoulders, jaw or arms
*   feeling faint
*   feeling sick (nausea)

But not everyone has the same symptoms and some people may not have any before coronary heart disease is diagnosed.

Causes of coronary heart disease (CHD)
--------------------------------------

Coronary heart disease is the term that describes what happens when your heart's blood supply is blocked or interrupted by a build-up of fatty substances in the coronary arteries.

Over time, the walls of your arteries can become furred up with fatty deposits. This process is known as [atherosclerosis](https://www.nhs.uk/conditions/atherosclerosis/) and the fatty deposits are called atheroma.

Atherosclerosis can be caused by lifestyle factors, such as smoking and regularly drinking excessive amounts of alcohol.

You're also more at risk of getting atherosclerosis if you have conditions like [high cholesterol](https://www.nhs.uk/conditions/high-cholesterol/), [high blood pressure (hypertension)](https://www.nhs.uk/conditions/high-blood-pressure-hypertension/) or [diabetes](https://www.nhs.uk/conditions/diabetes/).

Diagnosing coronary heart disease (CHD)
---------------------------------------

If a doctor feels you're at risk of coronary heart disease, they may carry out a risk assessment.

They'll ask you about your medical and family history and your lifestyle, and they'll take a [blood test](https://www.nhs.uk/conditions/blood-tests/).

Further tests may be needed to confirm coronary heart disease, including:

*   electrocardiogram (ECG)
*   echocardiogram
*   chest x-ray
*   coronary angiogram

Read more about [how coronary heart disease is diagnosed](https://www.nhs.uk/conditions/coronary-heart-disease/diagnosis/).

Treating coronary heart disease (CHD)
-------------------------------------

Coronary heart disease cannot be cured but treatment can help manage the symptoms and reduce the chances of problems such as heart attacks.

Treatment can include:

*   lifestyle changes, such as regular exercise and [stopping smoking](https://www.nhs.uk/live-well/quit-smoking/)
*   medicines
*   [angioplasty](https://www.nhs.uk/conditions/coronary-angioplasty/) – where balloons and stents are used to treat narrow heart arteries
*   surgery

Recovering from the effects of coronary heart disease (CHD)
-----------------------------------------------------------

If you've had a heart attack, an angioplasty, or heart surgery, you’ll want to get back to as full a life as possible.

Advice and support is available to help you deal with aspects of your life that may have been affected by coronary heart disease.

Read more about [recovering from the effects of coronary heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/recovery/).

Preventing coronary heart disease (CHD)
---------------------------------------

You can reduce your risk of getting coronary heart disease by making some simple lifestyle changes.

These include:

*   eating a healthy, balanced diet
*   being physically active
*   giving up smoking
*   controlling blood cholesterol and sugar levels

Keeping your heart healthy will also have other health benefits, such as helping reduce your risk of [stroke](https://www.nhs.uk/conditions/stroke/) and [dementia](https://www.nhs.uk/conditions/dementia/about-dementia/what-is-dementia/).

The heart
---------

The heart is a muscle about the size of your fist. It pumps blood around your body and beats approximately 70 times a minute.

After the blood leaves the right side of the heart, it goes to your lungs where it picks up oxygen.

The oxygen-rich blood returns to your heart and is then pumped to the body's organs through a network of arteries.

The blood returns to your heart through veins before being pumped back to your lungs again. This process is called circulation.

The heart gets its own supply of blood from a network of blood vessels on the heart's surface called coronary arteries.

Video: coronary arteries and heart disease
------------------------------------------

This video shows how your heart works and what happens when your coronary arteries stop functioning properly.

Media last reviewed: 21 April 2023  
Media review due: 21 April 2026

Page last reviewed: 17 January 2024  
Next review due: 17 January 2027
