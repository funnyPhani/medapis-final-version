Title: Alcohol poisoning

URL Source: https://www.nhs.uk/conditions/alcohol-poisoning/

Published Time: 17 Oct 2017, 4:40 p.m.

Markdown Content:
**Alcohol poisoning can happen when you drink alcohol quicker than your body can process it. It can make you seriously ill and you may need to go to hospital for treatment.**

Check if it's alcohol poisoning
-------------------------------

Symptoms start after drinking a lot of alcohol and may include:

*   confusion
*   slurring words or being unable to speak
*   being unable to coordinate movement, for example, being unable to stand, walk, or pick things up
*   being sick
*   peeing or pooing yourself
*   pale or blue-tinged skin - on black or brown skin this may be easier to see inside the lips, on the gums and under the fingernails
*   slow or irregular breathing
*   having a seizure or fit
*   loss of consciousness

Immediate action required: Call 999 if:
---------------------------------------

*   you think someone has alcohol poisoning
*   you or someone else has had a seizure or fit
*   someone has lost consciousness
*   someone has stopped breathing

Information:

Do not drive yourself to A&E.

The person you speak to at 999 will give you advice about what to do.

Things you can do to help someone who has drunk too much alcohol
----------------------------------------------------------------

### Do

*   stay with them because there's a risk they could choke on their own sick or stop breathing
    
*   sit them up if they're awake, or put them in the [recovery position](https://www.nhs.uk/conditions/first-aid/recovery-position/) if they've passed out and check they're breathing properly
    
*   give them water to sip if they're able to swallow
    
*   keep them warm with a jacket or blanket
    

### Don’t

*   do not let them drink more alcohol
    
*   do not give them coffee or drinks containing caffeine because this can dehydrate people with alcohol poisoning
    
*   do not put them in a cold shower or bath because there's a risk they could get too cold, fall or lose consciousness in the water
    
*   do not try to make them sick
    

Treatment for alcohol poisoning
-------------------------------

You'll need to go to hospital to be monitored if you have alcohol poisoning. It can cause serious complications, like liver and heart failure, which can be fatal.

You may be given fluids, which may be given into your veins with a drip. You may also be given help with your breathing until the effects of the alcohol wear off.

Causes of alcohol poisoning
---------------------------

Alcohol poisoning is usually caused by binge drinking, which is where you have a lot of alcohol in one drinking session. It can happen when you drink alcohol faster than your body can filter it out of your blood.

Having too much alcohol in your blood stops your body working properly and can be life-threatening.

Alcohol affects people differently. Some people may be able to drink more alcohol than others, with fewer effects.

[Find out more about the risks of drinking too much](https://www.nhs.uk/live-well/alcohol-advice/the-risks-of-drinking-too-much/)

Page last reviewed: 11 January 2023  
Next review due: 11 January 2026
