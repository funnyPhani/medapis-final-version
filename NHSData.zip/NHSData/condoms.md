Title: Condoms

URL Source: https://www.nhs.uk/contraception/methods-of-contraception/condoms/

Published Time: 29 Feb 2024, 9:10 a.m.

Markdown Content:
There is separate information about [internal (female) condoms](https://www.nhs.uk/contraception/methods-of-contraception/internal-condoms/).

Who can use condoms
-------------------

Most people can use condoms.

Some condoms are made from latex, others are latex free. It will say on the packet what the condom is made of.

Do not use latex condoms if:

*   you have a latex allergy
*   you’re using antifungal medicine on or around your anus, vulva and vagina, or penis and testicles

Using a condom
--------------

Condoms can be used for:

*   vaginal sex
*   anal sex
*   oral sex

Some people also put condoms on sex toys.

### Do

*   use a new condom every time you have sex
    
*   follow the instructions on the condom packet to put it on correctly
    
*   check the use by date has not expired – an expired condom may not be effective
    
*   check the packet for a European CE mark or UKCA mark – this means it’s been tested to high safety standards
    

### Don’t

*   do not use more than one condom – this can make one or both condoms split
    
*   do not use oil-based lubricant with latex condoms – use water-based or silicone-based lubricant instead
    

### How to use a condom

Put the condom on before you start having sex (before the penis touches the vagina or anus).

1.  Make sure the penis is fully erect.
2.  Open the packet carefully so you do not damage the condom. Do not use your teeth as this could rip the condom.
3.  Hold the tip of the condom to squeeze out any air.
4.  Roll the condom all the way down to the base of the penis. If the condom does not roll down, you may have put it on the wrong way round. Throw it away and use a new condom.
5.  Keep the condom on until you finish having sex. When you've finished, grip the base of the condom as you pull out to stop it coming off the penis.
6.  Always put used condoms in the bin, not in the toilet.

How well condoms work
---------------------

### How well condoms work at preventing pregnancy

Condoms are up to 98% effective at preventing pregnancy if you use them correctly every time you have sex.

If not used correctly they’re 82% effective, which means around 1 in 5 women who use condoms for a year will get pregnant.

Incorrect use includes:

*   putting a condom on after the penis has touched the vagina
*   a condom splitting or coming off during sex

### How well condoms work to prevent sexually transmitted infections (STIs)

Using a condom every time you have sex is the best way to protect you and your partner from HIV and other STIs.

Where to get condoms
--------------------

Contraception services are free and confidential on the NHS.

You can get condoms for free from:

*   sexual health clinics, also called family planning or contraception clinics
*   some GP surgeries and pharmacies
*   some young people's services (call the national sexual health helpline on 0300 123 7123 for more information)

You can also buy condoms from pharmacies and supermarkets or online.

[Find contraception information and advice services](https://www.nhs.uk/service-search/other-health-services/contraception-information-and-advice)

### **Getting contraception if you’re under 16**

Contraception is free and confidential, including for young people under the age of 16.

The doctor or nurse will not tell anyone, including your parents or carer, unless they think you or someone else is at risk of harm.
