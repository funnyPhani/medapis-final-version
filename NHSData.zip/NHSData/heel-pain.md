Title: Heel pain

URL Source: https://www.nhs.uk/conditions/foot-pain/heel-pain/

Published Time: 30 Mar 2022, 1:58 p.m.

Markdown Content:
**There are lots of causes of heel pain. You can usually ease the pain yourself. But see a GP if the pain does not improve.**

How to ease heel pain yourself
------------------------------

If you see a GP, they'll usually suggest you try these things:

### Do

*   rest and raise your heel when you can
    
*   put an ice pack (or bag of frozen peas) in a towel on your heel for up to 20 minutes every 2 to 3 hours
    
*   wear wide comfortable shoes with a low heel and soft sole
    
*   use soft insoles or heel pads in your shoes
    
*   wrap a bandage around your heel and ankle to support it
    
*   try regular gentle stretching exercises
    
*   use painkillers such as [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen gel](https://www.nhs.uk/medicines/ibuprofen-for-adults/how-and-when-to-take-ibuprofen/) (or ibuprofen tablets if needed)
    

### Don’t

*   do not walk or stand for long periods, especially barefoot
    
*   do not wear high heels or tight pointy shoes
    

### A pharmacist can help with heel pain

You can ask a pharmacist about:

*   the best painkiller to take for your heel pain
*   insoles and pads for your shoes
*   treatments for common skin problems that can affect the heel
*   if you need to see a GP

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

### Video: exercises to reduce heel pain

This video demonstrates exercises that can help reduce heel pain.

Media last reviewed: 1 April 2022  
Media review due: 1 April 2025

See exercise video safety information

The exercises in this series of videos are suitable for most people in good health with a reasonable level of fitness.

Unless stated otherwise, they are general exercises only and are not aimed at treating any specific cause of pain or condition. Video titles and descriptions can give more information on how difficult the exercises are and who they are for.

Get advice from a healthcare professional before trying them if:

*   you are not sure if the exercises are suitable for your current level of fitness
*   you have a health problem, an injury, any symptoms, are feeling unwell, or you have had a recent health event such as a heart attack or operation
*   you have any other concerns about your health
*   you are pregnant or have recently given birth

Stop the exercise immediately if you feel any pain or become unwell. If you are concerned about any symptoms, or they do not go away, [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms) or call 111 for advice.

Non-urgent advice: See a GP if:
-------------------------------

*   heel pain is severe or stopping you doing normal activities
*   the pain is getting worse or keeps coming back
*   the pain has not improved after treating it at home for 2 weeks
*   you have any tingling or loss of sensation in your foot
*   you have diabetes and have heel pain – foot problems can be more serious if you have diabetes

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

Immediate action required: Go to an urgent treatment centre or A&E if you:
--------------------------------------------------------------------------

*   have severe heel pain after an injury
*   feel faint, dizzy or sick from the pain
*   have an ankle or foot that has changed shape or is at an odd angle
*   heard a snap, grinding or popping noise at the time of injury
*   are not able to walk

These might be signs of a broken heel bone or broken ankle.

[Find an urgent treatment centre](https://www.nhs.uk/service-search/Urgent-Treatment-Centre/LocationSearch/10022)

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

Common causes of heel pain
--------------------------

Heel pain is often caused by exercising too much or wearing shoes that are too tight.

Your symptoms might also give you an idea of what's causing your heel pain.

Possible causes of heel pain.
| Symptoms | Possible cause |
| --- | --- |
| Sharp pain between your arch and heel, feels worse when you start walking and better when resting, difficulty raising toes off floor | [Plantar fasciitis](https://www.nhs.uk/conditions/plantar-fasciitis/) |
| Pain in the back of the heel, and in the ankle and calf | [Achilles tendonitis](https://www.nhs.uk/conditions/tendonitis/) |
| Redness and swelling, dull aching pain in heel | [Bursitis](https://www.nhs.uk/conditions/bursitis/) |
| Sudden sharp pain in heel, swelling, a popping or snapping sound during the injury, difficulty walking | Heel fracture or ruptured Achilles tendon |

### If you're not sure what's causing your heel pain

Do not worry if you're not sure what the problem is.

Follow the advice on this page and see a GP if the pain does not get better in 2 weeks.

Information:

**Self-refer for treatment**
----------------------------

If you have heel pain, you might be able to refer yourself directly to services for help with your condition without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS treatment for heel pain near you
