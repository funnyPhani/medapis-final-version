Title: Hepatitis

URL Source: https://www.nhs.uk/conditions/hepatitis/

Published Time: 18 Oct 2017, 2:01 p.m.

Markdown Content:
**Hepatitis is the term used to describe inflammation of the liver. It's usually the result of a viral infection or liver damage caused by drinking alcohol.**

There are several different types of hepatitis. Some types will pass without any serious problems, while others can be long-lasting (chronic) and cause [scarring of the liver (cirrhosis)](https://www.nhs.uk/conditions/cirrhosis/), loss of liver function and, in some cases, [liver cancer](https://www.nhs.uk/conditions/liver-cancer/).

Symptoms of hepatitis
---------------------

Short-term (acute) hepatitis often has no noticeable symptoms, so you may not realise you have it.

If symptoms do develop, they can include:

*   muscle and [joint pain](https://www.nhs.uk/conditions/joint-pain/)
*   a high temperature
*   [feeling and being sick](https://www.nhs.uk/conditions/nausea-and-vomiting-in-adults/)
*   feeling unusually tired all the time
*   a general sense of feeling unwell
*   loss of appetite
*   [tummy pain](https://www.nhs.uk/conditions/stomach-ache/)
*   dark urine
*   pale, grey-coloured poo
*   [itchy skin](https://www.nhs.uk/conditions/itchy-skin/)
*   [yellowing of the eyes and skin (jaundice)](https://www.nhs.uk/conditions/jaundice/)

See your GP if you have any persistent or troublesome symptoms that you think could be caused by hepatitis.

Long-term (chronic) hepatitis also may not have any obvious symptoms until the liver stops working properly (liver failure) and may only be picked up during [blood tests](https://www.nhs.uk/conditions/blood-tests/).

In the later stages it can cause jaundice, swelling in the legs, ankles and feet, [confusion](https://www.nhs.uk/conditions/confusion/), and blood in your stools or vomit.

Hepatitis A
-----------

Hepatitis A is caused by the hepatitis A virus. It's usually caught by consuming food and drink contaminated with the poo of an infected person, and is most common in countries where sanitation is poor.

Hepatitis A usually passes within a few months, although it can occasionally be severe and even life threatening.

There's no specific treatment for it, other than to relieve symptoms like pain, nausea and itching.

Vaccination against hepatitis A is recommended if:

*   you're at high risk of infection or severe consequences of infection
*   you're travelling to an area where the virus is common, such as the Indian subcontinent, Africa, Central and South America, the Far East and eastern Europe.

[Find out more about hepatitis A](https://www.nhs.uk/conditions/hepatitis-a/)

Hepatitis B
-----------

Hepatitis B is caused by the hepatitis B virus, which is spread in the blood of an infected person.

It's a common infection worldwide and is usually spread from infected pregnant women to their babies, or from child-to-child contact.

It can also be spread through unprotected sex and injecting drugs.

Hepatitis B is uncommon in the UK. It most commonly affects people who became infected while growing up in part of the world where the infection is more common, such as southeast Asia and sub-Saharan Africa.

Most adults infected with hepatitis B are able to fight off the virus and fully recover from the infection within a couple of months.

But most people infected as children develop a long-term infection. This is known as chronic hepatitis B, and can lead to cirrhosis and liver cancer. Antiviral medicine can be used to treat it.

In the UK, vaccination against hepatitis B is recommended for people in high-risk groups, such as:

*   healthcare workers
*   people who inject drugs
*   men who have sex with men
*   children born to mothers with hepatitis B
*   people travelling to parts of the world where the infection is more common

Hepatitis B vaccination is also part of the routine immunisation programme so all children can benefit from protection from this virus.

[Find out more about hepatitis B](https://www.nhs.uk/conditions/hepatitis-b/)

Hepatitis C
-----------

Hepatitis C is caused by the hepatitis C virus.

It's usually spread through blood-to-blood contact with an infected person.

In the UK, it's most commonly spread through sharing needles used to inject drugs.

Poor healthcare practices and unsafe medical injections are the main way it's spread outside the UK.

Hepatitis C often causes no noticeable symptoms, or only flu-like symptoms, so many people are unaware they're infected.

Some people will fight off the infection and be free of the virus. In other cases, it'll stay in the body for many years.

This is known as chronic hepatitis C and can cause cirrhosis and liver failure.

Chronic hepatitis C can be treated with very effective antiviral medicines, but there's currently no vaccine available.

[Find out more about hepatitis C](https://www.nhs.uk/conditions/hepatitis-c/)

Hepatitis D
-----------

Hepatitis D is caused by the hepatitis D virus. It only affects people who are already infected with hepatitis B, as it needs the hepatitis B virus to be able to survive in the body.

Hepatitis D is usually spread through blood-to-blood contact or sexual contact. It's uncommon in the UK, but is more widespread in other parts of Europe, the Middle East, Africa and South America.

Long-term infection with hepatitis D and hepatitis B can increase your risk of developing serious problems, such as cirrhosis and liver cancer.

There's no vaccine specifically for hepatitis D, but the hepatitis B vaccine can help protect you from it.

Hepatitis E
-----------

Hepatitis E is caused by the hepatitis E virus. The number of cases in Europe has increased in recent years and it's now the most common cause of short-term (acute) hepatitis in the UK.

The virus has been mainly associated with the consumption of raw or undercooked pork meat or offal, but also with wild boar meat, venison and shellfish.

Hepatitis E is generally a mild and short-term infection that does not require any treatment, but it can be serious in some people, such as those who have a weakened immune system.

There's no vaccine for hepatitis E. When travelling to parts of the world with poor sanitation, where epidemic hepatitis E may be common, you can reduce your risk by practising good food and water hygiene measures.

[The British Liver Trust has more information about hepatitis E](http://www.britishlivertrust.org.uk/information-and-support/living-with-a-liver-condition/liver-conditions/hepatitis-e/)

Alcoholic hepatitis
-------------------

Alcoholic hepatitis is a type of hepatitis caused by drinking excessive amounts of alcohol over many years.

The condition is common in the UK and many people do not realise they have it.

This is because it does not usually cause any symptoms, although it can cause sudden jaundice and liver failure in some people.

Stopping drinking will usually allow your liver to recover, but there's a risk you could eventually develop cirrhosis, liver failure or liver cancer if you continue to drink alcohol excessively.

You can reduce your risk of developing alcoholic hepatitis by controlling how much you drink.

It's recommended that you do not regularly drink more than 14 [units of alcohol](https://www.nhs.uk/live-well/alcohol-advice/calculating-alcohol-units/) a week.

Read more about [alcohol-related liver disease](https://www.nhs.uk/conditions/alcohol-related-liver-disease-arld/) and the [health risks associated with alcohol](https://www.nhs.uk/live-well/alcohol-advice/the-risks-of-drinking-too-much/).

Autoimmune hepatitis
--------------------

Autoimmune hepatitis is a rare cause of long-term hepatitis where the immune system attacks and damages the liver.

Eventually, the liver can become so damaged that it stops working properly.

Treatment for autoimmune hepatitis involves very effective medicines that suppress the immune system and reduce inflammation.

It's not clear what causes autoimmune hepatitis and it's not known whether anything can be done to prevent it.

[The British Liver Trust has more information about autoimmune hepatitis](http://www.britishlivertrust.org.uk/information-and-support/living-with-a-liver-condition/liver-conditions/autoimmune-hepatitis/)

Page last reviewed: 23 August 2022  
Next review due: 23 August 2025
