Title: Circumcision in men

URL Source: https://www.nhs.uk/conditions/circumcision-in-men/

Published Time: 18 Oct 2017, 11:51 a.m.

Markdown Content:
**Circumcision is the surgical removal of the foreskin.**

The foreskin is the retractable fold of skin that covers the end of the penis. It's a continuation of the skin that covers the whole penis.

This page focuses on circumcision for medical reasons in men.

[Read about circumcision for medical reasons in boys](https://www.nhs.uk/conditions/circumcision-in-boys/)

Why circumcision is carried out in men
--------------------------------------

Circumcision may be carried out for a number of reasons.

### Medical reasons

In men, circumcision is most commonly carried out when the foreskin is tight and won't pull back (retract), which is known as [phimosis](https://www.nhs.uk/conditions/phimosis/).

But alternative treatments, such as [topical steroids](https://www.nhs.uk/conditions/topical-steroids/), are sometimes preferred.

### Non-medical reasons

Circumcision is a common practice in the Jewish and Islamic communities, and it's also practised by many African communities.

Most non-medical circumcisions are carried out on children.

Medical reasons for men to have a circumcision
----------------------------------------------

In men, circumcision is sometimes considered a possible treatment option for the following conditions.

### Tight foreskin (phimosis)

[Phimosis](https://www.nhs.uk/conditions/phimosis/) is where the foreskin is too tight to be pulled back over the head of the penis (glans).

This can sometimes cause pain when the penis is erect and, in rare cases, passing urine may be difficult.

### Recurrent balanitis

[Balanitis](https://www.nhs.uk/conditions/balanitis/) is where the foreskin and head of the penis become inflamed and infected.

### Paraphimosis

Paraphimosis is where the foreskin can't be returned to its original position after being pulled back, causing the head of the penis to become swollen and painful. It's a possible complication of a tight foreskin (phimosis).

Immediate treatment is needed to avoid serious complications, such as restricted blood flow to the penis.

### Balanitis xerotica obliterans

This condition causes phimosis and, in some cases, also affects the head of the penis, which can become scarred and inflamed.

### Cancer of the penis

[Cancer of the penis](https://www.nhs.uk/conditions/penile-cancer-1/) (penile cancer) is a very rare type of cancer, where a wart-like growth or ulcer appears on the end of the penis or under the foreskin, or there is bleeding, discharge or changes in the skin of the penis or foreskin.

Other treatments
----------------

In most cases, circumcision will only be recommended when other, less invasive and less risky treatments have been tried and haven't worked.

Mild cases of phimosis can be treated with topical steroids to help soften the skin and make it easier for the foreskin to retract.

In paraphimosis, a healthcare professional may rub a [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) gel onto the glans to help reduce pain and inflammation.

They may then apply pressure to the head of the penis while pushing the foreskin forward.

In severe cases of paraphimosis, local anaesthetic gel can be applied to the penis and a small slit is made in the foreskin to help relieve the pressure.

Balanitis and balanitis xerotica obliterans can sometimes be successfully treated using [corticosteroid ointment, gel or cream](https://www.nhs.uk/conditions/topical-steroids/), [antibiotic](https://www.nhs.uk/conditions/antibiotics/) creams or [antifungal](https://www.nhs.uk/conditions/antifungal-medicines/) creams.

The 3 main treatment options for penile cancer are:

*   surgery to remove the cancerous cells, and sometimes the surrounding tissue
*   [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/)
*   [chemotherapy](https://www.nhs.uk/conditions/chemotherapy/)

If you're considering circumcision for a medical reason, it's worth discussing alternative treatment options with your GP or specialist.

HIV prevention
--------------

There's evidence from several trials carried out in Africa that circumcised men have a lower risk of acquiring HIV.

But it's unclear whether circumcision can help prevent other [sexually transmitted infections (STIs)](https://www.nhs.uk/conditions/sexually-transmitted-infections-stis/).

There have been several studies into circumcision and the risk of other STIs, but the evidence to date has been inconclusive and conflicting.

The procedure
-------------

Circumcision is usually carried out on a day patient basis. This means you'll be admitted to hospital on the same day you have surgery and won't have to stay overnight.

You'll be asked not to eat and drink for 6 hours before surgery if you're having a [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/).

After you have been admitted to hospital, you'll be seen by the members of the medical team carrying out the procedure, including your surgeon and anaesthetist.

This is a good opportunity to discuss any concerns you have and ask questions about anything you're not sure about.

You'll be asked to sign a [consent](https://www.nhs.uk/conditions/consent-to-treatment/) form to confirm you agree to the surgery.

You'll usually either have a general anaesthetic, which means you'll be unconscious throughout the procedure, or a [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) injection, which will numb your penis and the surrounding area.

In some cases, a spinal anaesthetic, where you're unable to feel anything below your waist, will be used.

Circumcision is a relatively simple procedure. The foreskin is removed just behind the head of the penis using a scalpel or surgical scissors.

Any bleeding can be stopped using heat (cauterisation), and the remaining edges of skin will be stitched together using dissolvable stitches.

[The British Association of Urological Surgeons (BAUS) has produced a leaflet that outlines the circumcision procedure in more detail](https://www.baus.org.uk/patients/information_leaflets/88/circumcision)

Recovering after circumcision
-----------------------------

When you're discharged from hospital, you'll be given advice about your recovery at home, including when you can drive, return to work and have sex.

It usually takes at least 10 days for your penis to heal after circumcision.

You'll probably be advised to take at least 1 week off work to recover.

You don't need to tell the DVLA if you have had a routine circumcision and don't have any other medical conditions that affect your ability to drive.

But it's your responsibility to ensure you're fit to drive after having surgery.

You should avoid having sex for at least 4 weeks after your operation.

Your care team will give you a contact number to call in case you experience any problems or have any concerns.

You should also be given details about your follow-up appointment, which may be at the hospital or with your GP.

For 3 or 4 days after your operation, it's likely you'll experience some discomfort and swelling around the head of your penis.

Before leaving hospital, you'll be given painkilling medicine, such as paracetamol or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/), to help ease this.

But contact your GP if you have a temperature, increased redness, bleeding, persistent pain or throbbing of your penis, as it could be a sign of infection.

Applying petroleum jelly (Vaseline) around the tip of your penis will stop it sticking to your underwear.

Wearing light, loose-fitting clothing for 2 or 3 days after your operation will also help avoid irritation to your penis while it heals.

You may feel some discomfort while passing urine, but contact your GP if painkillers don't help or if the pain is getting worse.

If you are finding it hard to pee, you should contact your GP.

Risks of circumcision
---------------------

In the UK, complications after circumcisions carried out for medical reasons are rare and most men don't experience any significant problems.

Apart from the initial swelling, bleeding and infection are the 2 most common problems associated with circumcision.

Other possible complications of circumcision can include:

*   permanent reduction in sensation in the head of the penis, particularly during sex
*   tenderness around the scar
*   the need to remove stitches that haven't dissolved
*   occasionally, another operation is needed to remove some more skin from around the head of the penis

Page last reviewed: 21 September 2022  
Next review due: 21 September 2025
