Title: Amputation

URL Source: https://www.nhs.uk/conditions/amputation/

Published Time: 17 Oct 2017, 4:47 p.m.

Markdown Content:
**An amputation is the surgical removal of part of the body, such as an arm or leg.**

This topic may be helpful if you, a friend, or a member of your family, recently had or are planning to have an amputation.

Why amputation may be needed
----------------------------

An amputation may be needed for many reasons, including if:

*   you have a severe infection in your limb
*   your limb has been affected by [gangrene](https://www.nhs.uk/conditions/gangrene/) (often as a result of [peripheral arterial disease)](https://www.nhs.uk/conditions/peripheral-arterial-disease-pad/)
*   you have complications from [diabetes](https://www.nhs.uk/conditions/diabetes/)
*   there's serious trauma to your limb, such as a crush or blast wound
*   your limb is deformed and has limited movement and function

Assessment before surgery
-------------------------

Unless you need to have an emergency amputation, you'll be fully assessed before surgery to identify the most suitable type of amputation and any factors that may affect your rehabilitation.

The assessment is likely to include a thorough medical examination to check your physical condition, such as your cardiovascular system (heart, blood and blood vessels) and your respiratory system (lungs and airways).

The doctor will also check the condition and function of your healthy limb. Removing one limb can place extra strain on the remaining limb, so it's important to look after the healthy limb.

It may also include a psychological assessment to determine how well you'll cope with the psychological and emotional impact of amputation, and whether you'll need additional support.

There may be an assessment of your home, work and social environments to check if any changes will need to be made to help you cope.

You may also be introduced to a physiotherapist, who will be involved in your post-operative care. A prosthetist (a specialist in prosthetic limbs) will advise you about the type and function of prosthetic limbs or other devices available.

If you're having a planned amputation, you might find it reassuring to talk to someone who's had a similar type of amputation. A member of your care team may be able to arrange this.

How amputations are done
------------------------

Amputations can be done under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/) (where you're unconscious) or using either an [epidural anaesthetic](https://www.nhs.uk/conditions/epidural/) or spinal anaesthetic (both of which numb the lower half of the body). The choice of anaesthetic can depend on what part of your body is being amputated.

Most amputations involve removing a section of a limb rather than the entire limb.

Once the section of the limb has been amputated, additional techniques can be used to help improve the function of the remaining part of the limb and reduce the risk of complications.

These include shortening and smoothing the bone in the remaining section of the limb so it's covered by an adequate amount of soft tissue and muscle. The surgeon then stitches the muscle to the bones to help strengthen the remaining section (a technique known as myodesis).

After the amputation, your wound will be sealed with stitches. It will be covered with a bandage and a tube may be placed under your skin to drain any excess fluid. The bandage will usually need to be kept in place for a few days to reduce the risk of infection.

Recovering after an amputation
------------------------------

After surgery, you may be given oxygen through a mask and fluids through a drip for the first few days while you recover in a ward.

A small flexible tube ([urinary catheter](https://www.nhs.uk/conditions/urinary-catheters/)) may be placed in your bladder during surgery to drain urine. This means you will not need to get out of bed to go to the toilet for the first few days after the operation. You may be given a commode or bedpan so you can also poo without having to get up to use the toilet.

The site of the operation may be painful, so you'll be given painkillers if you need them. Tell a member of your care team if the painkillers are not working, as you may need a larger dose or a stronger painkiller.

Your physiotherapist will teach you some exercises to help prevent [blood clots](https://www.nhs.uk/conditions/blood-clots/) and improve your blood supply while you're recovering in hospital.

### Compression garments

You'll notice swelling ([oedema](https://www.nhs.uk/conditions/oedema/)) of the stump after surgery. This is normal and it may continue after you've been discharged.

Using a compression garment will help with swelling and the shape of the stump. It may also reduce phantom pain (pain that seems to be coming from your missing limb) and help support the limb.

You'll be fitted with a compression garment once your wound has healed. It should be worn every day, but taken off at bedtime. You should be given at least 2 garments, which should be washed regularly.

### Rehabilitation

Physical rehabilitation is an important part of the recovery process. It can be a long, difficult and frustrating process, but it's important to persevere. After rehabilitation, you may be able to return to work and other activities.

Your rehabilitation programme will be tailored to your individual needs and will aim to allow you to do as many of your normal activities as possible.

You'll work closely with physiotherapists and occupational therapists who will discuss with you what you'd like to achieve from rehabilitation so that some realistic goals can be set.

Your rehabilitation programme will usually start the day after your operation. It may begin with simple exercises you can do while lying down or sitting. If you've had a leg amputation, you'll be encouraged to move around as soon as possible using a wheelchair.

You'll also be taught "transfer techniques" to help you move around more easily, such as how to get into a wheelchair from your bed.

Once your wound has started to heal, you may start working on an exercise programme with a physiotherapist in the hospital to help you maintain your mobility and muscle strength.

If you have a prosthetic limb fitted, your physiotherapist will teach you how to use it. For example, how to walk on a prosthetic leg or grip with a prosthetic hand.

### Going home and follow-up

The length of time it will take before you're ready to go home will depend on the type of amputation you've had and your general state of health.

Before you're discharged from hospital, an occupational therapist may arrange to visit you at home to see if your home needs to be adapted to make it more accessible.

For example, you may need a wheelchair ramp or a stairlift. If these types of modifications are needed, the issue can be referred to your local social care and support services. Find out more about [walking aids, wheelchairs and mobility scooters](https://www.nhs.uk/conditions/social-care-and-support-guide/care-services-equipment-and-care-homes/walking-aids-wheelchairs-and-mobility-scooters/) and [assessing your care and support needs](https://www.nhs.uk/conditions/social-care-and-support-guide/help-from-social-services-and-charities/).

You may be given a wheelchair to help you get around if you've had an amputation of a lower limb.

You'll probably need to attend a follow-up appointment a few weeks after you leave hospital, to discuss how you're coping at home and whether you need additional help, support or equipment.

At your appointment, you may also be given details of your nearest amputee support group, made up of both healthcare professionals and people living with an amputation.

Prosthetic limbs
----------------

After an amputation, you may be able to have a prosthetic limb fitted.

Prosthetic limbs are not suitable for everyone who's had an amputation because an extensive course of [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) and rehabilitation is required.

Adjusting to life with a prosthetic limb takes a considerable amount of energy because you have to compensate for the loss of muscle and bone in the amputated limb.

This is why frail people or those with a serious health condition, such as [heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/), may not be suitable for a prosthetic limb.

If you're able to have a prosthetic limb, the type of limb that's recommended for you will depend on:

*   the type of amputation you had
*   the amount of muscle strength in the remaining section of the limb
*   your general health
*   tasks the prosthetic limb will be expected to perform
*   whether you want the limb to look as real as possible or you're more concerned with function

If it's thought that you would find it difficult to withstand the strain of using a prosthetic limb, a cosmetic limb may be recommended. This is a limb that looks like a real limb, but it cannot be used like a prosthetic limb.

It's possible to have a prosthetic limb that's both physically realistic and functional, but there may have to be an element of compromise between the different types.

### Preparing to have a prosthetic limb fitted

If a prosthetic limb is suitable for you, you'll begin a programme of activities while still in hospital to prepare for the prosthesis.

Before a prosthetic limb is fitted, the skin covering your stump may be made less sensitive (known as desensitisation). This will make the prosthesis more comfortable to wear.

Skin desensitisation involves:

*   gently tapping the skin with a face cloth
*   using compression bandages to help reduce swelling and prevent a build-up of fluid inside and around the stump
*   rubbing and pulling the skin around your bone to prevent excessive scarring

Your physiotherapist will teach you exercises to strengthen the muscles in your remaining limb and improve your general energy levels, so you're able to cope better with the demands of an artificial limb.

Depending on what's available in your local area, it can be several weeks before you get your first appointment with a prosthetist.

Stump care
----------

It's very important to keep the skin on the surface of your stump clean to reduce the risk of it becoming irritated or infected.

Gently wash your stump at least once a day (more frequently in hot weather) with mild unscented soap and warm water, and dry it carefully.

If you have a prosthetic limb, you should also regularly clean the socket using soap and warm water.

When taking a bath, avoid leaving your stump submerged in water for long periods because the water will soften the skin on your stump, making it more vulnerable to injury.

If your skin becomes dry, use an unscented moisturising cream before bedtime or when you're not wearing your prosthesis.

Some people find wearing one or more socks around their stump helps absorb sweat and reduces skin irritation. The size of your stump may change as the swelling goes down, so the number of socks you need to use may vary. You should change the socks every day.

Check your stump carefully every day for signs of infection, such as:

*   warm, red and tender skin
*   discharge of fluid or pus
*   increasing swelling

Contact your care team for advice if you think you may be developing a skin infection.

### Caring for your remaining limb

After having a leg or foot amputated, it's very important to avoid injuring your remaining "good" leg and foot, particularly if your amputation was needed because of [diabetes](https://www.nhs.uk/conditions/diabetes/). Your remaining leg and foot may also be at risk.

Avoid wearing poorly fitting footwear and ensure that an appropriately trained healthcare professional, such as a podiatrist, is involved in the care of your remaining foot. You should also be offered a regular review of your foot by a foot care team.

Complications
-------------

Like any type of operation, an amputation carries a risk of complications. It also carries a risk of additional problems directly related to the loss of a limb.

There are a number of factors that influence the risk of complications from amputation, such as your age, the type of amputation you've had and your general health.

The risk of serious complications is lower in planned amputations than in emergency amputations.

Complications associated with having an amputation include:

*   heart problems such as [heart attack](https://www.nhs.uk/conditions/heart-attack/)
*   [DVT (deep vein thrombosis)](https://www.nhs.uk/conditions/deep-vein-thrombosis-dvt/)
*   slow wound healing and wound infection
*   [pneumonia](https://www.nhs.uk/conditions/pneumonia/)
*   stump and "phantom limb" pain

In some cases, further surgery may be needed to correct problems that develop or to help relieve pain. For example, if neuromas (thickened nerve tissue) are thought to be causing pain, the affected cluster of nerves may need to be removed.

### Stump and "phantom limb" pain

Many people who have an amputation experience some degree of stump pain or "phantom limb" pain.

Stump pain can have many different causes, including rubbing or sores where the stump touches a prosthetic limb, nerve damage during surgery and the development of neuromas.

Phantom limb sensations are sensations that seem to be coming from the amputated limb. Occasionally, these can be painful (phantom limb pain).

The term "phantom" does not mean the sensations are imaginary. Phantom limb pain is a real phenomenon, which has been confirmed using brain imaging scans to study how nerve signals are transmitted to the brain.

The symptoms of phantom limb pain can range from mild to severe. Some people have described brief "flashes" of mild pain, similar to an electric shock, that last for a few seconds. Others have described constant severe pain.

### Treating stump and phantom limb pain

Stump and phantom limb pain will usually improve over time, but treatments are available to help relieve the symptoms.

#### Medicines

Medicines that may be used to help relieve pain include:

*   [non-steroidal anti-inflammatory drugs (NSAIDs)](https://www.nhs.uk/conditions/nsaids/), such as [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
*   anticonvulsants such as [pregabalin](https://www.nhs.uk/medicines/pregabalin/) or [gabapentin](https://www.nhs.uk/medicines/gabapentin/)
*   antidepressants such as [amitriptyline](https://www.nhs.uk/medicines/amitriptyline-for-depression/), or nortriptyline, which are useful in treating nerve pain
*   opioids such as [codeine](https://www.nhs.uk/medicines/codeine/) or [morphine](https://www.nhs.uk/medicines/morphine/)
*   [corticosteroid](https://www.nhs.uk/conditions/steroids/) or [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) injections

#### Self-help measures and complementary therapy

There are several non-invasive techniques that may help relieve pain in some people. They include:

*   adjusting the way your prosthesis fits to make it more comfortable
*   massage to increase circulation and stimulate muscles
*   [acupuncture](https://www.nhs.uk/conditions/acupuncture/) is thought to stimulate the nervous system and relieve pain
*   [transcutaneous electrical nerve stimulation (TENS)](https://www.nhs.uk/conditions/transcutaneous-electrical-nerve-stimulation-tens/), which uses a small, battery-operated device to deliver electrical impulses to the affected area of your body, to block or reduce pain signals

#### Mental imagery

Research has shown that people who imagine using the part of their limb that was amputated experience a reduction in pain symptoms.

This may be related to the central theory of phantom limb pain. Researchers think the brain looks to receive feedback from an amputated limb, and these mental exercises may provide an effective substitute for this missing feedback.

Another technique, known as mirror visual feedback, involves using a mirror to create a reflection of the other limb. Some people find that exercising and moving their other limb can help relieve phantom pain.

Psychological impact of amputation
----------------------------------

The loss of a limb can have a considerable psychological impact. Many people who've had an amputation report emotions such as grief and bereavement, similar to experiencing the death of a loved one.

Coming to terms with the psychological impact of an amputation is therefore often as important as coping with the physical demands.

Having an amputation can have a considerable psychological impact for 3 main reasons:

*   you have to cope with the loss of sensation from your amputated limb
*   you have to cope with the loss of function from your amputated limb
*   your sense of body image, and other people's perception of your body image, has changed

Negative thoughts and emotions are common after an amputation. This is particularly true in people who've had an emergency amputation because they do not have time to mentally prepare for the effects of surgery.

Common emotions and thoughts experienced by people after an amputation include:

*   [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/overview/)
*   [anxiety](https://www.nhs.uk/mental-health/conditions/generalised-anxiety-disorder/overview/)
*   denial (refusing to accept they need to make changes, such as having [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/), to adapt to life after an amputation)
*   grief

People who've had an amputation as a result of trauma (particularly members of the armed forces) also have an increased risk of developing [post-traumatic stress disorder (PTSD)](https://www.nhs.uk/mental-health/conditions/post-traumatic-stress-disorder-ptsd/).

Talk to your care team about your thoughts and feelings, particularly if you're feeling depressed or suicidal. You may need additional treatment, such as [antidepressants](https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/medicines-and-psychiatry/antidepressants/overview/) or [counselling](https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/talking-therapies-and-counselling/counselling/), to improve your ability to cope after having an amputation.

Help and support
----------------

Being told you need to have a limb amputated can be a devastating and frightening experience. Adjusting to life after an amputation can be challenging, but many people enjoy a good quality of life once they have managed to adapt and with appropriate treatment and support.

There are a number of charities that can provide advice and support for people living with amputations, which include:

*   [The Limbless Association](http://www.limbless-association.org/)
*   [Douglas Bader Foundation](https://www.douglasbaderfoundation.com/)
*   [Steel Bones](https://steelbone.co.uk/)
*   [Amputation Foundation](http://amputationfoundation.org/)
*   [Blesma, The Limbless Veterans](https://blesma.org/)

Page last reviewed: 17 February 2023  
Next review due: 17 February 2026
