Title: Herpetic whitlow (whitlow finger)

URL Source: https://www.nhs.uk/conditions/herpetic-whitlow/

Published Time: 18 Oct 2017, 2:33 p.m.

Markdown Content:
**Herpetic whitlow (whitlow finger) is a painful infection of the finger caused by the herpes virus. It's easily treated but can come back.**

Check if you have herpetic whitlow
----------------------------------

Herpetic whitlow can appear anywhere on your finger or thumb, but it usually affects the top of your finger (fingertip).

Symptoms of herpetic whitlow include:

*   swelling and pain in your finger
*   blisters or sores on your finger
*   skin becoming red or darker than your usual skin tone
*   feeling generally unwell and having a high temperature

![Image 1: A red and swollen fingertip with a small sore at the side of the nail. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/A_0917_herpetic-whitlow_A44K46.width-320.jpg)

![Image 2: A finger with red lumps under the skin filled with fluid. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_0917_Herpetic-whitlow_M1700211.width-320.jpg)

![Image 3: A swollen finger with red lumps under the skin and small blisters. Shown on brown skin.](https://assets.nhs.uk/nhsuk-cms/images/herpetic-whitlow-0005_copy.width-320.png)

Non-urgent advice: See a GP if:
-------------------------------

*   you think you have herpetic whitlow
*   you have herpetic whitlow and the infection gets worse or you have a very high temperature (or you feel hot and shivery)

Treatment is more effective if started early and will help stop the infection spreading.

Treatment from a GP
-------------------

You may be prescribed antiviral tablets if you see a GP within 48 hours of your symptoms showing.

Antiviral tablets can help your finger to heal more quickly.

If you cannot see a GP within 48 hours, the infection will usually go away without treatment within 2 to 3 weeks.

Things you can do if you have herpetic whitlow
----------------------------------------------

You can ease the symptoms of herpetic whitlow yourself by taking painkillers and avoiding touching the infected finger.

### Do

*   keep the affected finger clean and covered with a dressing
    
*   take painkillers, such as [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/), to ease the pain
    
*   try to discourage children with a whitlow from sucking their thumb
    

### Don’t

*   do not touch the infected finger
    
*   do not touch other people with your infected finger to avoid spreading the infection
    
*   do not try to drain the fluid by squeezing the affected area
    
*   do not touch other areas of your body with the infected finger, particularly your eyes – if you wear contact lenses, use the hand that's not affected to put them in and take them out, or wear glasses until the infection has healed
    

Causes of herpetic whitlow
--------------------------

Herpetic whitlow is caused by a virus called herpes simplex. You can get it if you touch a cold sore or blister of another infected person.

You're more likely to get herpetic whitlow if you've had cold sores or genital herpes.

You may also get it if you have a weakened immune system – for example, if you have diabetes or you're having chemotherapy.

The first time you have herpetic whitlow will usually be the most severe.

Herpetic whitlow can come back
------------------------------

Once you have the herpes virus, it stays in your body for the rest of your life, so if you get herpetic whitlow once you can get it again.

For example, it might come back if you have a cut or sore on your finger, or if you're feeling stressed or unwell.

There's not much you can do to prevent herpetic whitlow but it can be treated in the same way if it comes back.

Page last reviewed: 03 August 2023  
Next review due: 03 August 2026

Some images provided by [DermNet](https://dermnetnz.org/).
