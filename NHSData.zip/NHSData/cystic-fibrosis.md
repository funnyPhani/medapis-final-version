Title: Cystic fibrosis

URL Source: https://www.nhs.uk/conditions/cystic-fibrosis/

Published Time: 23 Oct 2017, 11:33 a.m.

Markdown Content:
**Cystic fibrosis is an inherited condition that causes sticky mucus to build up in the lungs and digestive system. This causes lung infections and problems with digesting food.**

In the UK, most cases of cystic fibrosis are picked up at birth using the [newborn screening heel prick test.](https://www.nhs.uk/conditions/baby/newborn-screening/blood-spot-test/)

Symptoms usually start in early childhood and vary from child to child, but the condition gets slowly worse over time, with the lungs and digestive system becoming increasingly damaged.

Treatments are available to help reduce the problems caused by the condition and make it easier to live with, but sadly life expectancy is shortened.

Symptoms of cystic fibrosis
---------------------------

The build-up of sticky mucus in the lungs can cause breathing problems and increases the risk of lung infections. Over time, the lungs may stop working properly.

Mucus also clogs the pancreas (the organ that helps with digestion), which stops enzymes reaching food in the gut and helping with digestion.

This means most people with cystic fibrosis don't absorb nutrients from food properly and need to eat more calories to avoid [malnutrition](https://www.nhs.uk/conditions/malnutrition/).

Symptoms of cystic fibrosis include:

*   recurring [chest infections](https://www.nhs.uk/conditions/chest-infection/)
*   wheezing, [coughing](https://www.nhs.uk/conditions/cough/), [shortness of breath](https://www.nhs.uk/conditions/shortness-of-breath/) and damage to the airways [(bronchiectasis)](https://www.nhs.uk/conditions/bronchiectasis/)
*   difficulty putting on weight and growing
*   yellowing of the skin and the whites of the eyes ([jaundice](https://www.nhs.uk/conditions/jaundice/))
*   [diarrhoea](https://www.nhs.uk/conditions/diarrhoea/), [constipation](https://www.nhs.uk/conditions/constipation/), or large, smelly poo
*   a bowel obstruction in newborn babies (meconium ileus) – surgery may be needed

People with the condition can also develop a number of related conditions, including [diabetes](https://www.nhs.uk/conditions/diabetes/), thin, weakened bones [(osteoporosis)](https://www.nhs.uk/conditions/osteoporosis/), [infertility](https://www.nhs.uk/conditions/infertility/) in males, and liver problems.

Diagnosing cystic fibrosis
--------------------------

In the UK, all newborn babies are screened for cystic fibrosis as part of the [newborn blood spot test](https://www.nhs.uk/conditions/pregnancy-and-baby/newborn-blood-spot-test/) (heel prick test) carried out shortly after they're born.

If the screening test suggests a child may have cystic fibrosis, they'll need these additional tests to confirm they have the condition:

*   a sweat test – to measure the amount of salt in sweat, which will be abnormally high in someone with cystic fibrosis
*   a genetic test – where a sample of blood or saliva is checked for the faulty gene that causes cystic fibrosis

These tests can also be used to diagnose cystic fibrosis in older children and adults who didn't have the newborn test.

The genetic test can also be used to see whether someone is a "carrier" of cystic fibrosis in cases where the condition runs in the family.

This test can be important for someone who thinks they may have the faulty gene and wishes to have children.

[The Cystic Fibrosis Trust has more information about genetic testing for cystic fibrosis.](https://www.cysticfibrosis.org.uk/what-is-cystic-fibrosis/diagnosis/family-genetic-testing)

Treatments for cystic fibrosis
------------------------------

There's no cure for cystic fibrosis, but a range of treatments can help control the symptoms, prevent or reduce complications, and make the condition easier to live with.

People with cystic fibrosis may need to take different medicines to treat and prevent lung problems.

Physical activity and the use of airway clearance techniques may also be recommended to help clear mucus from the lungs.

Find out more about [treatments for cystic fibrosis](https://www.nhs.uk/conditions/cystic-fibrosis/treatment/).

Complications of cystic fibrosis
--------------------------------

People with cystic fibrosis also have a higher risk of developing other conditions.

These include:

*   weak and brittle bones [(osteoporosis)](https://www.nhs.uk/conditions/osteoporosis/) – medicines called bisphosphonates can sometimes help
*   [diabetes](https://www.nhs.uk/conditions/diabetes/) – insulin and a special diet may be needed to control blood sugar levels
*   [nasal polyps](https://www.nhs.uk/conditions/nasal-polyps/) and [sinus infections](https://www.nhs.uk/conditions/sinusitis-sinus-infection/) – steroids, antihistamines, antibiotics or sinus flushes can help
*   liver problems
*   fertility problems – it's possible for women with cystic fibrosis to have children, but men won't be able to father a child without help from fertility specialists (see a doctor or fertility specialist for more advice)

People with cystic fibrosis should not meet face to face. This is because they're more likely to spread infections, and more vulnerable to complications if they do develop an infection.

[The Cystic Fibrosis Trust has more information about complications of cystic fibrosis](https://www.cysticfibrosis.org.uk/what-is-cystic-fibrosis/how-does-cystic-fibrosis-affect-the-body/symptoms-of-cystic-fibrosis/additional-complications) and [preventing cross-infection](https://www.cysticfibrosis.org.uk/life-with-cystic-fibrosis/cross-infection).

Cause of cystic fibrosis
------------------------

Cystic fibrosis is a genetic condition. It's caused by a faulty gene that affects the movement of salt and water in and out of cells.

This, along with recurrent infections, can result in a build-up of thick, sticky mucus in the body's tubes and passageways – particularly the lungs and digestive system.

A person with cystic fibrosis is born with the condition. It's not possible to "catch" cystic fibrosis from someone else who has it.

### How cystic fibrosis is inherited

To be born with cystic fibrosis, a child has to inherit a copy of the faulty gene from both of their parents.

This can happen if the parents are "carriers" of the faulty gene, which means they don't have cystic fibrosis themselves.

It's estimated around 1 in every 25 people in the UK are carriers of cystic fibrosis.

If both parents are carriers, there's a:

*   1 in 4 chance their child won't inherit any faulty genes and won't have cystic fibrosis or be able to pass it on
*   1 in 2 chance their child will inherit a faulty gene from one parent and be a carrier
*   1 in 4 chance their child will inherit the faulty gene from both parents and have cystic fibrosis

If one parent has cystic fibrosis and the other is a carrier, there's a:

*   1 in 2 chance their child will be a carrier
*   1 in 2 chance their child will have cystic fibrosis

Outlook
-------

Cystic fibrosis tends to get worse over time and can be fatal if it leads to a serious infection or the lungs stop working properly.

But people with cystic fibrosis are now living for longer because of advancements in treatment.

Currently, about half of people with cystic fibrosis will live past the age of 40. Children born with the condition nowadays are likely to live longer than this.

Support
-------

Support is available to help people with cystic fibrosis live as independently as they can and have the best possible quality of life.

It can be helpful to speak to others who have the same condition, and to connect with a charity.

The following links may be useful:

*   [Asthma + Lung UK](https://www.asthmaandlung.org.uk/conditions/cystic-fibrosis/) – the UK's lung health charity
*   [Cystic Fibrosis Trust](http://www.cftrust.org.uk/) – which has an online forum and news about ongoing research into cystic fibrosis
*   [CF Kids](https://www.cfkids.org.uk/) – a support group for parents of children with cystic fibrosis
*   [Cystic Fibrosis Care](https://cysticfibrosiscare.org.uk/) – a charity that provides practical help and support

### Information about you

If you or your child has cystic fibrosis, your clinical team will ask you if you consent to being on the UK Cystic Fibrosis Registry.

This is a secure anonymous registry sponsored by the Cystic Fibrosis Trust that records health information on people with cystic fibrosis.

The registry helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the UK Cystic Fibrosis Registry](https://www.cysticfibrosis.org.uk/the-work-we-do/uk-cf-registry)

Page last reviewed: 16 March 2021  
Next review due: 16 March 2024
