Title: Charcot-Marie-Tooth disease

URL Source: https://www.nhs.uk/conditions/charcot-marie-tooth-disease/

Published Time: 7 Sep 2018, 12:41 p.m.

Markdown Content:
**Charcot-Marie-Tooth disease (CMT) is a group of inherited conditions that damage the peripheral nerves.**

It's also known as hereditary motor and sensory neuropathy (HMSN) or peroneal muscular atrophy (PMA).

The peripheral nerves are found outside the main central nervous system (brain and spinal cord).

They control the muscles and relay sensory information, such as the sense of touch, from the limbs to the brain.

People with CMT may have:

*   muscle weakness in their feet, ankles, legs and hands
*   an awkward way of walking (gait)
*   highly arched or very [flat feet](https://www.nhs.uk/conditions/flat-feet/)
*   numbness in the feet, arms and hands

The symptoms of CMT usually start to appear between the ages of 5 and 15, although they sometimes do not develop until well into middle age or later.

CMT is a progressive condition. This means the symptoms slowly get worse, making everyday tasks increasingly difficult.

[Find out more about the symptoms of CMT](https://www.nhs.uk/conditions/charcot-marie-tooth-disease/symptoms/)

What causes CMT?
----------------

CMT is caused by an inherited fault in one of the many genes responsible for the development of the peripheral nerves. This fault means the nerves become damaged over time.

A child with CMT may have inherited the genetic fault responsible for the condition from 1 or both of their parents.

There's no single faulty gene that causes CMT. There are many types of CMT that are caused by different genetic faults and these can be inherited in several different ways.

The chances of passing CMT to your child depend on the specific genetic faults you and your partner carry.

[Find out more about the causes of CMT](https://www.nhs.uk/conditions/charcot-marie-tooth-disease/causes/)

Testing for CMT
---------------

See your GP if you think you may have symptoms of CMT.

If they suspect CMT, they'll refer you to a doctor who specialises in treating conditions of the nervous system (a neurologist) for further tests to confirm the diagnosis.

You should also see your GP if you or your partner have a family history of CMT and are considering having a baby.

Your GP can refer you for [genetic counselling](https://www.nhs.uk/conditions/genetics/services/), where you can discuss your concerns and the options available with a genetics specialist.

[Find out more about diagnosing CMT](https://www.nhs.uk/conditions/charcot-marie-tooth-disease/diagnosis/)

How CMT is treated
------------------

There's currently no cure for CMT. But treatments can help relieve symptoms, aid mobility, and increase independence and quality of life for people with the condition.

These treatments may include:

*   [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) and certain types of exercise
*   [occupational therapy](https://www.nhs.uk/conditions/occupational-therapy/)
*   walking aids

In some cases, surgery may be needed to correct problems such as [flat feet](https://www.nhs.uk/conditions/flat-feet/) and muscle contractures, where muscles shorten and lose their normal range of movement.

[Find out more about treating CMT](https://www.nhs.uk/conditions/charcot-marie-tooth-disease/treatment/)

Living with CMT
---------------

CMT is not life threatening and most people with the condition have the same life expectancy as a person without the condition.

But it can make everyday activities very difficult. Living with a long-term progressive condition can also have a significant emotional impact.

Some people find it helpful to speak to others with the condition through support groups.

You may also benefit from a talking therapy, such as [cognitive behavioural therapy (CBT)](https://www.nhs.uk/conditions/cognitive-behavioural-therapy-cbt/).

More information, support and practical advice about living with CMT can be found on the [Charcot-Marie-Tooth UK](http://cmt.org.uk/) website.

CMT UK is the main charity and support group for people with CMT in the UK.

National Congenital Anomaly and Rare Disease Registration Service
-----------------------------------------------------------------

If you have CMT, your clinical team will pass information about you on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://www.ndrs.nhs.uk/).

The NCARDRS helps scientists look for better ways to prevent and treat CMT. You can opt out of the register at any time.

Page last reviewed: 05 October 2022  
Next review due: 05 October 2025
