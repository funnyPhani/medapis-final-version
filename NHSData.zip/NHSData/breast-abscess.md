Title: Breast abscess

URL Source: https://www.nhs.uk/conditions/breast-abscess/

Published Time: 21 Nov 2017, 8:39 a.m.

Markdown Content:
**A breast abscess is a painful build-up of pus in the breast caused by an infection. It mainly affects women who are breastfeeding.** **It's not usually serious, but it needs treatment in hospital.**

Check if you have a breast abscess
----------------------------------

Symptoms of a breast abscess may include:

*   a lump or swelling in your breast
*   pain in your breast, it may also feel warm or look red (this may be harder to see on brown or black skin)
*   a high temperature
*   feeling generally unwell

You’re more likely to have a breast abscess if you have recently had a breast infection (mastitis) or if you’ve had a breast abscess before.

If you're not sure it's a breast abscess

Other conditions can make your breast sore and swollen:

*   [breast pain](https://www.nhs.uk/conditions/breast-pain/)
*   [breast pain when breastfeeding](https://www.nhs.uk/conditions/baby/breastfeeding-and-bottle-feeding/breastfeeding-problems/breast-pain/)
*   [breast lumps](https://www.nhs.uk/conditions/breast-lump/)

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if you have:
-------------------------------------------------------------------------------------

*   a painful, warm or red breast
*   a lump or swelling in your breast

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

What happens at your GP appointment for a breast abscess
--------------------------------------------------------

If the GP thinks you have a breast abscess, they will refer you to hospital for an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) of your breast to check for an abscess.

The GP may give you antibiotics first if they think you have a breast infection.

### Important

Go back to the GP if your symptoms do not start to improve within 2 days of starting antibiotics.

Treatment for a breast abscess
------------------------------

You’ll need to go to hospital to have treatment for a breast abscess.

Treatment involves the pus being drained from the abscess with either:

*   a needle – this might need to be done a few times and you may have to go back to hospital each time
*   a small cut in your skin

You'll be given a local anaesthetic before the pus is drained so you do not feel any pain. You can usually go home the same day and may be given antibiotics to take at home.

The abscess should heal completely in a few days or weeks.

Breastfeeding during treatment

Continue feeding with both breasts if you can. This will not harm your baby and can help your breast heal.

Try expressing milk from your breasts with your hand or a breast pump if breastfeeding is too painful.

Causes of a breast abscess
--------------------------

A breast abscess can form if you have a breast infection (called [mastitis](https://www.nhs.uk/conditions/mastitis/)) and it's not treated quickly.

You're more likely to get mastitis if you are breastfeeding. You can get it if you're not breastfeeding, but this is less common.

Getting treatment for mastitis as soon as possible can help reduce the risk of getting an abscess.

Page last reviewed: 14 June 2023  
Next review due: 14 June 2026
