Title: Cradle cap

URL Source: https://www.nhs.uk/conditions/cradle-cap/

Published Time: 24 Oct 2017, 9:31 a.m.

Markdown Content:
Check if your baby has cradle cap
---------------------------------

The main symptom of cradle cap is patches of greasy, scaly skin.

It's usually found on the scalp and face, but sometimes affects the nappy area. It can look like:

*   patches of white or yellow greasy scales on the scalp and face that form a crust which might flake off
*   small, dry flakes of skin on the nappy area

The scales look similar on all skin tones. But the skin under the scales may look pink or red if your baby has white skin, or lighter or darker than the surrounding skin if your baby has brown or black skin.

It is not itchy or painful and does not bother your baby.

The cause of cradle cap is not clear, but it cannot be caught from other babies.

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: Cradle cap on the scalp of a baby with white skin (thumbnail).](https://www.nhs.uk/conditions/cradle-cap/#gallery-image-1)
*   [2: Cradle cap on the scalp of a baby with medium brown skin (thumbnail).](https://www.nhs.uk/conditions/cradle-cap/#gallery-image-2)
*   [3: Cradle cap on the scalp of a baby with white skin (thumbnail).](https://www.nhs.uk/conditions/cradle-cap/#gallery-image-3)
*   [4: Cradle cap on the eyebrows of a baby with white skin (thumbnail).](https://www.nhs.uk/conditions/cradle-cap/#gallery-image-4)

![Image 1: Pale yellow cradle cap crusts on the scalp of a baby with white skin. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/S_0219_Cradle_cap_C0194113.2e16d0ba.fill-420x280.jpg)

Long description, image 1.

Cradle cap on the scalp of a baby with white skin and dark brown hair.

A pale yellow crust covers the top of the head. The crust ends at the hairline, just above the forehead. The crust has many scales of skin, many of which join together. There are no scales on the forehead.

Things you can do to help with cradle cap
-----------------------------------------

### Do

*   lightly massage an [emollient](https://www.nhs.uk/conditions/emollients/) (moisturiser) on to your baby's scalp to help loosen the scales
    
*   gently brush your baby's scalp with a soft brush and then wash it with baby shampoo
    

### Don’t

*   do not use olive oil, it may not be suitable for use on skin
    
*   do not use peanut oil (because of the allergy risk)
    
*   do not use soap or adult shampoos
    
*   do not pick crusts because this can increase the chance of infection
    

Information:

Your baby's hair may come away with the scales. Do not worry if this happens as it will soon grow back.

### A pharmacist can help with cradle cap

You can ask a pharmacist about:

*   an emollient you can use on your baby's scalp
*   unperfumed baby shampoos
*   barrier creams to use on your baby's nappy area, if it's also affected

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   your baby's cradle cap does not get better after a few weeks of treatment
*   your baby has cradle cap all over their body
*   the crusts bleed or leak fluid
*   the affected areas look swollen

Bleeding, leaking fluid and swelling could be signs of an infection or another condition like [atopic eczema](https://www.nhs.uk/conditions/atopic-eczema/) or [scabies](https://www.nhs.uk/conditions/scabies/).

Page last reviewed: 21 April 2022  
Next review due: 21 April 2025
