Title: Dizziness

URL Source: https://www.nhs.uk/conditions/dizziness/

Published Time: 18 Oct 2017, 11:14 a.m.

Markdown Content:
**It's common to sometimes feel dizzy, lightheaded or off-balance, and it's not usually serious. See a GP if you're worried.**

Check if you have dizziness
---------------------------

Dizziness includes feeling:

*   off-balance
*   giddy
*   lightheaded or faint
*   like you're spinning or things around you are spinning ([vertigo](https://www.nhs.uk/conditions/vertigo/))

How you can treat dizziness yourself
------------------------------------

Dizziness usually goes away on its own. But there are things you can do to take care of yourself while you're feeling dizzy.

### Do

*   lie down until the dizziness passes, then get up slowly
    
*   move slowly and carefully
    
*   get plenty of rest
    
*   drink plenty of fluids, especially water
    
*   avoid coffee, cigarettes, alcohol and drugs
    

### Don’t

*   do not bend down suddenly
    
*   do not get up suddenly after sitting or lying down
    
*   do not do anything that could be dangerous while you're dizzy, like driving, climbing a ladder or using heavy machinery
    

Non-urgent advice: See a GP if:
-------------------------------

*   you're worried about your dizziness or vertigo
*   it will not go away or it keeps coming back
*   you're finding it harder to hear or speak
*   there's ringing or other sounds in your ears (tinnitus)
*   you have double vision, blurred vision or other changes in your eyesight
*   your face, arms or legs feel numb or weak
*   you have other symptoms like changes to your pulse, fainting or collapsing, headaches, feeling or being sick

Causes of dizziness
-------------------

If you have other symptoms, this might give you an idea of the cause. Do not self-diagnose. See a GP if you're worried.

Dizziness while you're ill with something else Dizziness for no obvious reason

Dizziness for no obvious reason
| Dizziness symptoms | Possible causes |
| --- | --- |
| When standing or sitting up suddenly
 | Sudden drop in blood pressure (postural hypotension)

 |
| Feeling off-balance, losing some hearing, ringing or other sounds in your ears ([tinnitus](https://www.nhs.uk/conditions/tinnitus/))

 | Inner-ear problems

 |
| Feeling off-balance or like things are spinning, feeling or being sick, sometimes after a cold or flu

 | [Labyrinthitis](https://www.nhs.uk/conditions/labyrinthitis/)

 |
| After starting new prescription medicine

 | Side effect of medicine

 |

Page last reviewed: 21 April 2023  
Next review due: 21 April 2026
