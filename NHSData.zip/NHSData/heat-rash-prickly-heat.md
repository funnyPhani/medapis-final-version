Title: Heat rash (prickly heat)

URL Source: https://www.nhs.uk/conditions/heat-rash-prickly-heat/

Published Time: 24 Oct 2017, 9:02 a.m.

Markdown Content:
Heat rash is uncomfortable, but usually harmless. It usually gets better on its own after a few days.

Check if you have heat rash
---------------------------

The symptoms of heat rash are:

*   small, raised spots
*   an itchy, prickly feeling
*   mild swelling

The rash looks red on white skin. It may be harder to see or look grey or white on brown or black skin.

The symptoms of heat rash are often the same in adults and children.

It can appear anywhere on the body and spread, but it cannot be passed on to other people.

![Image 1: A red, patchy rash with some small, raised bumps, on the side of a child's chest. Shown on white skin](https://assets.nhs.uk/nhsuk-cms/images/C0465331-Sudamina_blisters_cropped.width-320.png)

Heat rash appears as raised spots that are 2mm to 4mm across. Some spots may be filled with fluid.

![Image 2: A rash with many small, raised bumps, on a child's tummy. Shown on black skin.](https://assets.nhs.uk/nhsuk-cms/images/VID_1795_-_New_image_for_Heat_rash_prickly_hea.width-320.png)

Heat rash may be harder to see on brown or black skin. The spots may look grey or white.

### If you're not sure if your child has heat rash

Look at other [rashes in babies and children](https://www.nhs.uk/conditions/rashes-babies-and-children/).

How you can treat heat rash yourself
------------------------------------

If you have heat rash the main thing to do is keep your skin cool so you do not sweat and irritate the rash.

### To keep your skin cool

*   Wear loose cotton clothing.
*   Use lightweight bedding.
*   Take cool baths or showers.
*   Drink plenty of fluid to avoid dehydration.

### To calm the itching or prickly feeling

*   Apply something cold, such as a damp cloth or ice pack (wrapped in a tea towel), for up to 20 minutes.
*   Tap or pat the rash instead of scratching it.
*   Do not use perfumed shower gels or creams.

### A pharmacist can help with heat rash

Speak to a pharmacist about heat rash. They can give advice and suggest the best treatment to use.

A pharmacist might recommend:

*   calamine lotion
*   [antihistamine](https://www.nhs.uk/conditions/antihistamines/) tablets
*   [hydrocortisone cream](https://www.nhs.uk/medicines/hydrocortisone-for-skin/) – though not for children under 10 as you'll need to get advice from a doctor before giving them this treatment

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Non-urgent advice: See a GP if:
-------------------------------

*   you have heat rash that does not improve after a few days
*   your baby has a rash and you're worried

Causes of heat rash
-------------------

Heat rash is usually caused by sweating a lot.

Sweat glands get blocked and the trapped sweat leads to a rash developing a few days later.

Babies often get heat rash because they cannot control their temperature as well as adults and children can.

Page last reviewed: 09 May 2024  
Next review due: 09 May 2027
