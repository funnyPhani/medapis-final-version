Title: Creutzfeldt-Jakob disease

URL Source: https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/

Published Time: 23 Oct 2017, 11:20 a.m.

Markdown Content:
**Creutzfeldt-Jakob disease (CJD) is a rare and fatal condition that affects the brain. It causes brain damage that worsens rapidly over time.**

Symptoms of CJD
---------------

Symptoms of CJD include:

*   loss of intellect and memory
*   changes in personality
*   loss of balance and co-ordination
*   slurred speech
*   vision problems and [blindness](https://www.nhs.uk/conditions/vision-loss/)
*   abnormal jerking movements
*   progressive loss of brain function and mobility

Most people with CJD will die within a year of the symptoms starting, usually from infection.

This is because the immobility caused by CJD can make people with the condition vulnerable to infection.

Read more about the [symptoms of Creutzfeldt-Jakob disease](https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/symptoms/) and [diagnosing Creutzfeldt-Jakob disease](https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/diagnosis/).

What causes CJD?
----------------

CJD appears to be caused by an abnormal infectious protein called a prion. These prions accumulate at high levels in the brain and cause irreversible damage to nerve cells.

While the abnormal prions are technically infectious, they're very different from viruses and bacteria.

For example, prions aren't destroyed by the extremes of heat and radiation used to kill bacteria and viruses, and [antibiotics](https://www.nhs.uk/conditions/antibiotics/) or antiviral medicines have no effect on them.

Read more about the [causes of Creutzfeldt-Jakob disease](https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/causes/).

Types of CJD
------------

There are 4 main types of CJD.

### Sporadic CJD

Sporadic CJD is the most common type.

The precise cause of sporadic CJD is unclear, but it's been suggested that a normal brain protein changes abnormally ("misfolds") and turns into a prion.

Most cases of sporadic CJD occur in adults aged between 45 and 75. On average, symptoms develop between the ages of 60 and 65.

Despite being the most common type of CJD, sporadic CJD is still very rare, affecting only 1 or 2 people in every million each year in the UK.

In 2020, there were 131 recorded deaths from sporadic CJD in the UK.

### Variant CJD

Variant CJD (vCJD) is likely to be caused by consuming meat from a cow that had bovine spongiform encephalopathy (BSE, or "mad cow" disease), a similar prion disease to CJD.

Since the link between variant CJD and BSE was discovered in 1996, strict controls have proved very effective in preventing meat from infected cattle entering the food chain.

See [preventing Creutzfeldt-Jakob disease](https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/prevention/) for more information.

But the average time it takes for the symptoms of variant CJD to occur after initial infection (the incubation period) is still unclear.

The incubation period could be very long (more than 10 years) in some people, so those exposed to infected meat before the food controls were introduced can still develop variant CJD.

The prion that causes variant CJD can also be transmitted by [blood transfusion](https://www.nhs.uk/conditions/blood-transfusion/), although this has only happened 5 times in the UK.

In 2020, there were no recorded deaths from variant CJD in the UK.

### Familial or inherited CJD

Familial CJD is a very rare genetic condition where one of the genes a person inherits from their parent (the prion protein gene) carries a mutation that causes prions to form in their brain during adulthood, triggering the symptoms of CJD.

It affects about 1 in every 9 million people in the UK.

The symptoms of familial CJD usually first develop in people when they're in their early 50s.

In 2020, there were 6 deaths from familial CJD and similar inherited prion diseases in the UK.

### Iatrogenic CJD

Iatrogenic CJD is where the infection is accidentally spread from someone with CJD through medical or surgical treatment.

For example, a common cause of iatrogenic CJD in the past was growth hormone treatment using human pituitary growth hormones extracted from deceased individuals, some of whom were infected with CJD.

Synthetic versions of human growth hormone have been used since 1985, so this is no longer a risk.

Iatrogenic CJD can also occur if instruments used during brain surgery on a person with CJD aren't properly cleaned between each surgical procedure and are reused on another person.

But increased awareness of these risks means iatrogenic CJD is now very rare.

In 2020, there was 1 death from iatrogenic CJD in the UK caused by receiving human growth hormone before 1985.

How CJD is treated
------------------

There's currently no cure for CJD, so treatment aims to relieve symptoms and make the affected person feel as comfortable as possible.

This can include using medicine such as [antidepressants](https://www.nhs.uk/mental-health/talking-therapies-medicine-treatments/medicines-and-psychiatry/antidepressants/) to help with [anxiety](https://www.nhs.uk/mental-health/conditions/anxiety/) and [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/), and painkillers to relieve pain.

Some people will need nursing care and assistance with feeding.

Read more about [treating Creutzfeldt-Jakob disease](https://www.nhs.uk/conditions/creutzfeldt-jakob-disease-cjd/treatment/).

Variant CJD compensation scheme
-------------------------------

In October 2001, the government announced a compensation scheme for UK victims of variant CJD.

The [vCJD Trust](http://www.vcjdtrust.co.uk/) assesses claims and pays compensation to victims and their families.

Page last reviewed: 07 September 2021  
Next review due: 07 September 2024
