Title: Autosomal dominant polycystic kidney disease

URL Source: https://www.nhs.uk/conditions/autosomal-dominant-polycystic-kidney-disease-adpkd/

Published Time: 20 Oct 2017, 1:56 p.m.

Markdown Content:
**Autosomal dominant polycystic kidney disease (ADPKD) is an inherited condition that causes small fluid-filled sacs called cysts to develop in the kidneys.**

Although children affected by ADPKD are born with the condition, it rarely causes any noticeable problems until the cysts grow large enough to affect the kidneys' functions.

In most cases, this does not occur until a person is between 30 and 40 years of age.

Less commonly, children or older people may have noticeable symptoms as a result of ADPKD.

When ADPKD reaches this stage, it can cause a wide range of problems, including:

*   tummy (abdominal) pain
*   [high blood pressure (hypertension)](https://www.nhs.uk/conditions/high-blood-pressure-hypertension/)
*   [blood in the urine (haematuria)](https://www.nhs.uk/conditions/blood-in-urine/), which may not always be noticeable to the naked eye
*   potentially serious upper [urinary tract infections (UTIs)](https://www.nhs.uk/conditions/urinary-tract-infections-utis/)
*   [kidney stones](https://www.nhs.uk/conditions/kidney-stones/)

Kidney function may gradually deteriorate until so much is lost that [kidney failure](https://www.nhs.uk/conditions/kidney-disease/) occurs.

Read more about the [symptoms of ADPKD](https://www.nhs.uk/conditions/autosomal-dominant-polycystic-kidney-disease-adpkd/symptoms/) and [diagnosing ADPKD](https://www.nhs.uk/conditions/autosomal-dominant-polycystic-kidney-disease-adpkd/diagnosis/).

What causes ADPKD
-----------------

ADPKD is caused by a genetic fault that disrupts the normal development of some of the cells in the kidneys and causes cysts to grow.

Faults in 1 of 2 different genes are known to cause ADPKD.

The affected genes are:

*   PKD1, which accounts for around 78% of cases
*   PKD2, which accounts for around 15% of cases

Both types of ADPKD have the same symptoms, but they tend to be more severe in PKD1.

A child has a 1 in 2 (50%) chance of developing ADPKD if one of their parents has the faulty PKD1 or PKD2 gene.

[Autosomal recessive polycystic kidney disease (ARPKD)](https://www.nhs.uk/conditions/autosomal-recessive-polycystic-kidney-disease-arpkd/) is a rarer type of kidney disease that can only be inherited if both parents carry the faulty gene. In this type problems usually start much earlier, during childhood.

### Non-inherited ADPKD

In up to 1 in 4 (25%) cases, a person develops ADPKD without having a known family history of the condition.

This could be because the condition was never diagnosed in a relative, or a relative with the condition may have died before their symptoms were recognised.

In around 1 in 10 cases of ADPKD, the mutation develops for the first time in the affected person. It's not known what causes this to happen.

The affected person can pass the faulty gene on to their children in the same way as someone who's inherited it from a parent.

Who's affected
--------------

ADPKD is the most common inherited condition to affect the kidneys, although it's still relatively uncommon.

It's estimated up to 1 in every 1000 to 2500 people in the UK has ADPKD. This means there could be between 30,000 and 70,000 people in the UK with the condition.

Treating ADPKD
--------------

There's currently no cure for ADPKD, however:

*   a healthy lifestyle may help to protect your kidney function
*   various treatments are available to manage problems caused by the condition

Most problems, such as high blood pressure, pain and UTIs, can be treated with medication, although you may need to have an operation to remove any large [kidney stones](https://www.nhs.uk/conditions/kidney-stones/) that develop.

If the condition reaches a point where the kidneys are not able to function properly, there are 2 main treatment options:

*   [dialysis](https://www.nhs.uk/conditions/dialysis/), where a machine is used to replicate kidney functions
*   a kidney transplant, where a healthy kidney is removed from a living or recently deceased donor and implanted into someone with kidney failure

A medication called tolvaptan can be used to slow down the formation of cysts and protect kidney function.

[Find out more about treating ADPKD](https://www.nhs.uk/conditions/autosomal-dominant-polycystic-kidney-disease-adpkd/treatment/)

Outlook
-------

The outlook for ADPKD is highly variable. Some people experience kidney failure soon after the condition is diagnosed, whereas others may live the rest of their life with their kidneys working relatively well.

On average, around half of people with ADPKD require treatment for kidney failure by the time they're 60.

As well as kidney failure, ADPKD can also cause a number of other potentially serious problems, such as [heart attacks](https://www.nhs.uk/conditions/heart-attack/) and [strokes](https://www.nhs.uk/conditions/stroke/) caused by high blood pressure, or bleeding on the brain [(subarachnoid haemorrhage)](https://www.nhs.uk/conditions/subarachnoid-haemorrhage/) caused by a bulge in the wall of a blood vessel in the brain [(brain aneurysm)](https://www.nhs.uk/conditions/brain-aneurysm/).

[Find out more about the complications of ADPKD](https://www.nhs.uk/conditions/autosomal-dominant-polycystic-kidney-disease-adpkd/complications/)

Information about you
---------------------

If you have ADPKD, your clinical team will pass information about you on to the National Congenital Anomaly and Rare Diseases Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the register](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet)

The kidneys
-----------

The kidneys are 2 bean-shaped organs located on either side of the back of the body, just underneath the ribcage.

The main role of the kidneys is to filter out waste products from the blood and pass them out of the body in urine.

The kidneys also play an important role in:

*   helping to maintain blood pressure at a healthy level
*   keeping salt and water in balance
*   making hormones needed for the production of blood and bone

Page last reviewed: 23 February 2023  
Next review due: 23 February 2026
