Title: Blood groups

URL Source: https://www.nhs.uk/conditions/blood-groups/

Published Time: 17 Oct 2017, 5:22 p.m.

Markdown Content:
**There are 4 main blood groups (types of blood) – A, B, AB and O. Your blood group is determined by the genes you inherit from your parents.**

Each group can be either RhD positive or RhD negative, which means in total there are 8 blood groups.

Antibodies and antigens
-----------------------

Blood is made up of red blood cells, white blood cells and platelets in a liquid called plasma. Your blood group is identified by antibodies and antigens in the blood.

Antibodies are proteins found in plasma. They're part of your body's natural defences. They recognise foreign substances, such as germs, and alert your immune system, which destroys them.

Antigens are protein molecules found on the surface of red blood cells.

The ABO system
--------------

There are 4 main blood groups defined by the ABO system:

*   **blood group A** – has A antigens on the red blood cells with anti-B antibodies in the plasma
*   **blood group B** – has B antigens with anti-A antibodies in the plasma
*   **blood group O** – has no antigens, but both anti-A and anti-B antibodies in the plasma
*   **blood group AB** – has both A and B antigens, but no antibodies

Blood group O is the most common blood group. Almost half of the UK population (around 48%) has blood group O.

Receiving blood from the wrong ABO group can be life-threatening. For example, if someone with group B blood is given group A blood, their anti-A antibodies will attack the group A cells.

This is why group A blood must never be given to someone who has group B blood and vice versa.

As group O red blood cells do not have any A or B antigens, it can safely be given to any other group.

[Find out more about the different blood groups on the NHS Blood and Transplant (NHSBT) website](http://www.blood.co.uk/about-blood/blood-group-basics/)

The Rh system
-------------

Red blood cells sometimes have another antigen, a protein known as the RhD antigen. If this is present, your blood group is RhD positive. If it's absent, your blood group is RhD negative.

This means you can be 1 of 8 blood groups:

*   A RhD positive (A+)
*   A RhD negative (A-)
*   B RhD positive (B+)
*   B RhD negative (B-)
*   O RhD positive (O+)
*   O RhD negative (O-)
*   AB RhD positive (AB+)
*   AB RhD negative (AB-)

About 85% of the UK population is RhD positive (35% of the population has O+, the most common type).

In most cases, O RhD negative blood (O-) can safely be given to anyone. It's often used in medical emergencies when the blood type is not immediately known.

It's safe for most recipients because it does not have any A, B or RhD antigens on the surface of the cells, and is compatible with every other ABO and RhD blood group.

[Find out more about the Rh system on the NHS Blood and Transplant (NHSBT) website](https://www.blood.co.uk/why-give-blood/the-need-for-blood/the-rh-system/)

Blood group test
----------------

To find out your blood group, a sample of your blood has to be taken and tested. However, GPs do not routinely check people's blood group.

You can find out your blood group by giving blood.

For the blood group test, your red blood cells are mixed with different antibody solutions. If, for example, the solution contains anti-B antibodies and you have B antigens on your cells (you're blood group B), it will clump together.

If the blood does not react to any of the anti-A or anti-B antibodies, it's blood group O. A series of tests with different types of antibody can be used to identify your blood group.

If you have a [blood transfusion](https://www.nhs.uk/conditions/blood-transfusion/) (where blood is taken from one person and given to another) your blood will be tested against a sample of donor cells that contain ABO and RhD antigens. If there's no reaction, donor blood with the same ABO and RhD type can be used.

Pregnancy
---------

Pregnant women are always given a blood group test. This is because if the mother is RhD negative but the child has inherited RhD-positive blood from the father, it could cause complications if left untreated.

RhD-negative women of child-bearing age should always only receive RhD-negative blood.

Read more about [Rhesus disease](https://www.nhs.uk/conditions/rhesus-disease/).

Giving blood
------------

Most people are able to give blood, but a lot fewer people than are needed to meet demand actually do.

You can usually donate blood if you:

*   are fit and healthy
*   weigh between 50kg (7st 12lb) and 158kg (25st)
*   are 17 to 65 years old

[Find your nearest blood donor centre in England and North Wales on the NHSBT website](https://my.blood.co.uk/home)

You can book an appointment online, or you can call 0300 123 23 23 to book an appointment.

*   [NHS Blood and Transplant (NHSBT): who can give blood](https://www.blood.co.uk/who-can-give-blood/)
*   [NHS Blood and Transplant (NHSBT): why give blood](https://www.blood.co.uk/why-give-blood/)

Page last reviewed: 10 May 2023  
Next review due: 10 May 2026
