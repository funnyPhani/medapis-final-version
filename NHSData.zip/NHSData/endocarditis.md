Title: Endocarditis

URL Source: https://www.nhs.uk/conditions/endocarditis/

Published Time: 25 Oct 2017, 3:48 p.m.

Markdown Content:
**Endocarditis is a rare and potentially fatal infection of the inner lining of the heart (the endocardium). It's most commonly caused by bacteria entering the blood and travelling to the heart.**

Although the heart is usually well protected against infection, it may be easier for bacteria to bypass the immune system in people who have:

*   an artificial (prosthetic) heart valve – [valve replacement surgery](https://www.nhs.uk/conditions/aortic-valve-replacement/) is increasingly being used when people experience narrowing of one of their heart valves
*   [congenital heart disease](https://www.nhs.uk/conditions/congenital-heart-disease/) – where a person is born with heart defects
*   hypertrophic [cardiomyopathy](https://www.nhs.uk/conditions/cardiomyopathy/) – where the heart muscle cells have enlarged and the walls of the heart chambers thicken
*   damaged heart valves – because of infection or heart disease
*   had endocarditis before

People who inject drugs are also more likely to develop endocarditis.

[Find out more about the causes of endocarditis](https://www.nhs.uk/conditions/endocarditis/causes/)

Symptoms of endocarditis
------------------------

The initial symptoms of endocarditis are similar to flu and include:

*   a high temperature
*   chills
*   [headache](https://www.nhs.uk/conditions/headaches/)
*   joint and muscle pain

Without treatment, the infection damages the heart valves and disrupts the normal flow of blood through the heart.

This could trigger a range of life-threatening complications, such as:

*   [heart failure](https://www.nhs.uk/conditions/heart-failure/) – where the heart is unable to pump enough blood around the body to properly meet the body's demands
*   [stroke](https://www.nhs.uk/conditions/stroke/) – where the supply of blood to the brain becomes disrupted

[Find out more about the symptoms of endocarditis](https://www.nhs.uk/conditions/endocarditis/symptoms/)

Treating endocarditis
---------------------

Endocarditis is treated with a course of [antibiotics](https://www.nhs.uk/conditions/antibiotics/) given via a drip. You'll need to be admitted to hospital for this.

Some people also need surgery to repair or replace a damaged heart valve or drain any abscesses that develop.

Endocarditis is a serious illness, especially if complications develop. Early diagnosis and treatment is vital to improve the outlook for the condition.

[Find out more about the treatment of endocarditis](https://www.nhs.uk/conditions/endocarditis/treatment/)

Who's affected
--------------

Endocarditis is a rare condition in England, even in those with a higher risk.

It's more common in older people.

But cases of endocarditis have been recorded in children, particularly those born with congenital heart disease.

Twice as many men are affected as women.

Although it may sound strange, rates of endocarditis are increasing because of advances in medical care.

This is because there's an increasing number of people being treated with valve replacement surgery or surgery to repair congenital heart disease.

Page last reviewed: 16 August 2022  
Next review due: 16 August 2025
