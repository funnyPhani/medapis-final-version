Title: Having an operation (surgery)

URL Source: https://www.nhs.uk/conditions/having-surgery/

Published Time: 23 Oct 2017, 1:26 p.m.

Markdown Content:
Having an operation (surgery) - NHS
===============
                                    

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/having-surgery/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

Overview \- Having an operation (surgery)
=========================================

Contents
--------

1.  Overview
2.  [Seeing a specialist](https://www.nhs.uk/conditions/having-surgery/specialist/)
3.  [Before surgery](https://www.nhs.uk/conditions/having-surgery/preparation/)
4.  [On the day](https://www.nhs.uk/conditions/having-surgery/what-happens/)
5.  [After surgery](https://www.nhs.uk/conditions/having-surgery/afterwards/)
6.  [Getting back to normal](https://www.nhs.uk/conditions/having-surgery/recovery/)

**If you're considering having an operation or your GP has suggested you may need surgery, this guide is for you.**

It'll take you through all the steps in the process, from referral to recovery, so you're fully prepared and know what questions to ask at each stage.

Before you start, you'll need to decide which hospital you'd like to be referred to. Find out about [NHS hospital services and choosing a hospital](https://www.nhs.uk/nhs-services/hospitals/about-nhs-hospital-services/).

You can also compare hospitals by following these steps:

*   [find hospitals by surgical procedures](https://www.nhs.uk/Service-Search/Hospital/LocationSearch/7/Procedures)
*   enter your postcode and the name of your operation or select it from the surgical procedures A-Z
*   you'll be taken to a page listing the hospitals that can carry out the operation
*   using the columns and drop-down menu, you can compare hospitals based on things such CQC inspection ratings, safety and facilities

Once you have chosen your hospital, in most cases your GP will refer you to see a specialist at this hospital.

Page last reviewed: 03 September 2021  
Next review due: 03 September 2024

*   [Next : Seeing a specialist](https://www.nhs.uk/conditions/having-surgery/specialist/)

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
