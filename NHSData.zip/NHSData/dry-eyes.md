Title: Dry eyes

URL Source: https://www.nhs.uk/conditions/dry-eyes/

Published Time: 23 Oct 2017, 12:06 p.m.

Markdown Content:
**Many people get dry eyes. It's not usually serious and there are things you can do to help.**

Check if you have dry eyes
--------------------------

You may have dry eyes if your eyes are:

*   itchy
*   sore
*   gritty
*   red
*   blurry
*   sensitive to light
*   more watery than normal

Causes of dry eyes
------------------

You can get dry eyes if you do not make enough tears or your tears dry up quickly.

You may be more likely to get dry eyes if:

*   you're over the age of 50
*   you wear contact lenses
*   you look at computer screens for a long time without a break
*   you spend time in air conditioned or heated environments
*   it's windy, cold, dry or dusty
*   you smoke or drink alcohol
*   you take certain medicines (for example, some antidepressants or blood pressure medicines)
*   you have a condition, such as [blepharitis](https://www.nhs.uk/conditions/blepharitis/), [Sjögren's syndrome](https://www.nhs.uk/conditions/sjogrens-syndrome/) or [lupus](https://www.nhs.uk/conditions/lupus/)

How to treat dry eyes yourself
------------------------------

### Do

*   clean your eyelids every day
    
*   take breaks to rest your eyes when using a computer screen
    
*   make sure your computer screen is just below eye level
    
*   use a humidifier to stop the air getting dry
    
*   if you wear contact lenses, take them out and wear glasses to rest your eyes
    

How to clean your eyelids

1.  Soak a flannel in warm (not hot) water and gently press it on the area around your eyes. This makes the oil produced by the glands around your eyes more runny.
2.  Gently massage your eyelids with your finger or a cotton bud. This pushes the oils out of the glands.
3.  Clean your eyelids by soaking cotton wool in warm (not hot) water and gently wipe away any excess oil, crusts, bacteria, dust or grime that might have built up.

### Don’t

*   do not smoke or drink too much alcohol
    
*   do not spend too long in smoky, dry or dusty places
    
*   do not spend too long in air conditioned or heated rooms
    
*   do not stop taking a prescribed medicine without getting medical advice first – even if you think it's causing your symptoms
    

A pharmacist may be able to help with dry eyes
----------------------------------------------

A pharmacist may be able to tell you:

*   what you can do to treat it yourself – such as cleaning and protecting your eyes
*   if you can buy anything to help – such as eye drops, gels, ointments or allergy medicines
*   if you need to see an optician or GP

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See an optician or GP if:
--------------------------------------------

*   you still have dry eyes after trying home treatments for a few weeks
*   there's any change in the shape of your eyelids

They can check what the cause might be and recommend treatment for it.

If an optician or GP cannot find a cause, they may refer you to an eye specialist (ophthalmologist) for tests.

[Find an optician](https://www.nhs.uk/service-search/find-an-optician)

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   your eye is painful and red
*   you have a red eye and wear contact lenses – you could have an eye infection

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   you have any changes to your sight, like wavy lines, flashing or loss of vision
*   it hurts to look at light
*   you have a red eye, severe headache and feel sick
*   your eye or eyes are very dark red
*   you have injured or pierced your eye
*   something is stuck in your eye (like a piece of glass or grit)

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Page last reviewed: 06 December 2021  
Next review due: 06 December 2024
