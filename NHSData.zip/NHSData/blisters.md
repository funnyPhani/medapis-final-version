Title: Blisters

URL Source: https://www.nhs.uk/conditions/blisters/

Published Time: 19 Dec 2017, 3:11 p.m.

Markdown Content:
**Blisters often heal on their own within a week. They can be painful while they heal, but you will not usually need to see a GP.**

How you can treat a blister yourself
------------------------------------

There are things you can do to protect a blister and help stop it getting infected.

### Do

*   keep the blister as clean as possible – gently wash the skin and pat it dry
    
*   cover blisters with a soft plaster or padded dressing
    
*   wash your hands before touching a burst blister
    
*   allow the fluid in a burst blister to drain before covering it with a plaster or dressing
    

### Don’t

*   do not burst a blister yourself
    
*   do not peel the skin off a burst blister
    
*   do not pick at the edges of the remaining skin
    
*   do not wear the shoes or use the equipment that caused your blister until it heals
    

### A pharmacist can help with blisters

To protect your blister from becoming infected, a pharmacist can recommend a plaster or dressing to cover it while it heals.

A hydrocolloid dressing (a moist dressing) can protect the blister, help reduce pain and speed up healing.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Check if you have a blister
---------------------------

![Image 1: An oval-shape bump on white skin that's filled with clear fluid. The skin over the blister is pink and shiny.](https://assets.nhs.uk/nhsuk-cms/images/C0095259-Blister_on_heel_from_new_shoes-SPL.width-320_uwBljCS.jpg)

Blisters are small pockets of clear fluid under a layer of skin.

![Image 2: A small round bump on the sole of the foot, just below the toes, that's filled with dark red blood.](https://assets.nhs.uk/nhsuk-cms/images/M7290012-Close-up_of_a_blister_after_verruca_c.width-320_pwXUN3H.jpg)

Blood blisters may look red or black and are filled with blood instead of clear fluid.

![Image 3: A round bump on the back of the heel filled with light green pus. The surface is dry and creased and the surrounding skin is red.](https://assets.nhs.uk/nhsuk-cms/images/C0197737-Infected_blister-SPL.width-320_tE7l5Rz.jpg)

An infected blister can be hot and filled with green or yellow pus. The surrounding skin may look red, but this can be hard to see on brown or black skin.

### Important

Do not ignore an infected blister. Without treatment it could lead to a skin or blood infection.

Urgent advice: Get help from NHS 111 if:
----------------------------------------

*   a blister is very painful or keeps coming back
*   the skin looks infected – it's hot and the blister is filled with green or yellow pus
*   the skin around the blister looks red, but this can be harder to see on brown or black skin
*   a blister is in an unusual place – such as your eyelids, mouth or genitals
*   several blisters have appeared for no reason
*   a blister was caused by a burn or scald, sunburn, or an allergic reaction

You can call [111](tel:111) or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Treatment for blisters from a GP
--------------------------------

A GP might burst a large or painful blister using a sterilised needle. If your blister is infected, they may prescribe [antibiotics](https://www.nhs.uk/conditions/antibiotics/).

They can also offer treatment and advice if blisters are caused by a medical condition.

Conditions that can cause blisters

Conditions that can cause blisters include:

*   [chickenpox](https://www.nhs.uk/conditions/chickenpox/) – a childhood illness that causes itchy spots
*   [cold sores](https://www.nhs.uk/conditions/cold-sore/) – small blisters that develop on the lips or around the mouth, caused by a virus
*   [genital herpes](https://www.nhs.uk/conditions/genital-herpes/) – a sexually transmitted infection (STI) that most commonly affects the genitals
*   [bullous impetigo](https://www.nhs.uk/conditions/impetigo/) – a bacterial skin infection
*   [pompholyx](https://www.nhs.uk/conditions/pompholyx/) – a type of eczema
*   [scabies](https://www.nhs.uk/conditions/scabies/) – a skin condition caused by tiny mites
*   [hand, foot and mouth disease](https://www.nhs.uk/conditions/hand-foot-mouth-disease/) – a viral infection that usually affects young children

How to prevent blisters
-----------------------

Blisters develop to protect damaged skin and help it heal. They're mostly caused by friction, burns and skin reactions, such as an allergic reaction.

Blood blisters appear when blood vessels in the skin have also been damaged.

If you often get friction blisters on your feet or hands:

*   wear comfortable, well-fitting shoes
*   wear new shoes for short periods of time, until they're comfortable
*   wear thick socks during exercise, such as moisture-wicking sports socks
*   change your socks frequently if you get sweaty feet
*   wear protective gloves when you exercise or if you use tools at work

Page last reviewed: 22 November 2023  
Next review due: 22 November 2026
