Title: Dentures (false teeth)

URL Source: https://www.nhs.uk/conditions/dentures/

Published Time: 18 Oct 2017, 10:39 a.m.

Markdown Content:
**Dentures are removable false teeth made of acrylic (plastic), nylon or metal. They fit snugly over the gums to replace missing teeth and eliminate potential problems caused by gaps.**

Gaps left by missing teeth can cause problems with eating and speech, and teeth either side of the gap may grow into the space at an angle.

Sometimes all the teeth need to be removed and replaced.

You may therefore need either:

*   **complete dentures** (a full set) – which replace all your upper or lower teeth, or
*   **partial dentures** – which replace just 1 tooth or a few missing teeth

Dentures may help prevent problems with eating and speech. If you need complete dentures, they may also improve the appearance of your smile and give you confidence.

It's also possible that dentures might not give you the result you hope for. Discuss plans openly with your dentist before you agree to go ahead.

How dentures are fitted
-----------------------

### Complete dentures

A full denture will be fitted if all your upper or lower teeth need to be removed or you're having an old complete denture replaced.

The denture will usually be fitted as soon as your teeth are removed, which means you won't be without teeth. The denture will fit snugly over your gums and jawbone.

But if you have dentures fitted immediately after the removal of several teeth, the gums and bone will alter in shape fairly quickly and the dentures will probably need relining or remaking after a few months.

Occasionally, your gums may need to be left to heal and alter in shape for several months before dentures can be fitted.

You can either see a dentist or a qualified clinical dental technician to have your dentures made and fitted.

The difference between them is that a:

*   dentist will take measurements and impressions (moulds) of your mouth, and then order your full or partial dentures from a dental technician
*   clinical dental technician will provide a full set of dentures directly without you having to see your dentist (although you should still have regular [dental check-ups](https://www.nhs.uk/live-well/healthy-teeth-and-gums/dental-check-ups/) with your dentist)

A trial denture will be created from the impressions taken of your mouth.

The dentist or clinical dental technician will try this in your mouth to assess the fit and for you to assess the appearance.

The shape and colour may be adjusted before the final denture is produced.

### Partial dentures

A partial denture is designed to fill in the gaps left by one or more missing teeth. It's a plastic, nylon or metal plate with a number of false teeth attached to it.

It usually clips onto some of your natural teeth via metal clasps, which hold it securely in place in your mouth. It can easily be unclipped and removed.

Occasionally, the clips can be made of a tooth- or gum-coloured material, although this type of clip isn't always suitable because it tends to be more brittle than metal.

Your dentist can measure your mouth and order a partial denture for you, or you can see a qualified clinical dental technician, who can provide a partial denture for you directly after you have first seen your dentist for a treatment plan and certificate of oral health.

The [Oral Health Foundation website](http://www.dentalhealth.org/) has more information and advice about [bridges and partial dentures](https://www.dentalhealth.org/bridges-and-partial-dentures), including which type of denture (metal or plastic) is best for you.

A fixed bridge is an alternative to a partial denture and may be suitable for some people.

Crowns are put on the teeth either side of the gap and joined together by a false tooth that's put in the gap.

Looking after your dentures
---------------------------

Dentures may feel a bit strange to begin with, but you'll soon get used to wearing them.

At first, you may need to wear your dentures all the time, including while sleeping.

Your dentist or clinical dental technician will advise you on whether you should remove your dentures before you go to sleep.

It isn't always necessary to remove your dentures at night, but doing so can allow your gums to rest as you sleep.

If you remove your dentures, they should be kept moist – for example, in water or a polythene bag with some dampened cotton wool in it, or in a suitable overnight denture-cleaning solution.

This will stop the denture material drying out and changing shape.

### Dental hygiene

Keeping your mouth clean is just as important when you wear dentures.

You should brush your remaining teeth, gums and tongue every morning and evening with fluoride toothpaste to prevent [tooth decay](https://www.nhs.uk/conditions/tooth-decay/), [gum disease](https://www.nhs.uk/conditions/gum-disease/) and other dental problems.

Read more about [how to keep your teeth clean](https://www.nhs.uk/live-well/healthy-teeth-and-gums/how-to-keep-your-teeth-clean/).

### Cleaning dentures

It's important to regularly remove plaque and food deposits from your dentures.

This is because unclean dentures can also lead to problems, such as [bad breath](https://www.nhs.uk/conditions/bad-breath/), [gum disease](https://www.nhs.uk/conditions/gum-disease/), [tooth decay](https://www.nhs.uk/conditions/tooth-decay/) and [oral thrush](https://www.nhs.uk/conditions/oral-thrush-mouth-thrush/).

Clean your dentures as often as you would normal teeth (at least twice a day: every morning and night).

You should:

*   brush your dentures with toothpaste or soap and water before soaking them to remove food particles
*   soak them in a fizzy solution of denture-cleaning tablets to remove stains and bacteria (follow the manufacturer's instructions)
*   brush them again as you would your normal teeth (but don't scrub them too hard)

Dentures may break if you drop them, so you should clean them over a bowl or sink filled with water, or something soft like a folded towel.

[Find more information on denture cleaning, on the Oral Health Foundation website](https://www.dentalhealth.org/denture-cleaning).

### Eating with dentures

When you first start wearing dentures, you should eat soft foods cut into small pieces and chew slowly, using both sides of your mouth.

Avoid chewing gum and any food that's sticky, hard or has sharp edges.

You can gradually start to eat other types of food until you're back to your old diet. Never use toothpicks.

### Denture adhesive

If your dentures fit properly, you shouldn't necessarily need to use denture fixative (adhesive).

But if your jawbone has shrunk significantly, adhesive may be the only way to help retain your dentures.

Your dentist or clinical dental technician will advise you if this is the case.

At first, some people feel more confident with their dentures if they use adhesive. Follow the manufacturer's instructions and avoid using excessive amounts.

Adhesive can be removed from the denture by brushing with soap and water.

Remnants of adhesive left in the mouth may need to be removed with some damp kitchen roll or a clean damp flannel.

When to see your dentist
------------------------

You should continue to see your dentist regularly if you have dentures (even if you have complete dentures) so they can check for any problems.

Your dentures should last several years if you take good care of them.

But your gums and jawbone will eventually shrink, which means the dentures may not fit as well as they used to and can become loose, or they may become worn.

See your dentist as soon as possible if:

*   your dentures click when you're talking
*   your dentures tend to slip, or you feel they no longer fit properly
*   your dentures feel uncomfortable
*   your dentures are visibly worn
*   you have signs of [gum disease](https://www.nhs.uk/conditions/gum-disease/) or [tooth decay](https://www.nhs.uk/conditions/tooth-decay/), such as bleeding gums or bad breath

If poorly fitting or worn dentures aren't replaced, they can cause great discomfort and lead to mouth sores, infections or problems eating and speaking.

How much dentures cost on the NHS
---------------------------------

Having dentures fitted is a band 3 treatment.

Read about [understanding NHS dental charges](https://www.nhs.uk/nhs-services/dentists/understanding-nhs-dental-charges/) for the different bands and how to [get help with dental costs](https://www.nhs.uk/nhs-services/dentists/get-help-with-dental-costs/).

Page last reviewed: 08 September 2021  
Next review due: 08 September 2024
