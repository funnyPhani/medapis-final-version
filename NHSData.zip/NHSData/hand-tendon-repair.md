Title: Hand tendon repair

URL Source: https://www.nhs.uk/conditions/hand-tendon-repair/

Published Time: 23 Oct 2017, 1:25 p.m.

Markdown Content:
**If any of the tendons in your hand are damaged, surgery may be needed to repair them and help restore movement in the affected fingers or thumb.**

What are tendons?
-----------------

Tendons are tough cords of tissue that connect muscles to bones.

When a group of muscles contract (tighten), the attached tendons will pull on certain bones, allowing you to make a wide range of movements.

There are 2 groups of tendons in the hand:

*   **extensor tendons** – which run from the forearm across the back of your hand to your fingers and thumb, allowing you to straighten your fingers and thumb
*   **flexor tendons** – which run from your forearm through your wrist and across the palm of your hand, allowing you to bend your fingers

Surgery can often be used to repair damage to both these groups of tendons.

When hand tendon repair is needed
---------------------------------

Hand tendon repair is needed when 1 or more tendons in your hand rupture (break or split) or are cut, leading to the loss of normal hand movements.

If your extensor tendons are damaged, you'll be unable to straighten 1 or more fingers. If your flexor tendons are damaged, you'll be unable to bend 1 or more fingers.

Tendon damage can also cause pain and swelling (inflammation) in your hand.

Sometimes, damage to the extensor tendons can be treated without the need for surgery, using a rigid support called a splint that's worn around the hand.

Common causes of tendon injuries include:

*   **cuts** – cuts across the back or palm of your hand can result in injury to your tendons
*   [**sports injuries**](https://www.nhs.uk/conditions/sports-injuries/) – extensor and flexor tendons can be injured when playing sports like rugby, and the pulleys holding flexor tendons can rupture if you do a lot of strenuous gripping like in rock climbing
*   [**animal and human bites**](https://www.nhs.uk/conditions/animal-and-human-bites/) – these type of bites can cause tendon damage, and a person may damage their hand tendon after punching another person in the teeth
*   **crushing injuries** – jamming a finger in a door or crushing a hand in a car accident can divide or rupture a tendon
*   [**rheumatoid arthritis**](https://www.nhs.uk/conditions/rheumatoid-arthritis/) – rheumatoid arthritis can cause tendons to become inflamed which, if severe, can lead to them rupturing

Tendon repair surgery
---------------------

Tendon repair may involve a surgeon making a cut (incision) in your wrist, hand or finger so they can locate the ends of the divided tendon and stitch them together.

Extensor tendons are easier to reach, so repairing them is relatively straightforward.

Read more about [how hand tendon repair is performed](https://www.nhs.uk/conditions/hand-tendon-repair/what-happens/).

Recovering from surgery
-----------------------

Both types of tendon surgery require a lengthy period of recovery (rehabilitation) because the repaired tendons will be weak until the ends heal together.

Depending on the location of the injury, it can take up to 3 months for the repaired tendon to regain its previous strength.

Rehabilitation involves protecting your tendons from overuse using a hand splint. You'll usually need to wear a hand splint for several weeks after surgery.

You'll also need to perform hand exercises regularly during your recovery to stop the repaired tendons sticking to nearby tissue, which can prevent you being able to fully move your hand.

When you can return to work will depend on your job. Light activities can often be resumed after 6 to 8 weeks, and heavy activities and sport after 10 to 12 weeks.

Read more about [recovering from hand tendon repair](https://www.nhs.uk/conditions/hand-tendon-repair/recovery/).

Results
-------

After an extensor tendon repair you should have a working finger or thumb, but you may not regain full movement.

The outcome is often better when the injury is a clean cut to the tendon, rather than one that involves crushing or damage to the bones and joints.

A flexor tendon injury is generally more serious because they're often put under more strain than extensor tendons.

After a flexor tendon repair, it's quite common for some fingers to not regain full movement. But the tendon repair will still give a better result than not having surgery.

Complications can sometimes develop after surgery, such as infection or the repaired tendon snapping or sticking to nearby tissue. In these circumstances, further treatment may be required.

Page last reviewed: 06 September 2021  
Next review due: 06 September 2024
