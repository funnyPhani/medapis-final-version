Title: Bowen's disease

URL Source: https://www.nhs.uk/conditions/bowens-disease/

Published Time: 17 Oct 2017, 5:18 p.m.

Markdown Content:
**Bowen's disease is a very early form of skin cancer that's easily treatable. The main sign is a red, scaly patch on the skin.**

It affects the squamous cells, which are in the outer layer of skin, and is sometimes referred to as squamous cell carcinoma in situ.

The patch is usually very slow growing, but there's a small chance it could turn into a more serious type of skin cancer if left untreated.

The most effective method of reducing your risk of Bowen's disease, as well as other more serious types of skin cancer, is to limit your exposure to the sun.

[Get more advice about sunscreen and sun safety](https://www.nhs.uk/live-well/seasonal-health/sunscreen-and-sun-safety/)

Is Bowen's disease serious?
---------------------------

Bowen's disease itself is not usually serious. It tends to grow very slowly over months or years, and there are several very effective treatments for it.

The concern is that Bowen's disease can eventually develop into a different type of skin cancer called [squamous cell skin cancer](https://www.nhs.uk/conditions/non-melanoma-skin-cancer/) if it's left undiagnosed or neglected.

It's estimated this happens in up to 1 in 20 to 1 in 30 people with untreated Bowen's disease.

Squamous cell skin cancer is often treatable, but it can spread deeper into the body and is sometimes very serious.

Symptoms of Bowen's disease
---------------------------

Bowen's disease usually appears as a patch on the skin that has clear edges and does not heal.

Some people have more than 1 patch.

![Image 1: A small red patch on the skin. The patch is flat with an irregular outline and looks dry and scaly. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/M1200082.width-320.jpg)

The patch may be:

*   scaly or crusty
*   flat or raised
*   up to a few centimetres across
*   itchy (but not all the time)
*   red or pink on white skin, but this may be harder to see on brown and black skin

The patch can appear anywhere on the skin, but is especially common on exposed areas like the lower legs, neck and head.

Sometimes they can affect the groin area and, in men, the penis.

If the patch bleeds, starts to turn into an open sore (ulcer) or develops a lump, it could be a sign it's turned into squamous cell skin cancer.

When to get medical advice
--------------------------

See a GP if you have a persistent red or scaly patch of skin and do not know the cause.

It's important to get a proper diagnosis, as Bowen's disease can look like other conditions, such as [psoriasis](https://www.nhs.uk/conditions/psoriasis/) or [eczema](https://www.nhs.uk/conditions/atopic-eczema/).

If necessary, your GP will refer you to a skin specialist (dermatologist) to determine what the problem is.

If they are not sure about the cause, they may need to remove a small sample of skin so it can be looked at more closely (a [biopsy](https://www.nhs.uk/conditions/biopsy/)).

Causes of Bowen's disease
-------------------------

Bowen's disease usually affects people in their 60s and 70s.

The exact cause is unclear, but it's been closely linked with:

*   long-term exposure to the sun or use of sunbeds – especially in people with fair skin
*   having a weak immune system – for example, it's more common in people taking medicine to suppress their immune system after an organ transplant, or those with [AIDS](https://www.nhs.uk/conditions/hiv-and-aids/)
*   previously having [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) treatment
*   the [human papillomavirus (HPV)](https://www.nhs.uk/conditions/human-papilloma-virus-hpv/) – a common virus that often affects the genital area and can cause [genital warts](https://www.nhs.uk/conditions/genital-warts/)

Bowen's disease does not run in families and it's not infectious.

Treatments for Bowen's disease
------------------------------

There are a number of treatment options for Bowen's disease. Talk to your dermatologist about which treatment is most suitable for you.

The main treatments are:

*   cryotherapy – liquid nitrogen is sprayed on to the affected skin to freeze it. The procedure may be painful and the skin may remain a bit uncomfortable for a few days. The affected skin will scab over and fall off within a few weeks.
*   imiquimod cream or chemotherapy cream (such as 5-fluorouracil) – this is applied to the affected skin regularly for a few weeks. It may cause your skin to become red and inflamed before it gets better.
*   curettage and cautery – the affected area of skin is scraped away under [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/), where the skin is numbed, and heat or electricity is used to stop any bleeding, leaving the area to scab over and heal after a few weeks.
*   [photodynamic therapy (PDT)](https://www.nhs.uk/conditions/photodynamic-therapy/) – a light-sensitive cream is applied to the affected skin and a laser is directed on to the skin a few hours later to destroy the abnormal cells. The treatment session usually lasts between 8 to 45 minutes. You may need more than 1 session.
*   surgery – the abnormal skin is cut out under local anaesthetic and stitches may be needed afterwards.

In some cases, your dermatologist may just advise monitoring your skin closely – for example, if it's very slow growing and they feel the side effects of treatment will outweigh the benefits.

Looking after your skin after treatment
---------------------------------------

After having treatment for Bowen's disease, you may need follow-up appointments with your dermatologist or GP to see if you need any further treatment.

If you had surgery, you may need to have any stitches removed at your GP surgery 5 to 14 days later or once your wound has healed. Sometimes dissolvable stitches are used that do not need to be removed.

If you had a dressing on your wound, you may need to go to your GP or the hospital to have it changed.

After treatment:

*   see a GP if an existing patch starts to bleed, change in appearance or develops a lump – do not wait for your follow-up appointment
*   see a GP if you notice any new patches on your skin
*   make sure you protect your skin from the sun – wear protective clothing and use a sunscreen with a high sun protection factor (SPF) of at least 30

[Get more advice on sunscreen and sun safety](https://www.nhs.uk/live-well/seasonal-health/sunscreen-and-sun-safety/)

Page last reviewed: 06 October 2022  
Next review due: 06 October 2025
