Title: High temperature (fever) in children

URL Source: https://www.nhs.uk/conditions/fever-in-children/

Published Time: 24 Oct 2017, 4:25 p.m.

Markdown Content:
**A high temperature (fever) is very common in young children. The temperature usually returns to normal within 1 to 4 days.**

Checking a high temperature
---------------------------

A normal temperature in babies and children can vary slightly from child to child.

A high temperature is 38C or more.

If your child has a high temperature, they might:

*   feel hotter than usual when you touch their back or chest
*   feel sweaty
*   look or feel unwell
*   have a seizure or fit, called a [febrile seizure](https://www.nhs.uk/conditions/febrile-seizures/)

Use a digital thermometer, which you can buy from pharmacies and supermarkets, to take your child's temperature.

How to take your child's temperature

1.  Place the thermometer inside the top of the armpit.
2.  Gently close the arm over the thermometer and keep it pressed to the side of the body.
3.  Leave the thermometer in place for as long as it says in the instruction leaflet. Some digital thermometers beep when they're ready.
4.  Remove the thermometer. The display will show your child's temperature.

If your child has just had a bath or been wrapped in a blanket, their temperature may be higher for a short time. Wait a few minutes then try again.

What to do if your child has a high temperature
-----------------------------------------------

If your child or baby has a high temperature, you can usually look after them at home. The temperature should go down over 1 to 4 days.

### Do

*   give them plenty of fluids – if your baby is breastfed, continue to breastfeed as normal
    
*   look out for [signs of dehydration](https://www.nhs.uk/conditions/dehydration/)
    
*   give them food if they want it
    
*   check on your child regularly, including during the night
    
*   keep them at home
    
*   give them [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-children/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-children/) if they're distressed or uncomfortable – check the packaging or leaflet to make sure the medicine is suitable for your child, or speak to a pharmacist or GP if you're not sure
    
*   get medical advice if you're worried about your child
    

### Don’t

*   do not undress your child or sponge them down to cool them – a high temperature is a natural and healthy response to infection
    
*   do not cover them up in too many clothes or bedclothes
    
*   do not give aspirin to children under 16 years of age
    
*   do not combine ibuprofen and paracetamol, unless a GP tells you to
    
*   do not give paracetamol to a child under 2 months
    
*   do not give ibuprofen to a child who is under 3 months, weighs under 5kg, has chickenpox, or is dehydrated
    
*   do not give ibuprofen to children with [asthma](https://www.nhs.uk/conditions/asthma/) unless it's been recommended by a doctor
    

[Read more about giving medicines to babies and children](https://www.nhs.uk/conditions/baby/health/medicines-for-babies-and-children/)

Urgent advice: Call 111 or your GP surgery now if your child:
-------------------------------------------------------------

*   is under 3 months old and has a temperature of 38C or higher, or you think they have a high temperature
*   is 3 to 6 months old and has a temperature of 39C or higher, or you think they have a high temperature
*   has other signs of illness, such as a [rash](https://www.nhs.uk/conditions/rashes-babies-and-children/), as well as a high temperature
*   has a high temperature that's lasted for 5 days or more
*   does not want to eat, or is not their usual self and you're worried
*   is dehydrated – such as nappies that are not very wet, sunken eyes, and no tears when they're crying  
    

Immediate action required: Call 999 if your child:
--------------------------------------------------

*   has a stiff neck
*   has a rash that does not fade when you press a glass against it
*   is bothered by light
*   has a fit ([febrile seizure](https://www.nhs.uk/conditions/febrile-seizures/)) for the first time (they cannot stop shaking)
*   has unusually cold hands and feet
*   has changes to their skin colour such as blue, grey, paler than usual or blotchy skin (this may be harder to see on brown or black skin), or blue, grey or paler than usual lips or tongue
*   is drowsy and hard to wake
*   is extremely agitated (does not stop crying) or is confused
*   has difficulty breathing (you may notice grunting noises or their stomach sucking under their ribcage), breathlessness or breathing very fast
*   is not responding like they normally do, or is not interested in feeding or normal activities

Causes of a high temperature in children
----------------------------------------

A high temperature is the body's natural response to fighting infections like coughs and colds.

Many things can cause a high temperature in children, from common childhood illnesses like [chickenpox](https://www.nhs.uk/conditions/chickenpox/) and [tonsillitis](https://www.nhs.uk/conditions/tonsillitis/), to vaccinations.

Video: Caring for children with fever at home
---------------------------------------------

Watch this video on how to help a child with fever recover as quickly as possible.

Media last reviewed: 1 June 2023  
Media review due: 1 June 2026

Help us improve our website
---------------------------

Page last reviewed: 03 January 2024  
Next review due: 03 January 2027
