Title: Hidradenitis suppurativa (HS)

URL Source: https://www.nhs.uk/conditions/hidradenitis-suppurativa/

Published Time: 18 Oct 2017, 2:43 p.m.

Markdown Content:
**Hidradenitis suppurativa (HS) is a painful, long-term skin condition that causes** [**skin abscesses**](https://www.nhs.uk/conditions/skin-abscess/) **and scarring on the skin.**

The exact cause of hidradenitis suppurativa is unknown, but it occurs near hair follicles where there are sweat glands, usually around the groin, bottom, breasts and armpits.

For reasons that are unknown, more women than men have the condition. It's thought to affect about 1 in 100 people.

Symptoms
--------

The symptoms of hidradenitis suppurativa range from mild to severe.

It causes a mixture of [boil](https://www.nhs.uk/conditions/boils/)\-like lumps, blackheads, cysts, scarring and channels in the skin that leak pus.

![Image 1: Around 4 large boil-like lumps on the skin of a black person's armpit. The lumps vary in size up to around 1cm and are round or oval.](https://assets.nhs.uk/nhsuk-cms/images/S_0917_Hidradenitis_suppurativa_C0254591.width-320.jpg)

Hidradenitis suppurativa can cause fleshy lumps to grow on the surface of the skin

![Image 2: A close-up of a white person's armpit with a large, pink, sore looking lesion that's leaking pus. There are around 4 smaller red spots near the lesion.](https://assets.nhs.uk/nhsuk-cms/images/D1ARYB.width-320.jpg)

Sometimes, narrow channels (sinus tracts) form under the skin, which can break out on the surface and leak pus

The condition tends to start with blackheads, spots filled with pus and firm pea-sized lumps that develop in one place. The lumps will either disappear or rupture and leak pus after a few hours or days.

New lumps will then often develop in an area nearby. If these are not controlled with medicine, larger lumps may develop and spread. Narrow channels called sinus tracts also form under the skin that break out on the surface and leak pus.

Hidradenitis suppurativa can be very painful. The lumps develop on the skin in the following areas:

*   around the groin and genitals
*   in the armpits
*   on the bottom and around the anus
*   below the breasts

The lumps may also appear on the nape of the neck, waistband and inner thighs.

Some of the lumps may become infected with bacteria, causing a secondary infection that will need to be treated with [antibiotics](https://www.nhs.uk/conditions/antibiotics/).

Many people with hidradenitis suppurativa also develop a [pilonidal sinus](https://www.nhs.uk/conditions/pilonidal-sinus/), which is a small hole or "tunnel" in the skin at the top of the buttocks, where they divide (the cleft).

What causes hidradenitis suppurativa?
-------------------------------------

The exact cause of hidradenitis suppurativa is unknown, but the lumps develop as a result of blocked hair follicles.

[Smoking](https://www.nhs.uk/live-well/quit-smoking/) and [obesity](https://www.nhs.uk/conditions/obesity/) are both strongly associated with hidradenitis suppurativa, and if you're obese and/or smoke it will make your symptoms worse.

Hidradenitis suppurativa usually starts around puberty, but it can occur at any age after puberty. This may suggest that sex hormones play a part. Many people with the condition also have [acne](https://www.nhs.uk/conditions/acne/) and [excessive hair growth (hirsutism)](https://www.nhs.uk/conditions/hirsutism/).

In rare cases, hidradenitis suppurativa may be linked to [Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/), particularly if it develops around the groin area and the skin near the anus. Crohn's disease is a long-term condition that causes the lining of the digestive system to become inflamed.

Hidradenitis suppurativa runs in families in about 1 in 3 cases. It's not infectious and isn't linked to poor hygiene.

Diagnosing hidradenitis suppurativa
-----------------------------------

There's no definitive test to help diagnose hidradenitis suppurativa.

A GP will examine the affected areas of skin, and they may take a swab of an infected area. This can be helpful in making a diagnosis because the condition is not usually associated with the presence of bacteria that cause skin infections.

Hidradenitis suppurativa could be mistaken for acne or [ingrown hairs](https://www.nhs.uk/conditions/ingrown-hairs/).

Treating hidradenitis suppurativa
---------------------------------

Hidradenitis suppurativa is a lifelong, recurring condition that is often difficult to manage, although the symptoms may improve or eventually stop with treatment.

It's important to recognise and diagnose the condition in its early stages to prevent it getting worse.

In the early stages, it may be controlled with medicine. Surgery may be required in severe or persistent cases.

### Antibiotics

If you have lumps that are particularly painful, inflamed and oozing pus, you may be prescribed a 1- or 2-week course of antibiotics, if test show that you have a bacterial infection.

If bacterial infection is not present, low doses of [antibiotics](https://www.nhs.uk/conditions/antibiotics/) may be used to prevent inflammation. This longer course of antibiotics will last at least 3 months, to reduce the number of lumps that develop.

You may be given antibiotics as a cream (topical) or as a tablet, capsule or liquid. Antibiotic types can include [lymecycline](https://www.nhs.uk/medicines/lymecycline/), [doxycycline](https://www.nhs.uk/medicines/doxycycline/), [erythromycin](https://www.nhs.uk/medicines/erythromycin/) or [clarithromycin](https://www.nhs.uk/medicines/clarithromycin/).

In severe cases of hidradenitis suppurativa, a combination of clindamycin and rifampicin can be effective.

### Antiseptics

Antiseptic washes, such as 4% chlorhexidine, applied daily to affected areas are often prescribed alongside other treatments.

### Retinoids

Retinoids, such as acitretin, are vitamin-A based medicines that help some people with hidradenitis suppurativa.

Retinoids are always prescribed by dermatologists. They must be used with caution and cannot be taken during pregnancy. It's also important to avoid getting pregnant for 3 years after stopping treatment, so they're not usually prescribed if there's a chance you could get pregnant.

### Contraceptives

If hidradenitis suppurativa flares up before a [period](https://www.nhs.uk/conditions/periods/) you may benefit from taking oral contraceptives.

### Immunosuppressive treatments

In severe cases of hidradenitis suppurativa, treatments that suppress the immune system, such as [adalimumab](https://www.nhs.uk/medicines/adalimumab/) or infliximab, can be useful.

However, there are risks associated with suppressing the immune system, so they are usually only prescribed by a dermatologist if other treatments do not work.

Immunosuppressive treatments such as infliximab and adalimumab are given by injection or infusion at regular intervals, either at home or in hospital.

### Steroids

Rarely, you may be prescribed steroids, such as [prednisolone](https://www.nhs.uk/medicines/prednisolone/), to reduce severely inflamed skin. [Steroids](https://www.nhs.uk/conditions/steroids/) can be taken as skin creams or tablets, or you may have an injection directly into affected skin.

Possible side effects of steroids include weight gain, poor sleep and mood swings.

Read more about [steroid creams (topical corticosteroids)](https://www.nhs.uk/conditions/topical-steroids/), [steroid tablets](https://www.nhs.uk/conditions/steroid-tablets/) and [steroid injections](https://www.nhs.uk/conditions/steroid-injections/#side-effects).

### Surgery

Surgery may be considered in cases where hidradenitis suppurativa cannot be controlled with medicine.

Lifestyle advice
----------------

If you have hidradenitis suppurativa you should:

*   lose weight if you are overweight
*   [stop smoking](https://www.nhs.uk/live-well/quit-smoking/) if you smoke
*   use an antiseptic skin wash or antiseptic soap – this may be prescribed alongside other treatment
*   hold a warm flannel on the lumps to encourage the pus to drain
*   wear loose-fitting clothes
*   avoid shaving affected skin

Outlook
-------

Although hidradenitis suppurativa can persist for many years, if it's diagnosed early the symptoms can be improved with treatment.

However, the condition can have a significant impact on a person's everyday life. Having to regularly change dressings and constantly live with the pain and discomfort of the symptoms can affect your quality of life and lead to [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/overview/).

Speak to a GP if you're finding it difficult to cope.

Page last reviewed: 17 March 2023  
Next review due: 17 March 2026
