Title: Idiopathic pulmonary fibrosis

URL Source: https://www.nhs.uk/conditions/idiopathic-pulmonary-fibrosis/

Published Time: 23 Oct 2017, 11:44 a.m.

Markdown Content:
**Idiopathic pulmonary fibrosis (IPF) is a condition in which the lungs become scarred and breathing becomes increasingly difficult.**

It's not clear what causes it, but it usually affects people who are around 70 to 75 years old, and is rare in people under 50.

Several treatments can help reduce the rate at which IPF gets worse, but there's currently no treatment that can stop or reverse the scarring of the lungs.

Symptoms of idiopathic pulmonary fibrosis
-----------------------------------------

The symptoms of IPF tend to develop gradually and get slowly worse over time.

Symptoms can include:

*   [shortness of breath](https://www.nhs.uk/conditions/shortness-of-breath/)
*   a persistent dry [cough](https://www.nhs.uk/conditions/cough/)
*   tiredness
*   loss of appetite and [weight loss](https://www.nhs.uk/conditions/unintentional-weight-loss/)
*   rounded and swollen fingertips (clubbed fingers)

Many people ignore their breathlessness at first and blame it on getting old or being out of shape.

But eventually even light activity such as getting dressed can cause shortness of breath.

When to get medical advice
--------------------------

See a GP if you have struggled with your breathing for a while or have had a cough for more than 3 weeks.

These symptoms are not normal and should not be ignored.

If a GP thinks you could have a lung condition such as IPF, they can refer you to a hospital specialist for tests such as:

*   breathing (lung function) tests
*   [blood tests](https://www.nhs.uk/conditions/blood-tests/)
*   a chest [X-ray](https://www.nhs.uk/conditions/x-ray/) and [CT scan](https://www.nhs.uk/conditions/ct-scan/)
*   a lung [biopsy](https://www.nhs.uk/conditions/biopsy/), where a small piece of lung tissue is removed during [keyhole surgery](https://www.nhs.uk/conditions/laparoscopy/) so it can be analysed

[Find out more about the tests for idiopathic pulmonary fibrosis](https://www.nhs.uk/conditions/idiopathic-pulmonary-fibrosis/diagnosis/)

Causes of idiopathic pulmonary fibrosis
---------------------------------------

In people with IPF, the tiny air sacs in the lungs (alveoli) become damaged and increasingly scarred.

This causes the lungs to become stiff and makes it difficult for oxygen to get into the blood.

The reason this happens is not clear. Idiopathic means the cause is unknown.

IPF has been linked to:

*   exposure to certain types of dust, such as metal or wood dust
*   viral infections
*   a family history of IPF – around 1 in 20 people with IPF has another family member with the condition
*   [acid reflux](https://www.nhs.uk/conditions/heartburn-and-acid-reflux/)
*   smoking

But it's not known whether some of these factors directly cause IPF.

Treatments for idiopathic pulmonary fibrosis
--------------------------------------------

There's currently no cure for IPF, but there are several treatments that can help relieve the symptoms and slow down its progression.

Treatments include:

*   self care measures, such as stopping smoking, eating healthily and exercising regularly
*   medicines to reduce the rate at which scarring worsens, such as pirfenidone and nintedanib
*   breathing oxygen through a mask – you can do this while you're at home or while you're out and about
*   exercises and advice to help you breathe more easily (pulmonary rehabilitation)
*   a lung transplant – this is suitable in a few cases, although donor lungs are rare

[Find out more about how idiopathic pulmonary fibrosis is treated](https://www.nhs.uk/conditions/idiopathic-pulmonary-fibrosis/treatment/)

### Further information

UK Charities [Action for Pulmonary Fibrosis](https://www.actionpf.org/) and the [Pulmonary Fibrosis Trust](https://pulmonaryfibrosistrust.org/) provide information and support for people affected by IPF as well as news items about ongoing research into the condition.

Outlook for idiopathic pulmonary fibrosis
-----------------------------------------

IPF gets worse over time, although the speed at which this happens is highly variable.

Some people respond well to treatment and remain relatively free of symptoms for many years, while others may get rapidly worse or find the breathlessness debilitating.

Other problems can also sometimes develop, including [chest infections](https://www.nhs.uk/conditions/chest-infection/), [pulmonary hypertension](https://www.nhs.uk/conditions/pulmonary-hypertension/) and [heart failure](https://www.nhs.uk/conditions/heart-failure/).

It's very difficult to predict how long someone with IPF will survive at the time of diagnosis.

Regular monitoring over time can indicate whether it's getting worse quickly or slowly.

National Congenital Anomaly and Rare Disease Registration Service
-----------------------------------------------------------------

If you have IPF, your clinical team will pass information about you on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://www.ndrs.nhs.uk/).

The NCARDRS help scientists look for better ways to prevent and treat IPF. You can opt out of the register at any time.

Page last reviewed: 18 October 2022  
Next review due: 18 October 2025
