Title: Haemochromatosis

URL Source: https://www.nhs.uk/conditions/haemochromatosis/

Published Time: 23 Oct 2017, 1:13 p.m.

Markdown Content:
**Haemochromatosis is an inherited condition where iron levels in the body slowly build up over many years.**

This build-up of iron, known as iron overload, can cause unpleasant symptoms. If it is not treated, this can damage parts of the body such as the liver, joints, pancreas and heart.

Haemochromatosis most often affects people of white northern European background and is particularly common in countries where lots of people have a Celtic background, such as Ireland, Scotland and Wales.

Symptoms of haemochromatosis
----------------------------

Symptoms of haemochromatosis usually start between the ages of 30 and 60.

Common symptoms include:

*   feeling very tired all the time (fatigue)
*   weight loss
*   weakness
*   [joint pain](https://www.nhs.uk/conditions/joint-pain/)
*   an inability to get or maintain an erection ([erectile dysfunction](https://www.nhs.uk/conditions/erection-problems-erectile-dysfunction/))
*   [irregular periods](https://www.nhs.uk/conditions/irregular-periods/) or stopped or missed periods
*   Brain fog, mood swings, [depression](https://www.nhs.uk/mental-health/conditions/depression/) and [anxiety](https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/feelings-and-symptoms/anxiety-fear-panic/)

[Read more about symptoms of haemochromatosis](https://www.nhs.uk/conditions/haemochromatosis/symptoms/)

When to see a GP
----------------

See a GP if you have:

*   persistent or worrying symptoms that could be caused by haemochromatosis – particularly if you have a northern European family background
*   a parent or sibling with haemochromatosis, even if you do not have symptoms yourself – tests can be done to check if you're at risk of developing problems

Talk to the GP about whether you should have blood tests to check for haemochromatosis.

[Read more about tests for haemochromatosis](https://www.nhs.uk/conditions/haemochromatosis/diagnosis/)

Treatments for haemochromatosis
-------------------------------

There's currently no cure for haemochromatosis, but there are treatments that can reduce the amount of iron in the body and reduce the risk of damage.

There are 2 main treatments.

*   venesection (phlebotomy) – a procedure to remove some of your blood; this may need to be done every week at first and can continue to be needed 2 to 4 times a year for the rest of your life
*   chelation therapy – where you take medicine to reduce the amount of iron in your body; this is only used if it's not easy to regularly remove some of your blood

You do not need to make any big changes to your diet to control your iron levels if you're having treatment, but you'll usually be advised to avoid:

*   breakfast cereals containing added iron
*   iron or [vitamin C](https://www.nhs.uk/conditions/vitamins-and-minerals/vitamin-c/) supplements
*   drinking too much alcohol

[Read more about how haemochromatosis is treated](https://www.nhs.uk/conditions/haemochromatosis/treatment/)

Causes of haemochromatosis
--------------------------

Haemochromatosis is caused by a faulty gene that affects how the body absorbs iron from your diet.

You're at risk of developing the condition if both of your parents have this faulty gene and you inherit 1 copy from each of them.

You will not get haemochromatosis if you only inherit 1 copy of the faulty gene but there's a chance you could pass the faulty gene on to any children you have.

If you do inherit 2 copies, you will not necessarily get haemochromatosis. Only a small number of people with 2 copies of this faulty gene will ever develop the condition. It's not known exactly why this is.

[Read more about the causes of haemochromatosis](https://www.nhs.uk/conditions/haemochromatosis/causes/)

Complications of haemochromatosis
---------------------------------

If the condition is diagnosed and treated early on, haemochromatosis does not affect life expectancy and is unlikely to result in serious problems.

But if it's not found until it's more advanced, the high iron levels can damage parts of the body.

This can lead to potentially serious complications, such as:

*   liver problems – including scarring of the liver ([cirrhosis](https://www.nhs.uk/conditions/cirrhosis/)) or [liver cancer](https://www.nhs.uk/conditions/liver-cancer/)
*   [diabetes](https://www.nhs.uk/conditions/diabetes/) – where the level of sugar in the blood becomes too high
*   [arthritis](https://www.nhs.uk/conditions/arthritis/) – pain and swelling in the joints
*   [heart failure](https://www.nhs.uk/conditions/heart-failure/) – where the heart is unable to pump blood around the body properly

[Read more about complications of haemochromatosis](https://www.nhs.uk/conditions/haemochromatosis/complications/)

Further support
---------------

[Haemochromatosis UK](https://www.haemochromatosis.org.uk/) is a patient-run UK charity that provides information and support to people living with haemochromatosis.

Page last reviewed: 29 March 2023  
Next review due: 29 March 2026
