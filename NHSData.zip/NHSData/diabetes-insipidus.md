Title: Diabetes insipidus

URL Source: https://www.nhs.uk/conditions/diabetes-insipidus/

Published Time: 4 May 2018, 4:29 p.m.

Markdown Content:
**Diabetes insipidus is a rare condition where you pee a lot and often feel thirsty.**

Diabetes insipidus is not related to [type 1 diabetes](https://www.nhs.uk/conditions/type-1-diabetes/) or [type 2 diabetes](https://www.nhs.uk/conditions/type-2-diabetes/) (also known as diabetes mellitus), but it does share some of the same signs and symptoms.

The 2 main symptoms of diabetes insipidus are:

*   extreme [thirst](https://www.nhs.uk/conditions/thirst/) (polydipsia)
*   peeing a lot, even at night (polyuria)

In very severe cases of diabetes insipidus, a person can pee up to 20 litres of urine in a day.

[Find out more about the symptoms of diabetes insipidus](https://www.nhs.uk/conditions/diabetes-insipidus/symptoms/)

When to seek medical advice
---------------------------

You should always see your GP if you're feeling thirsty all the time.

Although it may not be diabetes insipidus, it should be investigated.

Also see your GP if you're:

*   peeing more than normal – most healthy adults pass urine 4 to 7 times in a 24-hour period
*   needing to pee small amounts at frequent intervals – sometimes this can occur along with the feeling that you need to pee immediately

Children tend to pee more frequently because they have smaller bladders.

But seek medical advice if your child pees more than 10 times a day.

Your GP will be able to carry out a number of tests to help determine what's causing the problem.

[Find out more about diagnosing diabetes insipidus](https://www.nhs.uk/conditions/diabetes-insipidus/diagnosis/)

What causes diabetes insipidus
------------------------------

Diabetes insipidus is caused by problems with a hormone called arginine vasopressin (AVP), also called antidiuretic hormone (ADH).

AVP plays a key role in regulating the amount of fluid in the body.

It's produced by specialist nerve cells in a part of the brain known as the hypothalamus.

AVP passes from the hypothalamus to the pituitary gland, where it's stored until needed.

The pituitary gland releases AVP when the amount of water in the body becomes too low.

It helps retain water in the body by reducing the amount of water lost through the kidneys, making the kidneys produce more concentrated urine.

In most cases of diabetes insipidus, the lack of production of AVP means the kidneys cannot make enough concentrated urine and too much water is passed from the body. This is called AVP deficiency (previously called cranial diabetes insipidus).

In rare cases, the kidneys do not respond to AVP. This causes a specific form of diabetes insipidus called AVP resistance (formerly nephrogenic diabetes insipidus).

People feel thirsty as the body tries to compensate for the increased loss of water by increasing the amount of water taken in.

[Find out more about the causes of diabetes insipidus](https://www.nhs.uk/conditions/diabetes-insipidus/causes/)

Who's affected by diabetes insipidus
------------------------------------

Diabetes insipidus affects about 1 in 25,000 people in the general population.

Adults are more likely to develop the condition, but it can occur at any age.

In rarer cases, diabetes insipidus can develop during pregnancy, known as gestational diabetes insipidus.

Types of diabetes insipidus
---------------------------

There are 2 main types of diabetes insipidus:

*   AVP deficiency (formerly cranial diabetes insipidus)
*   AVP resistance (formerly nephrogenic diabetes insipidus)

### Arginine vasopressin deficiency (AVP-D)

Arginine vasopressin deficiency (AVP-D) occurs when there's not enough AVP in the body to regulate urine production.

AVP-D is the most common type of diabetes insipidus.

It can be caused by damage to the hypothalamus or pituitary gland – for example, after an infection, operation, brain tumour or head injury.

In about 1 in 3 cases of AVP-D there's no obvious reason why the hypothalamus stops making enough AVP.

### Arginine vasopressin resistance (AVP-R)

Arginine vasopressin resistance (AVP-R) occurs when there's enough AVP in the body but the kidneys fail to respond to it.

It can be caused by kidney damage or, in some cases, inherited as a problem on its own.

Some medications, particularly lithium (used to help stabilise mood in some people with specific mental health conditions, such as bipolar disorder), can cause AVP-R.

Treating diabetes insipidus
---------------------------

Treatment is not always needed for mild cases of AVP-D.

You just need to increase the amount of water you drink to compensate for the fluid lost through urination.

If necessary, a medication called desmopressin can be used to replicate the functions of AVP.

AVP-R is often treated with medications called thiazide diuretics, which reduce the amount of urine the kidneys produce.

[Find out more about treating diabetes insipidus](https://www.nhs.uk/conditions/diabetes-insipidus/treatment/)

Complications
-------------

As diabetes insipidus increases water loss in the urine, the amount of water in the body can become low. This is known as [dehydration](https://www.nhs.uk/conditions/dehydration/).

Rehydration with water can be used to treat mild dehydration. Severe dehydration will need to be treated in hospital.

[Find out more about the complications of diabetes insipidus](https://www.nhs.uk/conditions/diabetes-insipidus/complications/)

Page last reviewed: 13 October 2022  
Next review due: 13 October 2025
