Title: Head and neck cancer

URL Source: https://www.nhs.uk/conditions/head-and-neck-cancer/

Published Time: 18 Oct 2017, 12:58 p.m.

Markdown Content:
**Head and neck cancer is a relatively uncommon type of cancer. Around 12,400 new cases are diagnosed in the UK each year.**

There are more than 30 areas within the head and neck where [cancer](https://www.nhs.uk/conditions/cancer/) can develop, including the:

*   mouth and lips
*   voice box (larynx)
*   throat (pharynx)
*   salivary glands
*   nose and sinuses
*   area at the back of the nose and mouth (nasopharynx)

[Oesophageal (gullet) cancer](https://www.nhs.uk/conditions/oesophageal-cancer/), [thyroid cancer](https://www.nhs.uk/conditions/thyroid-cancer/), [brain tumours](https://www.nhs.uk/conditions/malignant-brain-tumour/) and [eye cancer](https://www.nhs.uk/conditions/eye-cancer/) do not tend to be classified as a head and neck cancer.

Mouth cancer
------------

Mouth cancer is the most common type of head and neck cancer.

It can affect a number of areas in and around the mouth, including the:

*   lips
*   tongue
*   inside of the cheeks
*   floor or roof of the mouth
*   gums

Symptoms of mouth cancer can include [mouth ulcers](https://www.nhs.uk/conditions/mouth-ulcers/) and unexplained, persistent lumps in your mouth, both of which may be painful.

Read more about [mouth cancer](https://www.nhs.uk/conditions/mouth-cancer/).

Laryngeal cancer
----------------

Laryngeal cancer develops in the tissue of the larynx (voice box).

Symptoms of laryngeal cancer can include:

*   a change in the voice, such as persistent hoarseness
*   difficulty or pain when swallowing
*   noisy breathing
*   [shortness of breath](https://www.nhs.uk/conditions/shortness-of-breath/)
*   a persistent [cough](https://www.nhs.uk/conditions/cough/)
*   a lump or swelling in your neck

Read more about [laryngeal cancer](https://www.nhs.uk/conditions/laryngeal-cancer/).

Throat cancers
--------------

Doctors do not tend to use the term "throat cancer", as the throat (pharynx) includes many different parts that can be affected by cancer.

The main areas that can be affected are the:

*   **oropharynx** – the part of the throat at the back of the mouth
*   **hypopharynx** – the part of the throat connecting the oropharynx to the gullet and windpipe
*   **nasopharynx** – the part of the throat that connects the back of the nose to the back of the mouth

The most common symptoms of cancer in the oropharynx or hypopharynx include a lump in the neck, a persistent [sore throat](https://www.nhs.uk/conditions/sore-throat/) and difficulty swallowing.

Read more about throat cancers:

*   [Cancer Support UK: mouth and oropharyngeal cancer](https://www.cancerresearchuk.org/about-cancer/mouth-cancer)
*   [Macmillan Cancer Support: oropharyngeal cancer](https://www.macmillan.org.uk/cancer-information-and-support/head-and-neck-cancer/oropharyngeal-cancer)

Salivary gland cancer
---------------------

Salivary glands produce saliva, which keeps your mouth moist and helps with swallowing and digestion.

There are 3 main pairs of salivary glands. They are the:

*   **parotid glands** – located between your cheeks and your ears
*   **sublingual glands** – located under your tongue
*   **submandibular glands** – located under each side of your jawbone

Salivary gland cancer most commonly affects the parotid glands.

The main symptom of salivary gland cancer is a lump or swelling on or near your jaw, or in your mouth or neck. But most of these lumps are non-cancerous.

Other symptoms can include numbness in part of your face and drooping on one side of your face.

Read more about salivary gland cancer:

*   [Cancer Research UK: salivary gland cancer](https://www.cancerresearchuk.org/about-cancer/salivary-gland-cancer)
*   [Macmillan Cancer Support: salivary gland cancer](https://www.macmillan.org.uk/cancer-information-and-support/head-and-neck-cancer/salivary-gland-cancer)

Nasal and sinus cancer
----------------------

Nasal and sinus cancer affects the nasal cavity (above the roof of your mouth) and the sinuses (the small, air-filled cavities inside the bones of the nose and within the cheekbones and forehead).

The symptoms of nasal and sinus cancer are similar to viral or bacterial infections, such as the [common cold](https://www.nhs.uk/conditions/common-cold/) or [sinusitis](https://www.nhs.uk/conditions/sinusitis-sinus-infection/), and include:

*   a persistent blocked nose, which usually only affects 1 side
*   [nosebleeds](https://www.nhs.uk/conditions/nosebleed/)
*   a decreased sense of smell
*   mucus running from the nose or down the throat

Read more about [nasal and sinus cancer](https://www.nhs.uk/conditions/nasal-and-sinus-cancer/).

Nasopharyngeal cancer
---------------------

Nasopharyngeal cancer affects the part of the throat that connects the back of the nose to the back of the mouth. It's one of the rarest types of head and neck cancer in the UK.

Symptoms can include:

*   a lump in the neck, due to the cancer spreading to the lymph nodes (small glands that are part of the immune system) in the neck
*   a blocked or stuffy nose
*   nosebleeds
*   [hearing loss](https://www.nhs.uk/conditions/hearing-loss/) (usually only in 1 ear)

Read more about [nasopharyngeal cancer](https://www.nhs.uk/conditions/nasopharyngeal-cancer/).

Further information
-------------------

*   [Macmillan Cancer Support: staging and grading of head and neck cancer](https://www.macmillan.org.uk/cancer-information-and-support/head-and-neck-cancer/staging-and-grading-of-head-and-neck-cancer)

Page last reviewed: 28 October 2021  
Next review due: 28 October 2024
