Title: Hysteroscopy

URL Source: https://www.nhs.uk/conditions/hysteroscopy/

Published Time: 23 Oct 2017, 1:35 p.m.

Markdown Content:
**A hysteroscopy is a test to look inside a woman's womb, using a thin tube with a small camera inside it. The womb is where a baby grows in pregnancy.**

Anyone with a womb can have a hysteroscopy, as long as they are not pregnant.

Why a hysteroscopy is done
--------------------------

A hysteroscopy can be done to find out why you're having certain symptoms such as unexplained vaginal bleeding.

It can help diagnose or treat many different health issues, including:

*   very heavy periods or bleeding between periods
*   bleeding after the menopause
*   [fibroids](https://www.nhs.uk/conditions/fibroids/) or small growths (polyps)
*   problems getting pregnant or repeated miscarriages
*   removal of a coil (IUS or IUD) if the threads are missing

Sometimes a sample of tissue ([biopsy](https://www.nhs.uk/conditions/biopsy/)) is taken during a hysteroscopy, or fibroids and polyps are removed.

Preparing for a hysteroscopy
----------------------------

A GP or hospital doctor can refer you for a hysteroscopy if they think you need one. You'll get printed information about the procedure, including details of pain relief options, or a link to where you can read this information online.

Before you go in for your hysteroscopy, let staff at the hospital or clinic know if you'd like to bring a friend or family member with you. There will also be a nurse or other trained member of staff with you during the test (a chaperone).

### Pain relief options

Having a hysteroscopy can be uncomfortable and may feel like period pain. Taking ibuprofen or paracetamol 1 hour before the procedure can help.

However, some people find having a hysteroscopy very painful. If you're worried about pain, or have questions about pain relief, you may want to speak to staff at the hospital or clinic before the day of your hysteroscopy.

Tell them in advance if:

*   you have painful periods that make you faint
*   you've had painful vaginal examinations or cervical smears in the past
*   you've experienced sexual violence, which could make the procedure difficult for you

It may be possible to have a [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/) or an injection to help you relax (intravenous sedation) during the hysteroscopy. Not all hospitals or clinics offer this, so you may need to be referred to one that does.

Before having a hysteroscopy with general anaesthetic or sedation, you'll be invited to a separate appointment for some health checks.

### Important: Do not have a hysteroscopy if you could be pregnant

Use contraception, or avoid sex, in the weeks between your last period and having your hysteroscopy.

You may also be given a pregnancy test on the day of the procedure.

How a hysteroscopy is done
--------------------------

Before the hysteroscopy, you'll meet the healthcare professional who will be doing the procedure (the hysteroscopist).

They'll explain what will happen, including your pain relief options, and can answer any questions. They'll ask you to sign a consent form.

During your hysteroscopy, a thin tube with a small camera inside is inserted into your vagina, passed through your cervix and into your womb. Salt water (saline solution) is injected through the tube, to make it easier to see inside your womb.

The camera sends images to a screen, so the hysteroscopist can see what they're doing. You can also watch the screen if you want to.

You may feel sick or faint during the procedure.

If you're in a lot of discomfort or pain, you may be offered gas and air or a local anaesthetic to help with the pain. Or you can ask to stop the procedure at any time.

You may be able to have the test at a later date with local anaesthetic or general anaesthetic, or an injection to relax you (intravenous sedation).

A hysteroscopy usually takes 10 to 15 minutes but can take longer if any tissue samples are taken, or a fibroid or small growth is removed.

Afterwards, you'll be moved to a recovery area until you feel ready to go home.

### Hysteroscopy with general anaesthetic or sedation

If you have a hysteroscopy with a general anaesthetic, you may need to stay in hospital overnight.

If you have a general anaesthetic or intravenous sedation, a friend or family member will need to collect you afterwards. Do not drive yourself.

Recovering from a hysteroscopy
------------------------------

It's normal to have pain, similar to period pain, for a couple of days after a hysteroscopy. Taking paracetamol, ibuprofen or your usual period pain medicine should help.

You may also have some bleeding, or spots of blood (spotting), for up to a week. Use sanitary pads not tampons.

Avoid exercise or having sex until the pain and bleeding has stopped.

Possible complications of a hysteroscopy
----------------------------------------

Most hysteroscopies are quick and safe, without any problems. But like any procedure there's a small chance that something can go wrong.

It happens rarely, but there's a risk of:

*   developing an infection afterwards – this can be treated with antibiotics
*   making a small hole in the wall of the womb when removing a polyp

If there's a hole in the wall of your womb after removing a polyp, you may need to stay in hospital overnight. This often gets better on its own, but sometimes an operation is needed to repair it.

### Urgent advice: Contact the hospital or clinic where you had the procedure urgently if:

*   you have bleeding that gets worse or does not stop after a few days
*   you have tummy pain that gets worse and painkillers or your usual period pain tablets have not helped
*   you have a high temperature
*   you have smelly [vaginal discharge](https://www.nhs.uk/conditions/vaginal-discharge/)

You can also call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Page last reviewed: 18 January 2024  
Next review due: 18 January 2027
