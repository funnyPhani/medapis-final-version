Title: Heartburn and acid reflux

URL Source: https://www.nhs.uk/conditions/heartburn-and-acid-reflux/

Published Time: 23 Oct 2017, 12:10 p.m.

Markdown Content:
**Heartburn is a burning feeling in the chest caused by stomach acid travelling up towards the throat (acid reflux). If it keeps happening, it may be called gastro-oesophageal reflux disease (GORD).**

Check if you have acid reflux
-----------------------------

The main symptoms of acid reflux are:

*   heartburn – a burning sensation in the middle of your chest
*   an unpleasant sour taste in your mouth, caused by stomach acid

You may also have:

*   a cough or hiccups that keep coming back
*   a hoarse voice
*   bad breath
*   bloating and feeling sick

Symptoms are often worse after eating, when lying down and when bending over.

Causes of heartburn and acid reflux
-----------------------------------

Lots of people get heartburn from time to time. There's often no obvious reason why.

Sometimes it's caused or made worse by:

*   certain food and drink – such as coffee, tomatoes, alcohol, chocolate and fatty or spicy foods
*   being overweight
*   smoking
*   pregnancy - find out more about [indigestion and heartburn in pregnancy](https://www.nhs.uk/pregnancy/related-conditions/common-symptoms/indigestion-and-heartburn/)
*   stress and anxiety
*   an increase in some types of hormones, such as progesterone and oestrogen
*   some medicines, such as anti-inflammatory painkillers (like [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/about-ibuprofen-for-adults/))
*   a [hiatus hernia](https://www.nhs.uk/conditions/hiatus-hernia/) – when part of your stomach moves up into your chest
*   a [stomach ulcer](https://www.nhs.uk/conditions/stomach-ulcer/)
*   a bacterial infection in your stomach

How you can ease heartburn and acid reflux yourself
---------------------------------------------------

Simple lifestyle changes can help stop or reduce heartburn.

### Do

*   eat smaller, more frequent meals
    
*   try to lose weight if you're overweight
    
*   try to find ways to relax
    

### Don’t

*   do not have food or drink that triggers your symptoms
    
*   do not eat within 3 or 4 hours before bed
    
*   do not wear clothes that are tight around your waist
    
*   do not smoke
    
*   do not drink too much alcohol
    
*   do not stop taking any prescribed medicine without speaking to a doctor first
    

You may find that using wood, bricks or books to raise the head of your bed by around 10 to 20cm, so your chest and head are above your waist, helps relieve symptoms. This can help stop stomach acid travelling up towards your throat.

But do not try to achieve the same effect by using additional pillows, as this can increase pressure on your belly and make your symptoms worse.

### A pharmacist can help with heartburn and acid reflux

Speak to a pharmacist for advice if you keep getting heartburn.

They may recommend medicines called [antacids](https://www.nhs.uk/conditions/antacids/) or alginates that can help ease your symptoms.

It's best to take these with food or soon after eating, as this is when you're most likely to get heartburn. They may also work for longer if taken with food.

Although antacids and alginates help symptoms in the short term, they will not cure the problem and should not be taken regularly for long periods.

If you're pregnant, a pharmacist can advise you about medicines you can take.

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

### Non-urgent advice: See a GP if:

*   lifestyle changes and pharmacy medicines are not helping your heartburn
*   you have heartburn most days
*   you also have other symptoms, like food getting stuck in your throat, frequently being sick, or losing weight for no reason

A GP can provide alternative or stronger treatments and help rule out any more serious causes of your symptoms.

If at any time you feel your symptoms are getting worse, contact a GP, go to [111.nhs.uk](https://111.nhs.uk/triage/check-your-symptoms) or call 111.

Treatment for heartburn and acid reflux from a GP
-------------------------------------------------

If you have acid reflux, a GP may prescribe a medicine called a proton pump inhibitor (PPI) that reduces how much acid your stomach makes.

PPIs include:

*   [omeprazole](https://www.nhs.uk/medicines/omeprazole/)
*   [lansoprazole](https://www.nhs.uk/medicines/lansoprazole/)

You'll usually need to take this type of medicine for 4 or 8 weeks, depending on how serious your acid reflux is.

Go back to the GP if your symptoms return after stopping your medicine. You may need a long-term prescription.

### Important

If a PPI does not help, your doctor may suggest trying a different type of medicine called an H2 receptor antagonist, such as famotidine.

### Tests and treatments for severe heartburn and acid reflux

If medicines do not help or your symptoms are severe, a GP may refer you to a specialist for:

*   tests to find out what's causing your symptoms, such as a [gastroscopy](https://www.nhs.uk/conditions/gastroscopy/) (where a thin tube with a camera inside it is passed down your throat and into your stomach)
*   tests to check for bacteria that can cause heartburn – this can be treated with a combination of antibiotics and PPIs
*   surgery on your stomach or food pipe (oesophagus) to stop acid reflux

Page last reviewed: 20 November 2023  
Next review due: 20 November 2026
