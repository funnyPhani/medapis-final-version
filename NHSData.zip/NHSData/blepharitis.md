Title: Blepharitis

URL Source: https://www.nhs.uk/conditions/blepharitis/

Published Time: 19 Oct 2017, 3:54 p.m.

Markdown Content:
**Blepharitis causes swollen, itchy eyelids. It’s not usually serious and can often be treated by washing your eyelids every day.**

Check if you have blepharitis
-----------------------------

Blepharitis symptoms often come and go.

Symptoms of blepharitis include:

*   sore eyelids
*   itchy eyes
*   a gritty feeling in the eyes
*   flakes or crusts around the roots of the eyelashes
*   eyelids sticking together in the morning when you wake up

![Image 1: Blepharitis in someone with white skin. There are flakes of skin and crusts along the eyelid and eyelashes, and the eyelid looks slightly red.](https://assets.nhs.uk/nhsuk-cms/images/M1550263.width-320_ukPcJ8s.jpg)

### If you're not sure it's blepharitis

Read more about [eyelid problems](https://www.nhs.uk/conditions/eyelid-problems/).

Things you can do to treat and prevent blepharitis
--------------------------------------------------

### Do

*   clean your eyelids twice a day to start with and then once a day as your symptoms improve
    
*   continue to clean your eyes, even if your symptoms clear up
    

### Don’t

*   do not wear contact lenses while you have symptoms
    
*   do not use eye makeup, especially eyeliner and mascara, while you have symptoms
    

### How to clean your eyes

1.  Soak a clean flannel or cotton wool in warm water and place it on your closed eyelid for 5 to 10 minutes.
2.  Gently massage your eyelids for around 30 seconds.
3.  Clean your eyelids using cotton wool or a cotton bud. It might help to use a small amount of baby shampoo in water. Gently wipe along the edge of your eyelids to remove any flakes or crusts.

A pharmacist can help with blepharitis
--------------------------------------

A pharmacist might be able to suggest things to help keep your eyelids clean, including:

*   eye pads and wipes
*   eyedrops

[Find a pharmacy](https://www.nhs.uk/using-the-nhs/nhs-services/pharmacies/)

Non-urgent advice: See a GP if:
-------------------------------

*   blepharitis symptoms do not improve after a few weeks of cleaning your eyelids

Treatment for blepharitis from a GP
-----------------------------------

A GP might suggest using an antibiotic cream or ointment that you rub on your eyelid if your blepharitis does not clear up after cleaning your eyelids regularly.

If blepharitis has caused other problems, such as a lump of fluid under the skin (cyst), antibiotic eyedrops or tablets may be recommended.

If your blepharitis is severe, or if you also have other eye symptoms, the GP may refer you to an eye specialist (ophthalmologist).

Causes of blepharitis
---------------------

Blepharitis can be caused by:

*   a type of bacteria that lives on the skin
*   a skin condition, such as seborrhoeic dermatitis
*   the glands inside the eyelids not producing enough oil

Blepharitis cannot be spread to other people.

Page last reviewed: 08 February 2022  
Next review due: 08 February 2025
