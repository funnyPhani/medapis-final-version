Title: Down's syndrome

URL Source: https://www.nhs.uk/conditions/downs-syndrome/

Published Time: 23 Oct 2017, 2:29 p.m.

Markdown Content:
Down's syndrome - NHS
===============
                                     

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/downs-syndrome/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

What is Down's syndrome? \- Down's syndrome
===========================================

Contents
--------

1.  What is Down's syndrome?
2.  [Advice for new parents](https://www.nhs.uk/conditions/downs-syndrome/advice-for-new-parents/)
3.  [How to help children and young people](https://www.nhs.uk/conditions/downs-syndrome/how-to-help-children-and-young-people/)
4.  [Support for adults](https://www.nhs.uk/conditions/downs-syndrome/support-for-adults/)
5.  [Support for families and carers](https://www.nhs.uk/conditions/downs-syndrome/support-for-families-and-carers/)
6.  [Other health conditions](https://www.nhs.uk/conditions/downs-syndrome/other-health-conditions/)

**Down's syndrome is when you're born with an extra chromosome.**

You usually get an extra chromosome by chance, because of a change in the sperm or egg before you're born.

This change does not happen because of anything anyone did before or during pregnancy.

What it's like to have Down's syndrome
--------------------------------------

People with Down's syndrome will have some level of [learning disability](https://www.nhs.uk/conditions/learning-disabilities/). This means they'll have a range of abilities.

Some people will be more independent and do things like get a job. Other people might need more regular care.

But, like everyone, people with Down's syndrome have:

*   their own personalities
*   things they like and dislike
*   things that make them who they are

### Having a child with Down's syndrome

3 families share their experience of having a child with Down's syndrome

TranscriptTranscriptAudio DescriptionAudio Description

Video Player is loading.

Play Video

Play

Mute

Current Time 0:00

/

Duration 0:00

Loaded: 0%

0:00

Stream Type LIVE

Seek to live, currently behind liveLIVE

Remaining Time \-0:00

1x

Playback Rate

Chapters

*   Chapters

Descriptions

*   descriptions off, selected
*   English

Subtitles

*   subtitles settings, opens subtitles settings dialog
*   subtitles off, selected

Audio Track

Picture-in-PictureFullscreen

This is a modal window.

Beginning of dialog window. Escape will cancel and close the window.

TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-Transparent

BackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparent

WindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaque

Font Size50%75%100%125%150%175%200%300%400%

Text Edge StyleNoneRaisedDepressedUniformDropshadow

Font FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall Caps

Reset restore all settings to the default valuesDone

Close Modal DialogEnd of dialog window.

Close Modal DialogThis is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

Close Modal DialogThis is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

Displays the text version below the video

Plays the video with descriptive audio

Media last reviewed: 18 March 2022  
Media review due: 18 March 2025

Having a baby with Down's syndrome
----------------------------------

In almost all cases, Down's syndrome does not run in families.

Your chance of having a baby with Down's syndrome increases as you get older, but anyone can have a baby with Down's syndrome.

Speak to a GP if you want to find out more. They may be able to refer you to a [genetic counsellor](https://www.nhs.uk/conditions/genetic-and-genomic-testing/).

### Screening

If you're pregnant, you'll be offered a screening test to find out your chance of having a baby with Down's syndrome.

You'll be offered the test between weeks 10 and 14 of pregnancy. It involves an ultrasound scan with a blood test. The blood test can be carried out at the same time as the [12-week scan](https://www.nhs.uk/pregnancy/your-pregnancy-care/12-week-scan/).

If you have a higher chance, you can have further tests.

### Important

It's your choice whether or not to have any screening tests.

Information:**Find out more about screening:**

*   [NHS website: what to do if screening finds something](https://www.nhs.uk/pregnancy/your-pregnancy-care/if-antenatal-screening-tests-find-something/)
*   [Down's Syndrome Association: screening, diagnosis and support](https://www.downs-syndrome.org.uk/about-downs-syndrome/pregnancy-and-baby/screening-diagnosis-and-support/)

Page last reviewed: 17 February 2023  
Next review due: 17 February 2026

*   [Next : Advice for new parents](https://www.nhs.uk/conditions/downs-syndrome/advice-for-new-parents/)

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
