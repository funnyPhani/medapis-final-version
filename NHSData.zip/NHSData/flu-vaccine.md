Title: Flu vaccine

URL Source: https://www.nhs.uk/vaccinations/flu-vaccine/

Published Time: 6 Mar 2024, 5:39 p.m.

Markdown Content:
This page is about the flu vaccine for adults. There are also pages about the [children's flu vaccine](https://www.nhs.uk/vaccinations/child-flu-vaccine/) and [flu jab in pregnancy](https://www.nhs.uk/pregnancy/keeping-well/flu-jab/).

Who should have the flu vaccine
-------------------------------

The flu vaccine is recommended for people at higher risk of getting seriously ill from [flu](https://www.nhs.uk/conditions/flu/).

It's offered on the NHS every year in autumn or early winter.

You can get the free NHS flu vaccine if you:

*   are aged 65 or over
*   have certain long-term health conditions
*   are pregnant
*   live in a care home
*   are the main carer for an older or disabled person, or receive a carer's allowance
*   live with someone who has a weakened immune system

Frontline health and social care workers can also get a flu vaccine through their employer.

Health conditions that mean you're eligible for the flu vaccine

The flu vaccine is recommended for people with certain long-term health conditions, including:

*   conditions that affect your breathing, such as asthma (needing a steroid inhaler or tablets), chronic obstructive pulmonary disease (COPD) or cystic fibrosis
*   heart conditions, such as coronary heart disease or heart failure
*   chronic kidney disease
*   liver disease, such as cirrhosis or hepatitis
*   some conditions that affect your brain or nerves, such as Parkinson's disease, motor neurone disease, multiple sclerosis or cerebral palsy
*   diabetes or Addison's disease
*   a weakened immune system due to a condition such as HIV or AIDS, or due to a treatment such as chemotherapy or steroid medicine
*   problems with your spleen, such as sickle cell disease, or if you've had your spleen removed
*   a learning disability
*   being very overweight – a body mass index (BMI) of 40 or above

Speak to your GP surgery or specialist if you have a health condition and you're not sure if you're eligible for the flu vaccine.

How to get the flu vaccine
--------------------------

If you're eligible for an NHS flu vaccine, you can get your vaccine from:

*   your GP surgery
*   a pharmacy that offers NHS flu vaccination (if you're aged 18 or over)

Some people may be able to get the vaccine through their maternity service or care home.

The NHS will let you know in autumn or early winter when you can get your flu vaccine.

Frontline health or social care workers

Frontline health and social care workers will usually get the flu vaccine through their employer.

If you cannot get a flu vaccine through your employer, you can get it at a pharmacy or your GP surgery if you're employed:

*   by a registered residential care or nursing home
*   by a registered domiciliary care provider
*   by a voluntary managed hospice provider
*   through direct payments or personal health budgets

Information:

### Having the flu vaccine at the same time as other vaccines

You can have the flu vaccine at the same time as other vaccines such as the COVID-19 vaccine and shingles vaccine.

Who cannot have the flu vaccine
-------------------------------

Most people who are eligible for the flu vaccine can have it.

You only cannot have the vaccine if you've had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a previous dose of the vaccine or an ingredient in the vaccine.

Some of the flu vaccines used in the UK contain egg protein. Tell the person vaccinating you if you have an egg allergy.

Information:

### Getting vaccinated if you're unwell

If you have a high temperature, wait until you're feeling better before having your flu vaccine.

Flu vaccine ingredients
-----------------------

There are several types of flu vaccine given in the UK. If you're eligible for the flu vaccine on the NHS, you'll be offered one of the types that's most appropriate for you.

You can check the ingredients in the patient leaflets.

Vaccines for people aged 65 and over Vaccines for people aged 18 to 64

Side effects of the flu vaccine
-------------------------------

The most common side effects of the flu vaccine are mild and get better within 1 to 2 days.

They can include:

*   pain or soreness where the injection was given
*   a slightly raised temperature
*   an aching body

More serious side effects such as a severe allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) are very rare. The person who vaccinates you will be trained to deal with allergic reactions and treat them immediately.

The injected flu vaccines used in the UK do not contain live flu viruses. They cannot give you flu.

How well the flu vaccine works and how long it lasts
----------------------------------------------------

The flu vaccine aims to protect you against the most common types of flu viruses.

There's still a chance you might get flu after getting vaccinated, but it's likely to be milder and not last as long.

The vaccine usually takes up to 14 days to work.

Protection from the flu vaccine goes down with time and the flu strains the vaccine protects against are updated each year. This is why it's important to get the flu vaccine every year.
