Title: First aid

URL Source: https://www.nhs.uk/conditions/first-aid/

Published Time: 24 Oct 2017, 9:12 a.m.

Markdown Content:
**Every year in the UK, thousands of people die or are seriously injured in incidents. Many deaths could be prevented if first aid was given before emergency services arrive.**

What to do
----------

If someone is injured, you should:

*   first check that you and the injured person aren't in any danger, and, if possible, make the situation safe
*   if necessary, dial 999 for an ambulance when it's safe to do so
*   carry out basic first aid

[Find out what to do after an incident](https://www.nhs.uk/conditions/first-aid/after-an-accident/)

### If someone is unconscious and breathing

If someone is unconscious but breathing, and has no other injuries that would stop them being moved, place them in the [recovery position](https://www.nhs.uk/conditions/first-aid/recovery-position/) until help arrives.

Keep them under observation to ensure they continue to breathe normally.

### If someone is unconscious and not breathing

If someone is not breathing normally, call 999 and start cardiopulmonary resuscitation (CPR) straight away.

[Find out more about CPR](https://www.nhs.uk/conditions/first-aid/cpr/)

Common accidents and emergencies
--------------------------------

Here are some of the most common injuries that may need emergency treatment in the UK and information about how to deal with them.

### Anaphylaxis

[Anaphylaxis (or anaphylactic shock)](https://www.nhs.uk/conditions/anaphylaxis/) is a severe allergic reaction that can occur after an [insect sting](https://www.nhs.uk/conditions/insect-bites-and-stings/) or eating certain foods.

The adverse reaction can be very fast, occurring within seconds or minutes of coming into contact with the substance the person is allergic to (allergen).

During anaphylactic shock, it may be difficult for the person to breathe, as their tongue and throat may swell, obstructing their airway.

**Call 999 immediately if you think someone is experiencing anaphylactic shock.**

Check if the person is carrying any medication. Some people who know they have severe allergies may carry an adrenaline self-injector, which is a type of pre-loaded syringe.

You can either help the person administer their medication or, if you're trained to do so, give it to them yourself.

After the injection, continue to look after the person until medical help arrives.

All casualties who have had an intramuscular or subcutaneous (under the skin) injection of adrenaline must be seen and medically checked by a healthcare professional as soon as possible after the injection has been given.

Make sure they're comfortable and can breathe as best they can while waiting for medical help to arrive.

If they're conscious, sitting upright is normally the best position for them.

[Find out how to treat anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/treatment/)

### Bleeding heavily

If someone is bleeding heavily, the main aim is to prevent further blood loss and minimise the effects of shock.

First, dial 999 and ask for an ambulance as soon as possible.

If you have disposable gloves, use them to reduce the risk of any infection being passed on.

Check that there's nothing embedded in the wound. If there is, take care not to press down on the object.

Instead, press firmly on either side of the object and build up padding around it before bandaging to avoid putting pressure on the object itself.

Do not try to remove it because it may be helping to slow down the bleeding.

If nothing is embedded:

*   Apply and maintain pressure to the wound with your gloved hand, using a clean pad or dressing if possible. Continue to apply pressure until the bleeding stops.
*   Use a clean dressing or any clean, soft material to bandage the wound firmly.
*   If bleeding continues through the pad, apply pressure to the wound until the bleeding stops, and then apply another pad over the top and bandage it in place. Do not remove the original pad or dressing, but continue to check that the bleeding has stopped.

If a body part, such as a finger, has been severed, place it in a plastic bag or wrap it in cling film. Do not wash the severed limb.

Wrap the package in soft fabric and place in a container of crushed ice. Do not let the limb touch the ice.

Make sure the severed limb goes with the patient to hospital.

Always seek medical help for bleeding, unless it's minor.

[Find out how to treat cuts and grazes](https://www.nhs.uk/conditions/cuts-and-grazes/) and [how to treat nosebleeds](https://www.nhs.uk/conditions/nosebleed/).

### Burns and scalds

If someone has a burn or scald:

*   Cool the burn as quickly as possible with cool running water for at least 20 minutes, or until the pain is relieved.
*   Call 999 or seek medical help, if needed.
*   While cooling the burn, and before the area begins to swell, carefully remove any clothing or jewellery, unless it's attached to the skin.
*   If you're cooling a large burnt area, particularly in babies, children and elderly people, be aware that it may cause hypothermia (it may be necessary to stop cooling the burn to avoid hypothermia).
*   If the burn has cooled, cover it loosely with cling film. If cling film isn't available, use a clean, dry dressing or non-fluffy material. Do not wrap the burn tightly as swelling may lead to further injury.
*   Do not apply creams, lotions or sprays to the burn.

If you are not sure if medical help is needed or what to do next, call 111 or [get help from 111 online](https://111.nhs.uk/).

[Find out how to treat burns and scalds](https://www.nhs.uk/conditions/burns-and-scalds/treatment/)

### Chemical burns

For chemical burns, wear protective gloves, remove any affected clothing, and rinse the burn with cool running water for at least 20 minutes to remove the chemical.

If possible, determine the cause of the injury.

In certain situations where a chemical is regularly handled, a specific chemical antidote may be available to use.

Be careful not to contaminate and injure yourself with the chemical, and wear protective clothing if necessary.

**Call 999 for immediate medical help.**

### Choking

The following information is for choking in adults. There is separate advice on [how to stop a child from choking](https://www.nhs.uk/conditions/baby/first-aid-and-safety/first-aid/how-to-stop-a-child-from-choking/).

#### Mild choking

If the airway is only partly blocked, the person will usually be able to speak, cry, cough or breathe.

In situations like this, a person will usually be able to clear the blockage themselves.

If choking is mild:

*   Encourage the person to cough to try to clear the blockage.
*   Ask them to try to spit out the object if it's in their mouth.
*   Do not put your fingers in their mouth if you can't see the object, as you risk pushing it further down their mouth.

If coughing doesn't work, start back blows.

#### Severe choking 

If choking is severe, the person won't be able to speak, cry, cough or breathe, and without help they'll eventually become unconscious. If coughing doesn't work start back blows.

##### How to do back blows

To help an adult or child over 1 year old:

*   Stand behind the person and slightly to one side. Support their chest with 1 hand. Lean the person forward so the object blocking their airway will come out of their mouth, rather than moving further down.
*   Give up to 5 sharp blows between the person's shoulder blades with the heel of your hand (the heel is between the palm of your hand and your wrist).
*   Check if the blockage has cleared.
*   If not, give up to 5 abdominal thrusts.

**Do not give abdominal thrusts to babies under 1 year old or to pregnant women.**

To perform abdominal thrusts on a person who is severely choking and isn't in one of the above groups:

*   Stand behind the person who is choking.
*   Place your arms around their waist and bend them well forward.
*   Clench 1 fist and place it just above the person's belly button.
*   Place your other hand on top of your fist and pull sharply inwards and upwards.
*   Repeat this up to 5 times.

The aim is to get the obstruction out with each chest thrust, rather than necessarily doing all 5.

**If the person's airway is still blocked after trying back blows and abdominal thrusts:**

*   **Call 999 and ask for an ambulance. Tell the 999 operator that the person is choking.**
*   **Continue with the cycles of 5 back blows and 5 abdominal thrusts until help arrives.**

The person choking should always be seen by a healthcare professional afterwards to check for any injuries or small pieces of the obstruction that remain.

### Drowning

If someone is in difficulty in water, don't enter the water unless it's safe to do so. Don't put yourself at risk.

Once the person is on land, you need to check if they're breathing. Ask someone to call 999 for medical help.

If they're not breathing, open the airway and give 5 initial rescue breaths before starting CPR.

[Find out how to give CPR](https://www.nhs.uk/conditions/first-aid/cpr/), including rescue breaths.

If the person is unconscious but still breathing, put them into the [recovery position](https://www.nhs.uk/conditions/first-aid/recovery-position/) with their head lower than their body and call an ambulance immediately.

Continue watching the patient to ensure they don't stop breathing and continue to breathe normally.

### Electric shock (domestic)

If someone has had an electric shock, switch off the electrical current at the mains to break the contact between the person and the electrical supply.

If you can't reach the mains supply:

*   Do not go near or touch the person until you're sure the electrical supply has been switched off.
*   Once the power supply has been switched off, and if the person isn't breathing, dial 999 to for an ambulance.

Afterwards, seek medical help.

### Fractures

It can be difficult to tell if a person has a broken bone or a joint, as opposed to a simple muscular injury. If you're in any doubt, treat the injury as a broken bone.

If the person is unconscious or is bleeding heavily, these must be dealt with first by controlling the bleeding with direct pressure and [performing CPR](https://www.nhs.uk/conditions/first-aid/cpr/). See the section on bleeding heavily above.

If the person is conscious, prevent any further pain or damage by keeping the fracture as still as possible until you get them safely to hospital.

Once you have done this, decide whether the best way to get them to hospital is by ambulance or car.

If the pain isn't too severe, you could transport them to hospital by car. Get someone else to drive if possible so you can care for the person who is injured during the trip.

But call 999 if:

*   they're in a lot of pain and in need of strong painkilling medication – call an ambulance and do not move them
*   it's obvious they have a broken leg – do not move them, but keep them in the position you found them in and call an ambulance
*   you suspect they have injured or broken their back – call an ambulance and do not move them

Do not give the person who is injured anything to eat or drink, as they may need an anaesthetic (numbing medication) when they reach hospital.

Find out more about:

*   [broken ankle](https://www.nhs.uk/conditions/broken-ankle/)
*   [broken arm or wrist](https://www.nhs.uk/conditions/broken-arm-or-wrist/)
*   [broken collarbone](https://www.nhs.uk/conditions/broken-collarbone/)
*   [broken nose](https://www.nhs.uk/conditions/broken-nose/)
*   [broken toe](https://www.nhs.uk/conditions/broken-toe/)
*   [broken ribs](https://www.nhs.uk/conditions/broken-or-bruised-ribs/)
*   [hip fracture](https://www.nhs.uk/conditions/broken-hip/)

### Heart attack

A [heart attack](https://www.nhs.uk/conditions/heart-attack/) is one of the most common life-threatening heart conditions in the UK.

**If you think someone is having or has had a heart attack, call 999 and then move them into a comfortable sitting position.**

Symptoms of a heart attack include:

*   chest pain – the pain is usually located in the centre or left side of the chest and can feel like a sensation of pressure, tightness or squeezing
*   pain in other parts of the body – it can feel as if the pain is travelling from the chest down 1 or both arms, or into the jaw, neck, back or abdomen (tummy)

Sit the person down and make them comfortable.

If they can, it's best for them to sit on the floor with their knees bent and their head and shoulders supported. If possible, place cushions behind them or under their knees.

If they're conscious, reassure them and ask them to take a 300mg aspirin tablet to chew slowly, (unless you know they shouldn't take aspirin, for example if they are under 16 or they say they are allergic to it).

If the person has any medication for [angina](https://www.nhs.uk/conditions/angina/), help them to take it.

Monitor their vital signs, such as their breathing, until help arrives.

If the person deteriorates and becomes unconscious, open their airway, check their breathing and, if necessary, start [CPR](https://www.nhs.uk/conditions/first-aid/cpr/).

**Call 999 to tell them you think the person is now in cardiac arrest (their heart has stopped beating).**

### **Needlestick injuries**

If you pierce your skin with a used needle:

*   gently squeeze the wound to encourage it to bleed (ideally while holding it under running water)
*   wash the wound using running water and plenty of soap
*   do not scrub or suck the wound
*   dry the wound and cover it with a waterproof plaster or dressing

Get urgent medical advice from [NHS 111 online](https://111.nhs.uk/triage/check-your-symptoms), calling 111, or going to [your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/). You may need treatment to reduce the risk of getting an infection.

If you injure yourself at work, contact your employer's occupational health service.

[Find out more about sharps injuries on the Health and Safety Executive (HSE) website](https://www.hse.gov.uk/healthservices/needlesticks/index.htm).

### Poisoning

[Poisoning](https://www.nhs.uk/conditions/poisoning/) is potentially life threatening.

Common causes of poisoning include:

*   swallowing a toxic substance, such as bleach
*   taking an overdose of a prescription medicine
*   eating something, like wild plants and fungi

[Alcohol poisoning](https://www.nhs.uk/conditions/alcohol-poisoning/) can cause similar symptoms.

**If you think someone has swallowed a poisonous substance, call 999 to get immediate medical help and advice.**

The effects of poisoning depend on the substance swallowed, but can include vomiting, loss of consciousness, pain or a burning sensation.

The following advice is important:

*   Find out what's been swallowed so you can tell the paramedic or doctor.
*   Do not give the person anything to eat or drink unless a healthcare professional advises you to.
*   Do not try to cause vomiting.
*   Stay with the person, as their condition may get worse and they could become unconscious.

If the person becomes unconscious while you're waiting for help to arrive, check for breathing and, if necessary, [perform CPR](https://www.nhs.uk/conditions/first-aid/cpr/).

Do not perform mouth-to-mouth resuscitation if the person's mouth or airway is contaminated with the poison.

Do not leave them if they're unconscious: they could vomit. The vomit could then enter their lungs and make them choke.

If they do vomit naturally, try to collect some of it for the ambulance crew – this may help identify the cause of the poisoning.

If the patient is conscious and breathing normally, put them into the [recovery position](https://www.nhs.uk/conditions/first-aid/recovery-position/) and keep checking they're breathing normally.

Find out more about [treatment for poisoning](https://www.nhs.uk/conditions/poisoning/treatment/) and [alcohol poisoning](https://www.nhs.uk/conditions/alcohol-poisoning/).

### Shock

In the case of a serious injury or illness, it's important to look out for signs of shock.

Shock is a life-threatening condition that occurs when the circulatory system fails to provide enough oxygenated blood to the body and, as a result, deprives the vital organs of oxygen.

This is usually the result of severe blood loss, but it can also occur after severe burns, severe vomiting, a heart attack, a bacterial infection, or a severe allergic reaction (anaphylaxis).

The type of shock described here isn't the same as the emotional response of feeling shocked, which can also occur after an accident.

Signs of shock include:

*   pale, cold, clammy skin
*   sweating
*   rapid, shallow breathing
*   weakness and dizziness
*   feeling sick and possibly vomiting
*   thirst
*   yawning
*   sighing

Seek medical help immediately if you notice that someone has any of these signs of shock.

You should:

*   call 999 as soon as possible and ask for an ambulance
*   treat any obvious injuries
*   lie the person down if their injuries allow you to and, if possible, raise and support their legs
*   use a coat or blanket to keep them warm
*   do not give them anything to eat or drink
*   give them lots of comfort and reassurance
*   monitor the person – if they stop breathing, start [CPR](https://www.nhs.uk/conditions/first-aid/cpr/) and call 999 to update them

### Stroke

The FAST guide is the most important thing to remember when dealing with people who have had a [stroke](https://www.nhs.uk/conditions/stroke/).

The earlier they receive treatment, the better. Call for emergency medical help straight away.

If you think a person has had a stroke, use the FAST guide:

*   Face – the face may have dropped on 1 side, the person may not be able to smile, or their mouth or eye may have drooped.
*   Arms – the person with suspected stroke may not be able to lift both arms and keep them there because of weakness or numbness in 1 arm.
*   Speech – their speech may be slurred or garbled, or the person may not be able to talk at all despite appearing to be awake.
*   Time – it's time to dial 999 immediately if you notice any of these signs or symptoms.

If a person had symptoms of a stroke but they do not have them now, you should still call 999 as it may have been a mini-stroke (also called a [transient ischaemic attack or TIA](https://www.nhs.uk/conditions/transient-ischaemic-attack-tia/)).

Find out more about the [symptoms of a stroke](https://www.nhs.uk/conditions/stroke/symptoms/).

Calling 999 to get help in an emergency
---------------------------------------

When you call 999, you'll be asked what service you need, as well as:

*   your telephone number
*   the address you're calling from
*   a brief description of what's wrong with the person and whether they're bleeding, unconscious or not breathing

The call handler may advise you on what you can do until help arrives.

Page last reviewed: 15 March 2022  
Next review due: 15 March 2025
