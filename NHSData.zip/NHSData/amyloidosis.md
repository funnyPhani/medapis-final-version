Title: Amyloidosis

URL Source: https://www.nhs.uk/conditions/amyloidosis/

Published Time: 17 Oct 2017, 4:48 p.m.

Markdown Content:
**Amyloidosis is a group of rare conditions where a protein called amyloid builds up in your body. It can affect organs such as your heart, kidneys, liver, nerves or digestive system. It cannot be cured, but there are treatments that may help with symptoms.**

Symptoms of amyloidosis
-----------------------

Common symptoms of amyloidosis include:

*   feeling very tired or weak
*   losing weight without trying to
*   shortness of breath
*   swollen feet or legs
*   bruising around your eyes

Other symptoms depend on which parts of your body are affected, so you may not have all the symptoms. They can include:

*   a fast or slow heartbeat or chest pain, if your heart is affected
*   loss of appetite, feeling or being sick, diarrhoea or constipation, if your digestive system is affected
*   frothy pee, if your kidneys are affected
*   pain, numbness or tingling in your hands and feet, if your nerves are affected

### Important

These symptoms can be caused by many different conditions. Having them does not definitely mean you have amyloidosis. But it's important to get them checked by a GP.

Non-urgent advice: See a GP if:
-------------------------------

*   you have symptoms of amyloidosis

How you get amyloidosis
-----------------------

There are several types of amyloidosis, with different causes.

Causes of the main types of amyloidosis
| Type | Cause |
| --- | --- |
| AL amyloidosis
 | A problem with your bone marrow. Sometimes linked with [multiple myeloma](https://www.nhs.uk/conditions/multiple-myeloma/), a type of bone marrow cancer.

 |
| AA amyloidosis

 | Long-term inflammatory conditions such as [rheumatoid arthritis](https://www.nhs.uk/conditions/rheumatoid-arthritis/), [Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/) or [ulcerative colitis](https://www.nhs.uk/conditions/ulcerative-colitis/), or infectious diseases such as [tuberculosis (TB)](https://www.nhs.uk/conditions/tuberculosis-tb/).

 |
| Hereditary ATTR amyloidosis

 | An inherited genetic condition.

 |
| Wild-type ATTR amyloidosis

 | Develops as you get older, usually affecting men over 75 years old.

 |
| Beta-2 microglobulin amyloidosis

 | Having long-term [dialysis](https://www.nhs.uk/conditions/dialysis/).

 |

Tests for amyloidosis
---------------------

If a GP thinks you may have amyloidosis they'll refer you to a specialist. You may be seen in a specialist amyloidosis treatment centre.

Amyloidosis is often hard to diagnose because the symptoms vary and are similar to other conditions.

You'll usually have tests such as:

*   [blood tests](https://www.nhs.uk/conditions/blood-tests/) and urine tests
*   tests such as an [electrocardiogram (ECG)](https://www.nhs.uk/conditions/electrocardiogram/), [echocardiogram](https://www.nhs.uk/conditions/echocardiogram/) or [MRI scan](https://www.nhs.uk/conditions/mri-scan/), to check your heart and other organs
*   a [biopsy](https://www.nhs.uk/conditions/biopsy/), where a small sample of cells is removed and tested to check for amyloid
*   a type of scan called a SAP scan, to show where amyloid has built up in your body
*   [genetic testing](https://www.nhs.uk/conditions/genetic-and-genomic-testing/) to find out if you have a hereditary type of amyloidosis

These tests will show what type of amyloidosis you have and how it's affecting you.

Treatments for amyloidosis
--------------------------

There's no cure for amyloidosis, but some types can be managed well through treatment to improve the symptoms. But for some people, amyloidosis eventually leads to organs such as your heart or kidneys no longer working properly.

Your doctor will explain your treatment options and what to expect.

If your amyloidosis is caused by another health condition, such as rheumatoid arthritis, treating the condition can improve your symptoms.

Other treatments depend on what type of amyloidosis you have and what parts of your body are affected. Treatments may include:

*   medicines to help with symptoms, such as painkillers, anti-sickness medicines, or medicines that reduce swelling (diuretics)
*   medicines to reduce the amount of amyloid your body produces
*   kidney [dialysis](https://www.nhs.uk/conditions/dialysis/), if your kidneys are not working properly
*   a kidney transplant or liver transplant, if these organs are damaged

### Treatments for AL amyloidosis

If you have AL amyloidosis, caused by a problem with your bone marrow, you may be offered:

*   [chemotherapy](https://www.nhs.uk/conditions/chemotherapy/) to destroy the blood cells in your bone marrow that cause the condition
*   a [stem cell or bone marrow transplant](https://www.nhs.uk/conditions/stem-cell-transplant/)

Recording information about you and your condition
--------------------------------------------------

If you have amyloidosis, your care team will pass information on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://digital.nhs.uk/ndrs/about/ncardrs).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

Page last reviewed: 23 August 2023  
Next review due: 23 August 2026
