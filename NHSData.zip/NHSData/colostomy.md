Title: Colostomy

URL Source: https://www.nhs.uk/conditions/colostomy/

Published Time: 23 Oct 2017, 11 a.m.

Markdown Content:
**A colostomy is an operation to divert 1 end of the colon (part of the bowel) through an opening in the tummy.**

The opening is called a stoma. A pouch can be placed over the stoma to collect your poo (stools).

A colostomy can be permanent or temporary.

When a colostomy is needed
--------------------------

A colostomy may be needed if you cannot pass stools through your anus. This could be the result of an illness, injury or problem with your digestive system.

You may have a colostomy to treat:

*   [bowel cancer](https://www.nhs.uk/conditions/bowel-cancer/)
*   [Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/)
*   [diverticulitis](https://www.nhs.uk/conditions/diverticular-disease-and-diverticulitis/)
*   [anal cancer](https://www.nhs.uk/conditions/anal-cancer/)
*   [vaginal cancer](https://www.nhs.uk/conditions/vaginal-cancer/treatment/) or [cervical cancer](https://www.nhs.uk/conditions/cervical-cancer/treatment/)
*   [bowel incontinence](https://www.nhs.uk/conditions/bowel-incontinence/)
*   [Hirschsprung's disease](https://www.nhs.uk/conditions/hirschsprungs-disease/)

A colostomy is often used after a section of the colon has been removed and the bowel cannot be joined back together.

This may be temporary and followed by another operation to reverse the colostomy at a later date, or it may be permanent.

[Read more about reversing a colostomy](https://www.nhs.uk/conditions/colostomy/reversal/)

How a colostomy is carried out 
-------------------------------

A colostomy is carried out while you're asleep under [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/), using either:

*   **open surgery (laparotomy)** – where a long cut (incision) is made in the tummy to access the colon, or
*   **laparoscopic (keyhole surgery)** – where the surgeon makes several smaller incisions and uses a tiny camera and surgical instruments to access the colon

Generally, keyhole surgery is the preferred option because recovery is quicker and the risk of complications is lower.

There are 2 main types of colostomy: a loop colostomy and an end colostomy. The specific technique used will depend on your circumstances.

A loop colostomy is often used if the colostomy is temporary as it's easier to reverse.

### Loop colostomy

In a loop colostomy, a loop of colon is pulled out through a cut in your tummy. The loop is opened up and stitched to your skin to form an opening called a stoma.

The stoma has 2 openings that are close together. One is connected to the functioning part of your bowel, where waste leaves your body after the operation.

The other opening is connected to the inactive part of your bowel, leading to your anus.

In some cases, a support device (a rod or bridge) may be used to hold the loop of colon in place while it heals. It's usually removed after a few days.

### End colostomy

With an end colostomy, 1 end of the colon is pulled out through a cut in your tummy and stitched to the skin to create a stoma.

An end colostomy is often permanent. Temporary end colostomies are sometimes used in emergencies.

### The stoma

The position of the stoma will depend on the section of your colon that's diverted, but it's usually on the left-hand side of your tummy, below your waist.

If the operation is planned in advance, you'll meet a specialist stoma nurse to discuss the positioning of the stoma.

The stoma will be red and moist and may bleed slightly, particularly in the beginning – this is normal. It should not be painful as it does not have a nerve supply.

Recovering from a colostomy
---------------------------

After having a colostomy, you'll need to recover in hospital for a few days.

You may have:

*   a drip in your vein to provide fluids
*   a [catheter](https://www.nhs.uk/conditions/urinary-catheters/) to drain urine from your bladder
*   an oxygen mask to help you breathe

A clear colostomy bag will be placed over the stoma so it can be easily monitored and drained. The first bag is often quite large – it'll usually be replaced with a smaller bag before you go home.

### Stoma nurse

While you recover in hospital, a stoma nurse will show you how to care for your stoma, including how to empty and change the bag.

The nurse will teach you how to keep your stoma and surrounding skin clean and free from irritation, and give you advice about preventing infection.

They'll also explain the different types of equipment available and how to get new supplies.

When you leave hospital, a local stoma nurse will visit you at home, or you may be asked to go to a stoma care clinic.

### Going home

Most people are well enough to leave hospital 3 to 10 days after having a colostomy.

Once home, avoid strenuous activities that could place a strain on your abdomen, such as lifting heavy objects.

Your stoma nurse will give you advice about how soon you can go back to normal activities.

At first you will pass wind through your stoma and then, usually within 2 or 3 days, you poo through it.

This should start to improve as your bowel recovers from the effects of the operation.

Living with a colostomy
-----------------------

Adjusting to life with a colostomy can be challenging, but most people get used to it in time.

Colostomy equipment is discreet and secure, and you should be able to do most of the activities you enjoyed before.

Your specialist stoma nurse will be able to give you further support and advice to help you adapt to life with a colostomy.

Read more about [living with a colostomy](https://www.nhs.uk/conditions/colostomy/living-with/) and [complications of a colostomy](https://www.nhs.uk/conditions/colostomy/risks/).

### Colostomy UK

[Colostomy UK](http://www.colostomyuk.org/) provides support, reassurance and practical advice to anyone who's had, or is about to have, stoma surgery.

Their website has information about products you may find useful, and also provides details of [stoma support groups](http://www.colostomyuk.org/support-groups/) in your area.

Page last reviewed: 16 September 2020  
Next review due: 16 September 2023
