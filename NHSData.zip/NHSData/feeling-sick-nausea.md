Title: Feeling sick (nausea)

URL Source: https://www.nhs.uk/conditions/feeling-sick-nausea/

Published Time: 4 May 2018, 9:35 a.m.

Markdown Content:
**Feeling sick (nausea) is common and usually goes away on its own. There are some things you can try that might help.**

Things that may help you stop feeling sick
------------------------------------------

### Do

*   get plenty of fresh air
    
*   distract yourself – for example, listen to music or watch a film
    
*   take regular sips of a cold drink
    
*   drink ginger or peppermint tea
    
*   eat foods containing ginger – such as ginger biscuits
    
*   eat smaller, more frequent meals
    

### Don’t

*   do not eat or cook strong-smelling food
    
*   do not eat hot, fried or greasy food
    
*   do not eat too quickly
    
*   do not have a large drink with meals
    
*   do not lie down soon after eating
    
*   do not wear clothes that are tight around your waist or tummy
    

Non-urgent advice: See a GP if you:
-----------------------------------

*   are feeling sick and do not feel better in a few days
*   often feel sick (it keeps coming back)

The GP can look for the cause and suggest treatments.

They may prescribe anti-sickness medicine if needed.

Call 111 for advice if you cannot see a GP.

Immediate action required: Call 999 if:
---------------------------------------

You suddenly feel sick and have:

*   chest pain that feels tight or heavy
*   pain that spreads to your arms, back, neck or jaw
*   shortness of breath

This could be a heart attack.

Common causes of feeling sick
-----------------------------

Lots of things can make you feel sick.

Any other symptoms you have may give you an idea of the cause. But do not self-diagnose – see a GP if you're worried.

Other reasons for feeling sick include:

*   pregnancy ([morning sickness](https://www.nhs.uk/pregnancy/related-conditions/common-symptoms/vomiting-and-morning-sickness/))
*   [motion sickness](https://www.nhs.uk/conditions/motion-sickness/)
*   [anxiety](https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/feelings-and-symptoms/anxiety-fear-panic/)
*   alcohol
*   medicines
*   recent surgery

Information:

Do not worry if you're not sure what's causing you to feel sick. Try the things that may stop you feeling sick and see a GP if you do not feel better in a few days.

Page last reviewed: 17 November 2023  
Next review due: 17 November 2026
