Title: Chemotherapy

URL Source: https://www.nhs.uk/conditions/chemotherapy/

Published Time: 20 Oct 2017, 4:24 p.m.

Markdown Content:
**Chemotherapy is a cancer treatment where medicine is used to kill cancer cells.**

There are many different types of chemotherapy medicine, but they all work in a similar way.

They stop [cancer](https://www.nhs.uk/conditions/cancer/) cells reproducing, which prevents them from growing and spreading in the body.

When chemotherapy is used
-------------------------

Chemotherapy may be used if cancer has spread or there's a risk it will.

It can be used to:

*   try to cure the cancer completely (curative chemotherapy)
*   make other treatments more effective – for example, it can be combined with [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) (chemoradiation) or used before surgery (neo-adjuvant chemotherapy)
*   reduce the risk of the cancer coming back after radiotherapy or surgery (adjuvant chemotherapy)
*   relieve symptoms if a cure is not possible (palliative chemotherapy)

The effectiveness of chemotherapy varies significantly. Ask your doctors about the chances of treatment being successful for you.

Types of chemotherapy
---------------------

Chemotherapy can be given in several ways. Your doctors will recommend the best type for you.

The most common types are:

*   chemotherapy given into a vein (intravenous chemotherapy) – this is usually done in hospital and involves medicine being given through a tube in a vein in your hand, arm or chest
*   chemotherapy tablets (oral chemotherapy) – this usually involves taking a course of medicine at home, with regular check-ups in hospital

You may be treated with one type of chemotherapy medicine or a combination of different types.

You'll usually have several treatment sessions, which will typically be spread over the course of a few months.

Side effects of chemotherapy
----------------------------

As well as killing cancer cells, chemotherapy can damage some healthy cells in your body, such as blood cells, skin cells and cells in the stomach.

This can cause a range of unpleasant side effects, such as:

*   feeling tired most of the time
*   feeling and being sick
*   [hair loss](https://www.nhs.uk/conditions/chemotherapy/cancer-and-hair-loss/)
*   an increased risk of getting infections
*   a sore mouth
*   dry, sore or itchy skin
*   [diarrhoea](https://www.nhs.uk/conditions/diarrhoea-and-vomiting/) or [constipation](https://www.nhs.uk/conditions/constipation/)

Many of these side effects can be treated or prevented and most, if not all, will pass after treatment stops.

Page last reviewed: 25 May 2023  
Next review due: 25 May 2026
