Title: Appendicitis

URL Source: https://www.nhs.uk/conditions/appendicitis/

Published Time: 20 Oct 2017, 3:55 p.m.

Markdown Content:
**Appendicitis is a painful swelling of the appendix. The appendix is a small, thin pouch about 5 to 10cm (2 to 4 inches) long. It's connected to the large intestine, where poo forms.**

Nobody knows exactly what the appendix does, but removing it is not harmful.

Symptoms of appendicitis
------------------------

Appendicitis typically starts with a pain in the middle of your tummy (abdomen) that may come and go.

Within hours, the pain travels to the lower right-hand side, where the appendix usually lies, and becomes constant and severe.

Pressing on this area, coughing or walking may make the pain worse.

You may lose your appetite, feel sick and have [constipation](https://www.nhs.uk/conditions/constipation/) or [diarrhoea](https://www.nhs.uk/conditions/diarrhoea-and-vomiting/).

When to get medical help
------------------------

If you have abdominal pain that's gradually getting worse, contact a GP or your local [out-of-hours service](https://www.nhs.uk/nhs-services/urgent-and-emergency-care-services/nhs-out-of-hours-services/) immediately.

If these options are not available, call [NHS 111](https://www.nhs.uk/nhs-services/urgent-and-emergency-care-services/when-to-use-111/) for advice.

Call 999 to ask for an ambulance if you have pain that suddenly gets worse and spreads across your abdomen, or if your pain temporarily improves before getting worse again.

If your pain eases for a while but then gets worse, your appendix may have burst, which can lead to life-threatening complications.

Read more about [diagnosing appendicitis](https://www.nhs.uk/conditions/appendicitis/diagnosis/) and [complications of appendicitis](https://www.nhs.uk/conditions/appendicitis/complications/).

How appendicitis is treated
---------------------------

If you have appendicitis, it's likely your appendix will need to be removed as soon as possible.

Removal of the appendix, known as an appendicectomy or appendectomy, is 1 of the most common operations in the UK and its success rate is excellent.

It's most commonly carried out as keyhole surgery ([laparoscopy](https://www.nhs.uk/conditions/laparoscopy/)).

Several small cuts are made in the abdomen, allowing special surgical instruments to be inserted.

Open surgery, where a larger, single cut is made in the abdomen, is usually used if the appendix has burst or access is more difficult.

It usually takes a couple of weeks to make a full recovery after your appendix has been removed.

But strenuous activities may need to be avoided for up to 6 weeks after having open surgery.

What causes appendicitis?
-------------------------

It's not clear what causes appendicitis. In many cases it may be that something blocks the entrance of the appendix.

For example, it could become blocked by a small piece of poo, or an upper [respiratory tract infection](https://www.nhs.uk/conditions/respiratory-tract-infection/) could cause the lymph node within the wall of the bowel to become swollen.

If the obstruction causes inflammation and swelling, it could lead to increased pressure within the appendix, which may then burst.

As the causes of appendicitis are not fully understood, there's no guaranteed way of preventing it.

Who's affected
--------------

Appendicitis is a common condition. In England, around 50,000 people are admitted to hospital with appendicitis each year.

You can get appendicitis at any age, but it usually affects people aged between 10 and 30 years.

Video: what is appendicitis?
----------------------------

Watch this animation to learn about what causes appendicitis and how it's treated.

Media last reviewed: 1 May 2021  
Media review due: 1 May 2024

Page last reviewed: 21 October 2022  
Next review due: 21 October 2025
