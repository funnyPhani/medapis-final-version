Title: Atopic eczema

URL Source: https://www.nhs.uk/conditions/atopic-eczema/

Published Time: 19 Oct 2017, 4:22 p.m.

Markdown Content:
**Atopic eczema (atopic dermatitis) is one of the most common forms of eczema, a condition that causes the skin to become itchy, dry and cracked.**

Atopic eczema is the most common type of eczema in children, often developing before their first birthday. But it may also develop for the first time in adults.

It's usually a long-term (chronic) condition, although it can improve significantly, or even clear completely, in some children as they get older.

Symptoms of atopic eczema
-------------------------

Atopic eczema causes the skin to become itchy, dry, cracked and sore.

Some people only have small patches of dry skin, but others may experience widespread inflamed skin all over the body.

Inflamed skin can look red on white skin, and darker brown, purple or grey on brown and black skin. This means it may also be more difficult to see on brown and black skin.

Although atopic eczema can affect any part of the body, it most often affects the hands in adults, and the inside of the elbows, backs of the knees and the face and scalp in children. It may also affect the outside of elbows and front of knees in children with brown and black skin.

People with atopic eczema usually have periods when symptoms are less noticeable, as well as periods when symptoms become more severe (flare-ups).

When to seek medical advice
---------------------------

See a GP if you have symptoms of atopic eczema. They'll usually be able to diagnose atopic eczema by looking at your skin and asking:

*   whether the rash is itchy and where it appears
*   when the symptoms first began
*   whether it comes and goes over time
*   whether there's a history of atopic eczema in your family
*   whether you have any other conditions, such as [allergies](https://www.nhs.uk/conditions/allergies/) or [asthma](https://www.nhs.uk/conditions/asthma/)
*   whether something in your diet or lifestyle may be contributing to your symptoms

Typically, you or your child will be diagnosed with atopic eczema if you, or they, have an itchy skin condition and 3 or more of the following:

*   visibly irritated red skin in the creases of your skin – such as the insides of your elbows or behind your knees (or on the cheeks, outsides of elbows, or fronts of the knees in children aged 18 months or under, and children with brown and black skin) at the time of examination by a health professional
*   a history of skin irritation occurring in the same areas mentioned above
*   generally dry skin in the last 12 months (in children)
*   a history of asthma or [hay fever](https://www.nhs.uk/conditions/hay-fever/) – children under 4 must have an immediate relative, such as a parent, brother or sister, who has 1 of these conditions
*   if your child is 4 years old or older and the condition started before the age of 2

Causes of atopic eczema
-----------------------

The exact cause of atopic eczema is unknown, but it's clear it is not down to one single thing.

Atopic eczema often occurs in people who get [allergies](https://www.nhs.uk/conditions/allergies/). "Atopic" means sensitivity to allergens.

It can run in families, and often develops alongside other conditions, such as [asthma](https://www.nhs.uk/conditions/asthma/) and [hay fever](https://www.nhs.uk/conditions/hay-fever/).

The symptoms of atopic eczema often have certain triggers, such as soaps, detergents, stress and the weather.

Sometimes [food allergies](https://www.nhs.uk/conditions/food-allergy/) can play a part, especially in young children with severe eczema.

You may be asked to keep a food diary to try to determine whether a specific food makes your symptoms worse.

[Allergy tests](https://www.nhs.uk/conditions/allergies/) are not usually needed, although they're sometimes helpful in identifying whether a food allergy may be triggering symptoms.

Treating atopic eczema
----------------------

Treatment for atopic eczema can help to relieve the symptoms, and the condition often improves over time.

But there's currently no cure and severe eczema often has a significant impact on daily life, which may be difficult to cope with physically and mentally.

There's also an increased risk of skin infections.

Many different treatments can be used to control symptoms and manage eczema, including:

*   self-care techniques, such as reducing scratching and avoiding triggers
*   [emollients](https://www.nhs.uk/conditions/emollients/) (moisturising treatments) – used on a daily basis for dry skin
*   [topical corticosteroids](https://www.nhs.uk/conditions/steroids/) – used to reduce swelling, redness and itching during flare-ups

Other types of eczema
---------------------

Eczema is the name for a group of skin conditions that cause dry, irritated skin.

Other types of eczema include:

*   [discoid eczema](https://www.nhs.uk/conditions/discoid-eczema/) – a type of eczema that occurs in circular or oval patches on the skin
*   [contact dermatitis](https://www.nhs.uk/conditions/contact-dermatitis/) – a type of eczema that occurs when the body comes into contact with a particular substance
*   [varicose eczema](https://www.nhs.uk/conditions/varicose-eczema/) – a type of eczema that most often affects the lower legs and is caused by problems with the flow of blood through the leg veins
*   [seborrhoeic eczema](https://www.nhs.uk/conditions/dandruff/) – a type of eczema where red, scaly patches develop on the sides of the nose, eyebrows, ears and scalp
*   [dyshidrotic eczema](https://www.nhs.uk/conditions/pompholyx/) (pompholyx) – a type of eczema that causes tiny blisters to erupt across the palms of the hands and bottom (soles) of the feet

Page last reviewed: 13 November 2023  
Next review due: 13 November 2026
