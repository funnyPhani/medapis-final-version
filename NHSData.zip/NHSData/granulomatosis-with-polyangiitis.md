Title: Granulomatosis with polyangiitis (GPA)

URL Source: https://www.nhs.uk/conditions/granulomatosis-with-polyangiitis/

Published Time: 18 Oct 2017, 2:33 p.m.

Markdown Content:
GPA was previously called Wegener's granulomatosis.

Symptoms of granulomatosis with polyangiitis (GPA)
--------------------------------------------------

Granulomatosis with polyangiitis (GPA) is a type of [vasculitis](https://www.nhs.uk/conditions/vasculitis/), which is an inflammation of the blood vessels.

Symptoms vary between people, and can be mild or severe. In some people, they come on slowly over many months, and in others they appear suddenly.

General symptoms may be mild and start before symptoms in specific parts of the body. They can include:

*   high temperature
*   night sweats
*   feeling weak and tired
*   joint pain
*   loss of appetite
*   weight loss

Other symptoms depend on which parts of your body are affected, so you may not have all the symptoms.

Symptoms that may affect specific parts of the body
| Body part | Possible symptoms |
| --- | --- |
| Ears, nose and sinuses
 | Ear infection, hearing loss, blocked or runny nose, crusting of blood and mucus in the nose, nosebleeds, sinus pain

 |
| Eyes

 | Conjunctivitis, swollen eyelids, double vision, blurred vision

 |
| Lungs

 | A cough that does not go away, coughing up blood, shortness of breath, chest pain, wheezing

 |
| Kidneys

 | High blood pressure, swelling in the legs, kidney failure

 |
| Skin

 | Rashes, ulcers, small spots

 |
| Stomach

 | Tummy pain, diarrhoea, blood in poo

 |

### Important

Some of these symptoms are very common and can be caused by other conditions.

Having the symptoms does not definitely mean you have GPA, but it's important to get checked by a GP.

Non-urgent advice: See a GP if:
-------------------------------

*   you have symptoms of granulomatosis with polyangiitis (GPA)

If you have been diagnosed with GPA, and have new or returning symptoms, see the specialist treating you.

Tests for granulomatosis with polyangiitis (GPA)
------------------------------------------------

There's no single test for granulomatosis with polyangiitis (GPA) and it can be difficult to diagnose.

A GP will ask about your symptoms and may examine the affected part of your body. If they think you could have GPA they'll refer you to a specialist.

You'll have tests such as:

*   a [blood test](https://www.nhs.uk/conditions/blood-tests/) to see if you have an antibody called ANCA (antineutrophil cytoplasmic antibodies), which may be a sign of GPA
*   a [biopsy](https://www.nhs.uk/conditions/biopsy/), where a small sample of tissue from any affected body parts is sent for testing
*   an [X-ray](https://www.nhs.uk/conditions/x-ray/), [CT scan](https://www.nhs.uk/conditions/ct-scan/) or [MRI scan](https://www.nhs.uk/conditions/mri-scan/) of any affected body parts
*   a urine (pee) test if you have symptoms affecting your kidneys

Treatments for granulomatosis with polyangiitis (GPA)
-----------------------------------------------------

You'll be treated by a specialist if you have granulomatosis with polyangiitis (GPA).

Treatment depends on how severe it is and the body parts affected.

There are 2 stages of treatment – bringing the condition under control and keeping it under control.

### Stage 1: Bringing the condition under control

If you have mild GPA, you may be given an anti-inflammatory medicine called a [steroid](https://www.nhs.uk/conditions/steroids/) to control your symptoms. You may also have an immunosuppressant medicine such as [methotrexate](https://www.nhs.uk/medicines/methotrexate/).

If you have severe GPA, you may be given a biological medicine such as rituximab or avacopan, or both, along with steroids.

You may also be given a type of chemotherapy medicine, such as cyclophosphamide, to bring it under control.

### Stage 2: Keeping the condition under control

Once the condition is under control, treatment aims to stop your symptoms coming back.

You may have lower doses of your medicines or take a different type of medicine.

### Treating symptoms if they come back

If your symptoms come back or you get new symptoms (a relapse), your treatment may be changed or restarted.

### Treating severe cases

In very severe cases that affect the kidneys, you may need [dialysis](https://www.nhs.uk/conditions/dialysis/) or a kidney transplant.

You may also need surgery to the affected body part if you have complications from GPA, for example reconstructive surgery if the bridge of the nose has been damaged.

Recording information about you and your condition
--------------------------------------------------

If you have granulomatosis with polyangiitis (GPA), your care team will pass information on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://digital.nhs.uk/ndrs/about/ncardrs).

It's used to help scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

Get support for granulomatosis with polyangiitis (GPA)
------------------------------------------------------

For more information and advice about granulomatosis with polyangiitis (GPA), visit the Vasculitis UK website:

*   [Vasculitis UK: Granulomatosis with polyangiitis (GPA)](https://www.vasculitis.org.uk/about-vasculitis/gpa-granulomatosis-with-polyangiitis)
*   [Vasculitis UK: Living with vasculitis](https://www.vasculitis.org.uk/living-with-vasculitis)

Page last reviewed: 28 May 2024  
Next review due: 28 May 2027
