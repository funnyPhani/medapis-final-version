Title: Bleeding from the bottom (rectal bleeding)

URL Source: https://www.nhs.uk/conditions/bleeding-from-the-bottom-rectal-bleeding/

Published Time: 20 Oct 2017, 2:30 p.m.

Markdown Content:
**A small amount of one-off bleeding from the bottom is not usually a serious problem. But a GP can check.**

Check if you're bleeding from the bottom
----------------------------------------

You might be bleeding from the bottom if you have:

*   blood on your toilet paper
*   red streaks on the outside of your poo
*   pink water in the toilet bowl
*   blood in your poo or bloody diarrhoea
*   very dark poo (this can be blood mixed in poo)

A small amount of one-off bleeding can often go away on its own without needing treatment.

Non-urgent advice: See a GP if:
-------------------------------

*   your child has blood in their poo
*   you've had blood in your poo for 3 weeks
*   your poo has been softer, thinner or longer than normal for 3 weeks
*   you're in a lot of pain around the bottom
*   you have a pain or lump in your tummy
*   you've been more tired than usual
*   you've lost weight for no reason

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   your poo is black or dark red
*   you have bloody diarrhoea

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Go to A&E or call 999 if:
----------------------------------------------------

*   you're bleeding non-stop
*   there's a lot of blood – for example, the toilet water turns red or you see large blood clots

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

What happens at the GP appointment
----------------------------------

If you have bleeding from your bottom, a GP will check what's causing it.

They might:

*   check your bottom (rectum) with a gloved finger ([rectal examination](https://www.nhs.uk/conditions/rectal-examination/))
*   ask for a sample of poo for testing
*   refer you to a specialist for tests

### Important: Bowel cancer risk

Bleeding from the bottom is sometimes a sign of bowel cancer.

This is easier to treat if it's found early, so it's important to get it checked.

Common causes of bleeding from the bottom
-----------------------------------------

If you have other symptoms, this might give you an idea of the cause.

Do not self-diagnose. See a GP if you're worried.

Bright red blood on toilet paper, streaks on poo, pink toilet water

Possible causes of bright red rectal bleeding
| Symptoms | Possible causes |
| --- | --- |
| Bright red blood and pain when pooing, itchy bottom, lumps
 | [Piles (haemorrhoids)](https://www.nhs.uk/conditions/piles-haemorrhoids/)

 |
| Bright red blood and pain when pooing – often after [constipation](https://www.nhs.uk/conditions/constipation/)

 | A small tear in your anus ([anal fissure](https://www.nhs.uk/conditions/anal-fissure/))

 |
| Bleeding with or without lumps, itching or pain

 | [Sexually transmitted infections (STIs)](https://www.nhs.uk/conditions/sexually-transmitted-infections-stis/) like genital warts, damage from anal sex

 |
| Bright red blood without pain

 | Side effect of medicine to help prevent blood clots like warfarin and apixaban ([anticoagulants](https://www.nhs.uk/conditions/anticoagulants/)) or aspirin. Broken blood vessels in the gut (angiodysplasia)

 |

Blood in poo or blood with slime

Poo can look like it's mixed with blood if you've eaten a lot of red or purple foods like tomatoes and beetroot.

But it's sometimes a sign of something else. A GP can check if you're worried.

Possible causes of slime or blood in your poo
| Symptoms | Possible causes |
| --- | --- |
| Blood and yellow slime when pooing, irritated anus, non stop bottom pain
 | [Anal fistula](https://www.nhs.uk/conditions/anal-fistula/)

 |
| Bloody diarrhoea with clear slime, feeling and being sick

 | Tummy bug (gastroenteritis)

 |
| Bloody [diarrhoea](https://www.nhs.uk/conditions/diarrhoea-and-vomiting/), tummy cramps and pain, feeling bloated

 | An [inflammatory bowel disease (IBD)](https://www.nhs.uk/conditions/inflammatory-bowel-disease/) like ulcerative colitis or Crohn's disease

 |
| Blood in poo

 | Bleeding in the anus, bowel or lower gut from injury or another problem

 |
| Blood in poo, change in pooing habits (like looser poo, diarrhoea or [constipation](https://www.nhs.uk/conditions/constipation/)), slime with poo

 | [Bowel polyps](https://www.nhs.uk/conditions/bowel-polyps/), early signs of [bowel cancer](https://www.nhs.uk/conditions/bowel-cancer/)

 |

Very dark or black blood or poo

Poo can look very dark or black if you:

*   take iron tablets
*   eat a lot of dark foods like liquorice and blueberries

But it's sometimes a sign of something else. A GP can do a test to check this if you're worried.

Possible causes of very dark or black blood coming from your bottom
| Symptoms | Possible causes |
| --- | --- |
| Dark or black poo
 | Bleeding in the stomach or gut – can be from injury or a side effect of medicine to help prevent blood clots like warfarin and apixaban ([anticoagulants](https://www.nhs.uk/conditions/anticoagulants/)) or aspirin

 |
| Dark blood or poo with tummy pain or cramps

 | [Stomach ulcer](https://www.nhs.uk/conditions/stomach-ulcer/)

 |
| Dark blood without pain

 | Side effect of medicine to help prevent blood clots like warfarin and apixaban ([anticoagulants](https://www.nhs.uk/conditions/anticoagulants/)) or aspirin

 |

Page last reviewed: 12 April 2023  
Next review due: 12 April 2026
