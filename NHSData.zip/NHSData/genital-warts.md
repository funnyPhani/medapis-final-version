Title: Genital warts

URL Source: https://www.nhs.uk/conditions/genital-warts/

Published Time: 21 Nov 2017, 10:02 a.m.

Markdown Content:
**Genital warts are small, rough lumps that can appear around the vagina, penis or anus. They're a common sexually transmitted infection (STI). Treatment from a sexual health clinic can help.**

Check if you have genital warts
-------------------------------

It can take a few weeks or months for genital warts to appear after having sex with someone who is infected.

Genital warts are usually small, rough lumps on the skin.

They can appear:

*   around the vagina and on the penis
*   around the anus
*   on the skin between the genitals and anus (perineum)

Genital warts may:

*   appear on their own or in a group (groups of warts can look like a cauliflower)
*   feel soft or firm
*   be white, red, skin-coloured, or darker than the surrounding skin

They do not usually cause symptoms but sometimes they may be painful, itchy or bleed.

You may also have:

*   pain or discomfort during sex
*   problems peeing (there may be blood in your pee, you may find it hard to pee, or you may stop and start a lot)

See pictures of genital warts

Non-urgent advice: Go to a sexual health clinic if you have:
------------------------------------------------------------

*   1 or more painless lumps or growths around your vagina, penis or anus
*   itching or bleeding from your genitals or anus
*   a change to your normal flow of pee (for example, it's begun to flow sideways) that does not go away
*   a sexual partner who has genital warts, even if you do not know if you have them

You may have genital warts. Go to a sexual health clinic to be checked.

Sexual health clinics are sometimes called genitourinary medicine (GUM) clinics, or sexual and reproductive health (SRH) services.

Treatment can help remove the warts and stop the infection being passed on.

Information:

### Why you should go to a sexual health clinic

A GP will probably refer you to a sexual health clinic if they think you might have genital warts.

Sexual health clinics specialise in treating problems with the genitals and urine system.

Many sexual health clinics offer a walk-in service where you do not need an appointment.

Sexual health clinics often get test results quicker than GP surgeries. You also do not have to pay a prescription charge for medicines prescribed by a sexual health clinic.

[Find a sexual health clinic](https://www.nhs.uk/service-search/sexual-health/find-a-sexual-health-clinic)

What happens at a sexual health clinic
--------------------------------------

A doctor or nurse at a sexual health clinic will usually be able to diagnose genital warts by looking at them.

They may:

*   ask you about your symptoms and sexual partners
*   look at the lumps around your genitals and anus, sometimes using a magnifying lens
*   possibly need to look inside your vagina, anus or urethra (tube where pee comes out), depending on where the warts are

It may not be possible to find out who you got genital warts from, or how long you've had the infection.

Treatments for genital warts
----------------------------

Treatment for genital warts is not always needed. They sometimes disappear on their own within 6 months.

If treatment is recommended, it will need to be prescribed by a doctor.

The type of treatment you'll be offered depends on what the warts look like and where they are. The doctor or nurse will discuss this with you.

Treatments for genital warts include:

*   cream, liquid or ointment – you can usually apply these yourself, but if the area is large, a doctor or nurse will need to apply it (these treatments can cause pain, irritation or a burning sensation)
*   freezing (cryotherapy) – this treatment may need to be repeated several times and can be painful
*   surgery – the warts are cut out after numbing the affected area with [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/), or they may be removed using heat or a laser (these treatments can cause pain, irritation or scarring)

It may take weeks or months for genital wart treatment to work and the warts may come back. Sometimes the treatment does not work.

Tell the doctor or nurse if you're pregnant or thinking about becoming pregnant, as some treatments will not be suitable for you.

Some creams can weaken condoms and vaginal diaphragms if it comes into contact with them. Ask the doctor or nurse about this.

Things you can do while having treatment for genital warts
----------------------------------------------------------

There are some things you can do while having treatment for genital warts.

### Do

*   follow the instructions about how to apply creams, liquids and ointments carefully – some creams should only be left on for a certain amount of time before being washed off
    
*   avoid getting any treatment you apply to genital warts on normal skin or in open wounds
    

### Don’t

*   do not use wart treatment from a pharmacy because they're not made for genital warts
    
*   do not smoke – many treatments for genital warts work better if you do not smoke
    
*   do not have vaginal, anal or oral sex until the warts have gone (but if you do have sex, always use a condom)
    

How genital warts are passed on
-------------------------------

Genital warts are caused by the [human papillomavirus (HPV)](https://www.nhs.uk/conditions/human-papilloma-virus-hpv/). The virus can be passed on even when there are no visible warts.

Many people with the virus do not have symptoms but can still pass it on.

If you have genital warts, your current sexual partners should consider getting checked because they may have warts and not know it.

After you get the infection, it can take weeks to many months before symptoms appear.

You can get genital warts from:

*   skin-to-skin contact, including vaginal and anal sex
*   sharing sex toys
*   oral sex, but this is rare

The virus can also be passed to a baby from its mother during birth, but this is rare.

Genital warts can be spread if you touch an infected area and then touch another part of your body.

You cannot get genital warts from kissing or from sharing things like towels, cutlery, cups or toilet seats.

Stopping genital warts being passed on
--------------------------------------

You can stop genital warts being passed on by:

*   using a condom every time you have vaginal, anal or oral sex – but if the virus is in any skin that's not protected by a condom, it can still be passed on
*   not having sex while you're having treatment for genital warts
*   not sharing sex toys – if you do share them, wash them or cover them with a new condom before anyone else uses them

### HPV vaccine

The HPV vaccine offered to 12 to 13 year-old girls and boys in England protects against genital warts and some cancers (such as cervical cancer and anal cancer).

The HPV vaccine is also offered to men (up to and including 45 years old) who have sex with men, some trans men and trans women, sex workers and people living with HIV.

[Find out more about the HPV vaccine](https://www.nhs.uk/vaccinations/hpv-vaccine/)

Genital warts and pregnancy
---------------------------

Genital warts are not usually harmful during pregnancy.

But you'll usually be referred to a sexual health specialist if you have genital warts and you’re pregnant.

During pregnancy, genital warts may:

*   multiply and get bigger (they may be removed if they're very big)
*   become more easily irritated
*   be passed on to the baby during birth, but this is rare (the HPV virus can cause infection in the baby’s throat or genitals)

Most creams, liquids and ointments used to treat genital warts are not recommended during pregnancy.

Genital warts often disappear on their own within 6 weeks after the baby is born, so treatment is often delayed until after the birth.

Page last reviewed: 10 July 2023  
Next review due: 10 July 2026
