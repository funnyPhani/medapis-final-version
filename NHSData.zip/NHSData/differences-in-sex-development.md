Title: Differences in sex development

URL Source: https://www.nhs.uk/conditions/differences-in-sex-development/

Published Time: 18 Oct 2017, 10:52 a.m.

Markdown Content:
**Differences in sex development (DSD) is a group of rare conditions involving genes, hormones and reproductive organs, including genitals. It means a person's sex development is different to most other people's.**

Sometimes the term Disorders of Sex Development is used, as is Variations in Sex Characteristics (VSC) or Diverse Sex Development. Some people prefer to use the term intersex.

Why does DSD happen?
--------------------

You or your child may have sex chromosomes (bundles of genes) usually associated with being female (XX chromosomes) or usually associated with being male (XY chromosomes), but reproductive organs and genitals that may look different from usual.

This happens because of a difference with your genes or how you respond to the sex hormones in your body, or both. It can be inherited, but there is often no clear reason why it happens.

The most common times to find out that a person has a DSD are around the time of their birth or when they're a teenager.

Types of DSDs
-------------

There are many different types of DSD. Some examples are:

### Usual female pattern genes with genitals that look different to girls' genitals

Some people have XX (usual female) chromosomes with ovaries and a womb, but their genitals may not look the same as many females.

For example, they may have a more developed clitoris and their vagina may be closed.

Doctors refer to this condition as 46,XX DSD.

The most common cause is congenital adrenal hyperplasia (CAH). A person who has CAH lacks an enzyme (chemical substance) that their body needs to make the hormones cortisol and aldosterone.

Without these hormones, their body produces more androgens (sex hormones that are naturally higher in males). If the child is female, the raised androgen levels before birth can cause their genitals to look different, such as a larger clitoris and a vagina that is not open in the usual place.

CAH can also cause serious health issues, such as life-threatening kidney problems that need to be treated as soon as possible

Find out more:

*   [The Great Ormond Street Hospital for Children: CAH (congenital adrenal hyperplasia)](https://www.gosh.nhs.uk/conditions-and-treatments/conditions-we-treat/congenital-adrenal-hyperplasia-cah/)
*   [Living with CAH - what is CAH?](https://www.livingwithcah.com/about/)

### Genes usually seen in males with genitals that look the same as most girls' and some internal male structures

Some people have XY (male) chromosomes, but their external genitals may develop in the usual way for girls or boys.

Sometimes it's difficult at first to know whether their genitals are more similar to girls' or boys'. A person may have a womb and may also have testicles inside their body. Sometimes the testicles might not work properly.

Doctors refer to this condition as 46,XY DSD.

Many people with 46,XY DSD are boys born with the opening to pass urine towards the bottom of their penis or below it.

For some, the scrotum appears separated into two smaller sacs, one on either side. Doctors call this peno-scrotal hypospadias and boys and men with this DSD can have either fully developed or partially developed testes.

There are several causes of 46,XY DSD. One possible cause is [androgen insensitivity syndrome (AIS)](https://www.nhs.uk/conditions/androgen-insensitivity-syndrome/), where the body "ignores" androgens or is insensitive to them.

Sometimes a person's body does not respond at all or only partly responds to androgens.

Complete insensitivity to androgens makes a person with XY chromosomes female. Partial insensitivity to androgens can mean that some people are male and others are female.

### Ordinary looking genitals but different sex development

Some people have a chromosome pattern other than the usual XY or XX. They may have one X chromosome (XO), or they may have an extra chromosome (XXY).

Their internal and external sex organs can be either male or female, but they may not go through a full physical development at puberty. For example, a child with female sex organs may not start having periods.

Doctors call this sex chromosome DSD.

One type is [Klinefelter syndrome](https://www.nhs.uk/conditions/klinefelters-syndrome/), which is where a boy is born with an extra X chromosome (XXY).

This can mean they do not produce the usual level of testosterone, the sex hormone responsible for the development of male characteristics, such as the testes and body hair. Testosterone is also important for bone strength and fertility in men.

Another example of this type of DSD is [Turner syndrome](https://www.nhs.uk/conditions/turner-syndrome/), which is where a girl is born with a missing X chromosome.

Girls and women with Turner syndrome are often [infertile](https://www.nhs.uk/conditions/infertility/) and their height may be shorter than average.

Find out more:

*   [Klinefelter’s Syndrome Association](https://www.ksa-uk.net/)
*   [Turner Syndrome Support Society - What is TS?](https://tss.org.uk/ts/what)

### Female with usual external genitals, but without a womb

Some females are born with an underdeveloped womb or without a womb, cervix and upper vagina. The ovaries and external genitalia look the same as most girls and women and they develop breasts and pubic hair as they get older.

This is called Rokitansky syndrome. It's also known as Mayer-Rokitansky-Küster-Hauser (MRKH syndrome). The cause is not clear, but girls and women with Rokitansky syndrome/MRKH have XX chromosomes.

Often the first sign of Rokitansky syndrome is that a girl does not start having periods. Sex involving the vagina may also be difficult because the vagina may be shorter than most women's.

Not having a womb means that a woman cannot become pregnant, but it's sometimes possible to take eggs from their ovaries, fertilise them, and implant them in another woman's womb (surrogacy).

You can find more support and information on Rokitansky syndrome at:

*   [DSD Teens – MRKH (a.k.a. Mayer-Rokitansky-Küster-Hauser Syndrome)](https://www.dsdteens.org/puberty-and-you/your-puberty-by-condition/girls/mrkh/)
*   [MRKH Connect – What is MRKH](https://mrkhconnect.co.uk/what-is-mrkh/)

### Sex characteristics usually seen in males or females

Some people with a very rare type of DSD have both ovarian and testicular tissue (sometimes one ovary and one testis). Their genitals may appear female or male or could look different from either.

Most people with this type of DSD have XX (female) chromosomes. The cause is not usually clear, but some people with the condition have been found to have genetic material that's usually seen on the Y chromosome appearing on their X chromosome.

Doctors refer to this condition as 46,XX ovotesticular DSD.

What happens after the birth of a baby
--------------------------------------

Doctors will check a baby for DSD soon after birth because of signs such as undescended testicles or if a baby's genitals look different.

Tests may be done to help get a clear diagnosis and find out whether any immediate treatment is needed.

Tests may include:

*   a further physical examination of your baby done by a specialist
*   an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) to examine their internal organs
*   [blood tests](https://www.nhs.uk/conditions/blood-tests/) to check their genes and hormone levels

In England you need to register your baby’s birth within 42 days. This is usually enough time to complete the tests, discuss the results with your child’s care team and identify your baby’s sex.

Many forms of DSD do not require any medical care other than understanding the baby's development and knowing what to expect as they grow older.

A specialist nurse in your care team can help you learn about DSD and a psychologist will help you address any concerns you have.

Find out more about what happens when your baby is born with genitals that look different, in the First Days leaflet. This is on the [DSD Families Resources website page](https://dsdfamilies.org/resources).

Advice for parents of older children
------------------------------------

Sometimes a DSD may be diagnosed if an older child does not go through puberty properly. For example, your child may not start showing the changes linked with puberty, or they may start puberty but not have periods.

Speak to a GP if you have any concerns about your child's development at puberty. They can refer your child to a specialist. This will usually be a consultant paediatric endocrinologist, who specialises in hormones, or an adolescent gynaecologist.

A team of specialist healthcare professionals will work with you to understand your child's condition and offer you and your child support and advice.

A psychologist in the team can talk with you or your child about sexuality, relationships and body image among other subjects.

Some people with DSD may need hormone therapy and psychological support. Some may want to think about altering their existing genitals, for example by using vaginal stretch techniques.

Some people with DSD consider altering the appearance of their genitals by having surgery.

If you think you have a DSD
---------------------------

If you think or know you have a DSD, information and support is available.

Speak to a GP, as they'll be able to refer you to a team of specialist healthcare professionals. They can answer your questions, help you stay healthy and put you in touch with others with DSD if that's something you're interested in.

You can stay with the gender linked to your sex at birth, which is the sex on your birth certificate. But if your legal sex does not represent who you are or how you identify, you may want to discuss your options with your care team.

If you have a DSD and want to explore parenthood, you can also discuss this with your specialist care team.

Where to get support
--------------------

If you have a DSD or you're the parent of a child with a DSD, you may find it useful to contact a group involving others with the same or similar experiences.

These groups can often offer more information and advice about living with a DSD, and may be able to put you in contact with others who've been in a similar situation to you.

You are welcome to ask your care team about people with experience of your diagnosis in your local area who are happy to be contacted.

Page last reviewed: 16 March 2023  
Next review due: 16 March 2026
