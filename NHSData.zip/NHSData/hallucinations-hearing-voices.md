Title: Hallucinations and hearing voices

URL Source: https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/feelings-and-symptoms/hallucinations-hearing-voices/

Published Time: 3 Feb 2021, 11:47 a.m.

Markdown Content:
**Hallucinations are where you hear, see, smell, taste or feel things that appear to be real but only exist in your mind. Get medical help if you or someone else have hallucinations.**

Types of hallucinations
-----------------------

You may have hallucinations if you:

*   hear sounds or voices that nobody else hears
*   see things that are not there like objects, shapes, people or lights
*   feel touch or movement in your body that is not real like bugs are crawling on your skin or your internal organs are moving around.
*   smell things that do not exist
*   taste things that only you feel are not pleasant or is strange
*   think that your body is moving like flying or floating when it is not

Causes of hallucinations
------------------------

Hallucinations can be caused by many different health conditions that affect the senses.

Common causes of hallucinations include:

*   mental health conditions like [schizophrenia](https://www.nhs.uk/mental-health/conditions/schizophrenia/) or a [bipolar disorder](https://www.nhs.uk/mental-health/conditions/bipolar-disorder/)
*   drugs and alcohol
*   [Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/) or [Parkinson's disease](https://www.nhs.uk/conditions/parkinsons-disease/)
*   a change or loss of vision, such as [Charles Bonnet syndrome](https://www.nhs.uk/conditions/charles-bonnet-syndrome/)
*   [anxiety](https://www.nhs.uk/mental-health/conditions/generalised-anxiety-disorder/), [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/) or bereavement
*   side effect from medicines
*   after surgery and anaesthesia

Sometimes hallucinations can be temporary. They can happen if you have migraines, a high temperature or just as you wake up or fall asleep.

They can also be caused by an infection, [brain tumour](https://www.nhs.uk/conditions/brain-tumours/) or [confusion (delirium)](https://www.nhs.uk/conditions/confusion/), especially in older people.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you or someone else have hallucinations

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Immediate action required: Call 999 or go to A&E now if:
--------------------------------------------------------

You or someone else:

*   want to harm yourself or someone else
*   hear voices telling you to harm yourself or someone else
*   have a seizure (fit)
*   suddenly become confused
*   are not making sense when you speak

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Treatment for hallucinations
----------------------------

Treatment for hallucinations will depend on what's causing it.

For example, if you have a mental health condition like schizophrenia, you may be given therapy or medicine to help reduce your hallucinations.

A GP may recommend lifestyle changes like drinking less alcohol, not taking drugs and getting more sleep to reduce your hallucinations.
