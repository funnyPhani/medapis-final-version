Title: Chickenpox

URL Source: https://www.nhs.uk/conditions/chickenpox/

Published Time: 19 Oct 2017, 3:39 p.m.

Markdown Content:
**Chickenpox is common and mostly affects children, but you can get it at any age. It usually gets better by itself after 1 to 2 weeks without needing to see a GP.**

Check if it's chickenpox
------------------------

An itchy, spotty rash is the main symptom of chickenpox. It can be anywhere on the body.

Chickenpox happens in 3 stages. But new spots can appear while others are becoming blisters or forming a scab.

### Stage 1: small spots appear

The spots can:

*   be anywhere on the body, including inside the mouth and around the genitals, which can be painful
*   spread or stay in a small area
*   be red, pink, darker or the same colour as surrounding skin, depending on your skin tone
*   be harder to see on brown and black skin

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: White skin with stage 1 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-1)
*   [2: Light brown skin with stage 1 of the chickenpox (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-2)
*   [3: Light brown skin with stage 1 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-3)

![Image 1: Stage 1 chickenpox on white skin with red and pink spots. Some are raised. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/ABF9YH_GDGeL2X.2e16d0ba.fill-420x280.jpg)

Long description, image 1.

White skin with stage 1 chickenpox spots.

There are 10 spots that vary in size, but they're all less than 1cm. Some spots are close to others. Some spots are raised and appear to be forming a round or slightly oval blister. Other spots are flatter.

The spots are red and pink and the skin around the spot is pink.

### Stage 2: the spots become blisters

The spots fill with fluid and become blisters. The blisters are very itchy and may burst.

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: White skin with stage 2 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-1)
*   [2: Medium brown skin with stage 2 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-2)
*   [3: Medium brown skin with stage 2 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-3)
*   [4: Dark brown skin with stage 2 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-4)

![Image 2: Stage 2 chickenpox on white skin with pink and shiny blisters. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/D2BX3G.278461f6.fill-420x280.jpg)

Long description, image 1.

White skin with stage 2 chickenpox spots.

There are 13 spots which vary in size, but they're all less than 1cm. Some spots are close to others. Almost all the spots have formed a round or slightly oval blister. 1 spot appears to be flatter.

The blisters are pink and shiny. The skin around some spots appears slightly pink.

### Stage 3: the blisters become scabs

The spots form a scab. Some scabs are flaky while others leak fluid.

Here is an image gallery with images and detailed descriptions. Select an image tab to get the bigger version of the image and to access the description.

*   [1: White skin with stage 3 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-1)
*   [2: Light brown skin with stage 3 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-2)
*   [3: Medium brown skin with stage 3 of the chickenpox rash (thumbnail).](https://www.nhs.uk/conditions/chickenpox/#gallery-image-3)

![Image 3: Stage 3 of chickenpox on white skin with blisters and scabs. A long description is available next.](https://assets.nhs.uk/nhsuk-cms/images/D1BMFN.2e16d0ba.fill-420x280.jpg)

Long description, image 1.

White skin with stage 3 chickenpox spots, blisters and scabs.

There are about 14 spots which vary in size from around 1mm to 1cm. Some are close together.

Some of the spots look like very small pink blisters. Some are larger, raised and have a scab over them. Some scabs look soft and seem to have fluid under them.

2 of the scabs appear to have collapsed in the centre. The scabs are yellow and pink and the skin around the scabs is pink.

#### Other symptoms

Before or after the rash appears, you might also get:

*   a high temperature
*   aches and pains, and generally feeling unwell
*   loss of appetite

Chickenpox is very itchy and can make children feel miserable, even if they do not have many spots.

The chickenpox spots look the same on children and adults. But adults usually have a high temperature for longer and more spots than children.

It's possible to get chickenpox more than once, but it's unusual.

#### If you're not sure it's chickenpox

[Check other rashes in children](https://www.nhs.uk/conditions/rashes-babies-and-children/)

How to treat chickenpox at home
-------------------------------

### Important: Stay off school or work

You'll need to stay away from school, nursery or work until all the spots have formed a scab. This is usually 5 days after the spots appeared.

### Do

*   drink plenty of fluid (try ice lollies if your child is not drinking) to avoid dehydration
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-children/) to help with pain and discomfort
    
*   cut your child's fingernails and put socks on their hands at night to stop them scratching
    
*   use cooling creams or gels from a pharmacy
    
*   speak to a pharmacist about using [antihistamine medicine](https://www.nhs.uk/conditions/antihistamines/) to help itching
    
*   bathe in cool water and pat the skin dry (do not rub)
    
*   dress in loose clothes
    

### Don’t

*   do not use [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-children/) unless advised to do so by a doctor, as it may cause serious skin infections
    
*   do not give aspirin to children under 16
    
*   do not go near newborn babies, or anyone who is pregnant or has a weakened immune system, as chickenpox can be dangerous for them
    
*   do not scratch the spots, as scratching can cause scarring
    

Non-urgent advice: Speak to a GP if:
------------------------------------

*   you're not sure it's chickenpox
*   you're concerned about your child

Tell the receptionist you think it might be chickenpox before going in to a GP surgery.

Urgent advice: Get advice from 111 now if:
------------------------------------------

*   the skin around the chickenpox blisters is hot, painful and red, but redness may be harder to see on brown or black skin
*   your child has chickenpox and is [dehydrated](https://www.nhs.uk/conditions/dehydration/)
*   chickenpox symptoms suddenly get worse
*   you're pregnant and have not had chickenpox before, or you're not sure, and you've been near someone with chickenpox
*   you have a weakened immune system and have been near someone with chickenpox
*   you think your newborn baby has chickenpox

Some people may be able to take medicine to prevent complications. It needs to be started within 24 hours of the spots appearing.

111 will tell you what to do. They can arrange a phone call from a nurse or doctor if you need one.

Go to [111.nhs.uk](https://111.nhs.uk/?utm_source=nhsuk&utm_campaign=conditions&utm_content=chickenpox) or call [111](tel:111).

It's easy to catch chickenpox
-----------------------------

You can catch chickenpox by being in the same room as someone with it. It's also spread by touching things that have fluid from the blisters on them.

### When chickenpox can be spread

You can spread chickenpox to other people from 2 days before your spots appear until they have all formed scabs – usually 5 days after your spots appeared.

### How soon you get symptoms after catching chickenpox

The spots start appearing around 1 to 3 weeks after you caught chickenpox.

Chickenpox in pregnancy
-----------------------

Most people get chickenpox during childhood, so it's rare to get chickenpox when you're pregnant.

If you do get chickenpox when you're pregnant, there's a small risk of your baby being very ill when it's born.

Go to [111.nhs.uk](https://111.nhs.uk/?utm_source=nhsuk&utm_campaign=conditions&utm_content=chickenpox) or call [111](tel:111) if you have not had chickenpox before and you've been near someone with it.

The chickenpox vaccine
----------------------

You can get the [chickenpox vaccine](https://www.nhs.uk/vaccinations/chickenpox-vaccine/) on the NHS if there's a risk of harming someone with a weakened immune system if you spread the virus to them.

For example, a child can be vaccinated if 1 of their parents is having chemotherapy.

You can also pay for the vaccine at some private clinics or travel clinics. It costs between £120 and £200.

Shingles and chickenpox
-----------------------

You cannot catch shingles from someone with chickenpox.

You can catch chickenpox from someone with shingles if you have not had chickenpox before.

When you get chickenpox, the virus stays in your body. The virus can be triggered again if your immune system is weak. This causes shingles.

This can happen because of stress, certain conditions, or treatments like chemotherapy.

Page last reviewed: 12 November 2021  
Next review due: 12 November 2024
