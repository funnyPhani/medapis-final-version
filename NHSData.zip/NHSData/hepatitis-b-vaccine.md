Title: Hepatitis B vaccine

URL Source: https://www.nhs.uk/vaccinations/hepatitis-b-vaccine/

Published Time: 6 Mar 2024, 5:39 p.m.

Markdown Content:
What the hepatitis B vaccine is for
-----------------------------------

[Hepatitis B](https://www.nhs.uk/conditions/hepatitis-b/) is an infection that affects the liver. It's spread through blood, semen and vaginal fluids.

Hepatitis B can be very serious. It can make the liver suddenly stop working or cause gradual damage to the liver over time. It can also increase your chances of getting [liver cancer](https://www.nhs.uk/conditions/liver-cancer/).

Vaccination against hepatitis B helps reduce your chances of getting infected.

Who should have the hepatitis B vaccine
---------------------------------------

Vaccination against hepatitis B is recommended for all babies as part of the [NHS vaccination schedule](https://www.nhs.uk/vaccinations/nhs-vaccinations-and-when-to-have-them/).

The hepatitis B vaccine is also recommended for people at higher risk of catching or getting seriously ill from hepatitis B.

Babies

All babies should have 3 doses of the [6-in-1 vaccine](https://www.nhs.uk/vaccinations/6-in-1-vaccine/), which helps protect against hepatitis B and other illnesses.

A dose is given at:

*   8 weeks old
*   12 weeks old
*   16 weeks old

If you have hepatitis B while you're pregnant, there's a much higher chance your baby could get the infection. Because of this risk, your baby will be given extra doses of a hepatitis B vaccine:

*   within 24 hours of being born
*   at 4 weeks old
*   at 12 months old

This means they'll have 6 doses in total.

People at risk from hepatitis B

The hepatitis B vaccine is recommended for people at higher risk from hepatitis B, including:

*   people who inject drugs or live with someone who injects drugs
*   people who change sexual partners often
*   gay, bisexual and other men who have sex with men
*   sex workers
*   close family members or sexual partners of someone with hepatitis B
*   people who have regular blood transfusions or blood products (and their carers)
*   people with long-term (chronic) liver disease or kidney failure
*   healthcare workers and some laboratory staff
*   prison staff and prisoners
*   people travelling to parts of the world where they have a higher risk of getting hepatitis B
*   families adopting or fostering children from parts of the world where hepatitis B is more common
*   people who live in accommodation for people with learning disabilities or work with people with severe learning disabilities

People exposed to hepatitis B

The hepatitis B vaccine can help stop you getting hepatitis B if you're exposed to the blood or other body fluids of an infected person.

For example, it may be recommended if you've been bitten by someone or you've been injured by a used needle.

Who cannot have the hepatitis B vaccine
---------------------------------------

Most people who need the hepatitis B vaccine can have it, including if you're pregnant or breastfeeding.

The only reason you cannot have the vaccine is if you've had a serious allergic reaction ([anaphylaxis](https://www.nhs.uk/conditions/anaphylaxis/)) to a previous dose of the vaccine or an ingredient in the vaccine.

Information:

### **Getting vaccinated if you're unwell**

If you have a high temperature or feel too unwell to do your normal activities, wait until you're feeling better before having the vaccine.

Hepatitis B vaccine ingredients
-------------------------------

There are several types of hepatitis B vaccine used in the UK. You can check the ingredients in the patient leaflets.

Vaccines that only protect against hepatitis B Combined hepatitis A and B vaccines Vaccines that protect babies from hepatitis B and other illnesses (6-in-1 vaccines)

How to get the hepatitis B vaccine
----------------------------------

There are different ways to get vaccinated against hepatitis B.

Where to get the hepatitis B vaccine
| Who should have it | How to get it |
| --- | --- |
| Babies
 | You'll usually be contacted by your baby's GP surgery (speak to the surgery if you've not been contacted)

 |
| People travelling to parts of the world where they have a higher risk of getting hepatitis B

 | From travel vaccination clinics, pharmacies with travel health services and some GP surgeries (you'll usually have to pay)

 |
| People at risk through their work

 | Speak to your employer about getting vaccinated

 |
| People at risk of hepatitis B from sexual activity

 | Visit a [sexual health clinic](https://www.nhs.uk/service-search/sexual-health/find-a-sexual-health-clinic)

 |
| Other people at higher risk (for example because someone in their home has it or they have a condition that raises their risk)

 | Speak to your GP surgery

 |

How the hepatitis B vaccine is given
------------------------------------

The hepatitis B vaccine is given as an injection into the upper arm or thigh.

You need at least 3 doses of the vaccine to give you the best protection from hepatitis B.

There's usually a month gap between each dose, but sometimes 3 doses can be given within 21 days (with a 4th dose at 12 months) if you need faster protection.

Some people (such as babies exposed to hepatitis B before birth) need more than 3 doses to get the best protection.

### **Booster doses**

You usually only need booster doses of a hepatitis B vaccine if:

*   you're a healthcare worker and blood tests show that 3 doses of the vaccine have not given you enough protection from hepatitis B
*   you have kidney failure – you may need more doses if a blood test shows your protection has reduced
*   you're exposed to hepatitis B (for example, you're bitten by someone or injured by a used needle)

Information:

### **Having the hepatitis B vaccine at the same time as other vaccines**

You can have the hepatitis B vaccine at the same time as other vaccines, including the rotavirus vaccine and MMR vaccine.

Side effects of the hepatitis B vaccine
---------------------------------------

Most of the side effects of the hepatitis B vaccine are mild and do not last long.

They can include:

*   swelling or pain where the injection was given
*   feeling tired, sleepy or irritable
*   a headache
*   feeling or being sick
*   diarrhoea
*   a stomach ache
*   a high temperature

More serious side effects such as a severe allergic reaction are very rare. The person who vaccinates you will be trained to deal with allergic reactions and treat them immediately.

The hepatitis B vaccines used in the UK contain a killed (destroyed) version of the hepatitis B virus, so there's no risk of getting the infection from the vaccine.

How well the hepatitis B vaccine works
--------------------------------------

The hepatitis B vaccine works very well at helping protect people against hepatitis B.

Research has shown that:

*   90% of adults and over 98% of babies have good protection from hepatitis B after being vaccinated
*   protection against long-term hepatitis B infection could last for as long as 20 to 30 years after being vaccinated

The vaccine can work less well in some people, such as people with kidney failure, so extra doses are sometimes needed.

### Important

There's still a chance you could get hepatitis B after being vaccinated, so it's still important to try to reduce your risk of catching it, such as by using condoms during sex and not sharing toothbrushes or needles.
