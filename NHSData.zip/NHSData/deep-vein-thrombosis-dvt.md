Title: DVT (deep vein thrombosis)

URL Source: https://www.nhs.uk/conditions/deep-vein-thrombosis-dvt/

Published Time: 4 May 2018, 3:07 p.m.

Markdown Content:
**DVT (deep vein thrombosis) is a blood clot in a vein, usually in the leg. DVT can be dangerous. Get medical help as soon as possible if you think you have DVT.**

Symptoms of DVT (deep vein thrombosis)
--------------------------------------

Symptoms of DVT (deep vein thrombosis) in the leg are:

*   throbbing pain in 1 leg (rarely both legs), usually in the calf or thigh, when walking or standing up
*   swelling in 1 leg (rarely both legs)
*   warm skin around the painful area
*   red or darkened skin around the painful area – this may be harder to see on brown or black skin
*   swollen veins that are hard or sore when you touch them

These symptoms can also happen in your arm or tummy if that's where the blood clot is.

![Image 1: Swollen and red right leg caused by DVT (deep vein thrombosis), shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_0917_deep-vein-thrombosis_C0117382.width-320.jpg)

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you think you have DVT (deep vein thrombosis)

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You have symptoms of DVT (deep vein thrombosis), such as pain and swelling, and:

*   breathlessness
*   chest pain

DVT can be very serious because blood clots can travel to your lungs. This is called a [pulmonary embolism](https://www.nhs.uk/conditions/pulmonary-embolism/).

A pulmonary embolism can be life-threatening and needs treatment straight away.

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Who is more likely to get DVT (deep vein thrombosis)
----------------------------------------------------

A DVT (deep vein thrombosis) is more likely to happen if you:

*   are over 60
*   are overweight
*   smoke
*   have had DVT before
*   take the contraceptive pill or HRT
*   have cancer or heart failure
*   have [varicose veins](https://www.nhs.uk/conditions/varicose-veins/)

There are also some times when you have a higher chance of getting DVT.

These include if you:

*   are staying in or recently left hospital – especially if you cannot move around much (like after an operation)
*   are confined to bed
*   go on a long journey (more than 3 hours) by plane, car or train
*   are pregnant or if you've had a baby in the previous 6 weeks
*   are dehydrated

Sometimes DVT can happen for no obvious reason.

How DVT (deep vein thrombosis) is diagnosed
-------------------------------------------

If a doctor thinks you have DVT (deep vein thrombosis), you should be referred to hospital within 24 hours for an ultrasound scan. The scan shows whether blood is flowing normally through the vein.

You may also have an X-ray of the vein (venogram). For this, you'll be injected with a dye to show where the blood clot is.

Treatment of DVT (deep vein thrombosis)
---------------------------------------

You may have an injection of a blood-thinning medicine called heparin while you're waiting for an ultrasound scan to see if you have a DVT (deep vein thrombosis).

The main treatments include:

*   blood-thinning medicines, such as [warfarin](https://www.nhs.uk/medicines/warfarin/) or [rivaroxaban](https://www.nhs.uk/medicines/rivaroxaban/) – you'll probably need to take these for at least 3 months
*   surgery to remove blood clots or stop them forming

If you get a [DVT when you're pregnant](https://www.nhs.uk/pregnancy/related-conditions/complications/deep-vein-thrombosis/), you'll have injections for the rest of the pregnancy and until your baby is 6 weeks old.

Recovery from DVT (deep vein thrombosis)
----------------------------------------

There are things you can do to help you recover from DVT (deep vein thrombosis).

After you leave hospital, you'll be encouraged to:

*   walk regularly
*   keep your affected leg raised when you're sitting
*   delay any flights or long journeys until at least 2 weeks after you start taking blood-thinning medicine

How to prevent DVT (deep vein thrombosis)
-----------------------------------------

There are things you can do to lower your chance of getting DVT (deep vein thrombosis).

### Do

*   stay a healthy weight
    
*   stay active – taking regular walks can help
    
*   drink plenty of fluids to avoid dehydration – DVT is more likely if you're dehydrated
    

### Don’t

*   do not sit still for long periods of time – get up and move around every hour or so
    
*   do not cross your legs while you're sitting
    
*   do not smoke
    
*   do not drink lots of alcohol
    

### Going on a long journey

If you're travelling for 3 hours or more by plane, train or car, there are things you can do during the journey to lower your chances of getting DVT.

These include:

*   wearing loose clothing
*   drinking plenty of water
*   avoiding alcohol
*   walking around when possible

### Going into hospital

If you go into hospital, your healthcare team should check if there's a higher chance you'll get DVT.

If they think you're more likely to get DVT, you may be given treatment to prevent it, such as medicine or compression stockings (knee-high elastic socks that help your blood circulation), while you're in hospital.

You may continue treatment after you leave hospital because a blood clot can happen weeks later.

You can also help protect yourself against DVT while you're in hospital by:

*   staying active and walking around if you can
*   moving your toes (up and down) and ankles (in circles) if you have to stay in bed – your healthcare team may give you some exercises to do

Page last reviewed: 22 March 2023  
Next review due: 22 March 2026
