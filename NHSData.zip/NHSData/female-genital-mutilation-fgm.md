Title: Female genital mutilation (FGM)

URL Source: https://www.nhs.uk/conditions/female-genital-mutilation-fgm/

Published Time: 18 Oct 2017, 12:02 p.m.

Markdown Content:
**Female genital mutilation (FGM) is a procedure where the female genitals are deliberately cut, injured or changed, but there's no medical reason for this to be done.**

It's also known as female circumcision or cutting, and by other terms, such as Sunna, gudniin, halalays, tahur, megrez and khitan, among others.

FGM is usually carried out on young girls between infancy and the age of 15, most commonly before puberty starts.

It's illegal in the UK and is child abuse.

It's very painful and can seriously harm the health of women and girls.

It can also cause long-term problems with sex, childbirth and mental health.

Getting help and support
------------------------

All women and girls have the right to control what happens to their bodies and the right to say no to FGM.

Help is available if you have had FGM or you're worried that you or someone you know is at risk.

*   If someone is in immediate danger, contact the police immediately by dialling 999.
*   If you're concerned that someone may be at risk, contact the NSPCC helpline on 0800 028 3550 or email [fgmhelp@nspcc.org.uk](mailto:fgmhelp@nspcc.org.uk).
*   If you're under pressure to have FGM performed on your daughter, ask a GP, your health visitor or another healthcare professional for help, or contact the NSPCC helpline.
*   If you have had FGM, you can get help from a specialist NHS gynaecologist or FGM service – ask a GP, your midwife or any other healthcare professional about services in your area. 

Read about [National FGM Support Clinics and where to find them](https://www.nhs.uk/conditions/female-genital-mutilation-fgm/national-fgm-support-clinics/).

If you're a health professional caring for a patient under 18 who's had FGM, you have professional responsibilities to safeguard and protect her.

[Guidance and resources about FGM for healthcare staff are available on the GOV.UK website](https://www.gov.uk/government/collections/female-genital-mutilation-fgm-guidance-for-healthcare-staff).

Types of FGM
------------

There are 4 main types of FGM:

*   type 1 (clitoridectomy) – removing part or all of the clitoris
*   type 2 (excision) – removing part or all of the clitoris and the inner labia (the lips that surround the vagina), with or without removal of the labia majora (the larger outer lips)
*   type 3 (infibulation) – narrowing the vaginal opening by creating a seal, formed by cutting and repositioning the labia
*   other harmful procedures to the female genitals, including pricking, piercing, cutting, scraping or burning the area

FGM is often performed by traditional circumcisers or cutters who do not have any medical training. But in some countries it may be done by a medical professional.

Anaesthetics and antiseptics are not generally used, and FGM is often carried out using knives, scissors, scalpels, pieces of glass or razor blades.

FGM often happens against a girl's will without her consent, and girls may have to be forcibly restrained.

Effects of FGM
--------------

There are no health benefits to FGM and it can cause serious harm, including:

*   constant pain
*   pain and difficulty having sex
*   repeated infections, which can lead to [infertility](https://www.nhs.uk/conditions/infertility/)
*   bleeding, cysts and abscesses
*   problems peeing or holding pee in [(incontinence)](https://www.nhs.uk/conditions/urinary-incontinence/)
*   [depression](https://www.nhs.uk/mental-health/conditions/depression-in-adults/overview/), flashbacks and [self-harm](https://www.nhs.uk/mental-health/feelings-symptoms-behaviours/behaviours/self-harm/)
*   problems during labour and childbirth, which can be life threatening for mother and baby

Some girls die from blood loss or infection as a direct result of the procedure.

### FGM and sex

FGM can make it difficult and painful to have sex. It can also result in reduced sexual desire and a lack of pleasurable sensation.

Talk to your GP or another healthcare professional if you have sexual problems that you feel may be caused by FGM, as they can refer you to a special therapist who can help.

In some cases, a surgical procedure called a deinfibulation may be recommended, which can alleviate and improve some symptoms.

### FGM and pregnancy

Some women with FGM may find it difficult to become pregnant, and those who do conceive can have problems in childbirth.

If you're expecting a baby, your midwife should ask you if you have had FGM at your [antenatal appointment](https://www.nhs.uk/pregnancy/your-pregnancy-care/your-antenatal-appointments/).

It's important to tell your midwife if you think this has happened to you so they can arrange appropriate care for you and you baby.

### FGM and mental health

FGM can be an extremely traumatic experience that can cause emotional difficulties throughout life, including;

*   depression
*   anxiety
*   flashbacks to the time of the cutting
*   nightmares and other sleep problems

In some cases, women may not remember having the FGM at all, especially if it was performed when they were an infant.

Talk to a GP or another healthcare professional if you're experiencing emotional or mental health problems that may be a result of FGM. Help and support is available.

Treatment for FGM (deinfibulation)
----------------------------------

Surgery can be performed to open up the vagina, if necessary. This is called deinfibulation.

It's sometimes known as a reversal, although this name is misleading as the procedure does not replace any removed tissue and will not undo the damage caused.

But it can help many problems caused by FGM.

Surgery may be recommended for:

*   women who are unable to have sex or have difficulty peeing as a result of FGM
*   pregnant women at risk of problems during labour or delivery as a result of FGM

Deinfibulation should be carried out before getting pregnant, if possible.

It can be done in pregnancy or labour if necessary, but ideally should be done before the last 2 months of pregnancy.

The surgery involves making a cut (incision) to open the scar tissue over the entrance to the vagina.

It's usually performed under [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/) in a clinic and you will not normally need to stay overnight.

A small number of women need either a [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/) or an injection in the back [(epidural)](https://www.nhs.uk/conditions/epidural/), which may involve a short stay in hospital.

Video: female genital mutilation (FGM)
--------------------------------------

This video raises awareness of female genital mutilation (FGM) and has advice if you or someone else are at risk.

Media last reviewed: 1 July 2021  
Media review due: 1 July 2024

Why FGM is carried out
----------------------

FGM is carried out for various cultural, religious and social reasons within families and communities in the mistaken belief that it will benefit the girl in some way (for example, as a preparation for marriage or to preserve her virginity).

But there are no acceptable reasons that justify FGM. It's a harmful practice that has no health benefits.

FGM usually happens to girls whose mothers, grandmothers or extended female family members have had FGM themselves, or if their father comes from a community where it's carried out.

Where FGM is carried out
------------------------

Girls are sometimes taken abroad for FGM, but they may not be aware this is the reason for their travel.

Girls are more at risk of FGM being carried out during the summer holidays, as this allows more time for them to "heal" before they return to school.

If you think there's a risk of this happening to you, you can [download the Statement Opposing FGM on GOV.UK](https://www.gov.uk/government/publications/statement-opposing-female-genital-mutilation) and take it with you on holiday to show your family.

Communities that perform FGM are traditionally found in many parts of Africa, the Middle East and Asia.

Girls who were born in the UK or are resident here but whose families originate from an FGM-practising community are at greater risk of FGM happening to them.

Many communities practise FGM, but those at particular risk in the UK originate from:

*   Somalia
*   Egypt
*   Sudan
*   Sierra Leone
*   Eritrea
*   Gambia
*   Ethiopia

The law and FGM
---------------

FGM is illegal in the UK.

It's an offence to:

*   perform FGM (including taking a child abroad for FGM)
*   help a girl perform FGM on herself in or outside the UK
*   help anyone perform FGM in the UK
*   help anyone perform FGM outside the UK on a UK national or resident
*   fail to protect a girl for whom you're responsible from FGM

Anyone who performs FGM can face up to 14 years in prison.

Anyone found guilty of failing to protect a girl from FGM can face up to 7 years in prison.

Video: female genital mutilation - the facts
--------------------------------------------

This video dispels myths surrounding FGM and religion.

Media last reviewed: 1 July 2022  
Media review due: 1 July 2025

Download the Statement Opposing FGM
-----------------------------------

The summer holidays are when many young girls are taken abroad, often to their family's birth country, to have FGM performed.

The FGM statement, also known as the FGM health passport, highlights the fact FGM is a serious criminal offence in the UK.

If you're worried about FGM, print out this statement, take it abroad with you and show it to your family.

Keep the declaration in your passport, purse or bag, and carry it with you all the time.

[Download the statement opposing FGM on GOV.UK](https://www.gov.uk/government/publications/statement-opposing-female-genital-mutilation), which is also available in other languages.

Leaflets to download
--------------------

There are leaflets for patients who want to know [more about FGM on GOV.UK](https://www.gov.uk/government/publications/female-genital-mutilation-resource-pack/female-genital-mutilation-resource-pack#leaflets).

These are available in the following languages:

[Mwy o wybodaeth am FGM](https://assets.nhs.uk/prod/documents/2905952-DH-FGM-Leaflet-Welsh.pdf) – Welsh version (PDF, 164kb)

[ስለ ኤፍ ጂ ኤም ተጨማሪ መረጃ](https://assets.nhs.uk/prod/documents/2905944-DH-FGM-Leaflet-Amharic.pdf) – Amharic version (PDF, 472kb)

[مزيد من المعلومات حول ختان الإناث](https://assets.nhs.uk/prod/documents/2905943-DH-FGM-Leaflet-Arabic.pdf) – Arabic version (PDF, 228kb)

[FGM اطلاعات بیشتر درباره](https://assets.nhs.uk/prod/documents/2905945-DH-FGM-Leaflet-Farsi-Persian.pdf) – Farsi version (PDF, 207kb)

[Renseignements complémentaires sur les MGF](https://assets.nhs.uk/prod/documents/2905946-DH-FGM-Leaflet-French.pdf) – French version (PDF, 167kb)

[Informasi selengkapnya tentang FGM](https://assets.nhs.uk/prod/documents/2905953-DH-FGM-Leaflet-Indonesian.pdf) – Indonesian version (PDF, 160kb)

[FGM زانیاری زیاتر دەربارەی](https://assets.nhs.uk/prod/documents/2905949-DH-FGM-Leaflet-Kurdish-Sorani.pdf) – Kurdish Sorani version (PDF, 245kb)

[Macluumaad dheeraad ah ee ku saabsan FGM](https://assets.nhs.uk/prod/documents/2905951-DH-FGM-Leaflet-Somali.pdf) – Somali version (PDF, 170kb)

[Habari zaidi kuhusu ukeketaji wa wanawake](https://assets.nhs.uk/prod/documents/2905947-DH-FGM-Leaflet-Swahili.pdf) – Swahili version (PDF, 160kb)

[ብዛዕባ ኤፍ ጂ ኤም ተወሳኺ ሓበሬታ](https://assets.nhs.uk/prod/documents/2905948-DH-FGM-Leaflet-Tigrinya.pdf) – Tigrinya version (PDF, 491kb)

[ایف جی ایم کے بارے میں مزید معلومات](https://assets.nhs.uk/prod/documents/2905950-DH-FGM-Leaflet-Urdu.pdf) – Urdu version (PDF, 235kb)

Page last reviewed: 27 September 2022  
Next review due: 27 September 2025
