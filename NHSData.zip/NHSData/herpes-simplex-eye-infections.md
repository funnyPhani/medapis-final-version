Title: Herpes simplex eye infections

URL Source: https://www.nhs.uk/conditions/herpes-simplex-eye-infections/

Published Time: 18 Oct 2017, 2:35 p.m.

Markdown Content:
**A herpes simplex eye infection is a viral infection that can cause a painful, red eye. It's also called eye herpes or ocular herpes. It's important to get treatment because it can sometimes affect your sight.**

Check if it's a herpes simplex eye infection
--------------------------------------------

Herpes simplex eye infections usually affect only one eye.

The symptoms can be similar to some other eye conditions, and can include:

*   eye pain
*   a red eye
*   watering of your eye
*   sensitivity to light
*   blurred vision or other changes to your eyesight
*   a swollen eyelid
*   blisters or a rash on your eyelid or the skin around your eye

It's more likely to be a herpes simplex eye infection if you've had one before, or if you've had [cold sores](https://www.nhs.uk/conditions/cold-sores/).

If you keep getting herpes simplex eye infections they may become less painful.

### If you're not sure it's a herpes simplex eye infection

Find out about other conditions that can cause:

*   a [red eye](https://www.nhs.uk/conditions/red-eye/)
*   [eyelid problems](https://www.nhs.uk/conditions/eyelid-problems/)
*   [watering eyes](https://www.nhs.uk/conditions/watering-eyes/)

Non-urgent advice: See a GP or go to an opticians if:
-----------------------------------------------------

*   you have a red eye with no pain for more than a few days

You can get treatment on the NHS for some eye conditions at some opticians – check before you make an appointment.

If it's not clear what's causing your red eye, you may be referred to an eye specialist (ophthalmologist) for tests.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you have eye pain
*   you have a red eye that's getting worse
*   you have any changes to your eyesight, such as blurred vision
*   you have a swollen, irritated eyelid that has not got better

It might not be anything serious, but it's best to get help as it may need to be treated quickly.

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You have a red eye and:

*   it hurts to look at light
*   your eye is very dark red
*   one pupil is bigger than the other

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Treatment for herpes simplex eye infections
-------------------------------------------

If a GP thinks you have a herpes simplex eye infection they'll refer you to an eye specialist (ophthalmologist). You'll usually be seen the same day so that you can start treatment quickly.

You'll usually be prescribed either:

*   an antiviral medicine such as [aciclovir](https://www.nhs.uk/medicines/aciclovir/), taken as eye ointment, eye drops or sometimes tablets
*   antiviral medicine with steroid eye drops to reduce swelling

Most infections will get better with treatment in a couple of weeks and will not permanently affect your eyesight.

It's common for herpes simplex eye infections to come back. If you keep getting them a doctor might recommend that you take antiviral tablets every day to help prevent infections.

If treatment does not work or you keep getting the infections, your cornea (the transparent front part of your eye) might become scarred, causing sight loss. If this happens you might need to have a [cornea transplant](https://www.nhs.uk/conditions/cornea-transplant/).

Information:

If you use contact lenses, do not wear them until 24 hours after all your symptoms have gone.

How you get herpes simplex eye infections
-----------------------------------------

Most herpes simplex eye infections are caused by the same herpes simplex virus that causes [cold sores](https://www.nhs.uk/conditions/cold-sores/).

You usually get the herpes simplex virus from skin to skin contact from someone with a cold sore. Once you have it, it stays in your body. It does not usually cause any symptoms, but sometimes it can cause eye infections.

This is more likely if you have a weakened immune system. It might also be triggered by an illness, stress, exposure to bright light or an eye injury.

You're unlikely to pass the virus on to someone else from an eye infection, but try to avoid touching your eye, and wash your hands regularly.

Page last reviewed: 25 April 2023  
Next review due: 25 April 2026
