Title: Flu

URL Source: https://www.nhs.uk/conditions/flu/

Published Time: 23 Oct 2017, 12:51 p.m.

Markdown Content:
**Flu will often get better on its own, but it can make some people seriously ill. It's important to get the flu vaccine if you're advised to.**

Check if you have flu
---------------------

Flu symptoms come on very quickly and can include:

*   a sudden high temperature
*   an aching body
*   feeling tired or exhausted
*   a dry cough
*   a sore throat
*   a headache
*   difficulty sleeping
*   loss of appetite
*   diarrhoea or tummy pain
*   feeling sick and being sick

The symptoms are similar for children, but they can also get pain in their ear and appear less active.

Telling the difference between cold and flu

[Cold](https://www.nhs.uk/conditions/common-cold/) and flu symptoms are similar, but flu tends to be more severe.

Differences between cold and flu.
| Flu | Cold |
| --- | --- |
| Appears quickly within a few hours | Appears gradually |
| Affects more than just your nose and throat | Affects mainly your nose and throat |
| Makes you feel exhausted and too unwell to carry on as normal | Makes you feel unwell, but you still feel well enough to do your normal activities |

How to treat flu yourself
-------------------------

If you have flu, there are some things you can do to help get better more quickly.

### Do

*   rest and sleep
    
*   keep warm
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to lower your temperature and treat aches and pains
    
*   give paracetamol or ibuprofen to your child if they're distressed or uncomfortable – check the packaging or leaflet to make sure the medicine is suitable for your child, or speak to a pharmacist or GP if you're not sure
    
*   drink plenty of water to avoid [dehydration](https://www.nhs.uk/conditions/dehydration/) (your pee should be light yellow or clear)
    

### A pharmacist can help with flu

A pharmacist can give treatment advice and recommend flu remedies.

Do not take paracetamol and flu remedies that contain paracetamol at the same time as it's easy to take more than the recommended dose.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Information:

### Antibiotics

Antibiotics do not work for viral infections such as flu. GPs do not recommend antibiotics for flu because they will not relieve your symptoms or speed up your recovery.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

You or your child have symptoms of flu and:

*   you're worried about your baby's or child's symptoms
*   you're 65 or over
*   you're pregnant
*   you have a long-term medical condition – for example, diabetes or a condition that affects your heart, lungs, kidneys, brain or nerves
*   you have a weakened immune system – for example, because of chemotherapy or HIV
*   your symptoms do not improve after 7 days

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Immediate action required: Call 999 or go to A&E if you:
--------------------------------------------------------

*   get sudden chest pain
*   have difficulty breathing
*   start coughing up a lot of blood

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

How to avoid spreading the flu
------------------------------

Flu is very infectious and easily spread to other people. You're more likely to give it to others in the first 5 days.

Flu is spread by germs from coughs and sneezes, which can live on hands and surfaces for 24 hours.

To reduce the risk of spreading flu:

*   wash your hands often with warm water and soap
*   cover your mouth and nose with a tissue when you cough or sneeze (if you do not have a tissue, cough or sneeze into the bend of your elbow, not into your hand)
*   bin used tissues as quickly as possible

Try to stay at home and avoid contact with other people if you have a high temperature or you do not feel well enough to do your normal activities.

See how to wash your hands correctly

### Video: how to wash your hands

Watch this video to find out the best way to wash your hands.

Media last reviewed: 15 March 2023  
Media review due: 15 March 2026

How to get a flu vaccine
------------------------

Flu vaccines are safe and effective. They're offered on the NHS every year in autumn or early winter to help protect people at risk of flu and its complications.

Adults who can have a flu vaccine

A flu vaccine is given to people who:

*   are 65 and over
*   have certain health conditions
*   are pregnant
*   are in long-stay residential care
*   receive a carer's allowance, or are the main carer for an older or disabled person who may be at risk if you get sick
*   live with someone who is more likely to get a severe infection due to a weakened immune system, such as someone living with HIV, someone who has had a transplant, or is having certain treatments for cancer, lupus or rheumatoid arthritis

Children who can have a flu vaccine

The children's nasal spray flu vaccine is given to:

*   children aged 2 or 3 on 31 August 2024 (born between 1 September 2020 and 31 August 2022)
*   all primary school children (Reception to Year 6)
*   some secondary school children (Year 7 to Year 11)
*   children aged 2 to 17 with certain long-term health conditions

Babies and children aged 6 months to 2 years with certain health conditions will be offered a flu vaccine injection instead of the nasal spray.

Where to get a flu vaccine

If you're eligible for an NHS flu vaccine, you can get your vaccine from:

*   your GP surgery
*   a pharmacy that offers NHS flu vaccination (if you're aged 18 or over)

The NHS will let you know in autumn or early winter when you can get your flu vaccine.

Some people may be able to get vaccinated through their maternity service, care home or their employer if they are a frontline health or social care worker.

School-aged children will be offered a vaccine at school or an NHS community clinic.

Information:

### Find out more about the flu vaccine:

*   [adult flu vaccine](https://www.nhs.uk/vaccinations/flu-vaccine/)
*   [children's flu vaccine](https://www.nhs.uk/vaccinations/child-flu-vaccine/)

Page last reviewed: 09 August 2023  
Next review due: 05 September 2025
