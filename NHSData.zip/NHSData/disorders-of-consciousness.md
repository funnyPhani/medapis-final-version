Title: Disorders of consciousness

URL Source: https://www.nhs.uk/conditions/disorders-of-consciousness/

Published Time: 9 May 2018, 1:18 p.m.

Markdown Content:
**A disorder of consciousness, or impaired consciousness, is a state where consciousness has been affected by damage to the brain.**

Consciousness requires both wakefulness and awareness.

Wakefulness is the ability to open your eyes and have basic reflexes such as coughing, swallowing and sucking.

Awareness is associated with more complex thought processes and is more difficult to assess.

Currently, the assessment of awareness relies on physical responses being detected during an examination.

The main disorders of consciousness are:

*   coma
*   vegetative state
*   minimally conscious state

Coma
----

A coma is when a person shows no signs of being awake and no signs of being aware.

A person in a coma lies with their eyes closed and doesn't respond to their environment, voices or pain.

A coma usually lasts for less than 2 to 4 weeks, during which time a person may wake up or progress into a vegetative state or minimally conscious state.

Read more about [comas](https://www.nhs.uk/conditions/coma/).

Vegetative state
----------------

A vegetative state is when a person is awake but is showing no signs of awareness.

A person in a vegetative state may:

*   open their eyes
*   wake up and fall asleep at regular intervals
*   have basic reflexes (such as blinking when they're startled by a loud noise or withdrawing their hand when it's squeezed hard)

They're also able to regulate their heartbeat and breathing without assistance.

But a person in a vegetative state doesn't show any meaningful responses, such as following an object with their eyes or responding to voices.

They also show no signs of experiencing emotions.

If a person is in a vegetative state for a long time, it may be considered to be:

*   **a continuing vegetative state** when it's been longer than 4 weeks
*   **a permanent vegetative state** when it's been more than 6 months if caused by a non-traumatic brain injury, or more than 12 months if caused by a traumatic brain injury

If a person is diagnosed as being in a permanent vegetative state, recovery is extremely unlikely but not impossible.

Minimally conscious state
-------------------------

A person who shows clear but minimal or inconsistent awareness is classified as being in a minimally conscious state.

They may have periods where they can communicate or respond to commands, such as moving a finger when asked.

A person may enter a minimally conscious state after being in a coma or vegetative state.

In some cases a minimally conscious state is a stage on the route to recovery, but in others it's permanent.

As with vegetative state, a continuing minimally conscious state means it's lasted longer than 4 weeks.

But it's more difficult to diagnose a permanent minimally conscious state because it depends on things like:

*   the type of brain injury
*   how severe the injury is
*   how responsive the person is

In most cases, a minimally conscious state isn't usually considered to be permanent until it's lasted for several months and there have been no signs of improvement.

A person thought to be in a permanent minimally conscious state usually has the same prognosis as a person in a vegetative state. The longer they remain in that state, the less chance they have for recovery.

Why they happen
---------------

Disorders of consciousness can occur if the parts of the brain involved with consciousness are damaged.

These types of brain injury can be divided into:

*   **traumatic brain injury** – the result of a severe [head injury](https://www.nhs.uk/conditions/head-injury-and-concussion/), such as an injury sustained during a car accident or a fall from a great height
*   **non-traumatic brain injury** – where the injury to the brain is caused by a health condition, such as a [stroke](https://www.nhs.uk/conditions/stroke/)
*   **progressive brain damage** – where the brain is gradually damaged over time (for example, because of [Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/))

Read more about the [causes of disorders of consciousness](https://www.nhs.uk/conditions/disorders-of-consciousness/causes/).

Making a diagnosis
------------------

A disorder of consciousness will only be confirmed after extensive testing to determine the person's level of wakefulness and awareness.

These examinations need to be carried out by someone experienced in disorders of consciousness, although the views of other healthcare professionals and family members should also be taken into consideration.

For some states of impaired consciousness, such as vegetative state and minimally conscious state, there are recommended criteria to help confirm a diagnosis.

Read more about [diagnosing disorders of consciousness](https://www.nhs.uk/conditions/disorders-of-consciousness/diagnosis/).

Treatment and care
------------------

Treatment can't ensure recovery from a state of impaired consciousness.

Instead, supportive treatment is used to give the best chance of natural improvement.

This can involve:

*   providing nutrition through a feeding tube
*   making sure the person is moved regularly so they don't develop pressure ulcers
*   gently exercising their joints to prevent them becoming tight
*   keeping their skin clean
*   managing their bowel and bladder (for example, using a tube known as a catheter to drain the bladder)
*   keeping their teeth and mouth clean
*   offering opportunities for periods of meaningful activity – such as listening to music or watching television, being shown pictures or hearing family members talking

### Sensory stimulation

In some cases, a treatment called sensory stimulation may be used in an attempt to increase responsiveness.

This involves stimulating the main senses, such as vision, hearing and smell.

It's usually carried out by a trained specialist, but family members are often encouraged to be involved.

Some examples of sensory stimulation include:

*   visual – showing photos of friends and family, or a favourite film
*   hearing – talking or playing a favourite song
*   smell – putting flowers in the room or spraying a favourite perfume
*   touch – holding their hand or stroking their skin with different fabrics

It's not entirely clear how effective sensory stimulation is, but it's sometimes considered worthwhile.

Recovery
--------

It's impossible to predict the chances of someone in a state of impaired consciousness improving.

It largely depends on:

*   the type of brain injury
*   how severe the injury is
*   the person's age
*   how long they have been in the state for

Some people improve gradually, whereas others stay in a state of impaired consciousness for years. Many people never recover consciousness.

There are only isolated cases of people recovering consciousness after several years.

The few people who do regain consciousness after this time often have severe disabilities caused by the damage to their brain.

Withdrawing nutritional support
-------------------------------

If a person is in a permanent vegetative state for 12 months after a traumatic brain injury, or 6 months after a non-traumatic brain injury, then it may be recommended to withdraw their nutritional support.

This is because:

*   there's almost no chance of a recovery by this point
*   prolonging life would have no benefit for the person concerned
*   prolonging treatment could offer false hope and cause unnecessary emotional distress for the friends and family of the person concerned

The medical team will discuss the issue with family members.

If the family disagrees with the decision, then it will be referred to the courts.

If a decision is made to end nutritional support, a palliative care team, which specialises in providing care to the dying, will usually be involved in planning the withdrawal.

Once nutritional support is eventually withdrawn, the person will die within a few weeks

Locked-in syndrome
------------------

Locked-in syndrome has similar features to disorders of consciousness, but is considered and treated differently.

A person with locked-in syndrome is both conscious and aware, but completely [paralysed](https://www.nhs.uk/conditions/paralysis/) and unable to speak.

They're usually able to move their eyes and are sometimes able to communicate by blinking.

Page last reviewed: 27 May 2022  
Next review due: 27 May 2025
