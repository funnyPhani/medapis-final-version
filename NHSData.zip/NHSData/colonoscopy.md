Title: Colonoscopy

URL Source: https://www.nhs.uk/conditions/colonoscopy/

Published Time: 14 Jun 2019, 2:07 p.m.

Markdown Content:
Colonoscopy - NHS
===============
                                     

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/colonoscopy/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

What is a colonoscopy? \- Colonoscopy
=====================================

Contents
--------

1.  What is a colonoscopy?
2.  [Why it's done](https://www.nhs.uk/conditions/colonoscopy/why-its-done/)
3.  [Getting ready](https://www.nhs.uk/conditions/colonoscopy/getting-ready/)
4.  [What happens on the day](https://www.nhs.uk/conditions/colonoscopy/what-happens-on-the-day/)
5.  [Results](https://www.nhs.uk/conditions/colonoscopy/results/)

*   A colonoscopy is a test to check inside your bowels.
*   This test can help find what's causing your bowel symptoms.
*   A long, thin, flexible tube with a small camera inside it is passed into your bottom.
*   You'll be given a laxative so your bowels are empty for the test.

Important
---------

You're usually awake during a colonoscopy. You'll be offered medicine to make you more comfortable and make the test easier.

Video: What happens during a colonoscopy?
-----------------------------------------

In this video, a nurse explains what happens during a colonoscopy.

TranscriptTranscriptAudio DescriptionAudio Description

Video Player is loading.

Play Video

Play

Mute

Current Time 0:00

/

Duration 0:00

Loaded: 0%

0:00

Stream Type LIVE

Seek to live, currently behind liveLIVE

Remaining Time \-0:00

1x

Playback Rate

Chapters

*   Chapters

Descriptions

*   descriptions off, selected
*   English

Subtitles

*   subtitles settings, opens subtitles settings dialog
*   subtitles off, selected

Audio Track

Picture-in-PictureFullscreen

This is a modal window.

Beginning of dialog window. Escape will cancel and close the window.

TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-Transparent

BackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparent

WindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaque

Font Size50%75%100%125%150%175%200%300%400%

Text Edge StyleNoneRaisedDepressedUniformDropshadow

Font FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall Caps

Reset restore all settings to the default valuesDone

Close Modal DialogEnd of dialog window.

Close Modal DialogThis is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

Close Modal DialogThis is a modal window. This modal can be closed by pressing the Escape key or activating the close button.

Displays the text version below the video

Plays the video with descriptive audio

Media last reviewed: 4 April 2024  
Media review due: 4 April 2027

Page last reviewed: 14 November 2022  
Next review due: 14 November 2025

*   [Next : Why it's done](https://www.nhs.uk/conditions/colonoscopy/why-its-done/)

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
