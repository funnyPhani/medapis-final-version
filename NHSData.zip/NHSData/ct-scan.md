Title: CT scan

URL Source: https://www.nhs.uk/conditions/ct-scan/

Published Time: 18 Oct 2017, 9:39 a.m.

Markdown Content:
**A CT scan is a test that takes detailed pictures of the inside of your body. It's usually used to diagnose conditions or check how well treatment is working.**

Why a CT scan is done
---------------------

You may be referred for a CT scan to:

*   check your bones or internal organs after an accident
*   find out if symptoms you've been having are caused by a condition, such as cancer
*   see how well a treatment is working, such as checking the size of a tumour during and after cancer treatment
*   help doctors see inside your body during a procedure, such as taking a sample of cells (biopsy) or draining an abscess

Preparing for a CT scan
-----------------------

The hospital where you're having the CT scan will tell you if there's anything you need to do before it.

For example, you may be asked to:

*   follow a special diet
*   take certain medicines
*   not to eat or drink anything for several hours before the scan (fast)
*   not wear anything that has metal in it, such as jewellery, clothes with zips or poppers, bras or hair clips

Tell the hospital if you:

*   are pregnant or might be pregnant
*   are breastfeeding
*   take any medicines
*   have asthma
*   have kidney or thyroid problems
*   have diabetes
*   have any allergies or have had an allergic reaction to a dye called contrast medium before

Information:

Talk to a GP or doctor at the hospital if you're feeling anxious about having a CT scan or have a fear of small spaces (claustrophobia). They may be able to give you a medicine to help you relax.

You can also ask if you can bring someone to support you during the CT scan.

What happens during a CT scan
-----------------------------

A CT scan is usually done in hospital by a healthcare professional called a radiographer. It usually takes between 10 and 20 minutes.

### Before the CT scan

Depending on why you're having a CT scan, you may be given a dye to help show more detail in the CT scan pictures. The dye is called contrast medium.

It can be given to you in a drink, injected into a vein, or be put in your bottom. It'll pass out of your body in your pee.

If the contrast medium is injected into your body, you may feel:

*   hot and flushed
*   like you have a metal taste in your mouth
*   like you're peeing, but you're not

These feelings usually pass quickly.

### During the CT scan

![Image 1: Person lying on their back with their head in a ring-shaped CT scanner.](https://assets.nhs.uk/nhsuk-cms/images/E41XMA.width-320.jpg)

The CT scanner is a large ring that moves around part of your body as you lie on a flat bed.

1.  You'll be asked to lie on a flat bed.
2.  The radiographer will control the scanner from another room. They'll be able to hear and speak to you during the scan.
3.  You'll need to lie still so the scanner can move over you to take clear images.
4.  You may be asked to breathe in, out, or hold your breath during parts of the scan.

### After the CT scan

If you're having the scan as an outpatient, you'll be able to go home soon after you've had the scan.

If you were given contrast medium, you may be asked to wait in the hospital for up to 30 minutes to make sure you do not have a reaction to it.

Getting your CT scan results
----------------------------

It usually takes between 1 and 2 weeks for you to get your CT scan results. The images need to be looked at by a specialist called a radiologist.

The radiologist will write to the doctor who referred you for the scan. You may need a follow-up appointment to talk about your CT scan results.

If you have not heard anything after a few weeks, contact the doctor who referred you.

The doctor should talk to you about your results and explain what happens next.

Sometimes you may need other tests, depending on why you had the CT scan.

Ask to talk to a healthcare professional if you have questions about your results, or do not understand them.

Possible complications of a CT scan
-----------------------------------

Complications of a CT scan are rare. Some people can have an allergic reaction to the contrast medium (dye). This can cause weakness, sweating and difficulty breathing.

You'll be asked to wait at the hospital for up to 30 minutes after having the scan before you can go home if you had contrast medium.

Tell the radiographer if you feel unwell after the scan.

If you have lots of CT scans, there's a very small chance the radiation from the X-rays can cause cancer. The doctors will weigh up the risks before giving you a scan and discuss this with you.

Page last reviewed: 08 November 2023  
Next review due: 08 November 2026
