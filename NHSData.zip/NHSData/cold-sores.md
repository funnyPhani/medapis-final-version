Title: Cold sores

URL Source: https://www.nhs.uk/conditions/cold-sores/

Published Time: 12 Jan 2018, 11:05 a.m.

Markdown Content:
Check if it's a cold sore
-------------------------

A cold sore usually starts with a tingling, itching or burning feeling.

Over the next 48 hours one or more painful blisters will appear on your face.

![Image 1: Cold sore on the lower lip of someone with white skin.](https://assets.nhs.uk/nhsuk-cms/images/M1700345-Herpes_Cold_Sore-SPL.width-320.jpg)

Cold sore blisters are usually small and filled with fluid.

![Image 2: Cold sore on face just below the nose on someone with white skin.](https://assets.nhs.uk/nhsuk-cms/images/C0144603-Cold_sore-SPL.width-320.jpg)

The blisters can appear anywhere on the face.

![Image 3: Burst cold sore that has become a scab on the lower lip of someone with dark brown skin.](https://assets.nhs.uk/nhsuk-cms/images/C0473050-Cold_sore_on_lip.width-320.jpg)

The blisters burst and crust over into a scab.

Cold sores should start to heal within 10 days, but are contagious and may be irritating or painful while they heal.

Certain things may trigger a cold sore, such as illness, sunshine or being on your period.

When it's not a cold sore

Other possible causes of your symptoms
| Symptoms | Possible causes |
| --- | --- |
| Painful red spot on the face filled with pus
 | Spot or [boil](https://www.nhs.uk/conditions/boils/)

 |
| Blister on the inside of the lip or mouth

 | [Mouth ulcer](https://www.nhs.uk/conditions/mouth-ulcers/)

 |
| Red sores or blisters on the face that become crusty, golden-brown patches

 | [Impetigo](https://www.nhs.uk/conditions/impetigo/)

 |

How long cold sores are contagious
----------------------------------

Cold sores are contagious from the moment you first feel tingling or other signs of a cold sore coming on to when the cold sore has completely healed.

They can easily spread to other people and other parts of your body.

To help stop cold sores spreading:

*   wash your hands with soap and water whenever you touch your cold sore
*   do not kiss anyone while you have a cold sore
*   do not have oral sex until your cold sore completely heals as you could give your partner [genital herpes](https://www.nhs.uk/conditions/genital-herpes/)

### Important

Kissing a baby if you have a cold sore can lead to [neonatal herpes](https://www.nhs.uk/conditions/neonatal-herpes/), which is very dangerous to newborn babies.

A pharmacist can help with cold sores
-------------------------------------

A pharmacist can recommend:

*   creams to ease pain and irritation
*   antiviral creams to speed up healing time
*   cold sore patches to protect the skin while it heals

You can buy electronic devices from pharmacies that treat cold sores with light or lasers.

You may find these helpful, but there's not much evidence to confirm they work.

Information:

If you regularly get cold sores, use antiviral creams as soon as you recognise the early tingling feeling. They do not always work after blisters appear.

[Find a pharmacy](https://www.nhs.uk/service-search/find-a-pharmacy/)

Things you can do yourself to help with cold sores
--------------------------------------------------

There are things you can do to help ease cold sores while they heal and to avoid triggering a cold sore.

### Do

*   avoid anything that triggers your cold sores, such as sunbeds
    
*   use sunblock lip balm (SPF 15 or above) if you're outside in the sun
    
*   take [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) to ease pain and swelling ([liquid paracetamol is available for children](https://www.nhs.uk/medicines/paracetamol-for-children/)) – do not give aspirin to children under 16
    
*   drink plenty of fluids to avoid [dehydration](https://www.nhs.uk/conditions/dehydration/)
    

### Don’t

*   do not touch your cold sore (apart from applying antiviral cream) – and if you do wash your hands before and after
    
*   do not rub cream into the cold sore – dab it on instead
    
*   do not eat acidic or salty food if it makes your cold sore feel worse
    

Non-urgent advice: See a GP if:
-------------------------------

*   a cold sore has not started to heal within 10 days
*   you're worried about a cold sore or think it's something else
*   the cold sore is very large or painful
*   you or your child also have swollen, painful gums and sores in the mouth (gingivostomatitis)
*   you have a weakened immune system – for example, because of chemotherapy or diabetes

Treatment for cold sores from a GP
----------------------------------

A GP may prescribe antiviral tablets if your cold sores are very large, painful or keep coming back.

Newborn babies, pregnant women and people with a weakened immune system may be referred to hospital for advice or treatment.

Why cold sores come back
------------------------

Cold sores are caused by a virus called herpes simplex.

Most people are exposed to the virus when they're children after close skin to skin contact, such as kissing, with someone who has a cold sore.

Once you have the virus, it stays in your skin for the rest of your life. Sometimes it causes a cold sore.

Page last reviewed: 19 February 2024  
Next review due: 19 February 2027
