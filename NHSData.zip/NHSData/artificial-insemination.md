Title: intrauterine insemination (IUI) - NHS

URL Source: https://www.nhs.uk/conditions/artificial-insemination/

Published Time: 17 Oct 2017, 5:07 p.m.

Markdown Content:
**Intrauterine insemination (IUI) is a fertility treatment that involves directly inserting sperm into a woman's womb.**

Accessing IUI on the NHS
------------------------

See your GP if you are considering having IUI on the NHS.

You may be offered IUI if:

*   you're unable to have vaginal sex – for example, because of a physical disability or psychosexual problem
*   you have a condition that means you need specific help to conceive. For example, if 1 of you has [HIV](https://www.nhs.uk/conditions/hiv-and-aids/) and it's not safe to have unprotected sex
*   you're in a same-sex relationship and have not become pregnant after up to 6 cycles of IUI using donor sperm from a licensed fertility unit (read more about [ways to become a parent if you're LGBT+](https://www.nhs.uk/pregnancy/having-a-baby-if-you-are-lgbt-plus/ways-to-become-a-parent-if-you-are-lgbt-plus/))

Bear in mind that the waiting list for IUI treatment on the NHS can be very long in some areas.

The criteria you must meet to be eligible for IUI can also vary. Check with your GP or [local integrated care board](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/) (ICB) to find out what the rules are where you live.

Paying for IUI privately
------------------------

IUI is also available from some private fertility clinics. The Human Fertilisation and Embryology Authority (HFEA) has a [fertility clinic finder](https://www.hfea.gov.uk/choose-a-clinic/).

Costs range from about £700 to £1,600 for each cycle of IUI treatment.

The Human Fertilisation & Embryology Authority (HFEA) website has more information on [costs and funding for fertility treatments](https://www.hfea.gov.uk/treatments/explore-all-treatments/costs-and-funding/).

Fertility tests before IUI
--------------------------

Before IUI is done, you and your partner's fertility will need to be assessed to find out why you are having difficulty conceiving and to see whether IUI is suitable for you.

Read more about [diagnosing infertility](https://www.nhs.uk/conditions/infertility/diagnosis/).

For a woman to have IUI, her fallopian tubes (the tubes connecting the ovaries to the womb) must be open and healthy.

You and your partner will not usually be offered IUI if you have:

*   unexplained infertility
*   a low sperm count or poor‑quality sperm
*   mild [endometriosis](https://www.nhs.uk/conditions/endometriosis/)

This is because there is some evidence to suggest that IUI will not increase your chances of getting pregnant in these circumstances, compared with trying to get pregnant naturally.

Timing your IUI treatment
-------------------------

You may be offered IUI in a natural (unstimulated) cycle or in a stimulated cycle.

To increase your chances of success, a cycle of IUI should be done just after ovulation. Ovulation usually happens 12 to 16 days before your next period. This can vary if you have an irregular menstrual cycle.

You may be given an ovulation prediction kit (OPK) to help you work out the date of ovulation. An OPK device detects hormones released during ovulation in urine or saliva.

Otherwise, blood tests may be used to find out when you are about to ovulate.

### Stimulated IUI

Sometimes, [fertility medicines](https://www.nhs.uk/conditions/infertility/treatment/) are used to stimulate ovulation before IUI. In this case, vaginal [ultrasound scans](https://www.nhs.uk/conditions/ultrasound-scan/) are used to track the development of your eggs. As soon as an egg is mature, you'll be given a hormone injection to stimulate its release.

IUI using a partner's sperm
---------------------------

If a couple decides to have IUI using their own sperm, the man will be asked to provide a sperm sample at the fertility clinic by masturbating into a specimen cup. This usually happens on the same day that IUI takes place.

The sperm sample will be "washed" and filtered to produce a concentrated sample of healthy sperm.

An instrument called a speculum is inserted into the woman's vagina to keep it open. A thin, flexible tube called a catheter is then placed inside the vagina and guided into the womb. The sperm sample is then passed through the catheter and into the womb.

This process is mostly painless, although some women experience mild cramping for a short time.

The process usually takes no more than 10 minutes. You should be able to go home after a short rest.

IUI using donor sperm
---------------------

Frozen sperm from a donor can also be used for IUI, regardless of whether you are single or in a partnership, gay or straight.

All licensed fertility clinics in the UK are required to screen donor sperm for infections and inherited diseases.

Some infections take a while to show, so the sperm will be frozen for 6 months to allow time for infections, such as HIV, to be detected.

The sperm is frozen whether it's from someone you know, or from a registered and licensed sperm bank.

Choosing to use donated sperm can be a difficult decision, and you should be offered counselling before you go ahead.

The Human Fertilisation and Embryology Authority (HFEA) has more information about [using a sperm donor](https://www.hfea.gov.uk/treatments/explore-all-treatments/using-donated-eggs-sperm-or-embryos-in-treatment/).

Your chances of success with IUI
--------------------------------

This depends on lots of different things, including:

*   the cause of infertility
*   the woman's age
*   the man's sperm count and sperm quality (using fresh sperm leads to higher conception rates than using frozen sperm)
*   whether fertility medicines are used to stimulate ovulation (this can increase your chances of success)

There are many different factors involved, so it's best to talk to your fertility team about your individual chances of success.

Are there any risks?
--------------------

Some women have mild cramps similar to period pains, but otherwise the risks involved with IUI are minimal.

If you have fertility medicine to stimulate ovulation, there is a small risk of developing ovarian hyperstimulation syndrome. Read more about this condition on our page about [the risks of IVF](https://www.nhs.uk/conditions/ivf/risks/). There's also a chance that you will have more than 1 baby, which has additional risks for both you and your babies.

Page last reviewed: 10 March 2020  
Next review due: 10 March 2023
