Title: Hysterectomy

URL Source: https://www.nhs.uk/conditions/hysterectomy/

Published Time: 23 Oct 2017, 2 p.m.

Markdown Content:
**A hysterectomy is a surgical procedure to remove the womb (uterus). You'll no longer be able to get pregnant after the operation.**

If you have not already gone through the [menopause](https://www.nhs.uk/conditions/menopause/), you'll no longer have periods, regardless of your age.

It's more common for women aged 40 to 50.

Why do I need a hysterectomy?
-----------------------------

Hysterectomies are carried out to treat health problems that affect the female reproductive system.

These include:

*   [heavy periods](https://www.nhs.uk/conditions/heavy-periods/)
*   long-term [pelvic pain](https://www.nhs.uk/conditions/pelvic-pain/)
*   [non-cancerous tumours (fibroids)](https://www.nhs.uk/conditions/fibroids/)
*   [ovarian cancer](https://www.nhs.uk/conditions/ovarian-cancer/), [womb cancer](https://www.nhs.uk/conditions/womb-cancer/), [cervical cancer](https://www.nhs.uk/conditions/cervical-cancer/) or cancer of the fallopian tubes

A hysterectomy is a major operation with a long recovery time and is only considered after less invasive treatments have been tried.

[Find out why a hysterectomy is needed](https://www.nhs.uk/conditions/hysterectomy/why-its-done/)

Things to consider
------------------

If you have a hysterectomy, as well as having your womb removed, you may have to decide whether to also have your cervix or ovaries removed.

Your decision will usually be based on your personal feelings, medical history and any recommendations your doctor may have.

[Find out the things to consider before having a hysterectomy](https://www.nhs.uk/conditions/hysterectomy/considerations/)

Types of hysterectomy
---------------------

There are various types of hysterectomy. The type you have depends on why you need the operation and how much of your womb and surrounding reproductive system can safely be left in place.

The main types of hysterectomy are:

*   total hysterectomy – the womb and cervix (neck of the womb) are removed; this is the most commonly performed operation
*   subtotal hysterectomy – the main body of the womb is removed, leaving the cervix in place
*   total hysterectomy with bilateral salpingo-oophorectomy – the womb, cervix, fallopian tubes (salpingectomy) and ovaries (oophorectomy) are removed
*   radical hysterectomy – the womb and surrounding tissues are removed, including the fallopian tubes, part of the vagina, ovaries, lymph glands and fatty tissue

There are 3 ways to carry out a hysterectomy:

*   laparoscopic hysterectomy (keyhole surgery) – where small cuts are made in the tummy and the womb is removed through a cut in the vagina
*   vaginal hysterectomy – where the womb is removed through a cut in the top of the vagina
*   abdominal hysterectomy – where the womb is removed through a cut in the lower tummy

[Find out how a hysterectomy is performed](https://www.nhs.uk/conditions/hysterectomy/what-happens/)

Complications of a hysterectomy
-------------------------------

There's a small risk of complications, including:

*   heavy bleeding
*   infection
*   damage to your bladder or bowel
*   a serious reaction to the [general anaesthetic](https://www.nhs.uk/conditions/general-anaesthesia/)

[Find out more about the complications of a hysterectomy](https://www.nhs.uk/conditions/hysterectomy/risks/)

Recovering from a hysterectomy
------------------------------

A hysterectomy is a major operation. You can be in hospital for up to 5 days after surgery, and it can take about 6 to 8 weeks to fully recover.

Recovery times can also vary depending on the type of hysterectomy.

Rest as much as possible during this time and do not lift anything heavy, such as bags of shopping. You need time for your abdominal muscles and tissues to heal.

[Find out more about recovering from a hysterectomy](https://www.nhs.uk/conditions/hysterectomy/recovery/)

Surgical menopause
------------------

If your ovaries are removed during a hysterectomy, you'll go through the menopause immediately after the operation, regardless of your age. This is known as a surgical menopause.

If 1 or both of your ovaries are left intact, there's a chance you'll have the menopause sooner than you would have if you did not have a hysterectomy.

If you experience a surgical menopause after having a hysterectomy, you should be offered [hormone replacement therapy (HRT)](https://www.nhs.uk/medicines/hormone-replacement-therapy-hrt/).

The female reproductive system
------------------------------

The female reproductive system is made up of the:

*   womb (uterus) – a pear-shaped organ in the middle of your pelvis where a baby develops; the lining of the womb is shed during a period
*   cervix – the neck of the womb, where the womb meets the vagina; the cervix is the lower part of the womb and not separate
*   vagina – a muscular tube below the cervix
*   fallopian tubes – tubes that connect the womb to the ovaries
*   ovaries – small organs by the fallopian tubes that release an egg each month

Page last reviewed: 11 October 2022  
Next review due: 11 October 2025
