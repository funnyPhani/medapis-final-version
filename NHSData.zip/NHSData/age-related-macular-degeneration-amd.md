Title: Age-related macular degeneration (AMD)

URL Source: https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/

Published Time: 23 Oct 2017, 2:25 p.m.

Markdown Content:
Age-related macular degeneration (AMD) - NHS
===============
                                    

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

What is AMD? \- Age-related macular degeneration (AMD)
======================================================

Contents
--------

1.  What is AMD?
2.  [Symptoms](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/symptoms/)
3.  [Getting diagnosed](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/getting-diagnosed/)
4.  [Treatments](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/treatment/)
5.  [Living with AMD](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/living-with-amd/)

*   **Age-related macular degeneration (AMD) is a common condition that affects the middle part of your vision.** It usually first affects people in their 50s and 60s.
*   **It does not cause total blindness.** But it can make everyday activities like reading and recognising faces difficult.
*   **Without treatment, your vision may get worse.** This can happen gradually over several years ("dry AMD"), or quickly over a few weeks or months ("wet AMD").
*   **The exact cause is unknown.** It's been linked to smoking, high blood pressure, being overweight and having a family history of AMD.

Page last reviewed: 20 April 2021  
Next review due: 20 April 2024

*   [Next : Symptoms](https://www.nhs.uk/conditions/age-related-macular-degeneration-amd/symptoms/)

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
