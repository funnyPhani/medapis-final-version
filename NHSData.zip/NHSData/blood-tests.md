Title: Blood tests

URL Source: https://www.nhs.uk/conditions/blood-tests/

Published Time: 3 Oct 2018, 9 p.m.

Markdown Content:
**A blood test is often done to check your health, or to find out why you're having certain symptoms. It involves having a small amount of your blood taken for testing.**

Why a blood test is done
------------------------

There are lots of reasons why you may need a blood test.

A blood test may be done to:

*   check your general health
*   find out if symptoms you're having are caused by certain conditions
*   find out if you're more likely to get a condition
*   find out how well a condition is being treated or managed

How to get a blood test
-----------------------

If a healthcare professional such as a GP, nurse or a specialist thinks you need a blood test they will tell you how to book one.

Preparing for a blood test
--------------------------

The GP, nurse, or specialist should tell you if you need to do anything to prepare for a blood test.

For example, for a short time before some tests, you may need to:

*   not eat or drink anything other than water (fast)
*   stop taking certain medicines, such as medicines to help prevent blood clots (anticoagulant medicines)

What happens at a blood test
----------------------------

A blood test is usually done at a GP surgery or hospital. The test usually takes about 10 minutes.

A healthcare professional will take a small amount of blood, usually from the inside of your elbow, using a needle. Sometimes blood may be taken from your wrist, or your finger (called a finger-prick test).

A soft strap (tourniquet) may be put around your arm first. This helps to make taking blood easier.

You’ll feel a scratch as the needle goes in, which may be a bit uncomfortable. Your blood will be collected in a small tube which will be sent to a lab for testing.

After the test, you'll usually be given some cotton wool or a plaster to cover the area where the blood was taken.

You may get some bruising or swelling around the area where your blood was taken, but this should go away after a few days.

Information:

### If you're worried about needles

Tell the healthcare professional doing your blood test if you're worried about needles. They can help you feel more comfortable during the test.

You can also bring someone with you to the blood test to support you.

Getting your blood test results
-------------------------------

You may get your blood test results after a few days, and usually within a few weeks.

If you do not hear anything after a few weeks, contact the GP surgery or specialist.

The GP, nurse, or specialist should talk to you about your results and explain what happens next.

If your results do not show anything, you may not need to do anything else. Sometimes you may need other tests, depending on why you had the blood test.

Ask to talk to a healthcare professional if you have questions about your results, or do not understand them.

Information:

### **View your results online**

Results of tests you had at your GP surgery, and results that have been shared with your GP surgery, may be available in your online GP health record.

[View test results in your GP health record](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)

Find out more
-------------

*   [Find out more about types of blood tests from the Lab Tests Online UK website](https://labtestsonline.org.uk/tests-index)

Page last reviewed: 02 November 2023  
Next review due: 02 November 2026
