Title: Age-related cataracts

URL Source: https://www.nhs.uk/conditions/cataracts/

Published Time: 17 Oct 2017, 7:46 p.m.

Markdown Content:
**Cataracts are when the lens, a small transparent disc inside your eye, develops cloudy patches.**

Over time these patches usually become bigger causing blurry, misty vision and eventually blindness.

When we're young, our lenses are usually like clear glass, allowing us to see through them. As we get older, they start to become frosted, like bathroom glass, and begin to limit our vision.

![Image 1: An eye with cataracts](https://assets.nhs.uk/nhsuk-cms/images/S_1217_agre-related-cataract_M1550430.width-320.jpg)

Cataracts usually appear in both eyes. They may not necessarily develop at the same time or be the same in each eye.

They're more common in older adults and can affect your ability to carry out daily activities such as driving.

Cataracts can also affect babies and young children.

[Read more about childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/)

When to seek medical advice
---------------------------

You should see an optician if you have any of these symptoms:

*   your eyesight is blurred or misty
*   you find lights too bright or glaring
*   you find it harder to see in low light
*   colours look faded

If you wear glasses, you may feel your lenses are dirty and need cleaning, even when they do not.

Cataracts are not usually painful and do not make your eyes red or irritated, but they can be painful if they're in an advanced stage or if you've got another eye condition.

Testing for age-related cataracts
---------------------------------

An optician will do a series of eye tests, including a visual acuity exam, which measures how well you see at various distances.

If the optician thinks you have cataracts, you may be referred to an eye specialist (ophthalmologist) for more tests and treatment.

Treating age-related cataracts
------------------------------

If your cataracts are not too bad, stronger glasses and brighter reading lights may help for a while.

But cataracts get worse over time, so you'll eventually need surgery to remove and replace the affected lens.

Surgery is the only treatment that's proven to be effective for cataracts.

[Read about cataract surgery](https://www.nhs.uk/conditions/cataract-surgery/)

Driving and cataracts
---------------------

If you have cataracts, it could affect your ability to drive.

You do not need to tell the DVLA if you have (or previously had) cataracts and you still meet the [visual standards for driving](https://www.gov.uk/driving-eyesight-rules).

If you drive a bus, coach or lorry, you do not need to tell the DVLA if you have (or previously had) cataracts and:

*   you still meet the [visual standards for driving](https://www.gov.uk/driving-eyesight-rules)
*   you do not have an increased sensitivity to glare because of the cataract

[Read about cataracts and driving on the GOV.UK website](https://www.gov.uk/cataracts-and-driving)

What causes age-related cataracts?
----------------------------------

It's not entirely clear why we're more likely to develop cataracts as we get older, but some things may increase your risk of cataracts, including:

*   a family history of cataracts
*   smoking
*   [diabetes](https://www.nhs.uk/conditions/diabetes/)
*   eye injury
*   long-term use of steroids
*   drinking too much alcohol

Page last reviewed: 22 December 2020  
Next review due: 22 December 2023
