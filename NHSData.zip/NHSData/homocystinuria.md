Title: Homocystinuria

URL Source: https://www.nhs.uk/conditions/homocystinuria/

Published Time: 9 May 2018, 1:20 p.m.

Markdown Content:
**Homocystinuria (HCU) is a rare but potentially serious inherited condition.**

It means the body can't process the amino acid methionine. This causes a harmful build-up of substances in the blood and urine.

Normally, our bodies break down protein foods like meat and fish into amino acids, which are the "building blocks" of protein. Any amino acids that aren't needed are usually broken down and removed from the body.

Babies with HCU are unable to fully break down methionine, causing a build-up of methionine and a chemical called homocysteine. This build-up can be harmful.

Diagnosing homocystinuria
-------------------------

At around 5 days old, babies are offered a [newborn blood spot test](https://www.nhs.uk/conditions/baby/newborn-screening/blood-spot-test/) to check if they have HCU. This involves pricking your baby's heel to collect drops of blood to test.

If HCU is diagnosed, treatment can be given to reduce the risk of serious complications. Treatment may include trial doses of vitamin B6 (pyridoxine), a special diet and advice.

With early diagnosis and the correct treatment, the majority of children with HCU are able to live healthy lives. However, treatment for HCU must be continued for life.

Babies born with HCU don't usually have any symptoms in the first year of their life. But severe symptoms can develop later in life without early treatment. These may include:

*   vision problems, such as severe [short-sightedness (myopia)](https://www.nhs.uk/conditions/short-sightedness/)
*   weak bones ([osteoporosis](https://www.nhs.uk/conditions/osteoporosis/))
*   bone and joint problems
*   a risk of developing [blood clots](https://www.nhs.uk/conditions/blood-clots/) and [strokes](https://www.nhs.uk/conditions/stroke/)

Some children with untreated HCU are also at risk of brain damage, and their development might be affected.

Treating homocystinuria
-----------------------

### Vitamin B6 (pyridoxine)

In some babies, it's possible to control the levels of homocysteine with vitamin B6 (pyridoxine). If this works, your child will need to take vitamin B6 supplements for the rest of their life.

### Diet

Children diagnosed with HCU that doesn't respond to vitamin B6 are referred to a specialist metabolic dietitian and given a low-protein diet. This is tailored to reduce the amount of methionine your baby receives.

High-protein foods need to be limited, including:

*   meat
*   fish
*   cheese
*   eggs
*   pulses
*   nuts

Your dietitian will provide detailed advice and guidance, as your baby still needs some of these foods for healthy growth and development.

Breastfeeding and baby milk also need to be monitored and measured, as advised by your dietitian. Special formula milk may be used. The diet will be designed to contain all the vitamins, minerals and other amino acids your baby needs.

As your baby moves on to solid foods, your dietitian can explain which low-protein foods are suitable. Some of these may be available on prescription, including low-protein rusks, milk substitutes and low-protein pasta.

People with HCU may need to follow a modified diet for the rest of their life. As your child gets older, they'll eventually need to learn how to control their diet and stay in contact with a dietitian for advice and monitoring.

Regular [blood tests](https://www.nhs.uk/conditions/blood-tests/) will also be needed to monitor the amount of homocysteine in their blood.

### Medicine

Alongside a low-protein diet, your child may be prescribed a medicine called betaine in later childhood to help clear some of the excess homocysteine.

Medicine for HCU needs to be taken regularly, as directed by your doctor.

How homocystinuria is inherited
-------------------------------

The genetic cause (mutation) responsible for HCU is passed on by parents, who usually don't have any symptoms of the condition.

The way this mutation is passed on is known as autosomal recessive inheritance. This means a baby needs to receive two copies of the mutated gene to develop the condition – one from their mother and one from their father. If the baby only receives one affected gene, they'll just be a carrier of HCU.

If you're a carrier of the altered gene and you have a baby with a partner who's also a carrier, your baby has:

*   a 1 in 4 chance of developing the condition
*   a 2 in 4 chance of being a carrier of HCU
*   a 1 in 4 chance of receiving a pair of normal genes

Although it's not possible to prevent HCU, it's important to let your midwife and doctor know if you have a family history of the condition.

Any further children you have can be tested for the condition as soon as possible and given appropriate treatment.

You may also wish to consider [genetic counselling](https://www.nhs.uk/conditions/genetic-and-genomic-testing/) for information and advice about genetic conditions.

Information about your child
----------------------------

If your child has HCU, your clinical team will pass information about them on to the National Congenital Anomaly and Rare Disease Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about NCARDRS on GOV.UK](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet).

Page last reviewed: 19 May 2022  
Next review due: 19 May 2025
