Title: Chorionic villus sampling

URL Source: https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/

Published Time: 7 Jun 2018, 6:18 p.m.

Markdown Content:
Chorionic villus sampling (CVS) is a test you may be offered during pregnancy to check if your baby has a genetic or chromosomal condition, such as Down's syndrome, Edwards' syndrome or Patau's syndrome.

It involves removing and testing a small sample of cells from the placenta, the organ linking the mother's blood supply with the unborn baby's.

When CVS is offered
-------------------

CVS is not routinely offered in pregnancy.

It's only offered if there's a high chance your baby could have a genetic or chromosomal condition.

This could be because:

*   an [antenatal screening test](https://www.nhs.uk/conditions/pregnancy-and-baby/screening-tests-abnormality-pregnant/) has suggested your baby may be born with a condition, such as [Down's syndrome](https://www.nhs.uk/conditions/downs-syndrome/), [Edwards' syndrome](https://www.nhs.uk/conditions/edwards-syndrome/) or [Patau's syndrome](https://www.nhs.uk/conditions/pataus-syndrome/)
*   you had a previous pregnancy affected by a genetic condition
*   you have a family history of a genetic condition, such as [sickle cell disease](https://www.nhs.uk/conditions/sickle-cell-disease/), [thalassaemia](https://www.nhs.uk/conditions/thalassaemia/), [cystic fibrosis](https://www.nhs.uk/conditions/cystic-fibrosis/) or [muscular dystrophy](https://www.nhs.uk/conditions/muscular-dystrophy/)

It's important to remember that you do not have to have CVS if it's offered. It's up to you to decide whether you want it.

A midwife or doctor will speak to you about what the test involves, and let you know what the possible benefits are, to help you make a decision.

[Find out more about why CVS is offered and deciding whether to have it](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/why-its-done/)

How CVS is performed
--------------------

CVS is usually carried out between the 11th and 14th weeks of pregnancy, although it's sometimes performed later than this if necessary.

During the test, a small sample of cells is removed from the placenta using 1 of 2 methods:

*   transabdominal CVS – a needle is inserted through your tummy (this is the most common method used)
*   transcervical CVS – a tube or small forceps (smooth metal instruments that look like tongs) are inserted through the cervix (the neck of the womb)

The test itself takes about 10 minutes, although the whole consultation may take about 30 minutes.

The CVS procedure is usually described as being uncomfortable rather than painful, although you may experience some cramps that are similar to [period pains](https://www.nhs.uk/conditions/period-pain/) for a few hours afterwards.

[Find out more about what happens during CVS](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/what-happens/)

Getting your results
--------------------

The first results of the test should be available in about 3 days. This is known as the rapid CVS result.

A more detailed set of CVS results will be available after 2 weeks.

If the rapid CVS result and a previous ultrasound scan both indicate your baby has a condition, your doctor will discuss your options with you straightaway.

If your previous ultrasound did not find anything unexpected, it’s recommended you wait until the more detailed set of CVS results before making a decision about ending your pregnancy.

If the results of these tests suggest it is highly likely your baby has a genetic condition, a specialist doctor (obstetrician) or midwife will explain what the screening results mean and talk to you about your options.

There's no cure for most of the conditions found by CVS, so you'll need to consider your options carefully.

You may decide to continue with your pregnancy while gathering information about the condition so you're fully prepared.

[Find out more about having a baby that might be born with a genetic condition](https://www.nhs.uk/conditions/pregnancy-and-baby/having-a-baby-that-might-be-born-with-a-condition/)

Or you may consider [ending your pregnancy](https://www.nhs.uk/conditions/pregnancy-and-baby/termination-abortion-for-foetal-abnormality/) (having a termination).

[Find out more about the results of CVS](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/results/)

Miscarriage and infections.
---------------------------

Before you decide to have CVS, the possible complications will be discussed with you.

CVS can cause [miscarriage](https://www.nhs.uk/conditions/miscarriage/), the loss of the pregnancy in the first 23 weeks. The chance of miscarrying after CVS is thought to be less than 1 in 200 for most pregnancies, and at around 1 in 100 for multiple pregnancies (such as twins).

You might also get an infection, or need to have CVS again because it was not successful the first time.

[Read more about the complications of CVS](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/risks/)

What are the alternatives?
--------------------------

An alternative to CVS is a test called [amniocentesis](https://www.nhs.uk/conditions/amniocentesis/).

This is where a small sample of amniotic fluid, the fluid that surrounds the baby in the womb, is removed for testing.

It's usually carried out between the 15th and 18th week of pregnancy, although it can be performed later than this if necessary.

This test can also cause a miscarriage, but your pregnancy will be at a more advanced stage before you can get the results, so you'll have less time to consider your options.

If you're offered tests to look for a genetic or chromosomal condition in your baby, a specialist involved in carrying out the test will be able to discuss the different options with you and help you make a decision.

Page last reviewed: 03 January 2023  
Next review due: 03 January 2026
