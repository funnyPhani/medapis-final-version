Title: Compartment syndrome

URL Source: https://www.nhs.uk/conditions/compartment-syndrome/

Published Time: 18 Oct 2017, 9:26 a.m.

Markdown Content:
**Compartment syndrome is an increase in pressure inside a muscle, which restricts blood flow and causes pain. If it happens suddenly, it can be serious and need treatment as soon as possible.**

Check if you have compartment syndrome
--------------------------------------

You can get compartment syndrome in any muscle, but it most often affects the muscles in the lower legs and forearms.

Symptoms include:

*   pain in a muscle – this may feel like a burning pain or a deep ache (moving the body part can make the pain even worse)
*   swelling or bulging of the muscle
*   numbness, weakness or pins and needles
*   tightness or difficulty moving the affected body part

The symptoms can start suddenly, such as after an injury or if a bandage or plaster cast is too tight. This is called acute compartment syndrome.

Symptoms can also come on gradually after exercising and go away when you rest. This is called chronic compartment syndrome.

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   you have sudden, severe pain in any part of your body

If compartment syndrome is causing the pain, you’ll need surgery to treat it as soon as possible.

[Find your nearest A&E](https://www.nhs.uk/service-search/other-services/Accident-and-emergency-services/LocationSearch/428)

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Non-urgent advice: See a GP if:
-------------------------------

*   you keep getting pain, numbness, swelling, or have difficulty moving a part of your body when you exercise

A GP can help find out if the pain is caused by compartment syndrome or another condition.

Tests for compartment syndrome
------------------------------

If the GP thinks you may have compartment syndrome, you may be referred to a specialist for tests.

Tests you may have include:

*   an [X-ray](https://www.nhs.uk/conditions/x-ray/) to check if you’ve broken a bone
*   [MRI scans](https://www.nhs.uk/conditions/mri-scan/) while you’re resting and while you’re exercising
*   compartment pressure measurement – a needle connected to a pressure monitoring device is inserted into your muscle before and after exercise to measure the pressure inside it

Measuring the pressure inside a muscle is usually only recommended if your symptoms and other test results suggest compartment syndrome.

Treatments for compartment syndrome
-----------------------------------

Treatment for compartment syndrome depends on whether it happens suddenly or comes on gradually.

### Sudden (acute) compartment syndrome

If compartment syndrome happens suddenly, you’ll need surgery as soon as possible to relieve the pressure in the muscle.

This type of surgery is called a fasciotomy. During a fasciotomy, the surgeon makes cuts around the muscle to relieve the pressure.

Sometimes, skin may need to be removed from another part of the body and used to cover the wound. This is known as a skin graft.

After the operation, you’ll have medicine to help ease any pain. You may also need [physiotherapy](https://www.nhs.uk/conditions/physiotherapy/) to help regain full movement in the affected part of your body.

### Gradual (chronic) compartment syndrome

Treatment is often not needed for compartment syndrome that develops gradually.

To help relieve your symptoms you can:

*   avoid the activity that caused them – if you run, switching to a low-impact exercise, such as cycling, may help
*   use [anti-inflammatory painkillers](https://www.nhs.uk/conditions/nsaids/) to reduce the pain and discomfort
*   have physiotherapy
*   use inserts (orthotics) in your shoes if you start running again

If your symptoms do not improve after trying these things, surgery may be an option. The operation is similar to the one used to treat acute compartment syndrome.

Page last reviewed: 09 February 2023  
Next review due: 09 February 2026
