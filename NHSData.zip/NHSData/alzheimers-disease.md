Title: Alzheimer's disease

URL Source: https://www.nhs.uk/conditions/alzheimers-disease/

Published Time: 10 May 2018, 3:10 p.m.

Markdown Content:
**Alzheimer's disease is the most common cause of dementia in the UK.**

[Dementia](https://www.nhs.uk/conditions/dementia/about-dementia/what-is-dementia/) is the name for a group of symptoms associated with an ongoing decline of brain functioning. It can affect memory, thinking skills and other mental abilities.

The exact cause of Alzheimer's disease is not yet fully understood, although a number of things are thought to increase your risk of developing the condition.

These include:

*   increasing age
*   a family history of the condition
*   untreated [depression](https://www.nhs.uk/conditions/stress-anxiety-depression/low-mood-and-depression/), although depression can also be one of the symptoms of Alzheimer's disease
*   lifestyle factors and conditions associated with [cardiovascular disease](https://www.nhs.uk/conditions/cardiovascular-disease/)

Read more about the [causes of Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/causes/).

Signs and symptoms of Alzheimer's disease
-----------------------------------------

Alzheimer's disease is a progressive condition, which means the symptoms develop gradually over many years and eventually become more severe. It affects multiple brain functions.

The first sign of Alzheimer's disease is usually minor memory problems.

For example, this could be forgetting about recent conversations or events, and forgetting the names of places and objects.

As the condition develops, memory problems become more severe and further symptoms can develop, such as:

*   confusion, disorientation and getting lost in familiar places
*   difficulty planning or making decisions
*   problems with speech and language
*   problems moving around without assistance or performing self-care tasks
*   personality changes, such as becoming aggressive, demanding and suspicious of others
*   [hallucinations](https://www.nhs.uk/conditions/hallucinations/) (seeing or hearing things that are not there) and delusions (believing things that are untrue)
*   low mood or anxiety

Read more about the [symptoms of Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/symptoms/).

Who is affected?
----------------

Alzheimer's disease is most common in people over the age of 65.

The risk of Alzheimer's disease and other types of dementia increases with age, affecting an estimated 1 in 14 people over the age of 65 and 1 in every 6 people over the age of 80.

But around 1 in every 20 people with Alzheimer's disease are under the age of 65. This is called early- or young-onset Alzheimer's disease.

Getting a diagnosis
-------------------

As the symptoms of Alzheimer's disease progress slowly, it can be difficult to recognise that there's a problem. Many people feel that memory problems are simply a part of getting older.

Also, the disease process itself may (but not always) prevent people recognising changes in their memory. But Alzheimer's disease is not a "normal" part of the ageing process.

An accurate and timely diagnosis of Alzheimer's disease can give you the best chance to prepare and plan for the future, as well as receive any treatment or support that may help.

If you're worried about your memory or think you may have dementia, it's a good idea to see a GP.

If possible, someone who knows you well should be with you as they can help describe any changes or problems they have noticed.

If you're worried about someone else, encourage them to make an appointment and perhaps suggest that you go along with them.

There's no single test that can be used to diagnose Alzheimer's disease. And it's important to remember that memory problems do not necessarily mean you have Alzheimer's disease.

A GP will ask questions about any problems you're experiencing and may do some tests to rule out other conditions.

If Alzheimer's disease is suspected, you may be referred to a specialist service to:

*   assess your symptoms in more detail
*   organise further testing, such as brain scans if necessary
*   create a treatment and care plan

Read more about [diagnosing Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/diagnosis/).

How Alzheimer's disease is treated
----------------------------------

There's currently no cure for Alzheimer's disease, but medicines are available that can help relieve some of the symptoms.

Various other types of support are also available to help people with Alzheimer's live as independently as possible, such as making changes to your home environment so it's easier to move around and remember daily tasks.

Psychological treatments such as cognitive stimulation therapy may also be offered to help support your memory, problem solving skills and language ability.

Read more about [treating Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/treatment/).

Outlook
-------

People with Alzheimer's disease can live for several years after they start to develop symptoms. But this can vary considerably from person to person.

Alzheimer's disease is a life-limiting illness, although many people diagnosed with the condition will die from another cause.

As Alzheimer's disease is a progressive neurological condition, it can cause problems with swallowing.

This can lead to aspiration (food being inhaled into the lungs), which can cause frequent chest infections.

It's also common for people with Alzheimer's disease to eventually have difficulty eating and have a reduced appetite.

There's increasing awareness that people with Alzheimer's disease need [palliative care](https://www.nhs.uk/conditions/end-of-life-care/).

This includes support for families, as well as the person with Alzheimer's.

Can Alzheimer's disease be prevented?
-------------------------------------

As the exact cause of Alzheimer's disease is not clear, there's no known way to prevent the condition.

But there are things you can do that may reduce your risk or delay the onset of dementia, such as:

*   [stopping smoking](https://www.nhs.uk/live-well/quit-smoking/10-self-help-tips-to-stop-smoking/) and [cutting down on alcohol](https://www.nhs.uk/live-well/alcohol-advice/tips-on-cutting-down-alcohol/)
*   eating a [healthy, balanced diet](https://www.nhs.uk/live-well/eat-well/) and maintaining a healthy weight
*   staying [physically fit](https://www.nhs.uk/live-well/exercise/physical-activity-guidelines-for-adults-aged-19-to-64/) and mentally active

These measures have other health benefits, such as lowering your risk of cardiovascular disease and improving your overall mental health.

Read more about [preventing Alzheimer's disease](https://www.nhs.uk/conditions/alzheimers-disease/prevention/).

Dementia research
-----------------

There are dozens of dementia research projects going on around the world, many of which are based in the UK.

If you have a diagnosis of dementia or are worried about memory problems, you can help scientists better understand the disease by taking part in research.

If you're a carer for someone with dementia, you can also take part in research.

You can sign up to take part in trials on the [NHS Join Dementia Research website](https://www.joindementiaresearch.nihr.ac.uk/).

More information
----------------

Dementia can affect all aspects of a person's life, as well as their family's.

If you have been diagnosed with dementia, or you're caring for someone with the condition, remember that advice and support is available to help you live well.

Read more about:

*   [Staying independent with dementia](https://www.nhs.uk/conditions/dementia/living-with-dementia/staying-independent/)
*   [Living well with dementia](https://www.nhs.uk/conditions/dementia/living-with-dementia/living-well/)
*   [Communicating with someone with dementia](https://www.nhs.uk/conditions/dementia/living-with-dementia/communication/)
*   [Looking after someone with dementia](https://www.nhs.uk/conditions/dementia/living-with-dementia/looking-after-someone/)
*   [Coping with dementia behaviour changes](https://www.nhs.uk/conditions/dementia/living-with-dementia/behaviour/)
*   [Help and support for people with dementia](https://www.nhs.uk/conditions/dementia/care-and-support/help-and-support/)
*   [Dementia, social services and the NHS](https://www.nhs.uk/conditions/dementia/care-and-support/social-services-and-the-nhs/)

Information:

Social care and support guide
-----------------------------

If you:

*   need help with day-to-day living because of illness or disability
*   care for someone regularly because they're ill, elderly or disabled - including family members

Our [guide to care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/) explains your options and where you can get support.

Page last reviewed: 05 July 2021  
Next review due: 05 July 2024
