Title: Body odour

URL Source: https://www.nhs.uk/conditions/body-odour-bo/

Published Time: 15 Jan 2019, 2:04 p.m.

Markdown Content:
**Body odour is a common problem. You can usually treat it yourself.**

How to treat body odour yourself
--------------------------------

### Do

*   wash your armpits, groin and feet at least twice a day with soap and dry thoroughly
    
*   shave your armpits regularly
    
*   use antiperspirants and deodorants
    
*   change and wash your clothes regularly
    
*   wear natural fabrics like cotton, wool and silk
    
*   wear antibacterial socks
    

### Don’t

*   do not eat too much strong smelling or spicy food
    
*   do not drink too much coffee or alcohol
    

A pharmacist can help with body odour
-------------------------------------

You can ask a pharmacist about:

*   stronger antiperspirants
*   armpit or sweat shields to protect your clothing
*   foot powders for sweaty feet
*   soap substitutes that are gentler on your skin

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

You have body odour that has not got better after treating it yourself and:

*   it's affecting your self-esteem
*   you notice a change in how it usually smells
*   you suddenly begin to sweat much more than usual

Treatments from a GP
--------------------

If you have severe body odour and sweating, a GP may suggest:

*   stronger, prescription antiperspirants
*   injections in your armpits to reduce the amount of sweat
*   surgery to remove the sweat glands

Read more about [treating excessive sweating](https://www.nhs.uk/conditions/excessive-sweating-hyperhidrosis/).

Causes of body odour
--------------------

Things that can make body odour worse include:

*   exercise
*   hot weather
*   hormonal changes
*   being overweight
*   having a condition like [diabetes](https://www.nhs.uk/conditions/diabetes/), [kidney disease](https://www.nhs.uk/conditions/kidney-disease/) or [liver disease](https://www.nhs.uk/conditions/liver-disease/)
*   certain types of medicine, such as [antidepressants](https://www.nhs.uk/conditions/antidepressants/)

Body odour may also be linked to [excessive sweating](https://www.nhs.uk/conditions/excessive-sweating-hyperhidrosis/) and [smelly feet](https://www.nhs.uk/conditions/smelly-feet/).

Page last reviewed: 06 December 2021  
Next review due: 06 December 2024
