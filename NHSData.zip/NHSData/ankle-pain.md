Title: Ankle pain

URL Source: https://www.nhs.uk/conditions/foot-pain/ankle-pain/

Published Time: 30 Mar 2022, 1:58 p.m.

Markdown Content:
**There are lots of causes of ankle pain. You can usually ease the pain yourself. But see a GP if the pain does not improve.**

How you can ease ankle pain yourself
------------------------------------

If you see a GP about ankle pain, they'll usually suggest you try these things:

### Do

*   rest and raise your ankle when you can
    
*   put an ice pack (or bag of frozen peas) wrapped in a towel on your ankle for up to 20 minutes every 2 to 3 hours
    
*   wear wide comfortable shoes with a low heel and soft sole
    
*   use soft insoles or heel pads in your shoes
    
*   [wrap a bandage around your ankle](https://www.nhs.uk/common-health-questions/accidents-first-aid-and-treatments/how-do-i-apply-a-bandage/) to support it
    
*   try regular gentle stretching exercises
    
*   use painkillers such as [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen gel](https://www.nhs.uk/medicines/ibuprofen-for-adults/how-and-when-to-take-ibuprofen/) (or ibuprofen tablets if needed)
    

### Don’t

*   do not walk or stand for long periods
    
*   do not wear high heels or tight pointy shoes
    

### A pharmacist can help with ankle pain

You can ask a pharmacist about:

*   the best painkiller to take
*   insoles and pads for your shoes
*   if you need to see a GP

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   ankle pain is stopping you doing normal activities
*   the pain is getting worse or keeps coming back
*   the pain has not improved after treating it at home for 2 weeks
*   you have any tingling or loss of sensation in your foot
*   you have diabetes and foot pain – foot problems can be more serious if you have diabetes

Immediate action required: Go to an urgent treatment centre or A&E if:
----------------------------------------------------------------------

*   you have severe ankle pain
*   you feel faint, dizzy or sick from the pain
*   your ankle or foot has changed shape or is at an odd angle
*   you heard a snap, grinding or popping noise at the time of injury
*   you are not able to walk

These might be signs of a broken ankle.

[Find an urgent treatment centre](https://www.nhs.uk/service-search/Urgent-Treatment-Centre/LocationSearch/10022)

What we mean by severe pain

Severe pain:

*   always there and so bad it's hard to think or talk
*   you cannot sleep
*   it's very hard to move, get out of bed, go to the bathroom, wash or dress

Moderate pain:

*   always there
*   makes it hard to concentrate or sleep
*   you can manage to get up, wash or dress

Mild pain:

*   comes and goes
*   is annoying but does not stop you doing daily activities

Common causes of ankle pain
---------------------------

Ankle pain is often caused by exercising too much or wearing shoes that are too tight.

Your symptoms might also give you an idea of what's causing your ankle pain.

Possible symptoms and causes of ankle pain.
| Symptoms | Possible cause |
| --- | --- |
| Pain, swelling, bruising, started after intense or repetitive exercise | [Sprained ankle](https://www.nhs.uk/conditions/sprains-and-strains/) |
| Pain in ankle and heel, pain in calf when standing on tiptoes | [Achilles tendonitis](https://www.nhs.uk/conditions/tendonitis/) |
| Redness and swelling, dull aching pain | [Bursitis](https://www.nhs.uk/conditions/bursitis/) |
| Sudden sharp pain, swelling, a popping or snapping sound during the injury, difficulty walking, ankle at odd angle | [Broken ankle](https://www.nhs.uk/conditions/broken-ankle/) |

### If you're not sure what's causing your ankle pain

Do not worry if you're not sure what the problem is.

Follow the advice on this page and see a GP if the pain does not get better in 2 weeks.

Information:

**Self-refer for treatment**
----------------------------

If you have ankle pain, you might be able to refer yourself directly to services for help with your condition without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact your integrated care board (ICB) – [find your local ICB](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS treatment for ankle pain near you
