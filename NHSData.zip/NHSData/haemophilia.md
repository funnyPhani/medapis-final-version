Title: Haemophilia

URL Source: https://www.nhs.uk/conditions/haemophilia/

Published Time: 23 Oct 2017, 1:10 p.m.

Markdown Content:
**Haemophilia is a rare condition that affects the blood's ability to clot. It's usually inherited. Most people who have it are male.**

Normally, when you cut yourself, substances in your blood known as clotting factors mix with blood cells called platelets to make your blood sticky and form a clot. This makes the bleeding stop eventually.

People with haemophilia do not have as many clotting factors as they should have in their blood. This means they bleed for longer than usual.

Symptoms of haemophilia
-----------------------

The symptoms of haemophilia can be mild to severe, depending on the level of clotting factors you have.

The main symptom is bleeding that does not stop.

People with haemophilia may have:

*   nosebleeds that take a long time to stop
*   bleeding from wounds that lasts a long time
*   bleeding gums
*   skin that bruises easily
*   pain and stiffness around joints, such as elbows, because of bleeding inside the body (internal bleeding)

Read more about the [symptoms of haemophilia](https://www.nhs.uk/conditions/haemophilia/symptoms/).

When to get medical advice
--------------------------

See a GP if:

*   you or your child bruises easily and has bleeding that does not stop
*   your or your child has symptoms of joint bleeds – for example, tingling, pain, or stiffness in a joint, and the joint becoming hot, swollen, and tender
*   you have a family history of haemophilia and you're pregnant or planning to have a baby

There's a small risk that people with haemophilia may have a bleed inside their skull [(a brain or subarachnoid haemorrhage)](https://www.nhs.uk/conditions/subarachnoid-haemorrhage/).

Symptoms of a brain haemorrhage include:

*   a severe headache
*   a stiff neck
*   being sick (vomiting)
*   a change in mental state, such as confusion
*   difficulty speaking, such as slurred speech
*   changes in vision, such as double vision
*   loss of co-ordination and balance
*   paralysis of some or all the facial muscles

Call 999 and ask for an ambulance if you think someone's bleeding inside their skull.

Your local haemophilia centre
-----------------------------

If you have haemophilia, register at your local haemophilia centre. It's a useful source of advice and support.

People with haemophilia are cared for by a hospital haematology department.

Find [haematology services near you](https://www.nhs.uk/service-search/other-health-services/haematology).

Tests and diagnosis
-------------------

Blood tests can diagnose haemophilia and find out how severe it is.

If there's no family history of haemophilia, it's usually diagnosed when a child begins to walk or crawl.

Mild haemophilia may only be discovered later, usually after an injury or a dental or surgical procedure.

### Genetic tests and pregnancy

If you have a family history of haemophilia and you're planning to get pregnant, [genetic and genomic testing](https://www.nhs.uk/conditions/genetics/services/) can help you find out the risk of passing the condition on to a child.

This may involve testing a sample of your tissue or blood to look for signs of the genetic change that causes haemophilia.

Tests during pregnancy can diagnose haemophilia in the baby. These include:

*   [chorionic villus sampling (CVS)](https://www.nhs.uk/conditions/chorionic-villus-sampling-cvs/) – a small sample of the placenta is removed from the womb and tested for the haemophilia gene, usually during weeks 11 to 14 of pregnancy
*   [amniocentesis](https://www.nhs.uk/conditions/amniocentesis/) – a sample of amniotic fluid is taken for testing, usually during weeks 15 to 20 of pregnancy

There's a small risk of these procedures causing problems such as [miscarriage](https://www.nhs.uk/conditions/miscarriage/) or [premature labour](https://www.nhs.uk/conditions/pregnancy-and-baby/premature-early-labour/), so you may find it helpful to discuss this with your doctor.

If haemophilia is suspected after your child's born, a [blood test](https://www.nhs.uk/conditions/blood-tests/) can usually confirm the diagnosis. Blood from the umbilical cord can be tested at birth.

Treatments for haemophilia
--------------------------

There's no cure for haemophilia, but treatment usually allows a person with the condition to enjoy a good quality of life.

Man-made clotting factors are given as medicines to prevent and treat prolonged bleeding. These medicines are given as an injection.

In milder cases, injections are usually only given in response to prolonged bleeding. More severe cases are treated with regular injections to prevent bleeding.

Read more about [treatments for haemophilia](https://www.nhs.uk/conditions/haemophilia/treatment/).

Living with haemophilia
-----------------------

With treatment, most people with haemophilia can live a normal life.

However, you should:

*   avoid contact sports, such as rugby
*   be careful taking other medicines – some can affect your blood's ability to clot, such as [aspirin](https://www.nhs.uk/medicines/aspirin-for-pain-relief/) and [ibuprofen](https://www.nhs.uk/conditions/ibuprofen/)
*   [take care of your teeth and gums](https://www.nhs.uk/live-well/healthy-teeth-and-gums/take-care-of-your-teeth-and-gums/) and have regular check-ups at the dentist

Looking after your teeth and gums helps you avoid problems such as [gum disease](https://www.nhs.uk/conditions/gum-disease/), which can cause bleeding. Most non-surgical dental treatment can be done at a general dental surgery.

Your care team at the hospital can give you advice about surgical dental procedures, such as having a tooth removed, and further information and advice about living with haemophilia.

### Blood transfusions before 1996

If you received a blood transfusion or blood products before 1996, there's a chance you may have been given infected blood.

If you have not been tested for infection, speak to a specialist looking after your care.

You may need to be tested for hepatitis B, hepatitis C and HIV.

Find out more about [support for people who may have been affected by infected blood](https://www.nhs.uk/conditions/support-for-people-who-may-have-been-affected-by-infected-blood/).

Information about you
---------------------

If you have haemophilia, your clinical team may pass information about you on to the National Congenital Anomaly and Rare Diseases Registration Service (NCARDRS).

This helps scientists better understand the condition. You can opt out of the register at any time.

Find out [more about the NCARDRS in a leaflet](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet) you can download at GOV.UK

Page last reviewed: 17 April 2020  
Next review due: 17 April 2023
