Title: Behçet's disease

URL Source: https://www.nhs.uk/conditions/behcets-disease/

Published Time: 20 Oct 2017, 2:12 p.m.

Markdown Content:
**Behçet's disease, or Behçet's syndrome, is a rare and poorly understood condition that results in inflammation of the blood vessels and tissues.**

Confirming a diagnosis of Behçet's disease can be difficult because the symptoms are so wide-ranging and general (they can be shared with a number of other conditions).

Symptoms of Behçet's disease
----------------------------

The main symptoms of Behçet's disease include:

*   genital and mouth ulcers
*   red, painful eyes and blurred vision
*   [acne](https://www.nhs.uk/conditions/acne/)\-like spots
*   [headaches](https://www.nhs.uk/conditions/headaches/)
*   painful, stiff and swollen joints

In severe cases, there's also a risk of serious and potentially life-threatening problems, such as permanent [vision loss](https://www.nhs.uk/conditions/vision-loss/) and [strokes](https://www.nhs.uk/conditions/stroke/).

Most people with the condition experience episodes where their symptoms are severe (flare-ups or relapses), followed by periods where the symptoms disappear (remission).

Symptom's often start in adults in their 20s and 30s, but can also start in childhood.

Over time, some of the symptoms can settle down and become less troublesome, although they may never resolve completely.

[Read about the symptoms of Behçet's disease](https://www.nhs.uk/conditions/behcets-disease/symptoms/)

Diagnosing Behçet's disease
---------------------------

There's no definitive test that can be used to diagnose Behçet's disease.

Several tests may be necessary to check for signs of the condition, or to help rule out other causes, including:

*   [blood tests](https://www.nhs.uk/conditions/blood-tests/)
*   urine tests
*   scans, such as [X-rays](https://www.nhs.uk/conditions/x-ray/), a [CT scan](https://www.nhs.uk/conditions/ct-scan/) or an [MRI scan](https://www.nhs.uk/conditions/mri-scan/)
*   a skin [biopsy](https://www.nhs.uk/conditions/biopsy/)
*   a pathergy test – which involves pricking your skin with a needle to see if a particular red spot appears within the next day or two; people with Behçet's disease often have particularly sensitive skin

Current guidelines state a diagnosis of Behçet's disease can usually be confidently made if you've experienced at least 3 episodes of [mouth ulcers](https://www.nhs.uk/conditions/mouth-ulcers/) over the past 12 months and you have at least 2 of the following symptoms:

*   genital ulcers
*   eye inflammation
*   skin lesions (any unusual growths or abnormalities that develop on the skin)
*   pathergy (hypersensitive skin)

Other potential causes also need to be ruled out before the diagnosis is made.

Causes of Behçet's disease
--------------------------

The cause of Behçet's disease is unknown, although most experts believe it's an autoinflammatory condition.

An autoinflammatory condition is where there are repeated episodes of inflammation in the body.

In Behçet's disease, this involves inflammation of the blood vessels. This is thought to be caused by a problem with the immune system.

It's not clear what triggers this problem with the immune system, but 2 things are thought to play a role:

*   genes – Behçet's disease tends to be much more common in certain ethnic groups where the genes that are linked to the condition may be more common
*   environmental factors – although a specific environmental factor has not been identified, rates of Behçet's disease are lower in people from an at-risk ethnic group who live outside their native country

Behçet's disease is more common in the Far East, the Middle East and Mediterranean countries such as Turkey and Israel.

People of Mediterranean, Middle Eastern and Asian origin are thought to be most likely to develop the condition, although it can affect all ethnic groups.

Treating Behçet's disease
-------------------------

There's no cure for Behçet's disease, but it's often possible to control the symptoms with medicines that reduce inflammation in the affected parts of the body.

These medicines include:

*   [steroids](https://www.nhs.uk/conditions/steroids/) – powerful anti-inflammatory medicines
*   immunosuppressants – medicines that reduce the activity of the immune system
*   biological therapies – medicines that target the biological processes involved in the process of inflammation

Your healthcare team will create a specific treatment plan for you depending on your symptoms.

[Find out more about treating Behçet's disease](https://www.nhs.uk/conditions/behcets-disease/treatment/)

### Specialist Behçet's disease centres

There are 3 NHS Centres of Excellence that have been set up to help diagnose and treat people with Behçet's disease in England.

These are located in London, Birmingham and Liverpool.

You may be referred to one of these centres so a diagnosis can be confirmed. Staff at these centres may also liaise with specialists at other centres to help with a person's management and treatment, even if they're not seen directly.

You can find out more about these centres on the [Behçet's Syndrome Centres of Excellence website](http://www.behcets.nhs.uk/).

If you have Behçet's disease, your clinical team will pass information about you on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

Further information about Behçet's disease
------------------------------------------

A natural response to receiving a diagnosis of a complex condition such as Behçet's disease is to find out as much as possible about the condition.

However, in the UK this may be difficult because Behçet's disease is so rare that many healthcare professionals know little about it.

A good place to start to learn more about Behçet's disease is from [Behçet's UK](https://behcetsuk.org/) – the UK's main patient support group for people with Behçet's disease.

Its website has a range of information about different aspects of Behçet's disease, a members' forum, blogs and links to other useful resources.

Page last reviewed: 06 April 2023  
Next review due: 06 April 2026
