Title: Bedbugs

URL Source: https://www.nhs.uk/conditions/bedbugs/

Published Time: 17 Oct 2017, 5:09 p.m.

Markdown Content:
**Bedbugs are small insects that often live on furniture or bedding. Their bites can be itchy, but do not usually cause other health problems.**

Check if it's bedbugs
---------------------

![Image 1: A bedbug on the end of cotton bud with a ruler underneath showing the bedbug is around 5mm long.](https://assets.nhs.uk/nhsuk-cms/images/A_0119_bedbug_with_scale_V2_BMA6WW.width-320.png)

Bedbugs can be dark yellow, red or brown. Adults are around 5mm long.

Bedbugs can hide in many places, including on bed frames, mattresses, clothing, furniture, behind pictures and under loose wallpaper.

Signs of bedbugs include:

*   bites – often on skin exposed while sleeping, like the face, neck and arms
*   spots of blood on your bedding – from the bites or from squashing a bedbug
*   small brown spots on bedding or furniture (bedbug poo)

![Image 2: Bedbug bites on the thigh of someone with white skin. There are over 20 small red spots on the skin where bedbugs have bitten the skin.](https://assets.nhs.uk/nhsuk-cms/images/A_1218_bedbug_bites_MY8B9Y.width-320.jpg)

Bedbug bites can be raised and itchy. They're often in a line or grouped together.

On white skin, bedbug bites usually look red. On black or brown skin, they may look purple and may be harder to see.

Some people have a reaction to the bites. They can be very itchy and there may be painful swelling.

A [severe allergic reaction (anaphylaxis)](https://www.nhs.uk/conditions/anaphylaxis/) is also possible but rare.

How you can treat bedbug bites
------------------------------

Bedbug bites usually clear up on their own in a week or so.

Things you can do include:

*   putting something cool, like a clean, damp cloth, on the affected area to help with the itching and any swelling
*   keeping the affected area clean
*   not scratching the bites to avoid getting an infection

### A pharmacist can help with bedbug bites

You can ask a pharmacist about:

*   mild [steroid cream](https://www.nhs.uk/conditions/topical-steroids/) like hydrocortisone cream to ease bedbug bites (children under 10 and pregnant women should get advice from a doctor before using hydrocortisone cream)
*   [antihistamines](https://www.nhs.uk/conditions/antihistamines/) – these may help if the bites are very itchy and you're unable to sleep

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   bedbug bites are still very painful, swollen or itchy after trying treatments from a pharmacist
*   the pain or swelling around the bites is spreading

You may have an infection and need treatment with antibiotics.

How to get rid of bedbugs
-------------------------

If you think you have bedbugs, you should contact your local council or pest control service.

It's very difficult to get rid of bedbugs yourself because they can be hard to find and may be resistant to some insecticides.

There are some things you can try yourself, but these are unlikely to get rid of bedbugs completely.

### Do

*   wash affected bedding and clothing on a hot wash (60C) and tumble dry on a hot setting for at least 30 minutes
    
*   put affected clothing and bedding in a plastic bag and put it in the freezer for 3 or 4 days
    
*   clean and vacuum regularly – bedbugs are found in both clean and dirty places, but regular cleaning will help you spot them early
    

### Don’t

*   do not keep clutter around your bed
    
*   do not bring secondhand furniture indoors without carefully checking it first
    
*   do not take luggage or clothing indoors without checking it carefully if you have come from somewhere where you know there were bedbugs
    

Information:

### Find your local council

You can [find your local council on GOV.UK](https://www.gov.uk/find-local-council).

Page last reviewed: 02 August 2022  
Next review due: 02 August 2025
