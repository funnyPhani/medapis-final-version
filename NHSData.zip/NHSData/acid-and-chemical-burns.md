Title: Acid and chemical burns

URL Source: https://www.nhs.uk/conditions/acid-and-chemical-burns/

Published Time: 3 Oct 2018, 8:55 p.m.

Markdown Content:
Get medical advice as soon as possible if you think you have an acid or chemical burn. You'll need to be treated as soon as possible.

How acid or chemical burns happen
---------------------------------

Acid or chemical burns can happen when a harmful acid or chemical gets on your skin, or in your eyes.

Examples of harmful acids and chemicals include:

*   bleach
*   other household cleaning products, such as toilet, oven, and drain cleaners
*   battery acid (a liquid inside some types of batteries)
*   washing detergents
*   ammonia
*   chemicals used in industries such as farming, manufacturing, construction and laboratories

Information:

Many products have a label saying if they're harmful and if there's a risk of burns.

Immediate action required: Call 999 if:
---------------------------------------

*   you or someone else has got an acid or chemical on your skin, or in your eyes

First aid for an acid or chemical burn
--------------------------------------

An acid or chemical burn needs immediate first aid.

1.  Call 999 for medical help.
2.  Wear gloves to protect yourself from the chemical when helping yourself or someone else, if possible.
3.  Carefully remove any clothing that has the chemical on it, if possible.
4.  Carefully brush dry chemicals off the skin.
5.  Put the affected area under cool or lukewarm running water or pour lots of water over it for about 1 hour.

### Important

Do not put anything on the burn, such as skin creams or other chemicals.

Treatment for acid and chemical burns
-------------------------------------

Acid and chemical burns need to be checked and treated in hospital.

You may need:

*   painkillers to help ease pain
*   antibiotics to treat infection, or to stop you getting an infection
*   fluids, usually given through a vein

If your burn is severe, you may also need:

*   surgery to help your burn wounds to heal
*   reconstructive surgery if your burn affects your movement or physical appearance
*   physiotherapy if the burn has a lasting effect on your movement

Page last reviewed: 05 June 2024  
Next review due: 05 June 2027
