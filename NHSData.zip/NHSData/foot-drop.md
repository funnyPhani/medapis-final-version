Title: Foot drop

URL Source: https://www.nhs.uk/conditions/foot-drop/

Published Time: 3 Oct 2018, 8:57 p.m.

Markdown Content:
**Foot drop (drop foot) is where it's difficult to lift or move your foot and toes. It usually affects 1 foot and can affect the way you walk.**

Causes of foot drop
-------------------

The most common cause of foot drop is an injury to a nerve that runs down your leg and controls the muscles that lift your foot.

This can be caused by:

*   sports injuries
*   a [slipped disc](https://www.nhs.uk/conditions/slipped-disc/) in the spine
*   crossing your legs, kneeling or squatting for long periods of time
*   problems with your nerves ([peripheral neuropathy](https://www.nhs.uk/conditions/peripheral-neuropathy/)) caused by diabetes
*   hip or knee replacement surgery
*   not moving for a long time (for example, if you're staying in hospital)

Foot drop can get better on its own and with treatment, but sometimes it can be permanent.

Less common causes of foot drop include:

*   inherited conditions like [Charcot-Marie-Tooth disease](https://www.nhs.uk/conditions/charcot-marie-tooth-disease/)
*   muscle weakness caused by [muscular dystrophy](https://www.nhs.uk/conditions/muscular-dystrophy/), [spinal muscular atrophy](https://www.nhs.uk/conditions/spinal-muscular-atrophy-sma/) or [motor neurone disease](https://www.nhs.uk/conditions/motor-neurone-disease/)
*   damage to the brain or spinal cord caused by a [stroke](https://www.nhs.uk/conditions/stroke/), [cerebral palsy](https://www.nhs.uk/conditions/cerebral-palsy/), [Parkinson's disease](https://www.nhs.uk/conditions/parkinsons-disease/) or [multiple sclerosis](https://www.nhs.uk/conditions/multiple-sclerosis/)

Non-urgent advice: See a GP if:
-------------------------------

*   you find it difficult to lift the front part of your foot and toes

What happens at your GP appointment
-----------------------------------

If you have foot drop, a GP will examine your leg and foot, and look at the way you walk.

You may be referred to a specialist for more tests, such as an [X-ray](https://www.nhs.uk/conditions/x-ray/), [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) or [CT scan](https://www.nhs.uk/conditions/ct-scan/), to find out what's causing your dropped foot.

Treatment for foot drop
-----------------------

How foot drop is treated depends on what's causing it and how long you have had it for.

Sometimes it can get better on its own.

Common treatments for foot drop include:

*   physiotherapy to strengthen or stretch the muscles in your leg and foot
*   braces, splints or shoe inserts to help hold the foot in position
*   a small device that's put in your body and uses electrical signals to help your nerves work (electrical nerve stimulation) – especially if you've had a stroke or have multiple sclerosis

If you have permanent loss of movement from foot drop, you may have surgery to fuse the ankle and foot joints, or repair or graft the nerve.

Things you can do if you have foot drop
---------------------------------------

There's a higher risk of tripping and falling if you have a foot drop.

But there are some simple changes you can make to help avoid this.

### Do

*   use a walking aid, such as a stick, if you need one
    
*   keep the floors in your home clear
    
*   remove things you could trip on in your home, such as loose rugs and electrical cables
    
*   keep your house well-lit
    
*   install handrails on stairs
    

[Find out more about how to prevent falls](https://www.nhs.uk/conditions/falls/prevention/)

Page last reviewed: 06 January 2022  
Next review due: 06 January 2025
