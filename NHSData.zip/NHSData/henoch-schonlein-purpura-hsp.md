Title: Henoch-Schönlein purpura (HSP)

URL Source: https://www.nhs.uk/conditions/henoch-schonlein-purpura-hsp/

Published Time: 18 Oct 2017, 2:41 p.m.

Markdown Content:
**Henoch-Schönlein purpura (HSP) affects the blood vessels and causes a spotty rash. It's not usually serious, but can sometimes lead to kidney problems. It's more common in children, but adults can get it too.**

Check if it's Henoch-Schönlein purpura (HSP)
--------------------------------------------

The main symptom of Henoch-Schönlein purpura (HSP) is a rash with raised red or purple spots. The spots look like small bruises or blood spots.

![Image 1: Henoch-Schonlein purpura on white skin. There's lots of small red spots and patches on a child's legs and feet.](https://assets.nhs.uk/nhsuk-cms/images/S_0917_Henoch-Schonlein-Purpura_C0219672.width-320.jpg)

The rash usually appears on the legs, bottom, tummy, chest or back.

![Image 2: Henoch-Schönlein purpura on white skin. There are around 6 small red spots on a child's thighs.](https://assets.nhs.uk/nhsuk-cms/images/M2400247.width-320.jpg)

There may be lots of spots or just a few.

![Image 3: Henoch-Schönlein purpura on medium brown skin. There's lots of small, purple-red spots and patches on a child's legs.](https://assets.nhs.uk/nhsuk-cms/images/M6_-_Henoch-Schonlein_purpura.width-320.png)

You may also have pain or swelling in your joints, such as your knees and ankles. You may also have tummy pain.

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you or your child have a rash that does not fade when a glass is pressed against it but you do not feel unwell

This could be Henoch-Schönlein purpura (HSP).

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   a rash does not fade when a glass is pressed against it and you feel very unwell – for example, it's painful to look at bright lights or you have a stiff neck

This could be something serious like meningitis.

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Important: How to do the glass test
-----------------------------------

1.  Press the side of a clear glass firmly against the skin.
2.  Check a few times to see if you can still see the spots through the glass.

If you have brown or black skin, check paler areas like the palms of the hands and the soles of the feet.

See what a rash that does not fade looks like

![Image 4: A red spotty rash on white skin with a drinking glass pressed on it. You can see the spots through the glass.](https://assets.nhs.uk/nhsuk-cms/images/A8FF2B.width-320.jpg)

Treatments for Henoch-Schönlein purpura (HSP)
---------------------------------------------

There's no treatment for Henoch-Schönlein purpura (HSP). It usually gets better in a few weeks and you can usually just rest at home until you feel better.

HSP cannot spread to others, so:

*   your child can return to school or nursery when they feel well enough
*   you can go back to work as soon as you feel up to it

### Treatment to relieve your symptoms

[Paracetamol](https://www.nhs.uk/medicines/paracetamol-for-children/) can help ease any pain.

Do not take [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-children/) without speaking to your doctor because it could harm your kidneys.

### Regular check-ups for kidney problems

You'll have regular check-ups for 6 to 12 months to check how well your kidneys are working.

You'll usually be asked to provide a sample of pee and have your blood pressure checked at each appointment. This may be done at home, at your GP surgery, or in hospital.

### Treatment in hospital

You may need to go into hospital if HSP affects your kidneys.

In hospital, you may be given strong medicines like [steroids](https://www.nhs.uk/conditions/steroids/) to help ease your symptoms.

Risks of Henoch-Schönlein purpura (HSP)
---------------------------------------

Most people with Henoch-Schönlein purpura (HSP) make a full recovery. Any kidney problems usually get better without treatment.

But sometimes HSP can be severe and last several months.

There's also a small chance the kidneys could be permanently damaged ([chronic kidney disease](https://www.nhs.uk/conditions/kidney-disease/)). This is why it's important to have regular check-ups.

### Important: Getting HSP again

You can get HSP more than once. Get medical advice quickly if the symptoms come back.

Page last reviewed: 18 October 2023  
Next review due: 18 October 2026
