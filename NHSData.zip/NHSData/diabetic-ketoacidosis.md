Title: Diabetic ketoacidosis

URL Source: https://www.nhs.uk/conditions/diabetic-ketoacidosis/

Published Time: 18 Oct 2017, 10:27 a.m.

Markdown Content:
**Diabetic ketoacidosis (DKA) is a serious condition that can happen in people with diabetes. It's where a lack of insulin causes harmful substances called ketones to build up in the blood. It can be life threatening and needs urgent treatment in hospital.**

Check if you have diabetic ketoacidosis (DKA)
---------------------------------------------

Symptoms of diabetic ketoacidosis (DKA) include:

*   feeling thirsty
*   needing to pee more often
*   stomach pain, feeling sick or being sick
*   diarrhoea
*   breathing more deeply than usual
*   breath that smells fruity (like pear drop sweets or nail polish remover)
*   feeling tired, sleepy or confused
*   blurred vision

The symptoms usually develop over 24 hours, but it can be faster.

DKA usually affects people with [type 1 diabetes](https://www.nhs.uk/conditions/type-1-diabetes/), but it can also happen in people with [type 2 diabetes](https://www.nhs.uk/conditions/type-2-diabetes/) who need insulin.

It can happen when people first develop type 1 diabetes and have not yet been diagnosed, particularly children.

### Checking your blood glucose and ketones

If you have diabetes and have any of the symptoms of DKA, check your blood glucose. If it's high, test for ketones if you can.

If you use a meter to test for ketones in your blood:

*   under 0.6mmol/L is normal
*   0.6 to 1.5mmol/L is slightly high – test again in 2 hours
*   1.6 to 3mmol/L means you're at risk of DKA and should speak to your diabetes care team for advice
*   over 3mmol/L is high and means you may have DKA and should call 999 or go to A&E

If you use strips to test for ketones in your pee, over 2+ is high. This means you may have DKA and should call 999 or go to A&E.

#### Important

These ketone levels are a guide. Normal blood ketone levels can be different for different people. Your diabetes care team will advise you on what levels to look for.

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

*   you have a high level of ketones – over 3mmol/L in your blood, or over 2+ in your pee
*   you do not know your ketone levels but have symptoms of diabetic ketoacidosis, such as feeling thirsty and needing to pee more often, feeling sleepy or confused, and breath that smells fruity (like pear drop sweets or nail polish remover)
*   you have symptoms of diabetic ketoacidosis and have not been diagnosed with diabetes

Diabetic ketoacidosis can be life threatening so it's important to get treatment quickly.

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

Urgent advice: Call your diabetes care team now or get help from NHS 111 if:
----------------------------------------------------------------------------

You have diabetes and:

*   your blood glucose is high and your insulin treatment is not working to reduce it, even if your ketones are normal
*   your ketones are slightly high (0.6 to 1.5mmol/L) and you feel unwell
*   your ketones are 1.6 to 3mmol/L, even if you do not feel unwell

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Treatment for diabetic ketoacidosis (DKA)
-----------------------------------------

If you have diabetic ketoacidosis (DKA) you'll need to be admitted to hospital for urgent treatment.

You'll be given insulin, fluids and nutrients through a drip into your vein.

You'll be monitored for complications, as DKA can sometimes affect your brain, heart or lungs.

Once your ketones are at a safe level and you can eat and drink normally you'll be able to go home.

The doctors will talk to you about what caused DKA and give you advice on how to reduce the risk of it happening again.

How to reduce your risk of diabetic ketoacidosis (DKA)
------------------------------------------------------

If you have diabetes, it's important to be aware of the symptoms of diabetic ketoacidosis (DKA) and how to reduce the risk of getting it.

Causes of DKA can include being unwell, having an injury or surgery, having your period, or not taking enough [insulin](https://www.nhs.uk/medicines/insulin/).

Testing for ketones will help you know when you need to take action, such as increasing your insulin dose.

You can get kit to test for ketones free from the NHS, or buy it from a pharmacy. You can use:

*   a ketone meter to test your blood
*   some types of blood glucose monitor that also test for ketones
*   strips to test your pee

### Do

*   follow the treatment plan agreed with your diabetes care team, including adjusting your insulin dose when you need to
    
*   check your blood glucose regularly
    
*   ask your care team about getting a [continuous glucose monitor or flash monitor](https://www.nhs.uk/conditions/type-1-diabetes/managing-blood-glucose-levels/continuous-glucose-monitoring-cgm-and-flash/) if you do not already have one
    
*   test for ketones when your blood glucose is high and when you're ill
    
*   follow the sick day rules you've been given by your care team when you're ill
    
*   contact your care team if you're not sure what to do
    

### Don’t

*   do not stop taking insulin, even if you're not eating
    
*   do not skip insulin doses
    

Page last reviewed: 08 June 2023  
Next review due: 08 June 2026
