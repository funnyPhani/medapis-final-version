Title: Dyslexia

URL Source: https://www.nhs.uk/conditions/dyslexia/

Published Time: 14 Aug 2018, 3:15 p.m.

Markdown Content:
**Dyslexia is a common learning difficulty that mainly causes problems with reading, writing and spelling.**

It's a specific learning difficulty, which means it causes problems with certain abilities used for learning, such as reading and writing.

Unlike a [learning disability](https://www.nhs.uk/conditions/learning-disabilities/), intelligence isn't affected.

It's estimated up to 1 in every 10 people in the UK has some degree of dyslexia.

Dyslexia is a lifelong problem that can present challenges on a daily basis, but support is available to improve reading and writing skills and help those with the problem be successful at school and work.

What are the signs of dyslexia?
-------------------------------

Signs of dyslexia usually become apparent when a child starts school and begins to focus more on learning how to read and write.

A person with dyslexia may:

*   read and write very slowly
*   confuse the order of letters in words
*   be confused by letters that look similar and write letters the wrong way round (such as "b" and "d")
*   have poor or inconsistent spelling
*   understand information when told verbally, but have difficulty with information that's written down
*   find it hard to carry out a sequence of directions
*   struggle with planning and organisation

But people with dyslexia often have good skills in other areas, such as creative thinking and problem solving.

Read more about the [symptoms of dyslexia](https://www.nhs.uk/conditions/dyslexia/symptoms/).

Getting help
------------

If you think your child may have dyslexia, the first step is to speak to their teacher or their school's special educational needs co-ordinator (SENCO) about your concerns.

They may be able to offer additional support to help your child if necessary.

If your child continues to have problems despite extra support, you or the school may want to consider requesting an in-depth assessment from a specialist in assessing specific learning difficulties (SpLD), an educational psychologist or a speech and language therapist.

This can be arranged through the school, or you can request a private assessment by contacting:

*   an educational psychologist directly (see the [directory of chartered psychologists on the British Psychological Society's website](https://www.bps.org.uk/find-psychologist))
*   a voluntary organisation that can arrange an assessment or share details of a qualified assessor in your area, such as the [British Dyslexia Association](https://www.bdadyslexia.org.uk/services/assessments), [The Dyslexia Association](https://www.dyslexia.uk.net/services/diagnostic-assessments/childrens-assessment/), or [Patoss](https://www.patoss-dyslexia.org/Tutor-Index-Landing)

Adults who wish to be assessed for dyslexia should contact a local or national dyslexia association for advice.

Read more about [how dyslexia is diagnosed](https://www.nhs.uk/conditions/dyslexia/diagnosis/).

Support for people with dyslexia
--------------------------------

If your child has dyslexia, they'll probably need extra educational support from their school.

With appropriate support, there's usually no reason your child can't go to a mainstream school, although a small number of children may benefit from attending a specialist school.

Techniques and support that may help your child include:

*   occasional 1-to-1 teaching or lessons in a small group with a specialist teacher
*   phonics (a way of teaching children to identify and process the smaller sounds that make up words) combined with other techniques
*   technology like computers and speech-recognition software that may make it easier for your child to read and write when they're a bit older

Schools and colleges must offer support to students with a specific learning difficulty like dyslexia, and have access to specialist staff who are trained in helping students with special education needs.

Assistive technologies such as speech-recognition software, word processors and electronic organisers can be useful for adults, too.

Employers are required to make reasonable adjustments to the workplace to help people with dyslexia, such as allowing extra time for certain tasks.

Read more about [how dyslexia is managed](https://www.nhs.uk/conditions/dyslexia/living-with/).

### Support groups

As well as national dyslexia charities such as the [British Dyslexia Association (BDA)](http://www.bdadyslexia.org.uk/), there are several [local dyslexia associations listed on the BDA website](https://www.bdadyslexia.org.uk/membership/local-dyslexia-associations/lda-directory).

These are independently registered charities that run workshops and help to provide local support and access to information.

What causes dyslexia?
---------------------

People with dyslexia find it difficult to recognise the different sounds that make up words and relate these to letters.

Dyslexia isn't related to a person's general level of intelligence. Children and adults of all intellectual abilities can be affected by dyslexia.

The exact cause of dyslexia is unknown, but it often appears to run in families.

It's thought certain genes inherited from your parents may act together in a way that affects how some parts of the brain develop during early life.

Page last reviewed: 07 March 2022  
Next review due: 07 March 2025
