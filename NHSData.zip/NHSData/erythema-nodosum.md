Title: Erythema nodosum

URL Source: https://www.nhs.uk/conditions/erythema-nodosum/

Published Time: 24 Oct 2017, 10:20 a.m.

Markdown Content:
**Erythema nodosum is a condition that causes painful patches of skin that look red or darker than the surrounding skin. It usually goes away by itself, but it can sometimes be a sign of something serious like an inflammatory bowel condition, such as Crohn's disease.**

Check if you have erythema nodosum
----------------------------------

If you have erythema nodosum, you may have flu-like symptoms before or at the same time as you get the patches on your skin.

For example, you may:

*   have a high temperature
*   have swollen, aching joints, particularly the knees, ankles and wrists
*   feel generally unwell

![Image 1: A person's lower left leg with large areas of red skin that look sore and painful. Image shown is on white skin.](https://assets.nhs.uk/nhsuk-cms/images/en12_copy.width-320.png)

Large areas of skin are often red and tender or painful.

![Image 2: A person's lower legs. They have medium brown skin and there are some darker patches on their shins that look like bruises.](https://assets.nhs.uk/nhsuk-cms/images/M5_-_erythema_nodosum_-_blur_or_remove_writing.width-320.png)

Erythema nodosum commonly affects the lower legs, but you can get it in other areas, such as on the arms, thighs and neck.

![Image 3: A person's shins with patches of skin that look like bruises. They have white skin and the area of discoloured skin is larger on their right shin.](https://assets.nhs.uk/nhsuk-cms/images/C0024796.width-320.jpg)

The affected patches of skin may heal and fade to leave marks that look like bruises.

The skin usually heals on its own within 3 to 8 weeks without leaving a scar. But other symptoms, such as joint pain and swelling, can last for several weeks.

Things you can do to ease the pain of erythema nodosum
------------------------------------------------------

There are some things you can do to help ease the pain of erythema nodosum.

### Do

*   try taking [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/)
    
*   rest with your feet raised on a pillow
    
*   try to avoid long periods of standing, walking and running
    
*   put a cool wet compress, like a damp cloth, on the affected area
    

### A pharmacist can help with erythema nodosum

If you're in pain, a pharmacist can recommend:

*   stronger painkillers
*   supportive bandages or stockings

They may also suggest you see a GP.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   you have a painful skin condition that affects your daily life
*   lots of lumps or marks start appearing on your skin
*   the lumps or marks do not go away after 8 weeks

What happens at your GP appointment
-----------------------------------

The GP may be able to tell if you have erythema nodosum by looking at the inflamed areas of skin.

Tests may be needed to find the cause. This may include a [biopsy](https://www.nhs.uk/conditions/biopsy/), where a small sample of skin is taken so it can be looked at under a microscope.

Treatments for erythema nodosum
-------------------------------

Treatment for erythema nodosum depends on the cause.

If it's caused by another condition, treating that condition may help. For example, if it’s caused by an infection, you may be given [antibiotics](https://www.nhs.uk/conditions/antibiotics/).

If the GP thinks a medicine you've been taking might be causing erythema nodosum, they may advise you to stop taking it. Do not stop taking medicines without asking a GP first.

If your symptoms have lasted a long time or they keep returning, other treatments, such as [steroid tablets](https://www.nhs.uk/conditions/steroid-tablets/), may be recommended.

Causes of erythema nodosum
--------------------------

Erythema nodosum can be caused by lots of things, but often the cause is unknown.

Common causes include:

*   inflammatory bowel conditions like [Crohn's disease](https://www.nhs.uk/conditions/crohns-disease/) and [ulcerative colitis](https://www.nhs.uk/conditions/ulcerative-colitis/)
*   bacterial infections, such a throat infection, chest infection or lung infection ([tuberculosis](https://www.nhs.uk/conditions/tuberculosis-tb/))
*   a rare condition where small patches of swollen tissue develop in organs, such as the lungs, lymph nodes or skin ([sarcoidosis](https://www.nhs.uk/conditions/sarcoidosis/))
*   a reaction to some medicines, including the [contraceptive pill](https://www.nhs.uk/conditions/contraception/combined-contraceptive-pill/) and some antibiotics

Page last reviewed: 18 October 2023  
Next review due: 18 October 2026
