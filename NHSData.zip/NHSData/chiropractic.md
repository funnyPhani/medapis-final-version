Title: Chiropractic

URL Source: https://www.nhs.uk/conditions/chiropractic/

Published Time: 18 Oct 2017, 9:28 a.m.

Markdown Content:
**Chiropractic is a treatment where a practitioner called a chiropractor uses their hands to help relieve problems with the bones, muscles and joints.**

It's considered a type of [complementary and alternative medicine (CAM)](https://www.nhs.uk/conditions/complementary-and-alternative-medicine/), which means it's not a conventional medical treatment.

Uses of chiropractic
--------------------

Chiropractic can mainly help with pain in muscles and joints, such as:

*   [back pain](https://www.nhs.uk/conditions/back-pain/)
*   [neck pain](https://www.nhs.uk/conditions/neck-pain-and-stiff-neck/)
*   [shoulder pain](https://www.nhs.uk/conditions/shoulder-pain/)
*   [elbow pain](https://www.nhs.uk/conditions/elbow-and-arm-pain/)
*   pain from [osteoarthritis](https://www.nhs.uk/conditions/osteoarthritis/)

There's little evidence that it can help with more serious conditions or problems not affecting the muscles or joints, such as [asthma](https://www.nhs.uk/conditions/asthma/), [allergies](https://www.nhs.uk/conditions/allergies/) and mental health problems.

Getting chiropractic on the NHS
-------------------------------

Chiropractic is not widely available on the NHS, but it may be offered in exceptional circumstances in some areas.

To find out if you can see a chiropractor on the NHS in your area:

*   ask a GP
*   contact your [local integrated care board](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/) (ICB)

If you need hands-on treatment, a GP is more likely to refer you to a physiotherapist.

Paying for private chiropractic treatment
-----------------------------------------

Most people who have chiropractic treatment pay for it privately. It usually costs around £50 to £100 for a first session to assess your problem and plan your treatment, and then £30 to £50 per session.

You do not need to see a GP before making an appointment, but it's best to speak to them for advice first. They can let you know about other treatments that might help, and can advise you if chiropractic is suitable for you.

If you decide to contact a chiropractor yourself, make sure they're registered with the [General Chiropractic Council (GCC)](http://www.gcc-uk.org/). By law, all chiropractors must be registered with the GCC.

You can look out for chiropractors displaying the GCC "I'm Registered" mark or [find a registered chiropractor on the General Chiropractic Council (GCC) website](https://www.gcc-uk.org/find-a-chiropractor).

What happens during chiropractic treatment
------------------------------------------

At your first appointment, the chiropractor will assess your symptoms to determine if chiropractic is suitable and what techniques are likely to help.

Chiropractors use different techniques to treat problems with the muscles and joints, including:

*   spinal manipulation – using their hands to apply force to the muscles, bones and joints of the spine and neck
*   short, sharp thrusting movements
*   gradually moving your joints into different positions
*   pulling or stretching your muscles in different directions

Treatment is not normally painful, but some people experience a bit of discomfort. Tell your chiropractor immediately if you find it painful.

Risks and side effects of chiropractic
--------------------------------------

Chiropractic is generally safe when performed correctly by a trained and registered chiropractor.

Some people may experience side effects from treatment, such as:

*   aches and pains
*   stiffness
*   tiredness

These side effects are usually mild and pass in a few days.

There is a risk of more serious problems, such as [stroke](https://www.nhs.uk/conditions/stroke/), from spinal manipulation.

Speak to a GP if you're unsure whether chiropractic is safe for you.

Page last reviewed: 06 September 2023  
Next review due: 06 September 2026
