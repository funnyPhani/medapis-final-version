Title: Cavernous sinus thrombosis

URL Source: https://www.nhs.uk/conditions/cavernous-sinus-thrombosis/

Published Time: 14 May 2018, 2:33 p.m.

Markdown Content:
**Cavernous sinus thrombosis is a blood clot in the cavernous sinuses. It can be life-threatening.**

The cavernous sinuses are hollow spaces located under the brain, behind each eye socket. A major blood vessel called the jugular vein carries blood through the cavernous sinuses away from the brain.

A blood clot can develop when an infection in the face or skull spreads to the cavernous sinuses. The blood clot develops to prevent the infection spreading further, but it can restrict the blood flow from the brain, which can damage the brain, eyes and nerves running between them. Sometimes, clots can develop without infection.

Read more about the [causes of cavernous sinus thrombosis](https://www.nhs.uk/conditions/cavernous-sinus-thrombosis/causes/).

Symptoms of cavernous sinus thrombosis include:

*   a sharp and severe [headache](https://www.nhs.uk/conditions/headaches/), particularly around the eye
*   swelling and bulging of the eye(s) and the surrounding tissues
*   eye pain that's often severe
*   [double vision](https://www.nhs.uk/conditions/double-vision/)
*   a high temperature

Read more about the [symptoms of cavernous sinus thrombosis](https://www.nhs.uk/conditions/cavernous-sinus-thrombosis/symptoms/).

When to seek medical advice
---------------------------

Call 111 immediately if you experience:

*   a severe headache that is not relieved with painkillers or is getting worse
*   a headache that feels worse when you lie down or bend over
*   a headache that's unusual for you and occurs with blurred vision, feeling or being sick, problems speaking, weakness, drowsiness or seizures (fits)
*   eye pain or swelling of one or both eyes
*   a rash that looks like small bruises or bleeding under the skin
*   shortness of breath, chest pain, leg swelling or persistent abdominal (tummy) pain

While it's highly unlikely to be the result of cavernous sinus thrombosis, these symptoms need to be investigated.

In very rare cases, cavernous sinus thrombosis can occur after having some types of coronavirus (COVID-19) vaccine. If this happens, symptoms can appear between 4 days and 4 weeks after vaccination.

After an examination, you may be referred for tests, including a [CT scan](https://www.nhs.uk/conditions/ct-scan/), an [MRI scan](https://www.nhs.uk/conditions/mri-scan/) and [blood tests](https://www.nhs.uk/conditions/blood-tests/).

Treating cavernous sinus thrombosis
-----------------------------------

Cavernous sinus thrombosis needs treatment in hospital.

In most cases, you'll be treated in an intensive care unit, so you can be closely monitored.

### Antibiotics

[Antibiotics](https://www.nhs.uk/conditions/antibiotics/) are the main treatment for cavernous sinus thrombosis. Treatment will be started as soon as possible, even before tests have confirmed if a bacterial infection is responsible.

If tests later show that a bacterial infection did not cause the condition, antibiotic treatment may be stopped.

Most people will require antibiotics for a few weeks to ensure the infection has been fully cleared from their body. The antibiotics will be given through an intravenous drip directly connected to one of your veins.

Some people will experience side effects when taking antibiotics. These are generally mild and can include diarrhoea, nausea and a skin rash.

### Anticoagulants

You may also be given a medicine called heparin to help dissolve the clot and prevent further clots. Heparin is an [anticoagulant medicine](https://www.nhs.uk/conditions/anticoagulants/), which means it makes the blood less sticky.

Some people also need to take anticoagulant tablets for a few months or longer after leaving hospital.

### Corticosteroids

Some people are also given steroid medicine ([corticosteroids](https://www.nhs.uk/conditions/steroids/)). Corticosteroids can reduce inflammation and swelling in your body.

### Surgical drainage

If the symptoms of cavernous sinus thrombosis were caused by an infection spreading from a boil or sinusitis, it may be necessary to drain away pus from that site. This can be done either using a needle or during surgery.

### How long does treatment last?

Several weeks of antibiotic treatment are usually necessary to ensure the infection has cleared. However, it can take a long time to recover fully, and it may be several months before you're well enough to leave hospital.

Complications of cavernous sinus thrombosis
-------------------------------------------

Cavernous sinus thrombosis is a very serious condition. Even with prompt treatment, as many as 1 in 3 people with the condition may die.

Some people who survive will develop long-term health problems due to damage to their brain, such as persistent headaches and fits, or some degree of [vision loss](https://www.nhs.uk/conditions/vision-loss/).

Read more about the [complications of cavernous sinus thrombosis](https://www.nhs.uk/conditions/cavernous-sinus-thrombosis/complications/).

Who's affected?
---------------

It's difficult to say exactly how many people are affected by cavernous sinus thrombosis, but it's thought to be very rare.

The condition affects people of all ages and tends to be more common in women than men. This may be because [pregnancy](https://www.nhs.uk/conditions/pregnancy-and-baby/) and taking the [oral contraceptive pill](https://www.nhs.uk/contraception/methods-of-contraception/combined-pill/) can make women more vulnerable to blood clots.

Page last reviewed: 05 August 2021  
Next review due: 05 August 2024
