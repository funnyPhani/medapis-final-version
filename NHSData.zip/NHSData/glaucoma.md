Title: Glaucoma

URL Source: https://www.nhs.uk/conditions/glaucoma/

Published Time: 23 Oct 2017, 1:07 p.m.

Markdown Content:
**Glaucoma is a common eye condition where the optic nerve, which connects the eye to the brain, becomes damaged.**

It's usually caused by fluid building up in the front part of the eye, which increases pressure inside the eye.

Glaucoma can lead to loss of vision if it's not diagnosed and treated early.

It can affect people of all ages, but is most common in adults in their 70s and 80s.

Symptoms of glaucoma
--------------------

Glaucoma does not usually cause any symptoms to begin with.

It tends to develop slowly over many years and affects the edges of your vision (peripheral vision) first.

For this reason, many people do not realise they have glaucoma, and it's often only picked up during a routine eye test.

If you do notice any symptoms, they might include blurred vision, or seeing rainbow-coloured circles around bright lights.

Both eyes are usually affected, although it may be worse in 1 eye.

Very occasionally, glaucoma can develop suddenly and cause:

*   intense eye pain
*   nausea and vomiting
*   a [red eye](https://www.nhs.uk/conditions/red-eye/)
*   a [headache](https://www.nhs.uk/conditions/headaches/)
*   tenderness around the eyes
*   seeing rings around lights
*   blurred vision

When to get medical advice
--------------------------

Visit an [opticians](https://www.nhs.uk/service-search/Opticians/LocationSearch/9) or a GP if you have any concerns about your vision.

If you have glaucoma, early diagnosis and treatment can help stop your vision getting worse.

Without treatment, glaucoma can eventually lead to [blindness](https://www.nhs.uk/conditions/vision-loss/).

If you develop symptoms of glaucoma suddenly, go to your nearest [eye casualty unit](https://www.nhs.uk/service-search/Eye-accident-and-emergency-services/LocationSearch/1858) or [A&E](https://www.nhs.uk/Service-Search/Accident-and-emergency-services/LocationSearch/428) as soon as possible.

This is a medical emergency that may require immediate treatment.

Types of glaucoma
-----------------

There are several different types of glaucoma.

The most common is called primary open angle glaucoma. This tends to develop slowly over many years.

It's caused by the drainage channels in the eye becoming gradually clogged over time.

Other types of glaucoma include:

*   acute angle closure glaucoma – an uncommon type caused by the drainage in the eye becoming suddenly blocked, which can raise the pressure inside the eye very quickly
*   secondary glaucoma – caused by an underlying eye condition, such as [inflammation of the eye (uveitis)](https://www.nhs.uk/conditions/uveitis/)
*   childhood glaucoma (congenital glaucoma) – a rare type that occurs in very young children, caused by an abnormality of the eye

Causes of glaucoma
------------------

Glaucoma can occur for a number of reasons.

Most cases are caused by a build-up of pressure in the eye when fluid is unable to drain properly.

This increase in pressure then damages the nerve that connects the eye to the brain (optic nerve).

It's often unclear why this happens, although certain things can increase the risk, including:

*   your age – glaucoma becomes more common as you get older
*   your ethnicity – people of African, Caribbean or Asian origin are at a higher risk
*   your family history – you're more likely to develop glaucoma if you have a parent or sibling with the condition
*   other medical conditions – such as [short-sightedness](https://www.nhs.uk/conditions/short-sightedness/), [long-sightedness](https://www.nhs.uk/conditions/long-sightedness/) and [diabetes](https://www.nhs.uk/conditions/diabetes/)

It's not clear whether you can do anything to prevent glaucoma, but having regular eye tests should pick it up as early as possible.

Tests for glaucoma
------------------

Glaucoma can usually be detected during a routine eye test at an opticians, often before it causes any noticeable symptoms.

The tests are carried out in the opticians by an optometrist.

You should have a routine eye test at least every 2 years.

[Find out if you're eligible for free NHS eye tests](https://www.nhs.uk/using-the-nhs/help-with-health-costs/free-nhs-eye-tests-and-optical-vouchers/)

Several quick and painless tests can be carried out to check for glaucoma, including vision tests and measurements of the pressure inside your eye.

If tests suggest you have glaucoma, you should be referred to a specialist eye doctor (ophthalmologist) to discuss treatment.

[Find out how glaucoma is diagnosed](https://www.nhs.uk/conditions/glaucoma/diagnosis/)

Treatments for glaucoma
-----------------------

It's not possible to reverse any loss of vision that occurred before glaucoma was diagnosed, but treatment can help stop your vision getting worse.

The treatment recommended for you will depend on the type of glaucoma you have, but the options are:

*   eyedrops – to reduce the pressure in your eyes
*   laser treatment – to open up the blocked drainage tubes or reduce the production of fluid in your eyes
*   surgery – to improve the drainage of fluid

You'll also probably need regular appointments to monitor your condition and check the treatment is working.

Further support for glaucoma
----------------------------

The [Royal National Institute of Blind People (RNIB)](http://www.rnib.org.uk/eye-health-eye-conditions-z-eye-conditions/glaucoma) and [Glaucoma UK](https://glaucoma.uk/) have more information on glaucoma and offer further support for people affected by glaucoma.

Video: Glaucoma
---------------

In this video, an expert explains what glaucoma is, how it can affect your vision and how it can be treated.

Media last reviewed: 1 June 2023  
Media review due: 1 June 2026

Page last reviewed: 26 February 2021  
Next review due: 26 February 2024
