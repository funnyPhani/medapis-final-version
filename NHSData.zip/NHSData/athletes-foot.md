Title: Athlete's foot

URL Source: https://www.nhs.uk/conditions/athletes-foot/

Published Time: 17 Oct 2017, 5:02 p.m.

Markdown Content:
**Athlete's foot is a common fungal infection that affects the feet. You can usually treat it with creams, sprays or powders from a pharmacy, but it can keep coming back.**

Symptoms of athlete's foot
--------------------------

One of the main symptoms of athlete's foot is itchy white patches between your toes.

![Image 1: Athlete's foot on dark brown skin. Close-up of 2 toes. Between the toes is a scaly white and green patch.](https://assets.nhs.uk/nhsuk-cms/images/shutterstock_1885656472.width-320.png)

![Image 2: Athlete's foot on light brown skin. A hand holds open some toes. Between 2 toes is a scaly white patch.](https://assets.nhs.uk/nhsuk-cms/images/C0298816-Athlete_s_foot-SPL.width-320.jpg)

It can also cause sore and flaky patches on your feet.

The skin can look red, but this may be less noticeable on brown or black skin.

![Image 3: Athlete's foot on white skin. Close-up of the bottom of a foot with a red flaky patch behind 1 of the toes.](https://assets.nhs.uk/nhsuk-cms/images/S_0118_athletes-foot_M2700100.width-320.jpg)

![Image 4: Athlete's foot on dark brown skin. Close-up of 2 toes. Between the toes is a flaky, dark brown and slightly white patch.](https://assets.nhs.uk/nhsuk-cms/images/shutterstock_1885656484.width-320.png)

Sometimes the skin on your feet may become cracked or bleed.

![Image 5: Athlete's foot on white skin. Close-up of cracked skin between 2 toes. The crack is red and skin around it is white and red.](https://assets.nhs.uk/nhsuk-cms/images/S_0118_athletes-foot_M2700167.width-320.jpg)

### Other symptoms

Athlete's foot can also affect your soles or sides of your feet. It sometimes causes fluid-filled blisters.

If it's not treated, the infection can spread to your toenails and cause a [fungal nail infection](https://www.nhs.uk/conditions/fungal-nail-infection/).

A pharmacist can help with athlete's foot
-----------------------------------------

Athlete's foot is unlikely to get better on its own, but you can buy [antifungal medicines](https://www.nhs.uk/conditions/antifungal-medicines/) for it from a pharmacy. They usually take a few weeks to work.

Athlete's foot treatments are available as:

*   creams
*   sprays
*   powders

They're not all suitable for everyone – for example, some are only for adults. Always check the packet or ask a pharmacist.

You might need to try a few treatments to find one that works best for you.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

### Things you can do if you have athlete's foot

You can keep using some pharmacy treatments to stop athlete's foot coming back.

It's also important to keep your feet clean and dry. You do not need to stay off work or school.

#### Do

*   dry your feet after washing them, particularly between your toes – dab them dry rather than rubbing them
    
*   use a separate towel for your feet and wash it regularly
    
*   wear clean socks every day – cotton socks are best
    

#### Don’t

*   do not scratch affected skin – this can spread it to other parts of your body
    
*   do not walk around barefoot – wear flip-flops in places like changing rooms and showers
    
*   do not share towels, socks or shoes with other people
    
*   do not wear the same pair of shoes for more than 2 to 3 days in a row
    
*   do not wear shoes that make your feet hot and sweaty
    

#### Important

Keep following this advice after finishing treatment to help stop athlete's foot coming back.

Non-urgent advice: See a GP if:
-------------------------------

You have athlete's foot and:

*   treatments from a pharmacy do not work
*   you're in a lot of pain
*   your foot or leg is hot, painful and red (the redness may be less noticeable on brown or black skin) – this could be a more serious infection
*   the infection spreads to other parts of your body such as your hands
*   you have diabetes – foot problems can be more serious if you have diabetes
*   you have a weakened immune system – for example, you have had an organ transplant or are having chemotherapy

Treatment for athlete's foot from a GP
--------------------------------------

If you have athlete's foot and treatments from a pharmacy have not worked, a GP may:

*   send a small scraping of skin from your feet to a laboratory to check you have athlete's foot
*   prescribe a [steroid cream](https://www.nhs.uk/conditions/topical-steroids/) to use alongside antifungal cream
*   prescribe antifungal tablets – you might need to take these for several weeks
*   refer you to a skin specialist (dermatologist) for more tests and treatment if needed

How you get athlete's foot
--------------------------

You can catch athlete's foot from other people with the infection.

You can get it by:

*   walking barefoot in places where someone else has athlete's foot – especially changing rooms and showers
*   touching the affected skin of someone with athlete's foot

You're more likely to get it if you have wet or sweaty feet, or if the skin on your feet is damaged.

Page last reviewed: 29 April 2024  
Next review due: 29 April 2027
