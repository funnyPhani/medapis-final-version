Title: Autism

URL Source: https://www.nhs.uk/conditions/autism/

Published Time: 8 Mar 2023, 1:51 p.m.

Markdown Content:
Autism - NHS
===============
                                   

Cookies on the NHS website
--------------------------

We've put some small files called cookies on your device to make our site work.

We'd also like to use analytics cookies. These collect feedback and send information about how our site is used to services called Adobe Analytics, Adobe Target, Qualtrics Feedback and Google Analytics. We use this information to improve our site.

Let us know if this is OK. We'll use a cookie to save your choice. You can [read more about our cookies](https://www.nhs.uk/our-policies/cookies-policy/) before you choose.

*   I'm OK with analytics cookies
*   Do not use analytics cookies

You can change your cookie settings at any time using our [cookies page](https://www.nhs.uk/our-policies/cookies-policy/).

 [Skip to main content](https://www.nhs.uk/conditions/autism/#maincontent)

[](https://www.nhs.uk/)

Search the NHS website

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Search

[My account](https://www.nhs.uk/nhs-app/account/)

*   [Health A-Z](https://www.nhs.uk/conditions/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [Home](https://www.nhs.uk/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   Browse More
    

1.  [Home](https://www.nhs.uk/)
2.  [Health A to Z](https://www.nhs.uk/conditions/)

[Back to Health A to Z](https://www.nhs.uk/conditions/)

Autism
======

This guide can help if you or someone you care about is autistic or might be autistic.

*   [What is autism?](https://www.nhs.uk/conditions/autism/what-is-autism/)
    -----------------------------------------------------------------------
    
    An introduction to what autism is and how it affects people
    
*   [Signs of autism](https://www.nhs.uk/conditions/autism/signs/)
    --------------------------------------------------------------
    
    Find out what the main signs of autism are and if you should get advice
    
*   [Getting diagnosed](https://www.nhs.uk/conditions/autism/getting-diagnosed/)
    ----------------------------------------------------------------------------
    
    Find out how to get diagnosed as autistic and how a diagnosis can be helpful
    
*   [Newly diagnosed: things to help](https://www.nhs.uk/conditions/autism/newly-diagnosed/)
    ----------------------------------------------------------------------------------------
    
    Information and advice if you or your child have recently been diagnosed as autistic
    
*   [Autism and everyday life](https://www.nhs.uk/conditions/autism/autism-and-everyday-life/)
    ------------------------------------------------------------------------------------------
    
    Information and advice if you care for an autistic child
    
*   [Other conditions that affect autistic people](https://www.nhs.uk/conditions/autism/other-conditions/)
    ------------------------------------------------------------------------------------------------------
    
    Find out which conditions often affect autistic people, what the symptoms are and when to get help
    
*   [Where to get support](https://www.nhs.uk/conditions/autism/support/)
    ---------------------------------------------------------------------
    
    Find out where to get support if you or your child are autistic, such as charities and your council
    
*   [Easy read information and videos](https://www.nhs.uk/conditions/autism/easy-read-and-videos/)
    ----------------------------------------------------------------------------------------------
    
    Information about autism in an easy read format or video if you have a learning disability
    

Support links
-------------

*   [Home](https://www.nhs.uk/)
*   [Health A to Z](https://www.nhs.uk/conditions/)
*   [Live Well](https://www.nhs.uk/live-well/)
*   [Mental health](https://www.nhs.uk/mental-health/)
*   [Care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/)
*   [Pregnancy](https://www.nhs.uk/pregnancy/)
*   [NHS services](https://www.nhs.uk/nhs-services/)
*   [Coronavirus (COVID-19)](https://www.nhs.uk/conditions/coronavirus-covid-19/)

*   [NHS App](https://www.nhs.uk/nhs-app/)
*   [Find my NHS number](https://www.nhs.uk/nhs-services/online-services/find-nhs-number/)
*   [View your GP health record](https://www.nhs.uk/nhs-services/gps/view-your-gp-health-record/)
*   [View your test results](https://www.nhs.uk/nhs-services/online-services/view-your-test-results/)
*   [About the NHS](https://www.nhs.uk/using-the-nhs/about-the-nhs/)
*   [Healthcare abroad](https://www.nhs.uk/using-the-nhs/healthcare-abroad/apply-for-a-free-uk-global-health-insurance-card-ghic/)

*   [Other NHS websites](https://www.nhs.uk/nhs-sites/)
*   [Profile editor login](https://www.nhs.uk/our-policies/profile-editor-login/)

*   [About us](https://www.nhs.uk/about-us/)
*   [Give us feedback](https://www.nhs.uk/give-feedback-about-the-nhs-website/)
*   [Accessibility statement](https://www.nhs.uk/accessibility-statement/)
*   [Our policies](https://www.nhs.uk/our-policies/)
*   [Cookies](https://www.nhs.uk/our-policies/cookies-policy/)

© Crown copyright
