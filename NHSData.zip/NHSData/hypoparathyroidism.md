Title: Hypoparathyroidism

URL Source: https://www.nhs.uk/conditions/hypoparathyroidism/

Published Time: 27 Feb 2018, 4:25 p.m.

Markdown Content:
**Hypoparathyroidism is a rare condition where the parathyroid glands, which are in the neck near the thyroid gland, produce too little parathyroid hormone.**

This makes blood calcium levels fall (hypocalcaemia) and blood phosphorus levels rise (hyperphosphataemia), which can cause a wide range of symptoms, including muscle cramps, pain and twitching.

Treatment for hypoparathyroidism involves taking supplements, usually for life, to restore calcium and phosphorus levels.

Symptoms of hypoparathyroidism
------------------------------

The symptoms of hypoparathyroidism can include:

*   a [tingling sensation (paraesthesia)](https://www.nhs.uk/conditions/pins-and-needles/) in your fingertips, toes and lips
*   twitching facial muscles
*   muscle pains or cramps, particularly in your legs, feet or tummy
*   tiredness
*   mood changes, such as feeling irritable, anxious or [depressed](https://www.nhs.uk/conditions/clinical-depression/)
*   dry, rough skin
*   coarse hair that breaks easily and can fall out
*   fingernails that break easily

Diagnosing hypoparathyroidism
-----------------------------

Hypoparathyroidism is diagnosed after a blood test has shown:

*   low parathyroid hormone levels
*   low calcium levels
*   high phosphorus levels

Treating hypoparathyroidism
---------------------------

Treatment for hypoparathyroidism aims to relieve your symptoms and bring the levels of calcium and other minerals in your blood back to normal.

The normal calcium range is around 2.2 to 2.6 millimoles per litre (mmol/L). You'll be advised to keep your calcium levels in a slightly lower range – for example, 1.8 to 2.25mmol/L. Your recommended range will depend on your circumstances.

Calcium carbonate and [vitamin D supplements](https://www.nhs.uk/conditions/vitamins-and-minerals/vitamin-d/) – usually calcitriol (Rocaltrol) or alfacalcidol (One-Alpha) – can be taken to restore your blood calcium to these levels. They usually have to be taken for life.

You'll also need to have regular [blood tests](https://www.nhs.uk/conditions/blood-tests/) to monitor your parathyroid hormone, calcium and phosphorus levels.

If your blood calcium levels fall to a dangerously low level or you keep having muscle spasms, you may need to be given calcium through a drip directly into your vein.

### Dietary advice

It's also recommended that you follow a high-calcium, low-phosphorus diet.

Good sources of [calcium](https://www.nhs.uk/conditions/vitamins-and-minerals/calcium/) include:

*   milk, cheese and other dairy foods
*   leafy green vegetables, such as broccoli, cabbage and okra – but not spinach
*   soya beans
*   tofu
*   soya drinks with added calcium
*   nuts
*   bread and anything made with fortified flour
*   fish where you eat the bones, such as sardines and pilchards

[Phosphorus](https://www.nhs.uk/conditions/vitamins-and-minerals/others/#phosphorus) is found in:

*   red meat
*   dairy
*   fish
*   poultry
*   bread
*   rice
*   oats

Causes of hypoparathyroidism
----------------------------

The most common cause of hypoparathyroidism is removal of or accidental injury to the parathyroid glands during surgery to the neck.

Other causes include:

*   autoimmune conditions, where the body mistakenly attacks its own tissues – such as [Addison's disease](https://www.nhs.uk/conditions/addisons-disease/) and [pernicious anaemia](https://www.nhs.uk/conditions/vitamin-b12-or-folate-deficiency-anaemia/#causes-of-a-vitamin-b12-or-folate-deficiency)
*   being born without parathyroid glands or with glands that don't work properly – for example, people with the inherited genetic disorder [DiGeorge syndrome](https://www.nhs.uk/conditions/digeorge-syndrome/) can have underdeveloped parathyroid glands
*   [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) to treat throat or neck cancer
*   low blood magnesium levels – for example, because of [alcohol misuse](https://www.nhs.uk/conditions/alcohol-misuse/)

Page last reviewed: 01 April 2021  
Next review due: 01 April 2024
