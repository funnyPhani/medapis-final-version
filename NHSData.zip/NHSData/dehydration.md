Title: Dehydration

URL Source: https://www.nhs.uk/conditions/dehydration/

Published Time: 19 Dec 2017, 3:35 p.m.

Markdown Content:
**Dehydration means your body loses more fluids than you take in. If it's not treated, it can get worse and become a serious problem.**

Important
---------

Babies, children and older adults are more at risk of dehydration.

Check if you're dehydrated
--------------------------

Symptoms of dehydration in adults and children include:

*   feeling thirsty
*   dark yellow, strong-smelling pee
*   peeing less often than usual
*   feeling dizzy or lightheaded
*   feeling tired
*   a dry mouth, lips and tongue
*   sunken eyes

Signs of dehydration in a baby may include:

*   a sunken soft spot (fontanelle) on top of their head
*   sunken eyes
*   few or no tears when they cry
*   not having many wet nappies
*   being drowsy or irritable

Causes of dehydration
---------------------

Dehydration can happen more easily if you:

*   have [diabetes](https://www.nhs.uk/conditions/diabetes/)
*   have been sick or have diarrhoea
*   have been in the sun too long ([heatstroke](https://www.nhs.uk/conditions/heat-exhaustion-heatstroke/))
*   have drunk too much alcohol
*   sweat a lot after exercising
*   have a high temperature
*   take medicines that make you pee more (diuretics)

Things you can do to treat dehydration
--------------------------------------

You should drink fluids if you have symptoms of dehydration.

If you feel sick or have been sick, you may find it hard to drink, so start with small sips and then gradually drink more.

### A pharmacist can help with dehydration

If you're being sick or have diarrhoea and are losing too much fluid, you need to put back the sugar, salts and minerals your body has lost.

A pharmacist can recommend oral rehydration solutions. These are powders that you mix with water and then drink.

Ask your pharmacist which rehydration solutions are right for you or your child.

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   you're feeling unusually tired (or your child seems drowsy)
*   you're confused and disorientated
*   you feel dizzy when you stand up and it does not go away
*   you have dark yellow pee or you're peeing less than normal (or your baby has fewer wet nappies)
*   you or your child are breathing quickly or has a fast heart rate
*   your baby or child has few or no tears when they cry
*   your baby has a soft spot on their head that sinks inwards (sunken fontanelle)

These can be signs of serious dehydration that need urgent treatment.

You can call 111 or [get help from 111 online](https://111.nhs.uk/).

Keeping your child hydrated
---------------------------

Once dehydration has been treated, it's important that your child's fluid levels are maintained.

### Do

*   carry on breastfeeding your baby or using formula – try to give small amounts more often than usual
    
*   give your baby small sips of extra water if they’re on formula or solid foods
    
*   give regular small sips of rehydration solution to replace lost fluids – ask your pharmacist to recommend one
    
*   give small children their usual diet
    

### Don’t

*   do not make formula weaker
    
*   do not give young children fruit juice or fizzy drinks – it can make diarrhoea or vomiting worse
    

How to reduce the risk of dehydration
-------------------------------------

Drinking fluids regularly can reduce the risk of dehydration. Water or diluted squash are good choices.

You should drink enough during the day, so your pee is a pale clear colour.

Drink more when there's a higher risk of dehydrating. For example, if you're being sick, sweating due to hot weather or exercise, or you have diarrhoea.

Children under the age of 5 should get plenty of fluids to avoid dehydration.

### Helping someone you care for

A person you care for may not have a sense of how much they're drinking.

You can help them by:

*   making sure they drink at mealtimes
*   making drinking a social thing, like "having a cup of tea"
*   offering them food with a high water content – for example, soup, ice cream, jelly and fruits like melon

### Video: how to prevent dehydration

This video shows you how you can reduce the risk of dehydration.

Media last reviewed: 1 July 2023  
Media review due: 1 July 2026

Page last reviewed: 14 November 2022  
Next review due: 14 November 2025
