Title: Childhood cataracts

URL Source: https://www.nhs.uk/conditions/childhood-cataracts/

Published Time: 20 Oct 2017, 4:19 p.m.

Markdown Content:
**Cataracts occur when changes in the lens of the eye cause it to become less transparent (clear). This results in cloudy or misty vision.**

The lens is the transparent structure located just behind the pupil (the black circle in the centre of the eye).

It allows light to pass through to the light-sensitive layer of tissue at the back of the eye (retina).

Cataracts most commonly affect older adults ([age-related cataracts](https://www.nhs.uk/conditions/cataracts/)), but some babies are born with cataracts.

Children can also develop them at a young age. These are known as childhood cataracts.

Childhood cataracts are often referred to as:

*   congenital cataracts – cataracts present when a baby is born or shortly afterwards
*   developmental, infantile or juvenile cataracts – cataracts diagnosed in older babies or children

Cataracts in babies and children are rare. In the UK, around 3 to 4 in every 10,000 babies are born with cataracts.

Symptoms of cataracts in children
---------------------------------

In children, cataracts can affect 1 or both eyes.

Cloudy patches in the lens can sometimes get bigger and more can develop, resulting in the child's vision becoming increasingly affected.

As well as poor vision, cataracts can also cause "wobbling eyes" and a [squint](https://www.nhs.uk/conditions/squint/), where the eyes point in different directions.

When your child is very young, it can be difficult to spot signs of cataracts.

But your baby's eyes will be routinely examined at their newborn physical screening examination within 72 hours of birth, and again when they're 6 to 8 weeks old.

If a congenital cataract is suspected at the newborn examination, a specialist eye doctor will see your baby within 2 weeks of the examination.

If a congenital cataract is suspected at the 6 to 8 week examination, a specialist eye doctor will see your baby by the time they're 11 weeks old.

Sometimes cataracts can develop in children after these screening tests.

It's particularly important to spot cataracts in children quickly because early treatment can reduce the risk of long-term vision problems.

You should visit a GP or tell your health visitor if you have any concerns about your child's eyesight.

Read more about the [symptoms of childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/symptoms/) and [diagnosing childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/diagnosis/).

What causes cataracts in children?
----------------------------------

There are a number of reasons why a child may be born with cataracts or develop them while they're still young.

But in many cases it is not possible to determine the exact cause.

Possible causes include:

*   a genetic fault inherited from the child's parents that caused the lens to develop abnormally
*   certain genetic conditions, including [Down's syndrome](https://www.nhs.uk/conditions/downs-syndrome/)
*   certain infections picked up by the mother during pregnancy, including [rubella](https://www.nhs.uk/conditions/rubella/) and [chickenpox](https://www.nhs.uk/conditions/chickenpox/)
*   an injury to the eye after birth

Read more about the [causes of childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/causes/).

How childhood cataracts are treated
-----------------------------------

Cataracts in children are often not too bad and have little or no effect on their vision.

But if cataracts are affecting your child's vision, they can slow down or stop their normal sight development.

In these cases, surgery to remove the affected lens (or lenses) will usually be recommended as soon as possible.

Replacing the focusing power of the lens is as important as the surgery to remove it.

The affected lens may sometimes be replaced with an artificial lens during surgery. But it's more common for the child to wear contact lenses or glasses after surgery to compensate for the lens that was removed.

It can be difficult to predict exactly how much better your child's vision will be after treatment. It's likely there will always be a degree of reduced vision in the affected eye (or eyes).

But many children born with childhood cataracts do not grow up to have serious problems with their vision.

Read more about [treating childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/treatment/).

What are the risks?
-------------------

Cataracts that affect vision that are not quickly treated can sometimes cause irreversible damage to eyesight, including a permanently [lazy eye](https://www.nhs.uk/conditions/lazy-eye/) and even [blindness](https://www.nhs.uk/conditions/vision-loss/) in severe cases.

Cataract surgery is generally successful, with a low risk of serious complications.

The most common risk associated with cataract surgery is a condition that can affect artificial lens implants called posterior capsule opacification (PCO), which causes cloudy vision to return.

Another important risk of surgery is [glaucoma](https://www.nhs.uk/conditions/glaucoma/), where pressure builds inside the eye.

Without successful treatment, glaucoma can cause irreversible damage to key structures in the eye.

Although some of the possible complications of cataract surgery can affect your child's vision, they can often be treated with medicine or further surgery.

Read more about the [complications of childhood cataracts](https://www.nhs.uk/conditions/childhood-cataracts/complications/).

Can cataracts in children be prevented?
---------------------------------------

It's not usually possible to prevent cataracts, particularly those that are inherited (run in the family).

But following the advice of your midwife or a GP to avoid infections during pregnancy (including making sure all your vaccinations are up to date before getting pregnant) may reduce the chances of your child being born with cataracts.

If you previously had a baby with childhood cataracts and are planning another pregnancy, you may wish to speak with a GP about whether genetic counselling would be appropriate.

Genetic counselling can help couples who may be at risk of passing an inherited condition on to their child.

Read more about [infections in pregnancy](https://www.nhs.uk/pregnancy/keeping-well/infections-that-may-affect-your-baby/) and [genetic and genomic testing](https://www.nhs.uk/conditions/genetic-and-genomic-testing/).

Information about your child
----------------------------

If your child has had cataracts, your clinical team will pass information about him or her on to the National Congenital Anomaly and Rare Disease Registration Service (NCARDRS).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

[Find out more about the register on GOV.UK](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet)

Page last reviewed: 13 April 2022  
Next review due: 13 April 2025
