Title: Eyelid problems

URL Source: https://www.nhs.uk/conditions/eyelid-problems/

Published Time: 18 Oct 2017, 11:29 a.m.

Markdown Content:
**Find out what to do if you have a lump on your eyelid, or an eyelid that's swollen, sticky, itchy or painful.**

Most eyelid problems are harmless
---------------------------------

Many eyelid problems are not serious.

It's fairly common to have any of these problems:

*   a lump that goes away by itself after several days or weeks
*   mildly itchy, flaky or sticky eyelids that clear up by themselves
*   swelling from a nearby insect bite, injury or operation that goes away after a week or so
*   twitching or blinking from time to time – often when you're tired
*   eyelids that droop (or get more "hooded") as you get older

Types of eyelid problems
------------------------

Your symptoms might give you an idea of what's causing your eyelid problem. But do not self-diagnose – see a pharmacist, GP or optician.

Common eyelid problems and possible causes
| Eyelid problem | Possible cause |
| --- | --- |
| Lump or swelling on eyelid
 | [Stye](https://www.nhs.uk/conditions/stye/) or meibomian cyst (chalazion)

 |
| Itchy, flaky, sticky or swollen eyelid

 | [Allergy](https://www.nhs.uk/conditions/allergies/), [blepharitis](https://www.nhs.uk/conditions/blepharitis/), or [conjunctivitis](https://www.nhs.uk/conditions/conjunctivitis/)

 |
| Yellow lump or patch on eyelid

 | Xanthelasma (yellow patches sometimes caused by high cholesterol)

 |
| Eyelid turning outwards or inwards

 | [Ectropion](https://www.nhs.uk/conditions/ectropion/) or entropion

 |
| Hot, painful and swollen eyelid

 | [Cellulitis](https://www.nhs.uk/conditions/cellulitis/)

 |

Information:

There is separate information about [twitching eyelids](https://www.nhs.uk/conditions/twitching-eyes-and-muscles/).

A pharmacist can help with eyelid problems
------------------------------------------

You can ask a pharmacist about:

*   what you can do to treat common eyelid problems, like a stye or conjunctivitis, yourself
*   if you can buy anything to help – for example, cleaning solutions for sticky eyelids
*   if you need to see an optician or GP

[Find a pharmacy](https://www.nhs.uk/service-search/pharmacy/find-a-pharmacy)

Non-urgent advice: See a GP if:
-------------------------------

*   you're worried about an eyelid problem
*   your eyelid symptoms are not improving or they're lasting a long time
*   you have yellow lumps or patches around your eyes

Urgent advice: Ask for an urgent GP or optician appointment or get help from NHS 111 if:
----------------------------------------------------------------------------------------

*   your swollen eyelid is red, hot, painful, tender or blistered
*   your eyelid droops suddenly
*   you cannot open your eye or keep it open
*   the pain is in your eye (not your eyelid)
*   the white of your eye is very red, in part or all over
*   you have eye symptoms and a headache or you feel sick or are being sick
*   a newborn baby (less than 1 month old) has a sticky, red eye
*   you're sensitive to light (photophobia)
*   your eyesight changes – for example, you have blurred vision and see wavy flashing lights, zigzag patterns or coloured spots or lines
*   you have a very high temperature, or feel hot and shivery, or you feel generally unwell
*   you think it's an allergic reaction

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Page last reviewed: 17 November 2023  
Next review due: 17 November 2026
