Title: Cancer

URL Source: https://www.nhs.uk/conditions/cancer/

Published Time: 22 Nov 2017, 10:05 a.m.

Markdown Content:
**Cancer is a condition where cells in a specific part of the body grow and reproduce uncontrollably. The cancerous cells can invade and destroy surrounding healthy tissue, including organs.**

Cancer sometimes begins in one part of the body before spreading to other areas. This process is known as metastasis.

1 in 2 people will develop some form of cancer during their lifetime. In the UK, the 4 most common types of cancer are:

*   [breast cancer](https://www.nhs.uk/conditions/breast-cancer-in-women/)
*   [lung cancer](https://www.nhs.uk/conditions/lung-cancer/)
*   [prostate cancer](https://www.nhs.uk/conditions/prostate-cancer/)
*   [bowel cancer](https://www.nhs.uk/conditions/bowel-cancer/)

There are more than 200 different types of cancer, and each is diagnosed and treated in a particular way. You can find links on this page to information about other types of cancer.

Spotting signs of cancer
------------------------

Changes to your body's normal processes or unusual, unexplained symptoms can sometimes be an early sign of cancer.

Symptoms that need to be checked by a doctor include:

*   a lump that suddenly appears on your body
*   unexplained bleeding
*   changes to your bowel habits

But in many cases your symptoms will not be related to cancer and will be caused by other, non-cancerous health conditions.

Read more about the [signs and symptoms of cancer](https://www.nhs.uk/conditions/cancer/symptoms/).

Reducing your risk of cancer
----------------------------

Making some simple changes to your lifestyle can significantly reduce your risk of developing cancer.

For example:

*   [healthy eating](https://www.nhs.uk/live-well/eat-well/how-to-eat-a-balanced-diet/eating-a-balanced-diet/)
*   taking [regular exercise](https://www.nhs.uk/live-well/exercise/)
*   [not smoking](https://www.nhs.uk/live-well/quit-smoking/)

[Find out more about how a healthy lifestyle reduces your chances of developing cancer on the Macmillan Cancer Support website](https://www.macmillan.org.uk/cancer-information-and-support/worried-about-cancer/causes-and-risk-factors)

Cancer treatment
----------------

Surgery is the first treatment to try for most types of cancer, as solid tumours can usually be surgically removed.

2 other commonly used treatment methods are:

*   [chemotherapy](https://www.nhs.uk/conditions/chemotherapy/) – powerful cancer-killing medicines
*   [radiotherapy](https://www.nhs.uk/conditions/radiotherapy/) – the controlled use of high-energy [X-rays](https://www.nhs.uk/conditions/x-ray/)

Waiting times
-------------

Accurately diagnosing cancer can take weeks or months. As cancer often develops slowly over several years, waiting for a few weeks will not usually impact on the effectiveness of treatment.

[The National Institute for Health and Care Excellence (NICE) has produced referral guidelines for suspected cancer](https://www.nice.org.uk/guidance/ng12).

You should not have to wait more than 2 weeks to see a specialist if your GP suspects you have cancer and urgently refers you.

In cases where cancer has been confirmed, you should not have to wait more than 31 days from the decision to treat to the start of treatment.

[NHS England has more detailed statistics on cancer waiting times](https://www.england.nhs.uk/statistics/statistical-work-areas/cancer-waiting-times/)

Cancer services
---------------

*   [Find local cancer support services](https://www.nhs.uk/service-search/Cancer-information-and-support/LocationSearch/320)
*   [Find cancer support services for women](https://www.nhs.uk/Service-Search/Cancer-support-for-women/LocationSearch/319)

Other cancer pages
------------------

The Health A-Z covers many different types of cancer:

*   [Acute lymphoblastic leukaemia](https://www.nhs.uk/conditions/acute-lymphoblastic-leukaemia/)
*   [Acute myeloid leukaemia](https://www.nhs.uk/conditions/acute-myeloid-leukaemia/)
*   [Anal cancer](https://www.nhs.uk/conditions/anal-cancer/)
*   [Bile duct cancer](https://www.nhs.uk/conditions/bile-duct-cancer/)
*   [Bladder cancer](https://www.nhs.uk/conditions/bladder-cancer/)
*   [Bone cancer](https://www.nhs.uk/conditions/bone-cancer/)
*   [Bowel cancer](https://www.nhs.uk/conditions/bowel-cancer/)
*   [Brain tumour (cancerous)](https://www.nhs.uk/conditions/malignant-brain-tumour/)
*   [Brain tumour (non-cancerous)](https://www.nhs.uk/conditions/benign-brain-tumour/)
*   [Breast cancer in women](https://www.nhs.uk/conditions/breast-cancer-in-women/)
*   [Breast cancer in men](https://www.nhs.uk/conditions/breast-cancer-in-men/)
*   [Carcinoid tumours](https://www.nhs.uk/conditions/carcinoid-syndrome/)
*   [Cervical cancer](https://www.nhs.uk/conditions/cervical-cancer/)
*   [Chronic lymphocytic leukaemia](https://www.nhs.uk/conditions/chronic-lymphocytic-leukaemia/)
*   [Chronic myeloid leukaemia](https://www.nhs.uk/conditions/chronic-myeloid-leukaemia/)
*   [Endometrial cancer](https://www.nhs.uk/conditions/womb-cancer/)
*   [Ewing sarcoma](https://www.nhs.uk/conditions/ewing-sarcoma/)
*   [Eye cancer](https://www.nhs.uk/conditions/eye-cancer/)
*   [Gallbladder cancer](https://www.nhs.uk/conditions/gallbladder-cancer/) 
*   [Hairy cell leukaemia](https://www.nhs.uk/conditions/hairy-cell-leukaemia/)
*   [Head and neck cancer](https://www.nhs.uk/conditions/head-and-neck-cancer/)
*   [Hodgkin lymphoma](https://www.nhs.uk/conditions/hodgkin-lymphoma/)
*   [Kaposi's sarcoma](https://www.nhs.uk/conditions/kaposis-sarcoma/)
*   [Kidney cancer](https://www.nhs.uk/conditions/kidney-cancer/)
*   [Laryngeal cancer](https://www.nhs.uk/conditions/laryngeal-cancer/)
*   [Liver cancer](https://www.nhs.uk/conditions/liver-cancer/)
*   [Lung cancer](https://www.nhs.uk/conditions/lung-cancer/)
*   [Mesothelioma](https://www.nhs.uk/conditions/mesothelioma/)
*   [Mouth cancer](https://www.nhs.uk/conditions/mouth-cancer/)
*   [Multiple myeloma](https://www.nhs.uk/conditions/multiple-myeloma/)
*   [Nasopharyngeal cancer](https://www.nhs.uk/conditions/nasopharyngeal-cancer/)
*   [Neuroendocrine tumours](https://www.nhs.uk/conditions/neuroendocrine-tumours/)
*   [Non-Hodgkin lymphoma](https://www.nhs.uk/conditions/non-hodgkin-lymphoma/)
*   [Nasal and sinus cancer](https://www.nhs.uk/conditions/nasal-and-sinus-cancer/)
*   [Oesophageal cancer](https://www.nhs.uk/conditions/oesophageal-cancer/)
*   [Ovarian cancer](https://www.nhs.uk/conditions/ovarian-cancer/)
*   [Pancreatic cancer](https://www.nhs.uk/conditions/pancreatic-cancer/)
*   [Penile cancer](https://www.nhs.uk/conditions/penile-cancer-1/)
*   [Prostate cancer](https://www.nhs.uk/conditions/prostate-cancer/)
*   [Retinoblastoma](https://www.nhs.uk/conditions/retinoblastoma/)
*   [Skin cancer (melanoma)](https://www.nhs.uk/conditions/melanoma-skin-cancer/)
*   [Skin cancer (non-melanoma)](https://www.nhs.uk/conditions/non-melanoma-skin-cancer/)
*   [Soft tissue sarcoma](https://www.nhs.uk/conditions/soft-tissue-sarcoma-old/)
*   [Stomach cancer](https://www.nhs.uk/conditions/stomach-cancer/)
*   [Testicular cancer](https://www.nhs.uk/conditions/testicular-cancer/)
*   [Thyroid cancer](https://www.nhs.uk/conditions/thyroid-cancer/)
*   [Vaginal cancer](https://www.nhs.uk/conditions/vaginal-cancer/)
*   [Vulval cancer](https://www.nhs.uk/conditions/vulval-cancer/)
*   [Womb cancer](https://www.nhs.uk/conditions/womb-cancer/)

Page last reviewed: 13 October 2022  
Next review due: 13 October 2025

*   [Next : Signs and symptoms](https://www.nhs.uk/conditions/cancer/symptoms/)
