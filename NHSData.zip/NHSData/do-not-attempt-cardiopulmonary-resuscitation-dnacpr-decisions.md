Title: Do not attempt cardiopulmonary resuscitation (DNACPR) decisions

URL Source: https://www.nhs.uk/conditions/do-not-attempt-cardiopulmonary-resuscitation-dnacpr-decisions/

Published Time: 10 Mar 2021, 5:28 p.m.

Markdown Content:
CPR stands for cardiopulmonary resuscitation. It's a treatment that can be given when you stop breathing (respiratory arrest) or your heart stops beating (cardiac arrest).

CPR tries to get your breathing and heart going again.

It can involve:

*   pressing down hard on your chest repeatedly (chest compressions)
*   a machine to stimulate your heart using electrical shocks (sometimes more than once)
*   equipment that helps move oxygen around your body (artificial ventilation)
*   giving medicine by injection

How successful is CPR?
----------------------

CPR can sometimes get the heart and breathing going again. The actions used in CPR, such as chest compressions, can cause bruising, break ribs and puncture lungs.

Overall, CPR restarts the heart and/or breathing for between 1 and 2 in 10 people whose heart or breathing have stopped.

You have the best chance of CPR restarting your heart or breathing if:

*   your lungs, heart or other organs are healthy and working well before your heart or breathing stops
*   you are near a person trained in CPR
*   any equipment that is needed, such as a defibrillator, is nearby

The chances of CPR starting your heart and/or breathing are lower if your lungs, heart or other organs are struggling to work before CPR is needed. Your organs might be struggling because you:

*   have previous organ damage (for example, your lungs have been damaged by smoking)
*   have a serious long-term condition (this is not the same as a disability)
*   have current severe illness
*   are frail
*   are approaching the end of your life

Only a few people make a full recovery even if their heart or breathing can be restarted with CPR.

You may still be very unwell and need more treatment and you may never get back to the health you had before.

Your heart and/or brain may be permanently damaged. This is why DNACPR forms are written. They mean you do not receive a treatment that may prolong or cause suffering at the end of your life.

What does DNACPR mean and how is it recorded?
---------------------------------------------

DNACPR stands for do not attempt cardiopulmonary resuscitation. It's sometimes called DNAR (do not attempt resuscitation) or DNR (do not resuscitate) but they all refer to the same thing.

DNACPR means if your heart or breathing stops your healthcare team will not try to restart it.

A DNACPR decision is made by you and/or your doctor or healthcare team. This is explained in more detail in the following section "When is a DNACPR decision made and a form written and who is involved?".

A DNACPR decision is usually recorded on a special form. Different doctors or hospitals might use different forms, but they all serve the same purpose. Some examples are a DNACPR form, a treatment escalation plan, or a recommended summary plan for emergency care and treatment (ReSPECT) process.

All these forms are easily recognised by doctors, nurses and healthcare workers, so they know what to do in an emergency.

This form is kept in your medical records. It may also be printed and kept with you if you are at home or in a care home.

You and the people important to you should know that a DNACPR form has been put in your medical records.

The form says that if your heart or breathing stop, CPR should not be tried. This means medical staff will not try to restart your heart or breathing.

### Important

DNACPR is about CPR only. It does not mean that you will not get care and treatment. You will continue to have all the other appropriate care, treatment and support you need.

When is a DNACPR decision made and a form written and who is involved?
----------------------------------------------------------------------

There are different situations when a DNACPR decision might be made.

### You decide – deciding in advance to refuse CPR

Everyone who has capacity to do so can refuse CPR if they wish.

This is a choice you can make at any time, for example when you are healthy or when you are approaching the end of your life.

You can make it clear to your doctor or medical team that you do not want CPR if your heart or breathing stops.

Your doctor may complete a DNACPR form to indicate this and put it in your medical records.

*   If you wish to make your refusal of CPR legally binding for when in the future you are unable to make this decision, then you should write an [Advance Decision to Refuse Treatment (ADRT).](https://www.nhs.uk/conditions/end-of-life-care/planning-ahead/advance-decision-to-refuse-treatment/) An ADRT explains to a doctor or medical team when you want to refuse CPR (or other treatments).
*   You can change your mind about your DNACPR decision at any time. If you do, you need to tell your doctors and nurses so that the DNACPR form is marked as no longer valid. The fact that you once had a DNACPR form will still be recorded on your records so that doctors and nurses can see your full medical history and know about conversations that happened in the past.

### A doctor decides in advance

*   DNACPR is a medical treatment decision that can be made by your doctor even if you do not agree.
*   You must be told that a DNACPR form will be/has been completed for you, but a doctor does not need your consent. Doctors can only not tell you that a DNACPR form has been completed for you if they think doing so would cause you physical or psychological harm.
*   You should be given the chance to understand what a DNACPR is, how the decision is made and why they think CPR would not be suitable for you. For example, your doctor may think that CPR will not help you live longer or that giving you CPR could cause you more harm. This may be because your organs are already too damaged because of another illness or you are approaching the end of your life.
*   You should then be consulted, and doctors should ask about your wishes and preferences. Your doctor makes the final decision.
*   Doctors do not have to give you treatment if they think it will not work.
*   A DNACPR decision must be made on an individual (person by person) basis. This means it must be based on your health, needs and priorities as an individual. The judgement about whether the discussion or decision would cause you harm should also be made on an individual basis.
*   DNACPR decisions should not be made for a group of people at once. For example, DNACPR decisions should not be made for everyone living in a care home or for a group of people over a certain age. This is unlawful, irrespective of medical condition, age, disability, race or language.
*   Learning disability, autism or dementia are not reasons to put a DNACPR on someone's record.
*   If you disagree with a DNACPR decision that a doctor has made, you can ask for a second opinion and a review. You cannot demand CPR. The law does not require your consent to a DNACPR. The law does provide you with the right to be involved in, and informed of, a doctor's DNACPR decision.

What happens if you are unable to make or discuss a DNACPR decision in advance of your heart stopping?
------------------------------------------------------------------------------------------------------

Some people cannot make decisions about CPR for themselves. If you have been assessed as unable to make a specific decision for yourself, you will be referred to as "lacking capacity".

If you lack capacity to decide about CPR, doctors should first check to see if you have an [Advance Decision to Refuse Treatment (ADRT)](https://www.nhs.uk/conditions/end-of-life-care/planning-ahead/advance-decision-to-refuse-treatment/) that says that you do not want CPR. They should also check to see if you have a [Lasting Power of Attorney (LPA)](https://www.nhs.uk/conditions/end-of-life-care/planning-ahead/lasting-power-of-attorney/) for health and care decisions.

An LPA is a document that explains who you have chosen to help you make decisions or who can make decisions for you. Your chosen person(s) are known as "attorneys". If you would like your LPA to make decisions about CPR, then you must complete and sign the section on life-sustaining treatment in the LPA document.

An LPA (with the right to make decisions on life-sustaining treatment) means if you lack the relevant capacity, your attorney can make the decision relating to CPR in your best interests. Your attorney cannot insist on CPR being given.

If you do not have an ADRT (which says that you do not want CPR) or an LPA (with life-sustaining treatment decision-making powers) then a best interest's decision is made by the senior doctor.

This doctor must ask the people who are important to you about your wishes and preferences. This includes anyone with the legal power to represent you, such as a personal welfare deputy, special guardian or – for children and young people under 16 – a parent.

If you do not have family or friends appropriate to ask, then the doctor should ask an independent mental capacity advocate (IMCA) to represent you in the decision-making process. The doctor should also ask members of your healthcare (multidisciplinary) team for their views.

How long does a DNACPR form last?
---------------------------------

A DNACPR form can be written for a short period – for example, if you have been admitted to hospital. Or it can be written with no end date – for example, if you have a long-term condition that has damaged your heart, lungs or other organs – only being reviewed if your situation changes.

When the DNACPR decision is made you should be told when it will be reviewed, and this is usually recorded on the form. It's recommended that a DNACPR is reviewed each time your situation changes – for example, when you leave hospital. If a DNACPR form is placed on your medical records while in hospital, this will be included in your discharge summary and shared with your GP.

Is a DNACPR form legally binding?
---------------------------------

A DNACPR form is not legally binding. It's a tool to tell doctors, nurses or paramedics not to attempt CPR.

If you wish to make your DNACPR decision legally binding, you should write an [Advance Decision to Refuse Treatment (ADRT)](https://www.nhs.uk/conditions/end-of-life-care/planning-ahead/advance-decision-to-refuse-treatment/). An ADRT explains when you want to refuse CPR (or other treatment).

Talking about a DNACPR
----------------------

You do not have to talk about DNACPR if you do not want to. If you would prefer not to talk about it, you can let your doctors and nurses know. You could ask your doctors and nurses to make it clear on your record. If you change your mind and want to talk about it, you can.

If a decision needs to be made about CPR, your doctors can still decide to complete a form even if you ask not to talk about it. Your doctor will do this if they believe that CPR would not prolong your life or would do you more harm than good.

Even if you ask not to be involved in the decision, you should be told if a DNACPR form is written and placed on your medical records. Doctors can only not tell you that a DNACPR form has been completed for you if they think doing so would cause you physical or psychological harm.

What should you do if you are concerned about a DNACPR form in your medical record or on somebody else's (such as a relative)?
------------------------------------------------------------------------------------------------------------------------------

If you are concerned about a DNACPR form, you should first raise those concerns with your doctor.

If you are still not happy, then you can ask for another doctor's opinion.

If you are not the patient and the patient has capacity to make their own decisions, they will need to agree to it being discussed with you. If you do not have capacity, your family, friends or those with the legal power to represent you (such as a [Lasting Power of Attorney](https://www.nhs.uk/conditions/end-of-life-care/planning-ahead/lasting-power-of-attorney/)) can raise concerns on your behalf.

It's important to understand that nobody has the right to demand CPR, so the decision may not change if there was a good clinical reason for it (for example, your heart, lungs or other organs are struggling to work). The doctor should explain their reasons and ask about your wishes and preferences.

If the DNACPR form was made by a GP, and you are not happy with their response, you should follow the practice's complaints procedure. If you are still concerned, or you wish to make a complaint, contact [NHS England](https://www.england.nhs.uk/contact-us/complaint/complaining-to-nhse/) and NHS Improvement.

If the DNACPR form was made by a doctor in a hospital, and you are not happy with their response, you can ask to speak to the senior doctor on duty or the consultant responsible for your care. The hospital should have its own complaints procedure. This will tell you how to make a complaint.

If your DNACPR form was made by a GP or doctor in a hospital, you can contact your [local Healthwatch](https://www.healthwatch.co.uk/your-local-healthwatch/list) to find out about [how to get help making a complaint](https://www.healthwatch.co.uk/help-making-complaint). You can also have support from [an advocate](https://www.nhs.uk/conditions/social-care-and-support-guide/help-from-social-services-and-charities/someone-to-speak-up-for-you-advocate/) if you want help to make a complaint about your GP or a doctor in the hospital.

If you are still not happy with the response you can contact the [Parliamentary and Health Service Ombudsman](https://www.ombudsman.org.uk/).

Page last reviewed: 14 December 2023  
Next review due: 14 December 2026
