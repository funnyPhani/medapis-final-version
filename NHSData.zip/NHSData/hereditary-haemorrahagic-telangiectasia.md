Title: Hereditary haemorrhagic telangiectasia (HHT)

URL Source: https://www.nhs.uk/conditions/hereditary-haemorrahagic-telangiectasia/

Published Time: 18 Oct 2017, 2:07 p.m.

Markdown Content:
**Hereditary haemorrhagic telangiectasia (HHT) is an inherited genetic disorder that affects the blood vessels. It's also known as Osler-Weber-Rendu syndrome.**

People with HHT have some blood vessels that have not developed properly and sometimes cause bleeding, known as arteriovenous malformations (AVMs).

When AVMs form in the lining of the nose or the gut, they can easily bleed. Frequent bleeding can lead to anaemia and sometimes more serious problems.

Symptoms of HHT
---------------

The typical symptoms of HHT include:

*   regular nosebleeds
*   visible red spots in certain places on the body

Symptoms usually start in childhood or in the teenage years, but can start at any age.

See a GP if you have these symptoms so they can investigate the cause.

### Nosebleeds

[Nosebleeds](https://www.nhs.uk/conditions/nosebleed/) are often the first sign of HHT. They may be frequent and persistent.

They happen because of the abnormal blood vessels in the lining of the nose.

The loss of blood can lead to [iron-deficiency anaemia](https://www.nhs.uk/conditions/iron-deficiency-anaemia/), if the iron is not replaced through the diet and with iron supplements.

### Red or purple spots under the skin (telangiectasia)

Abnormal blood vessels (telangiectasia) may appear just underneath the skin, which show as red or purple spots.

These often start to appear in adolescence.

Red or purple spots usually form on the fingertip pads, the lips, and the lining of the nose or the gut. Sometimes, they can form on the ears and face.

### Abnormal blood vessels (AVMs) inside the body 

AVMs can form inside the body organs and tissues. Many people with AVMs inside the body will not have any symptoms.

However, AVMs in the lungs can lead to low blood oxygen levels and AVMs in the brain can cause seizures or headaches.

If AVMs in the body bleed, this can increase the risk of a stroke.

Causes of HHT
-------------

People with HHT have a faulty gene, which is usually inherited from one of their parents.

This gene normally provides instructions for making certain proteins found in the lining of the blood vessels. In HHT, the gene cannot produce this protein, or the protein it produces is abnormal.

You only need to have 1 copy of the faulty gene to develop HHT.

Treatment for HHT
-----------------

There's no cure for HHT, but there are effective treatments.

Some people can be treated by a GP and others need to be under the care of a specialist.

There are increased risks during pregnancy for women with HHT, such as a slight increased risk of a major bleed or a stroke. Tell a midwife or GP if you have HHT in your family and you become pregnant.

### Iron supplements

If you have regular nosebleeds you will probably lose a lot of iron through this loss of blood, especially if you also bleed from telangiectasia in the gut.

It may be necessary to replace the lost iron with iron supplements. Dietary changes alone may not be enough.

Read about:

*   the importance of [iron](https://www.nhs.uk/conditions/vitamins-and-minerals/iron/)
*   [iron deficiency anaemia](https://www.nhs.uk/conditions/iron-deficiency-anaemia/)

### Treatment of nosebleeds

People with severe nosebleeds may need emergency nasal packing, where the nose is packed with ribbon gauze or a special nasal sponge.

Read about [nosebleeds](https://www.nhs.uk/conditions/nosebleed/).

Some people may need to see an ear, nose and throat specialist for treatment. Laser therapy may help.

More severe cases may be treated with skin grafting or other surgery.

### Blood transfusion after loss of blood

If a lot of blood has been lost from bleeding inside the body or after nosebleeds, a blood transfusion may be needed.

Read about [blood transfusions](https://www.nhs.uk/conditions/blood-transfusion/).

### Laser treatment for telangiectasia

Telangiectasia on the skin or in the lining of the nose can sometimes be improved with vascular laser or intense pulsed light (IPL) treatment:

*   for the skin, you'll usually need a referral to a dermatologist – this may be expensive if treatment is not available on the NHS as 2 to 4 treatments a year may be needed
*   for the nose, you'll need a referral to an ear, nose and throat (ENT) specialist – these treatments are usually available on the NHS

Laser and IPL machines produce narrow beams of light aimed at the visible blood vessels in the skin. The heat from the lasers makes the veins shrink so they're no longer visible. This should leave minimal scarring or damage to the surrounding area.

Laser treatment can be uncomfortable, but most people do not need a local anaesthetic.

Treating AVMs inside the body
-----------------------------

AVMs in the body may require specialist treatment. Your HHT specialist will explain any procedures to you in more detail.

For example, AVMs in the lung are usually treated, even if they're not causing any apparent problems. They're treated by embolisation, a procedure that blocks the blood supply to the AVM. A tiny plug is inserted inside the artery supplying the abnormal blood vessel.

Embolisation is preferred to open surgery and is normally carried out under sedation (which helps relax you during the procedure).

For brain AVMs, embolisation, surgery and stereotactic radiotherapy (precisely delivering radiation to the blood vessel) are possible treatment options. Liver AVMs may require different types of specialist treatments.

However, these treatments are not always appropriate. Your specialist will explain why many AVMs, such as those in the liver and in the brain, may be better left alone. The risks of treatments may outweigh the potential benefits.

Information about you
---------------------

If you have HHT, your clinical team may pass information about you on to the [National Congenital Anomaly and Rare Disease Registration Service (NCARDRS)](https://www.gov.uk/government/publications/national-congenital-anomaly-and-rare-disease-registration-service-introductory-leaflet).

This helps scientists look for better ways to prevent and treat this condition. You can opt out of the register at any time.

Page last reviewed: 09 May 2023  
Next review due: 09 May 2026
