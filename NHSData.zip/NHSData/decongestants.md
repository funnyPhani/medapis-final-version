Title: Decongestants

URL Source: https://www.nhs.uk/conditions/decongestants/

Published Time: 18 Oct 2017, 10:23 a.m.

Markdown Content:
**Decongestants are a type of medicine that can provide short-term relief for a blocked or stuffy nose (nasal congestion).**

They can help ease the symptoms of conditions such as [colds](https://www.nhs.uk/conditions/common-cold/) and [flu](https://www.nhs.uk/conditions/flu/), [hay fever](https://www.nhs.uk/conditions/hay-fever/) and other [allergic reactions](https://www.nhs.uk/conditions/allergies/), [catarrh](https://www.nhs.uk/conditions/catarrh/) and [sinusitis](https://www.nhs.uk/conditions/sinusitis-sinus-infection/).

They work by reducing the swelling of the blood vessels in your nose, which helps to open the airways.

Examples include [pseudoephedrine](https://www.nhs.uk/medicines/pseudoephedrine/) (sometimes called by the brand name Sudafed).

Types of decongestants
----------------------

Decongestants are available as:

*   nasal sprays
*   drops
*   tablets or capsules
*   liquids or syrups
*   flavoured powders to dissolve in hot water

Some products may just contain decongestant medicine, but many are sold as "all-in-1" remedies that contain decongestants, painkillers or [antihistamines](https://www.nhs.uk/conditions/antihistamines/).

Most decongestants can be bought over the counter from pharmacies without a prescription.

Who can take decongestants
--------------------------

Most people can use decongestants safely, but they're not suitable for everyone.

They should not be used by the following groups of people without getting advice from a pharmacist or GP first:

*   people taking other medicines
*   people with [diabetes](https://www.nhs.uk/conditions/diabetes/)
*   people with [high blood pressure](https://www.nhs.uk/conditions/high-blood-pressure-hypertension/)
*   people with an overactive thyroid gland [(hyperthyroidism)](https://www.nhs.uk/conditions/overactive-thyroid-hyperthyroidism/)
*   men with an [enlarged prostate](https://www.nhs.uk/conditions/prostate-enlargement/)
*   people with liver, kidney, heart or circulation problems
*   people with increased pressure in the eye [glaucoma](https://www.nhs.uk/conditions/glaucoma/)

### Babies and children

Decongestants should not be given to children under 6 years of age.

Children aged 6 to 11 should take them for no longer than 5 days. Ask a pharmacist for advice about this.

Always follow the instructions that come with the packet.

### Pregnant and breastfeeding women

It's not clear whether it's safe to take any type of decongestant if you're pregnant, so you should only use them if told to by a healthcare professional.

Decongestants that come as tablets, liquids or powders that you swallow are not recommended if you're breastfeeding.

Some decongestants that come as nose sprays or drops are safe to use if you're breastfeeding, but check with a pharmacist or GP first before using them.

The patient information leaflet that comes with your medicine will say who should not use it and who should get advice before using it.

How to use decongestants
------------------------

Most decongestants should only be used between 1 and 4 times a day.

Check the patient information leaflet that comes with your medicine for advice about how much to take and how often to take it.

If you're not sure, ask a pharmacist for advice.

Decongestant nasal sprays and drops should not be used for more than a week at a time because using them for too long can make your stuffiness worse.

Speak to a GP if your symptoms do not improve after this time.

Side effects of decongestants
-----------------------------

Decongestant medicines do not usually have side effects, and any side effects you may experience are usually mild.

Possible side effects can include:

*   feeling sleepy (look for non-drowsy medicines)
*   irritation of the lining of your nose
*   headaches
*   feeling or being sick
*   a dry mouth
*   feeling restless or agitated
*   a rash

These side effects should go away once you stop taking the medicine.

More serious side effects can also happen, such as [hallucinations](https://www.nhs.uk/conditions/hallucinations/) and severe allergic reactions [(anaphylaxis)](https://www.nhs.uk/conditions/anaphylaxis/), but these are very rare.

Taking decongestants with other medicines
-----------------------------------------

Ask a pharmacist or GP before taking decongestants if you're taking other medicines.

Decongestants can increase or decrease the effect of some other medicines.

For example, taking decongestants alongside some [antidepressants](https://www.nhs.uk/conditions/antidepressants/) can cause a dangerous rise in blood pressure.

It's also important to be careful when taking other medicines if you're using an "all-in-1" decongestant remedy.

"All-in-1" decongestants also contain painkillers or antihistamines, so it could be dangerous to take extra doses of these medicines at the same time.

Page last reviewed: 03 November 2022  
Next review due: 03 November 2025
