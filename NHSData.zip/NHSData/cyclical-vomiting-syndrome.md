Title: Cyclical vomiting syndrome

URL Source: https://www.nhs.uk/conditions/cyclical-vomiting-syndrome/

Published Time: 18 Oct 2017, 10:40 a.m.

Markdown Content:
Check if it's cyclical vomiting syndrome
----------------------------------------

The main symptoms of cyclical vomiting syndrome are severe episodes of feeling sick (nausea) and being sick (vomiting), followed by periods of feeling well.

Each episode can last anything from a few hours up to a few days.

They begin with sweating, feeling sick and looking paler than usual, followed by retching (trying to be sick) and vomiting.

Other symptoms of cyclical vomiting syndrome may include:

*   being very tired (exhaustion)
*   loss of appetite
*   tummy pain
*   diarrhoea
*   dizziness
*   headaches
*   eye pain when looking at bright lights

Episodes usually start at the same time of day or night and last for the same length of time. Once these symptoms improve, most people with cyclical vomiting syndrome feel better for a few weeks or months until a new episode begins.

Cyclical vomiting syndrome often starts in children around 5 years old and improves as they get older. But it can also affect adults and is often more severe in adults who did not have the condition as a child.

Urgent advice: Get help from NHS 111 now if:
--------------------------------------------

*   you or your child keep being sick and cannot keep fluid down
*   you or your child are peeing less than usual (or your baby has fewer wet nappies)

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms). Call 111 if you're asking about a child under 5 years old.

Immediate action required: Call 999 or go to A&E if you or your child:
----------------------------------------------------------------------

*   vomit blood or have vomit that looks like ground coffee
*   have green vomit (adults)
*   have yellow-green or green vomit (children)
*   have a stiff neck and eye pain when looking at bright lights
*   have a sudden, severe headache
*   have a sudden, severe tummy ache
*   have blue, grey, pale or blotchy skin, lips or tongue – on brown or black skin this may be easier to see on the palms of the hands or soles of the feet
*   are having severe difficulty breathing – you're gasping, choking or not able to get words out (babies may make grunting noises or their stomach may suck under their ribcage)
*   are confused or not responding as usual

These could be signs of a more serious condition.

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

How cyclical vomiting syndrome is diagnosed
-------------------------------------------

If you or your child have episodes of severe nausea (feeling sick) and vomiting (being sick), a doctor will check if your symptoms could be caused by cyclical vomiting syndrome.

The doctor may ask you about:

*   how many episodes you've have and how long they last
*   how often you vomit during each episode
*   if you feel well between the episodes and how long you feel well for

You may need tests to rule out other conditions.

Treatment for cyclical vomiting syndrome
----------------------------------------

Medicines may be able to help with cyclical vomiting syndrome if you have more than 1 episode a month.

The medicines you're prescribed will depend on your symptoms and age, but may include:

*   medicines that can be used to treat and prevent [migraines](https://www.nhs.uk/conditions/migraine/)
*   anti-sickness medicines
*   painkillers

A doctor can also offer support if your child is struggling to cope with the symptoms of cyclical vomiting syndrome.

If an episode is very severe, you may need to be treated in hospital with medicine and fluids given directly into a vein (intravenously). This will help to prevent dehydration and treat the symptoms.

How to manage the symptoms of cyclical vomiting syndrome
--------------------------------------------------------

There are things you can do to help prevent episodes of cyclical vomiting syndrome, or manage the symptoms.

To help prevent episodes:

*   keep a diary to see if certain things trigger your symptoms – for example, some people find certain foods, large meals, stress or lack of sleep can be triggers and it can help to avoid them
*   remember to take any medicine you've been prescribed

During an episode:

*   stay in bed and sleep in a dark, quiet room
*   keep taking small sips of fluid, such as water or diluted squash, to prevent dehydration during and after an episode of vomiting – a pharmacist can recommend oral rehydration solutions that you mix with water and drink

Causes of cyclical vomiting syndrome
------------------------------------

The exact cause of cyclical vomiting syndrome is not known, but you're more likely to have it if you or anyone in your family gets migraines.

You may find the episodes of vomiting are triggered by something. Common examples include:

*   stress, anxiety or excitement
*   not getting enough sleep or doing too much exercise:
*   colds, allergies and infections
*   certain foods and drinks, such as alcohol, caffeine, cheese or chocolate
*   going without food or fluid for a long time

Information:

Find out more
-------------

More information and support for people with cyclical vomiting syndrome is available from:

*   [The Cyclical Vomiting Syndrome Association UK](http://www.cvsa.org.uk/)
*   [The Migraine Trust](https://migrainetrust.org/understand-migraine/types-of-migraine/cyclical-vomiting-syndrome/)

Page last reviewed: 31 May 2024  
Next review due: 31 May 2027
