Title: Carpal tunnel syndrome

URL Source: https://www.nhs.uk/conditions/carpal-tunnel-syndrome/

Published Time: 24 Oct 2017, 4:17 p.m.

Markdown Content:
Check if you have carpal tunnel syndrome (CTS)
----------------------------------------------

The symptoms of carpal tunnel syndrome include:

*   an ache or pain in your fingers, hand or arm
*   numb hands
*   tingling or pins and needles
*   a weak thumb or difficulty gripping

These symptoms often start slowly and come and go. They're usually worse at night.

How to treat carpal tunnel syndrome (CTS) yourself
--------------------------------------------------

Carpal tunnel syndrome (CTS) sometimes gets better by itself in a few months, particularly if you have it because you're pregnant.

### Wear a wrist splint

A wrist splint is something you wear on your hand to keep your wrist straight. It helps to relieve pressure on the nerve.

You wear it at night while you sleep. You may need to wear a splint for up to 6 weeks before it starts to feel better.

You can buy wrist splints online or from pharmacies.

### Stop or cut down on things that may be causing it

Stop or cut down on anything that causes you to frequently bend your wrist or grip hard, such as using vibrating tools for work or playing an instrument.

### Painkillers

Painkillers like [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) may help carpal tunnel pain short-term.

But there's little evidence to say they can treat the cause of CTS, so it's important not to rely on them.

### Hand exercises

There's a small amount of evidence to suggest hand exercises help ease the symptoms of CTS.

[The Chartered Society of Physiotherapy has instructions for simple hand exercises you can try](https://www.csp.org.uk/public-patient/rehabilitation-exercises/carpal-tunnel-syndrome).

Non-urgent advice: See a GP if:
-------------------------------

*   your carpal tunnel syndrome symptoms are getting worse or are not going away
*   treatment at home for carpal tunnel syndrome is not working

What happens at your appointment
--------------------------------

A GP can usually diagnose carpal tunnel syndrome (CTS) by asking about your symptoms and checking your hand.

If they're not sure it's CTS, they may refer you to hospital for:

*   a test of the nerves in your wrist (nerve conduction test)
*   scans such as an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) or [MRI scan](https://www.nhs.uk/conditions/mri-scan/)

Treatment for carpal tunnel syndrome (CTS) from a GP
----------------------------------------------------

If you have carpal tunnel syndrome (CTS) and a wrist splint does not help, the GP might recommend a [steroid injection](https://www.nhs.uk/conditions/steroid-injections/) into your wrist. This brings down swelling around the nerve, easing the symptoms of CTS.

Steroid injections are not always a cure. CTS can come back after a few months and you may need another injection.

Information:

### Self-refer for treatment

If you have carpal tunnel syndrome, you might be able to refer yourself directly to services for help with your condition without seeing a GP.

To find out if there are any services in your area:

*   ask the reception staff at your GP surgery
*   check your GP surgery's website
*   contact [your local integrated care board (ICB)](https://www.nhs.uk/nhs-services/find-your-local-integrated-care-board/)
*   search online for NHS treatment for carpal tunnel syndrome near you

### Carpal tunnel syndrome surgery

If your CTS is getting worse and other treatments have not worked, the GP might refer you to a specialist to discuss surgery.

Surgery usually cures CTS. You and your specialist will decide together if it's the right treatment for you.

An injection numbs your wrist so you do not feel pain (local anaesthetic) and a small cut is made in your hand. The carpal tunnel inside your wrist is cut so it no longer puts pressure on the nerve.

The operation takes around 20 minutes and you do not have to stay in hospital overnight.

It can take a month after the operation to get back to normal activities.

What causes carpal tunnel syndrome (CTS)
----------------------------------------

Carpal tunnel syndrome (CTS) happens when the carpal tunnel inside your wrist swells and squeezes 1 of your nerves (median nerve).

You're more at risk of CTS if you:

*   are overweight
*   are pregnant
*   do work or hobbies that mean you repeatedly bend your wrist or grip hard, such as using vibrating tools
*   have certain other conditions, such as arthritis or diabetes
*   have a parent, brother or sister with CTS
*   have previously injured your wrist

Page last reviewed: 17 April 2024  
Next review due: 17 April 2027
