Title: Granuloma annulare

URL Source: https://www.nhs.uk/conditions/granuloma-annulare/

Published Time: 18 Oct 2017, 2:51 p.m.

Markdown Content:
**Granuloma annulare is a skin condition that often looks like a ring of bumps. It sometimes clears up without treatment, but it can take a long time and it may come back. See a GP if you have bumps or lumps on your skin that do not go way in a few weeks.**

Check if you have granuloma annulare
------------------------------------

Granuloma annulare mainly affects children, teenagers and young adults, but older adults can get it too.

The most common symptom is small circular patches of pink, purple or skin-coloured bumps on the skin.

![Image 1: A pink, circular ring of raised lumps shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_Granuloma_annulare_C0037232.width-320.jpg)

The patches can appear on 1 or more places on your body. They tend to affect bony areas such as the back of the hands, fingers, elbows and feet.

The patches are usually raised and grow slowly to around 2.5 to 5cm. They may eventually become flatter before gradually fading.

Granuloma annulare may be harder to see on black and brown skin.

![Image 2: The first, second and third fingers of a person with dark brown skin. Several raised, circular areas of skin are visible on their middle finger.](https://assets.nhs.uk/nhsuk-cms/images/FN4-granuloma-annulare.width-320.png)

In older adults, granuloma annulare is often made up of lots of small pink or skin-coloured bumps that cover large areas of the arms, legs or trunk (chest, tummy and back).

![Image 3: A person’s upper right arm. There's a horseshoe-shaped ring of small, pink bumps covering a large area of their inner bicep. The image is on white skin.](https://assets.nhs.uk/nhsuk-cms/images/S_1017_granuloma_annulare_M1650186.width-320.jpg)

Less commonly, granuloma annulare can cause 1 or more firm, rubbery lumps just under the skin, usually on the feet and fingertips.

![Image 4: The inside of a child’s foot with a lump underneath the skin. The image is on white skin and the lump is skin-coloured.](https://assets.nhs.uk/nhsuk-cms/images/C0498687-Skin_lesion_copy.width-320.png)

Information:

### Other causes of circular skin conditions

If you have a circular rash it could be [ringworm](https://www.nhs.uk/conditions/ringworm/), a common fungal infection that can usually be treated with medicines from a pharmacy.

Non-urgent advice: See a GP if:
-------------------------------

*   you have lumps or raised areas of skin that do not go away within a few weeks

Treatments for granuloma annulare
---------------------------------

Granuloma annulare is harmless and sometimes disappears without treatment. But it can take a long time to clear up (2 to 10 years) and it often comes back.

A skin specialist (dermatologist) may suggest treatment if granuloma annulare affects a visible or large area of your body and it’s affecting your life.

Treatments for granuloma annulare can include:

*   steroid medicines – which may be creams, tablets or injections
*   freezing small areas of skin (cryotherapy) – this can leave a permanent scar
*   ultraviolet light therapy – light is used to reduce the inflammation in the skin
*   skin camouflage (make-up)

There are different types of granuloma annulare and some can be difficult to treat. Your doctor will talk to you about your options.

Causes of granuloma annulare
----------------------------

Granuloma annulare is inflammation in the deep layer of the skin called the dermis.

The exact cause is unknown, but some types may be related to other health problems, such as [diabetes](https://www.nhs.uk/conditions/diabetes/) and thyroid conditions like Graves' disease.

You cannot catch granuloma annulare from someone who has it.

Page last reviewed: 11 July 2023  
Next review due: 11 July 2026
