Title: Cardiac catheterisation and coronary angiography

URL Source: https://www.nhs.uk/conditions/coronary-angiography/

Published Time: 19 Oct 2017, 4:40 p.m.

Markdown Content:
**Cardiac catheterisation is an invasive diagnostic procedure that provides important information about the structure and function of the heart.**

It usually involves taking [X-rays](https://www.nhs.uk/conditions/x-ray/) of the heart's arteries (coronary arteries) using a technique called coronary angiography or arteriography.

The resulting images are known as coronary angiograms or arteriograms.

Why do I need coronary angiography?
-----------------------------------

Coronary angiography can be used to help diagnose heart conditions, help plan future treatments and carry out certain procedures.

For example, it may be used:

*   after a [heart attack](https://www.nhs.uk/conditions/heart-attack/) – where the heart's blood supply is blocked
*   to help diagnose [angina](https://www.nhs.uk/conditions/angina/) – where pain in the chest is caused by restricted blood supply to the heart
*   to plan interventional or surgical procedures – such as a [coronary angioplasty](https://www.nhs.uk/conditions/coronary-angioplasty/), where narrowed or blocked blood vessels are widened

Coronary angiography is also considered to be the best method of diagnosing [coronary heart disease](https://www.nhs.uk/conditions/coronary-heart-disease/), where a build-up of fatty substances in the coronary arteries affects the heart's blood supply.

[Find out why coronary angiography is used](https://www.nhs.uk/conditions/coronary-angiography/why-its-done/)

What happens during coronary angiography?
-----------------------------------------

During the procedure a long, thin, flexible tube called a catheter is inserted into a blood vessel in your groin or arm.

Using X-ray images as a guide, the tip of the catheter is passed up to the heart and coronary arteries.

A special type of dye called contrast medium is injected through the catheter and X-ray images (angiograms) are taken.

The contrast medium is visible on the angiograms, showing the blood vessels the fluid travels through. This clearly highlights any blood vessels that are narrowed or blocked.

The procedure is usually carried out under [local anaesthetic](https://www.nhs.uk/conditions/local-anaesthesia/), so you'll be awake while the procedure is carried out, but the area where the catheter is inserted will be numbed.

After coronary angiography
--------------------------

You'll usually be able to leave hospital on the same day you have a coronary angiography, after a period of rest and observation. You'll need to arrange a lift home from a family member or friend.

Most people feel fine a day or so after having the procedure, although you may feel a bit tired afterwards and the wound site is likely to be tender for up to a week. Any bruising may last for up to 2 weeks.

You'll usually be advised to avoid certain activities, such as bathing and lifting heavy objects, for a day or two after the procedure. Do not drive until you're told it's safe to do so, which may not be for up to 3 days.

While you're recovering, it's important to look out for signs of any problems.

You should seek immediate medical attention if swelling at the site of your wound gets worse, or if you experience excessive bleeding or circulation problems in your limbs.

Complications
-------------

Cardiac catheterisation and coronary angiography are usually very safe.

But as with all procedures, there are some risks, including:

*   being allergic to the contrast dye – this is uncommon, but you should discuss any [allergies](https://www.nhs.uk/conditions/allergies/) you have with your heart specialist (cardiologist) before having the procedure
*   bleeding under the skin where the catheter was inserted – this should stop after a few days, but you should contact your GP if you're concerned about it
*   a very small risk of more serious complications, including damage to the artery in the arm or leg where the catheter was inserted, [heart attack](https://www.nhs.uk/conditions/heart-attack/), [stroke](https://www.nhs.uk/conditions/stroke/), kidney damage and, very rarely, death

Video: Your guide to a coronary angiogram
-----------------------------------------

Watch this video to find out what to expect when having a coronary angiogram.

Media last reviewed: 1 April 2024  
Media review due: 1 April 2027

Page last reviewed: 04 October 2022  
Next review due: 04 October 2025
