Title: Cellulitis

URL Source: https://www.nhs.uk/conditions/cellulitis/

Published Time: 19 Oct 2017, 4 p.m.

Markdown Content:
Urgent advice: Ask for an urgent GP appointment or get help from NHS 111 if:
----------------------------------------------------------------------------

*   your skin is painful, hot and swollen

Early treatment with antibiotics can stop cellulitis becoming more serious.

You can call 111 or [get help from 111 online](https://111.nhs.uk/triage/check-your-symptoms).

Check if you have cellulitis
----------------------------

Cellulitis makes your skin painful, hot and swollen. The area usually looks red, but this may be less obvious on brown or black skin. Your skin may also be blistered.

You may also feel unwell and have flu-like symptoms, with [swollen, painful glands](https://www.nhs.uk/conditions/swollen-glands/).

You can get cellulitis on any part of your body but it's more common on your lower limbs.

![Image 1: Swollen, tight, red skin on the fingers and back of 1 hand caused by cellulitis. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/M1300345-Inflammation_of_hand_due_to_celluliti.width-320.jpg)

You can get cellulitis on your hands, which causes swelling in your fingers or on the back of your hands.

![Image 2: A patch of dark red skin on the top of a foot, caused by cellulitis. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/C0215596-Cellulitis_of_the_foot-SPL.width-320.jpg)

You can also get cellulitis on your feet, sometimes near your toes if you have athlete's foot.

![Image 3: Skin on a person's lower leg is swollen, red, with area of dark brown. A line of black ink is above the swelling. Skin on the other leg is medium brown.](https://assets.nhs.uk/nhsuk-cms/images/shutterstock_685424695.width-320.png)

Cellulitis on your legs is usually on your lower legs.

![Image 4: Red, swollen skin around the eye. The white part of the eye has also become red. Shown on white skin.](https://assets.nhs.uk/nhsuk-cms/images/M1300507-Young_boy_with_inflamed_eye_due_to_ce.width-320.png)

Cellulitis in your eye is very serious. The white part of your eye may become red, but this does not always happen.

Treatment for cellulitis
------------------------

For mild cellulitis affecting a small area of skin, a doctor will prescribe antibiotic tablets, usually for a week.

Your symptoms might get worse in the first 48 hours of treatment, but should then start to improve.

Contact your GP if you do not start to feel better 2 to 3 days after starting antibiotics.

It's important to keep taking antibiotics until they're finished, even when you feel better.

Most people make a full recovery after 7 to 10 days.

If cellulitis is severe, you might be referred to hospital for treatment.

### To stop cellulitis coming back

Some people with recurring cellulitis might be prescribed low-dose long-term antibiotics to stop infections coming back.

Things you can do to help with cellulitis
-----------------------------------------

As well as taking antibiotics for cellulitis, you can help speed up your recovery by:

*   taking [paracetamol](https://www.nhs.uk/medicines/paracetamol-for-adults/) or [ibuprofen](https://www.nhs.uk/medicines/ibuprofen-for-adults/) for the pain
*   raising the affected body part on a pillow or chair when you're sitting or lying down, to reduce swelling
*   regularly moving the joint near the affected body part, such as your wrist or ankle, to stop it getting stiff
*   drinking plenty of fluids to avoid dehydration
*   not wearing compression stockings until you're better

You can reduce the chances of getting cellulitis again by:

*   keeping skin clean and well moisturised
*   cleaning any cuts or wounds and using antiseptic cream
*   preventing cuts and scrapes by wearing appropriate clothing and footwear
*   wearing gloves if working outside

Complications of cellulitis
---------------------------

If cellulitis is not treated quickly, the infection can spread to other parts of the body, such as the blood, muscles and bones.

Immediate action required: Call 999 or go to A&E if:
----------------------------------------------------

You have cellulitis with:

*   a very high temperature, or you feel hot and shivery
*   a fast heartbeat or fast breathing
*   purple patches on your skin, but this may be less obvious on brown or black skin
*   feeling dizzy or faint
*   confusion or disorientation
*   cold, clammy or pale skin
*   unresponsiveness or loss of consciousness

These are symptoms of serious complications, which can be life threatening.

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Information:

Do not drive to A&E. Ask someone to drive you or call 999 and ask for an ambulance.

Bring any medicines you take with you.

How you get cellulitis
----------------------

Cellulitis is usually caused by a bacterial infection.

The bacteria can infect the deeper layers of your skin if it's broken, for example, because of an insect bite or cut, or if it's cracked and dry.

Sometimes the break in the skin is too small to notice.

You cannot catch cellulitis from another person, as it affects the deeper layers of the skin.

You're more at risk of cellulitis if you:

*   have poor circulation in your arms, legs, hands or feet, for example, because you're overweight
*   find it difficult to move around
*   have a weakened immune system, for example, because of chemotherapy treatment or diabetes
*   have [lymphoedema](https://www.nhs.uk/conditions/lymphoedema/), which causes fluid build-up under the skin
*   inject drugs
*   have a wound from surgery
*   have had cellulitis before

People who are more at risk of cellulitis should treat [athlete's foot](https://www.nhs.uk/conditions/athletes-foot/) promptly.

Information:

Social care and support guide
-----------------------------

Our [guide to care and support](https://www.nhs.uk/conditions/social-care-and-support-guide/) explains your options and where you can get support if you:

*   need help with day-to-day living because of illness or disability
*   care for someone regularly because they're ill or disabled or because of their age, including family members

Page last reviewed: 18 April 2024  
Next review due: 18 April 2027
