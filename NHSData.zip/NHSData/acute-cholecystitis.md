Title: Acute cholecystitis

URL Source: https://www.nhs.uk/conditions/acute-cholecystitis/

Published Time: 17 Oct 2017, 4:30 p.m.

Markdown Content:
**Acute cholecystitis is inflammation of the gallbladder. It usually happens when a gallstone blocks the cystic duct.**

[Gallstones](https://www.nhs.uk/conditions/gallstones/) are small stones, usually made of cholesterol, that form in the gallbladder. The cystic duct is the main opening of the gallbladder.

Gallstones are very common, affecting more than 1 in 10 adults in the UK.

They do not usually cause symptoms, but can occasionally cause episodes of pain (biliary colic) or acute cholecystitis.

Acute cholecystitis is potentially serious because of the risk of complications.

It usually needs to be treated in hospital with rest, intravenous fluids and [antibiotics](https://www.nhs.uk/conditions/antibiotics/).

Symptoms of acute cholecystitis
-------------------------------

The main symptom of acute cholecystitis is a sudden, sharp pain in the upper right-hand side of your tummy (abdomen). This pain spreads towards your right shoulder.

The affected part of the tummy is usually very tender, and breathing deeply can make the pain worse.

Unlike other types of [abdominal pain](https://www.nhs.uk/conditions/stomach-ache/), the pain of acute cholecystitis is usually persistent and does not go away within a few hours.

Some people may have additional symptoms, such as:

*   a high temperature
*   feeling sick
*   being sick
*   sweating
*   loss of appetite
*   yellowing of the skin and the whites of the eyes [(jaundice)](https://www.nhs.uk/conditions/jaundice/)
*   a bulge in the tummy

When to get medical advice
--------------------------

See a GP as soon as possible if you develop sudden and severe abdominal pain, particularly if it lasts longer than a few hours or is accompanied by other symptoms, such as jaundice and a high temperature.

If you're unable to contact a GP immediately, phone your local [out-of-hours service](https://www.nhs.uk/using-the-nhs/nhs-services/urgent-and-emergency-care/nhs-out-of-hours-services/) or call [NHS 111](https://www.nhs.uk/using-the-nhs/nhs-services/urgent-and-emergency-care/nhs-111/) for advice.

It's important for acute cholecystitis to be diagnosed as soon as possible, as there's a risk of serious complications developing if it's not treated promptly.

What causes acute cholecystitis?
--------------------------------

The causes of acute cholecystitis can be grouped into 2 main categories: calculous cholecystitis and acalculous cholecystitis.

### Calculous cholecystitis

Calculous cholecystitis is the most common, and usually less serious, type of acute cholecystitis. It accounts for around 95% of all cases.

Calculous cholecystitis develops when the main opening to the gallbladder, the cystic duct, gets blocked by a [gallstone](https://www.nhs.uk/conditions/gallstones/) or a substance known as biliary sludge.

Biliary sludge is a mixture of bile, a liquid produced by the liver that helps digest fats, and small cholesterol and salt crystals.

The blockage in the cystic duct causes bile to build up in the gallbladder, increasing the pressure inside it and causing it to become inflamed. An inflamed gallbladder can sometimes become infected by bacteria.

### Acalculous cholecystitis

Acalculous cholecystitis is gallbladder inflammation without gallstones. It's less common, but usually more serious, than calculous cholecystitis.

The exact cause of acalculous cholecystitis is not known, but it's usually a complication of a serious illness, infection or injury that damages the gallbladder.

A combination of risk factors may lead to acalculous cholecystitis, including accidental damage to the gallbladder during major surgery, serious injuries or [burns](https://www.nhs.uk/conditions/burns-and-scalds/), [sepsis](https://www.nhs.uk/conditions/sepsis/), severe [malnutrition](https://www.nhs.uk/conditions/malnutrition/) or [dehydration](https://www.nhs.uk/conditions/dehydration/).

Diagnosing acute cholecystitis
------------------------------

If you have severe tummy pain, a GP will probably carry out a simple test called Murphy's sign.

You'll be asked to breathe in deeply with the GP's hand pressed on your tummy, just below your rib cage.

Your gallbladder will move downwards as you breathe in. If you have cholecystitis, you'll experience sudden pain as your gallbladder reaches your doctor's hand.

If your symptoms suggest you have acute cholecystitis, your GP will refer you to hospital immediately for further tests and treatment.

Tests you may have in hospital include:

*   [blood tests](https://www.nhs.uk/conditions/blood-tests/) – to check for signs of inflammation in your body
*   an [ultrasound scan](https://www.nhs.uk/conditions/ultrasound-scan/) of your tummy – to check for gallstones or other signs of a problem with your gallbladder

Treating acute cholecystitis
----------------------------

If you're diagnosed with acute cholecystitis, you'll probably need to be admitted to hospital for treatment.

### Initial treatment

Initial treatment will usually involve:

*   not eating or drinking (fasting) to take the strain off your gallbladder
*   receiving fluids through a drip directly into a vein (intravenously) to prevent [dehydration](https://www.nhs.uk/conditions/dehydration/)
*   taking medicine to relieve your pain

You'll also be given [antibiotics](https://www.nhs.uk/conditions/antibiotics/) if it's thought you have an infection.

These often need to be continued for up to a week, during which time you may need to stay in hospital, or you may be able to go home.

### Surgery

Removing your gallbladder may be recommended at some point after initial treatment to prevent acute cholecystitis coming back and reduce your risk of developing potentially serious complications.

This type of surgery is known as a [cholecystectomy](https://www.nhs.uk/conditions/gallbladder-removal/).

There are 2 main types of cholecystectomy:

*   [open cholecystectomy](https://www.nhs.uk/conditions/gallbladder-removal/what-happens/#open) – where the gallbladder is removed through a single cut in the tummy
*   [laparoscopic cholecystectomy](https://www.nhs.uk/conditions/gallbladder-removal/what-happens/#keyhole) – keyhole surgery where the gallbladder is removed using special surgical instruments inserted through a number of small cuts in your abdomen

If you're fit enough to have surgery, your doctors will decide when the best time to remove your gallbladder is.

A laparoscopic cholecystectomy is often recommended within 1 week of confirming acute cholecystitis.

Some people who have had their gallbladder removed have symptoms of bloating and [diarrhoea](https://www.nhs.uk/conditions/diarrhoea/) after eating certain foods, but it's possible to lead a perfectly normal life without a gallbladder.

The organ can be useful, but it's not essential as your liver will still produce bile to digest food.

[Find out more about recovering from gallbladder removal](https://www.nhs.uk/conditions/gallbladder-removal/recovery/)

### Alternatives to surgery

Sometimes surgery may not be an option – for example, if you have another condition that makes surgery unsuitable.

If surgery is not an option, you may be offered a procedure to drain away the fluid that has collected in your gallbladder.

A narrow tube is inserted into the gallbladder to make an opening for the fluid to drain. This can be done through a cut made in the skin of your tummy, or using an endoscopic procedure (through your mouth and into the stomach).

Possible complications
----------------------

Without appropriate treatment, acute cholecystitis can sometimes lead to potentially life-threatening complications.

The main complications of acute cholecystitis are:

*   the death of gallbladder tissue (gangrenous cholecystitis) – which can cause a serious infection that could spread throughout the body
*   the gallbladder splitting open (perforated gallbladder) – which can spread the infection within your tummy [(peritonitis)](https://www.nhs.uk/conditions/peritonitis/) or lead to a build-up of pus (abscess)

Emergency surgery to remove the gallbladder is needed to treat these complications in about 2 or 3 in every 10 cases of acute cholecystitis.

Preventing acute cholecystitis
------------------------------

It's not always possible to prevent acute cholecystitis, but you can lower your risk of developing it by reducing your risk of getting gallstones.

One of the main things you can do to lower your chances of getting gallstones is to adopt a [healthy, balanced diet](https://www.nhs.uk/live-well/eat-well/how-to-eat-a-balanced-diet/eating-a-balanced-diet/) and reduce the number of high-cholesterol foods you eat, as cholesterol is thought to contribute to the formation of gallstones.

Living with overweight or [obesity](https://www.nhs.uk/conditions/obesity/) also increases your risk of developing gallstones.

You should therefore control your weight by eating a healthy diet and [exercising regularly](https://www.nhs.uk/live-well/exercise/exercise-health-benefits/).

But low-calorie rapid weight loss diets should be avoided because there's evidence they can disrupt your bile chemistry and actually increase your risk of developing gallstones.

A more [gradual weight loss plan](https://www.nhs.uk/better-health/lose-weight/) is best.

[Find out more about preventing gallstones](https://www.nhs.uk/conditions/gallstones/prevention/)

### The gallbladder

The gallbladder is a small pear-shaped organ located beneath the liver. Its main purpose is to store and concentrate bile.

The liver produces bile, a liquid that helps digest fats and carries toxins excreted by the liver.

Bile is passed from the liver through a series of channels called bile ducts into the gallbladder, where it's stored.

The gallbladder releases bile into the digestive system when it's needed. It's an organ that's useful, but not essential, and it can be safely removed without interfering with your ability to digest food.

Page last reviewed: 21 February 2023  
Next review due: 21 February 2026
