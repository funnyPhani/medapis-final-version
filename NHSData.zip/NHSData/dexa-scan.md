Title: Bone density scan (DEXA scan)

URL Source: https://www.nhs.uk/conditions/dexa-scan/

Published Time: 19 Oct 2017, 4:18 p.m.

Markdown Content:
**A bone density scan uses low dose X-rays to see how dense (or strong) your bones are. You may also hear it called a DEXA scan.**

Bone density scans are often used to diagnose or assess your risk of [osteoporosis](https://www.nhs.uk/conditions/osteoporosis/), a health condition that weakens bones and makes them more likely to break.

As well as being quick and painless, a bone density scan is more effective than normal X-rays in identifying low bone density.

Who needs to have a bone density scan
-------------------------------------

You may need to have a bone density scan if you're:

*   over 50 with a risk of developing osteoporosis
*   under 50 with other risk factors, such as smoking or a previous broken bone

The results from a bone density scan are usually used alongside a fracture risk assessment to assess your chances of osteoporosis and breaking a bone.

Osteoporosis can affect anyone at any age, although older postmenopausal women are particularly at risk.

This is because the level of oestrogen declines after the [menopause](https://www.nhs.uk/conditions/menopause/), resulting in a decrease in bone density.

The more dense your bones, the stronger and less likely they are to break (fracture). Osteoporosis does not cause any symptoms until a bone is broken.

[Find out when bone density scans are used](https://www.nhs.uk/conditions/dexa-scan/why-its-done/)

Measuring bone density
----------------------

During a bone density scan, a type of X-ray called dual energy X-ray absorptiometry is passed through your body. This is shortened to DEXA.

Some radiation is absorbed by the bone and soft tissue, and some travels through your body.

Special detectors in the DEXA machine measure how much radiation passes through your bones, and this information is sent to a computer.

Your bone density measurements will be compared with the bone density of a young healthy adult or an adult of your own age, gender and ethnicity.

[Find out more about how bone density scans are performed](https://www.nhs.uk/conditions/dexa-scan/what-happens/)

How safe are bone density (DEXA) scans
--------------------------------------

Bone density scans are very safe. They use a much lower level of radiation than standard X-rays, which means that the radiographer (the technical specialist carrying out the scan) can stay in the scanning room with you during the scan.

Despite being very safe, bone density scans and X-rays are not recommended for pregnant women, as X-rays can damage an unborn child.

[Find out about pregnancy care and the scans and tests you can have](https://www.nhs.uk/pregnancy/your-pregnancy-care/)

Page last reviewed: 05 October 2022  
Next review due: 05 October 2025
