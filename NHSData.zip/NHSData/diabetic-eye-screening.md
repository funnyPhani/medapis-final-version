Title: Diabetic eye screening

URL Source: https://www.nhs.uk/conditions/diabetic-eye-screening/

Published Time: 18 Oct 2017, 10:19 a.m.

Markdown Content:
Why diabetic screening is done
------------------------------

If you have diabetes you may be at risk of developing eye problems called [diabetic retinopathy](https://www.nhs.uk/conditions/diabetic-retinopathy/). Diabetic retinopathy can cause sight loss if it's not treated.

Diabetic eye screening checks your eyes for problems, often before you notice any changes in your sight. Finding and treating diabetic retinopathy early can reduce and prevent damage to your eyes and sight loss.

Who diabetic eye screening is for
---------------------------------

If you have diabetes and you're aged 12 or over, you'll get a letter every 1 or 2 years asking you to have diabetic eye screening.

See what to do if you do not get a letter

If you think you're due to go for a screening test and have not had a letter, tell either:

*   your GP practice
*   your local eye screening service – check any old letters you have or [search for your eye screening service](https://www.nhs.uk/service-search/other-services/NHS-Screening/LocationSearch/1912) to find contact details

How to get diabetic eye screening
---------------------------------

The letter inviting you for diabetic eye screening will tell you how to book the test.

You may be offered a choice of when and where you can get it.

You’ll usually be invited for diabetic eye screening every year, or every 2 years if your last 2 tests were clear.

Preparing for diabetic eye screening
------------------------------------

You will not be able to drive after diabetic eye screening, as your eyesight may be blurry for a few hours. It’s important to plan your route to and from the test.

You may want to ask someone to come to your appointment with you, or ask them to collect you after. You may also want to bring sunglasses as everything may look bright for a few hours after the test.

What happens during diabetic eye screening
------------------------------------------

Your diabetic eye screening appointment will last around 30 minutes.

1.  You'll be asked to read some letters on a chart.
2.  You'll have eye drops put in your eyes to make your pupils larger. These may sting for a few seconds and will make your sight blurry.
3.  When the drops start working, you'll be asked to look into a camera.
4.  Photographs will be taken of the back of your eyes. There will be a bright flash when a picture is taken.

You can go home when the test is finished. You will not get your test result on the day.

The photographs of your eye will be sent to an expert to be reviewed.

Video: diabetic eye screening
-----------------------------

This video shows what happens when you go for diabetic eye screening and why you need regular eye checks.

Media last reviewed: 1 November 2021  
Media review due: 1 November 2024

Possible complications of eye drops
-----------------------------------

Diabetic eye screening is a common and safe test.

Rarely, the eye drops can cause an increase to the pressure in your eye. This is called acute glaucoma and needs to be treated straight away.

Urgent advice: Go back to the screening centre or go to A&E if:
---------------------------------------------------------------

You’ve had diabetic eye screening and:

*   your eyes become painful
*   you have redness in the white part of your eyes
*   your sight is still blurry after 6 hours

[Find your nearest A&E](https://www.nhs.uk/service-search/find-an-accident-and-emergency-service/)

Results of diabetic eye screening
---------------------------------

You'll usually get a letter telling you the results of your diabetic eye screening within 6 weeks of the test.

You result letter should tell you what your result means, and what happens next. Sometimes the pictures of your eyes may not be clear enough to give a result. If this happens, you'll be asked to have another test.

There are 3 types of diabetic eye screening result.

Types of diabetic eye screening result and what they mean
| Result | What it means |
| --- | --- |
| No eye changes (no retinopathy)
 | No changes were found in your eyes.

You'll be asked to have your screening test in 1 to 2 years.

 |
| Some changes to your eyes (background retinopathy)

 | Diabetes has caused some small changes to your eyes, but your sight is not currently affected.

You'll be asked to have another screening test in 1 year.

 |
| Eye damage that could affect your sight (referable retinopathy)

 | Diabetes has damaged your eyes and your sight could be affected.

You'll be referred to a specialist to talk about what happens next. You may need more tests or [treatment for diabetic retinopathy](https://www.nhs.uk/conditions/diabetic-retinopathy/treatment/).

 |

Information:

Talk to your GP surgery if you do not get your diabetic eye screening result letter within 6 weeks.

More information
----------------

*   [GOV.UK has more information about diabetic eye screening, including an easy read guide and guides in other languages](https://www.gov.uk/government/publications/diabetic-eye-screening-description-in-brief)
*   [DiABETES UK: Diabetic eye screening](https://www.diabetes.org.uk/guide-to-diabetes/managing-your-diabetes/diabetic-eye-screening)
*   [Diabetic retinopathy](https://www.nhs.uk/conditions/diabetic-retinopathy/)

Help us improve our website
---------------------------

Can you answer a few questions about your visit today?

[Take our survey](https://feedback.digital.nhs.uk/jfe/form/SV_8uJlAqDfu8ANPN4)

Page last reviewed: 07 September 2022  
Next review due: 07 September 2025
